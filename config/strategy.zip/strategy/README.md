# backtest-go

本项目是一个用于本地研究和回测加密交易策略的工作区，当前保留两套可运行的 LeadLag 策略形态：

- **原版基线策略**
  - 路径：`invariant-strategy/`
  - 用途：作为基线实现与基线回测结果的参考
- **修复版策略**
  - 路径：`.wt-invariant-strategy-leadlag-must-fix/`
  - 用途：包含 `drift` warm-up 修复、`trailing_stop` 拆参、统一成本模型和对称测试补强

同时保留回测框架和底层依赖仓库：

- `pinnaquant/`：回测引擎与策略模板
- `xexchange/`：撮合、回放与市场数据基础设施
- `xex_mm_go/`：交易所符号、请求结构和部分共用工具

---

## 当前目录结构

```text
backtest-go/
├── AGENTS.md
├── README.md
├── LEADLAG_BACKTEST_GUIDE.md
├── LEADLAG_QUICK_START.md
├── invariant-strategy/
├── .wt-invariant-strategy-leadlag-must-fix/
├── pinnaquant/
├── xexchange/
├── xex_mm_go/
├── temp/
│   ├── leadlag-default-explicit/
│   └── backtest-compare-2026022600-2026022610/
└── docs/
```

说明：

- `invariant-strategy/`
  - 原版基线策略仓库
- `.wt-invariant-strategy-leadlag-must-fix/`
  - 修复版策略 worktree
- `temp/leadlag-default-explicit/`
  - 当前推荐的显式默认回测配置
- `temp/backtest-compare-2026022600-2026022610/`
  - 修复版 vs 原版基线的对比配置和回测日志
- `LEADLAG_BACKTEST_GUIDE.md`
  - 较详细的中文说明
- `LEADLAG_QUICK_START.md`
  - 快速上手说明

---

## 保留内容

当前项目只保留以下与“可运行”和“可比较”直接相关的内容：

- 原版基线策略代码
- 修复版策略代码
- 回测框架与底层依赖仓库
- 当前有效的策略文档
- 根目录工作流文件：`task_plan.md`、`findings.md`、`progress.md`
- 显式默认回测配置
- 与基线对比所需的回测配置和结果

已移出项目目录、放到 `/tmp/backtest-go-cleanup-20260416/` 的内容包括：

- Go 临时缓存
- 历史临时配置
- 旧运行日志
- 代理工作流文件与过程性计划文档

---

## 文档分工

- `README.md`
  - 工作区总览、目录结构、推荐入口
- `LEADLAG_BACKTEST_GUIDE.md`
  - 详细运行说明、参数解释、结果分析
- `LEADLAG_QUICK_START.md`
  - 最短运行路径和参数速查
- `docs/`
  - 当前有效的策略分析、收益质量与差异文档
- `docs/old/`
  - 已归档的旧版报告与旧版说明文档

---

## 当前项目阶段

当前项目处于 **LeadLag 修复版结果固化与回灌前整理阶段**。

更具体地说，当前已经完成：

- 基线策略与修复版策略的并行保留和隔离
- `drift` warm-up 修复
- `trailing_stop` 拆参与 `max_entry_spread` 显式化
- entry cost model 统一
- short 侧对称测试补强
- 严格对齐语义实现
- `0` 交易根因定位与最小修复
- 短窗口与长窗口 fresh-run 复验
- 新版收益、成交质量与策略差异报告生成

当前已经确认：

- 根因是 `leadlag/algo/analysis.go` 中 `StreamRecorder.Init()` 未清理 `sqTotal`
- 修复后：
  - 短窗口 fixed `History<Total = 26)`
  - 长窗口 fixed `History<Total = 99)`
- 当前 fixed 与 baseline 的差异，已经从“能否交易”转为“交易风格与收益结构差异”

当前下一阶段主要是二选一：

- 继续做更深层收益归因分析
- 准备将最小修复回灌主仓库

---

## 推荐配置入口

### 1. 修复版默认显式配置

路径：

- `temp/leadlag-default-explicit/strategy.json`
- `temp/leadlag-default-explicit/backtest.json`

特点：

- 显式包含 `execute.max_entry_spread`
- 显式包含 `trigger.target_profit_rate`
- 使用当前生效的 `trailing_stop` / `drift_limit` / `drift_period`

### 2. 基线对比配置

路径：

- `temp/backtest-compare-2026022600-2026022610/strategy-fixed.json`
- `temp/backtest-compare-2026022600-2026022610/strategy-baseline.json`
- `temp/backtest-compare-2026022600-2026022610/backtest-fixed.json`
- `temp/backtest-compare-2026022600-2026022610/backtest-baseline.json`

用途：

- 对比修复版与原版基线在相同数据窗口下的行为差异

---

## 运行方式

### 运行修复版策略

```bash
cd "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/.wt-invariant-strategy-leadlag-must-fix"
GODEBUG=cgocheck=0 \
go run leadlag/backtest/main.go \
  -s "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/leadlag-default-explicit/strategy.json" \
  -b "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/leadlag-default-explicit/backtest.json"
```

### 运行原版基线策略

```bash
cd "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/invariant-strategy"
GODEBUG=cgocheck=0 \
go run leadlag/backtest/main.go \
  -s "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022610/strategy-baseline.json" \
  -b "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022610/backtest-baseline.json"
```

---

## 当前结论

- 基线策略仍是唯一有效参考基线
- 修复版 `0` 交易异常已经完成根因定位与修复
- 修复后的 fixed 已恢复短窗口与长窗口交易能力
- 当前更有价值的问题不再是“为什么不交易”，而是：
  - fixed 与 baseline 的收益结构差异来自哪里
  - 是否准备回灌最小修复
- 如需回灌到主仓库，应只合并策略代码、测试和 repo 内文档，不要整体回灌 worktree
