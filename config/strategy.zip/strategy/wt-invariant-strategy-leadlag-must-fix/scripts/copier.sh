#!/bin/bash

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Default source (override with $REMOTE_DATA_DIR)
LOCAL_SOURCE="${REMOTE_DATA_DIR:-/Volumes/hf_data/raw_data_hourly}"

# Output base directory (override with $DATA_DIR, or prompt)
OUTPUT_BASE="${DATA_DIR:-$PWD}"

# If DATA_DIR is not provided, give user a chance to input it.
if [ -z "$DATA_DIR" ]; then
    echo -e "${YELLOW}Enter output base directory (default: ${GREEN}$PWD${YELLOW}):${NC}"
    read -r output_input
    if [ -n "$output_input" ]; then
        # Expand a leading ~
        if [[ "$output_input" == ~* ]]; then
            output_input="${output_input/#\~/$HOME}"
        fi
        OUTPUT_BASE="$output_input"
    fi
fi

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  HF Data Copy Script${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "${YELLOW}Source path: ${GREEN}${LOCAL_SOURCE}${NC}"
echo -e "${YELLOW}Output base: ${GREEN}${OUTPUT_BASE}${NC}"
echo ""

# Confirm output directory
echo -e "${YELLOW}This will create <hour>/ folders under the output base and copy files into them.${NC}"
echo -e "${YELLOW}Continue with output base: ${GREEN}${OUTPUT_BASE}${YELLOW}? Type 'y' to continue:${NC}"
read -r confirm_output
if [[ ! "$confirm_output" =~ ^([yY]|[yY][eE][sS])$ ]]; then
    echo -e "${RED}Aborted.${NC}"
    exit 1
fi

# Ensure output base exists
if [ ! -d "$OUTPUT_BASE" ]; then
    echo -e "${GREEN}Creating output base directory: ${OUTPUT_BASE}${NC}"
    mkdir -p "$OUTPUT_BASE" || exit 1
fi

# Get date range from argument or prompt
if [ -n "$1" ]; then
    date_input="$1"
else
    # Prompt for date range
    echo -e "${YELLOW}Enter date or date range (format: YYYYMMDDHH or YYYYMMDDHH,YYYYMMDDHH):${NC}"
    read -r date_input
    
    if [ -z "$date_input" ]; then
        echo -e "${RED}Error: Date cannot be empty${NC}"
        exit 1
    fi
fi

# Parse date range (split by comma if present)
if [[ "$date_input" == *","* ]]; then
    start_date="${date_input%,*}"
    end_date="${date_input#*,}"
    echo -e "${GREEN}Date range: ${start_date} to ${end_date}${NC}"
else
    start_date="$date_input"
    end_date="$date_input"
    echo -e "${GREEN}Date: ${start_date}${NC}"
fi

# Validate start date format (10 digits)
if ! [[ "$start_date" =~ ^[0-9]{10}$ ]]; then
    echo -e "${RED}Error: Invalid start date format. Expected YYYYMMDDHH (10 digits)${NC}"
    exit 1
fi

# Validate end date format (10 digits)
if ! [[ "$end_date" =~ ^[0-9]{10}$ ]]; then
    echo -e "${RED}Error: Invalid end date format. Expected YYYYMMDDHH (10 digits)${NC}"
    exit 1
fi

# Check date order
if [ "$end_date" -lt "$start_date" ]; then
    echo -e "${RED}Error: End date must be >= start date${NC}"
    exit 1
fi

# Get symbol patterns from argument or prompt
if [ -n "$2" ]; then
    symbol_input="$2"
    echo -e "${GREEN}Symbol pattern(s): ${symbol_input}${NC}"
else
    # Prompt for symbol pattern
    echo -e "${YELLOW}Enter symbol pattern(s) (e.g., bybit.eth_usdt* or bybit.*,binance.*,gateio.*):${NC}"
    read -r symbol_input
    
    if [ -z "$symbol_input" ]; then
        echo -e "${RED}Error: Symbol pattern cannot be empty${NC}"
        exit 1
    fi
fi

# Parse symbol patterns into array
IFS=',' read -ra symbol_patterns <<< "$symbol_input"

# Initialize counters
total_hours=0
success_count=0
fail_count=0

# Loop through date range
current_date="$start_date"
while [ "$current_date" -le "$end_date" ]; do
    total_hours=$((total_hours + 1))
    
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}Processing: ${current_date}${NC}"
    echo -e "${BLUE}========================================${NC}"
    
    # Check if source directory exists
    SOURCE_DIR="${LOCAL_SOURCE}/${current_date}"
    if [ ! -d "$SOURCE_DIR" ]; then
        echo -e "${YELLOW}Warning: Source directory does not exist: ${SOURCE_DIR}${NC}"
        echo -e "${YELLOW}Skipping...${NC}"
        fail_count=$((fail_count + 1))
        
        # Increment to next hour
        if [[ "$OSTYPE" == "darwin"* ]]; then
            current_date=$(date -j -v+1H -f "%Y%m%d%H" "$current_date" "+%Y%m%d%H")
        else
            _ts=$(date -d "${current_date:0:4}-${current_date:4:2}-${current_date:6:2} ${current_date:8:2}:00:00" +%s)
            current_date=$(date -d "@$((_ts + 3600))" "+%Y%m%d%H")
        fi
        if [ $? -ne 0 ]; then
            echo -e "${RED}Error: Failed to increment date${NC}"
            exit 1
        fi
        continue
    fi
    
    # Create local directory if it doesn't exist
    LOCAL_DIR="${OUTPUT_BASE}/${current_date}"
    if [ ! -d "$LOCAL_DIR" ]; then
        echo -e "${GREEN}Creating directory: ${LOCAL_DIR}${NC}"
        mkdir -p "$LOCAL_DIR"
    fi
    
    # Track if any pattern succeeded for this hour
    hour_success=false
    
    # Loop through each symbol pattern
    for pattern in "${symbol_patterns[@]}"; do
        # Trim whitespace
        pattern=$(echo "$pattern" | xargs)
        
        # Construct the cp command
        SOURCE_PATH="${SOURCE_DIR}/${pattern}"
        LOCAL_PATH="${LOCAL_DIR}/"
        
        echo -e "${BLUE}Pattern: ${pattern}${NC}"
        
        # Execute cp
        cp -v ${SOURCE_PATH} "${LOCAL_PATH}" 2>/dev/null
        
        if [ $? -eq 0 ]; then
            hour_success=true
        fi
    done
    
    if [ "$hour_success" = true ]; then
        echo -e "${GREEN}✓ Copy completed for ${current_date}${NC}"
        success_count=$((success_count + 1))
    else
        echo -e "${RED}✗ No files copied for ${current_date}${NC}"
        fail_count=$((fail_count + 1))
    fi
    
    # Increment to next hour
    if [[ "$OSTYPE" == "darwin"* ]]; then
        current_date=$(date -j -v+1H -f "%Y%m%d%H" "$current_date" "+%Y%m%d%H")
    else
        _ts=$(date -d "${current_date:0:4}-${current_date:4:2}-${current_date:6:2} ${current_date:8:2}:00:00" +%s)
            current_date=$(date -d "@$((_ts + 3600))" "+%Y%m%d%H")
    fi
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error: Failed to increment date${NC}"
        exit 1
    fi
done

# Print summary
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Summary${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}Total hours processed: ${total_hours}${NC}"
echo -e "${GREEN}Successful: ${success_count}${NC}"
echo -e "${RED}Failed: ${fail_count}${NC}"
echo ""
