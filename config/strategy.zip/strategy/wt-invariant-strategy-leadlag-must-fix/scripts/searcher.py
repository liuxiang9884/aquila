#!/usr/bin/env python3
"""
Search for pair files in a directory.

This script searches for matching data files across different exchanges within a date range.
A valid pair means files from different exchanges that have the same symbol and date.

Usage:
    python searcher.py --dates 2026010100,2026010200 --exchanges binance,bybit
    python searcher.py -d 2026010800 -e binance,okex
"""

import argparse
import json
import os
import re
import shutil
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Pattern


def parse_date_range(date_str: str) -> List[str]:
    """
    Parse date range string and return list of date-hour strings.
    
    Parameters:
    - date_str: Single date or date range like "2026010100" or "2026010100,2026010200"
    
    Returns:
    - List of date-hour strings in YYYYMMDDHH format
    """
    parts = date_str.split(',')
    
    if len(parts) == 1:
        # Single date
        return [parts[0]]
    elif len(parts) == 2:
        # Date range
        start = datetime.strptime(parts[0], '%Y%m%d%H')
        end = datetime.strptime(parts[1], '%Y%m%d%H')
        
        dates = []
        current = start
        while current <= end:
            dates.append(current.strftime('%Y%m%d%H'))
            current += timedelta(hours=1)
        return dates
    else:
        raise ValueError(f"Invalid date format: {date_str}")


def _copy_file(src: str, dst: str) -> None:
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    try:
        # copy2 preserves metadata (mtime/mode/xattrs where possible) but can fail on some mounts.
        shutil.copy2(src, dst)
        return
    except OSError as e:
        # EPERM (1) commonly happens when the destination filesystem disallows metadata/xattr operations.
        # Fall back to copying file contents and best-effort mode.
        if getattr(e, "errno", None) not in (1,):
            raise

    shutil.copyfile(src, dst)
    try:
        shutil.copymode(src, dst)
    except OSError:
        pass


def _rewrite_and_copy_paths(file_paths: List[str], root: str, copy_root: str) -> List[str]:
    """Copy files under root into copy_root, preserving relative structure.

    Expected src path: <root>/<datehour>/<filename>
    Dest path: <copy_root>/<datehour>/<filename>
    """
    out: List[str] = []
    root_abs = os.path.abspath(root)
    copy_abs = os.path.abspath(copy_root)

    for src in file_paths:
        src_abs = os.path.abspath(src)

        try:
            in_root = os.path.commonpath([root_abs, src_abs]) == root_abs
        except Exception:
            in_root = False

        if not in_root:
            print(
                f"Warning: file is outside root; skip copying and use original path: src={src_abs} root={root_abs}",
                file=sys.stderr,
            )
            out.append(src_abs)
            continue

        rel = os.path.relpath(src_abs, root_abs)
        dst_abs = os.path.join(copy_abs, rel)

        # If destination already exists, skip copying.
        if src_abs != dst_abs and os.path.exists(dst_abs):
            print(f"Skip (exists): {dst_abs}")
            out.append(dst_abs)
            continue

        if src_abs != dst_abs:
            try:
                _copy_file(src_abs, dst_abs)
                print(f"Copied: {src_abs} -> {dst_abs}")
                out.append(dst_abs)
                continue
            except Exception as e:
                print(
                    f"Warning: copy failed, using original path instead: src={src_abs} dst={dst_abs} err={e}",
                    file=sys.stderr,
                )
                print(f"Copy failed (fallback): {src_abs} -> {dst_abs}")
                out.append(src_abs)
                continue

        out.append(dst_abs)
    return out


def find_pairs(
    root: str,
    dates: List[str],
    exchanges: List[str],
    filename_regex: Optional[Pattern[str]] = None,
) -> Dict[str, List[Dict]]:
    """
    Find matching file pairs across exchanges.
    
    Parameters:
    - root: Root directory path
    - dates: List of date-hour strings
    - exchanges: List of exchange names
    
        Returns:
        - Dictionary mapping date to list of match records:
            {
                'symbol': str,
                'exchanges': [exchange1, exchange2],
                'files': [file1, file2]
            }
    """
    results = defaultdict(list)
    
    for date in dates:
        date_dir = os.path.join(root, date)
        if not os.path.isdir(date_dir):
            print(f"Warning: Directory not found: {date_dir}")
            continue
        
        # Group files by suffix (symbol_date.h5)
        suffix_groups = defaultdict(list)
        
        for exchange in exchanges:
            # Find all files for this exchange
            pattern = f"{exchange}."
            for filename in os.listdir(date_dir):
                if not (filename.startswith(pattern) and filename.endswith('.h5')):
                    continue

                if filename_regex is not None and filename_regex.search(filename) is None:
                    continue

                # Extract suffix: everything after exchange prefix
                # e.g., "binance.beat_usdt_swap_2026010801.h5" -> "beat_usdt_swap_2026010801.h5"
                suffix = filename[len(exchange) + 1:]  # +1 for the dot
                suffix_groups[suffix].append((exchange, os.path.join(date_dir, filename)))
    
        # Find pairs: suffixes that have files from multiple exchanges
        for suffix, files in suffix_groups.items():
            if len(files) >= 2:
                # Extract clean symbol name by removing date and .h5 extension
                # e.g., "beat_usdt_swap_2026010801.h5" -> "beat_usdt_swap"
                symbol = suffix.replace(f'_{date}.h5', '')
                
                # Generate all pairs
                for i in range(len(files)):
                    for j in range(i + 1, len(files)):
                        exchange1, file1 = files[i]
                        exchange2, file2 = files[j]
                        results[date].append({
                            'symbol': symbol,
                            'exchanges': [exchange1, exchange2],
                            'files': [file1, file2]
                        })
    
    return results


def main():
    parser = argparse.ArgumentParser(
        description='Search for matching data file pairs across exchanges',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Search for single date
  python searcher.py -d 2026010800 -e binance,bybit
  
  # Search for date range
  python searcher.py -d 2026010800,2026010810 -e binance,bybit,okex
  
  # Specify custom root directory
  python searcher.py -d 2026010800 -e binance,bybit -r /path/to/data
        """
    )
    
    parser.add_argument('-d', '--dates', required=True,
                       help='Date or date range in YYYYMMDDHH format (e.g., 2026010800 or 2026010800,2026010810)')
    parser.add_argument('-e', '--exchanges', required=True,
                       help='Comma-separated list of exchanges (e.g., binance,bybit,okex)')
    parser.add_argument('-r', '--root', default=os.getenv('REMOTE_DATA_DIR', '.'),
                       help='Root directory containing date folders (default: $REMOTE_DATA_DIR or current directory)')
    parser.add_argument('-c', '--copy', dest='copy_root', default=None,
                       help='Copy matched files into this directory (mirrors date folders) and rewrite output paths to copied files')
    parser.add_argument('--regex', dest='filename_regex', default=None,
                       help='Optional regex to filter filenames; only matching filenames are included')
    parser.add_argument('-v', '--verbose', action='store_true',
                       help='Show detailed output')
    parser.add_argument('-j', '--json', action='store_true',
                       help='Output results in JSON format')
    parser.add_argument('-o', '--output', help='Output file path (if not specified, prints to stdout)')
    
    args = parser.parse_args()
    
    # Parse inputs
    dates = parse_date_range(args.dates)
    exchanges = [e.strip().lower() for e in args.exchanges.split(',')]

    compiled_regex: Optional[Pattern[str]] = None
    if args.filename_regex:
        try:
            compiled_regex = re.compile(args.filename_regex)
        except re.error as e:
            raise SystemExit(f"Invalid --regex: {e}")
    
    # Find pairs
    pairs = find_pairs(args.root, dates, exchanges, filename_regex=compiled_regex)
    
    # Reorganize results by symbol and exchange pair
    symbol_pairs = defaultdict(lambda: defaultdict(list))
    for date in sorted(pairs.keys()):
        for pair in pairs[date]:
            symbol = pair['symbol']
            exchange_key = tuple(sorted(pair['exchanges']))  # Use sorted tuple as key

            # Keep file ordering aligned with exchange_key
            exchange_to_file = {ex: fp for ex, fp in zip(pair['exchanges'], pair['files'])}
            files_sorted = [exchange_to_file[ex] for ex in exchange_key]

            # Copy + rewrite paths if enabled
            if args.copy_root:
                try:
                    files_sorted = _rewrite_and_copy_paths(files_sorted, root=args.root, copy_root=args.copy_root)
                except Exception as e:
                    print(f"Warning: copy step failed; using original paths. err={e}", file=sys.stderr)
                    # Keep original paths if rewrite/copy step fails unexpectedly.
                    exchange_to_file = {ex: fp for ex, fp in zip(pair['exchanges'], pair['files'])}
                    files_sorted = [exchange_to_file[ex] for ex in exchange_key]

            symbol_pairs[symbol][exchange_key].append({
                'date': date,
                'files': files_sorted
            })
    
    # Output in JSON format
    if args.json:
        output = {
            'search_params': {
                'root': os.path.abspath(args.copy_root) if args.copy_root else args.root,
                'date_range': {
                    'start': dates[0],
                    'end': dates[-1],
                    'total_hours': len(dates)
                },
                'exchanges': exchanges,
                'regex': args.filename_regex,
                'copied_to': os.path.abspath(args.copy_root) if args.copy_root else None,
            },
            'results': {}
        }
        
        for symbol, exchange_groups in sorted(symbol_pairs.items()):
            output['results'][symbol] = []
            for exchange_key, date_list in sorted(exchange_groups.items()):
                date_ranges = [item['date'] for item in date_list]
                output['results'][symbol].append({
                    'exchanges': list(exchange_key),
                    'date_range': {
                        'start': date_ranges[0],
                        'end': date_ranges[-1],
                        'total_hours': len(date_ranges),
                        # 'dates': date_ranges
                    }
                })
        
        output['summary'] = {
            'total_symbols': len(symbol_pairs),
            'total_pairs': sum(len(groups) for groups in symbol_pairs.values())
        }
        
        json_str = json.dumps(output, indent=2)
        
        if args.output:
            with open(args.output, 'w') as f:
                f.write(json_str)
            print(f"Results saved to {args.output}")
        else:
            print(json_str)
    else:
        # Display results in human-readable format
        output_lines = []
        output_lines.append(f"Searching for pairs:")
        if args.copy_root:
            output_lines.append(f"  Root: {args.root} (copied to: {os.path.abspath(args.copy_root)})")
        else:
            output_lines.append(f"  Root: {args.root}")
        output_lines.append(f"  Dates: {dates[0]} to {dates[-1]} ({len(dates)} hours)")
        output_lines.append(f"  Exchanges: {', '.join(exchanges)}")
        if args.filename_regex:
            output_lines.append(f"  Regex: {args.filename_regex}")
        output_lines.append("")
        
        total_pairs = 0
        for symbol, exchange_groups in sorted(symbol_pairs.items()):
            output_lines.append(f"\n{symbol}:")
            for exchange_key, date_list in sorted(exchange_groups.items()):
                total_pairs += 1
                date_ranges = [item['date'] for item in date_list]
                output_lines.append(f"  {' & '.join(exchange_key)}: {len(date_ranges)} hour(s) [{date_ranges[0]} - {date_ranges[-1]}]")
                
                if args.verbose:
                    for item in date_list:
                        output_lines.append(f"    {item['date']}:")
                        for ex, file_path in zip(exchange_key, item['files']):
                            output_lines.append(f"      {ex}: {file_path}")
        
        output_lines.append(f"\n{'='*60}")
        output_lines.append(f"Total unique pairs: {total_pairs}")
        output_lines.append(f"Total symbols: {len(symbol_pairs)}")
        
        if total_pairs == 0:
            output_lines.append("\nNo matching pairs found. Possible reasons:")
            output_lines.append("  - Date directories don't exist")
            output_lines.append("  - No files matching the specified exchanges")
            output_lines.append("  - No common symbols across exchanges")
        
        output_text = '\n'.join(output_lines)
        
        if args.output:
            with open(args.output, 'w') as f:
                f.write(output_text)
            print(f"Results saved to {args.output}")
        else:
            print(output_text)


if __name__ == '__main__':
    main()
