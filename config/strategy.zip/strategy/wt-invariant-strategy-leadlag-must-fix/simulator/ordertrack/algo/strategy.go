package algo

import (
	"math"
	"strconv"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/atom_symbol"
	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

// OrderRecord represents a single realtime order record from the JSON data file.
type OrderRecord struct {
	SendOrderMs   int64  `json:"SendOrderMs"`
	FinOrderMs    int64  `json:"FinOrderMs"`
	ClientOrderId string `json:"ClientOrderId"`
	OperationId   string `json:"OperationId"`
	Symbol        string `json:"Symbol"`
	TradeType     string `json:"TradeType"` // "maker" or "taker"
	Side          int    `json:"Side"`      // -1 = sell, 1 = buy
	RequestPrc    string `json:"RequestPrc"`
	RequestQty    string `json:"RequestQty"`
	FilledPrc     string `json:"FilledPrc"`
	FilledAmount  string `json:"FilledAmount"`
}

// StrategyConfig holds configuration for the ordertrack strategy.
type StrategyConfig struct {
	Mode       string            `json:"mode"`
	Symbols    []string          `json:"symbols"`     // symbols to simulate (used as filter)
	Pairs      map[string]string `json:"pairs"`       // maker symbol -> taker symbol
	OrdersFile string            `json:"orders_file"` // path to order records JSON file
}

// IStrategy is the common interface for all ordertrack strategies.
// It embeds template.IStrategy (required by setting.NewBackTest) and adds
// the extra methods that main.go calls directly on the strategy value.
type IStrategy interface {
	template.IStrategy
	SetSymbols(symbolMap map[string]*atom_symbol.Symbol)
	SetRecorder(rec recorder.IRecorder)
	Brief()
	HandleOrderRecord(timeMs int64, rec *OrderRecord) error
}

// New creates a new Strategy from the config.
func (c *StrategyConfig) New(log *logrus.Entry) IStrategy {
	s := &Strategy{
		config:     *c,
		log:        log,
		recorder:   (*recorder.EmptyRecorder)(nil),
		pendingMap: make(map[string]*OrderRecord),
		depthMap:   make(map[string]*utils.Depth),
	}
	switch c.Mode {
	case "mock":
		return &MockStrategy{s}
	}

	return s
}

// Strategy copies realtime order execution into backtest and logs the final order status.
type Strategy struct {
	template.BaseSingleClientStrategy

	symbolMap  map[string]*atom_symbol.Symbol // symbol name -> atom symbol
	pendingMap map[string]*OrderRecord        // ClientOrderId -> original order record (taker only)
	depthMap   map[string]*utils.Depth        // symbol name -> latest cached depth

	config   StrategyConfig
	log      *logrus.Entry
	recorder recorder.IRecorder
}

// SetSymbols provides the atom symbol map resolved from the backtest widget.
func (s *Strategy) SetSymbols(symbolMap map[string]*atom_symbol.Symbol) {
	s.symbolMap = symbolMap
}

// SetRecorder sets the recorder used to log order status and depth snapshots.
func (s *Strategy) SetRecorder(rec recorder.IRecorder) {
	s.recorder = rec
}

// HandleOrderRecord is the custom data handler invoked at SendOrderMs for each record.
// taker: sends order to exchange and logs current taker depth snapshot.
// maker: logs taker depth snapshot at send time, schedules another log at FinOrderMs via CallSignal.
func (s *Strategy) HandleOrderRecord(timeMs int64, rec *OrderRecord) error {
	switch rec.TradeType {
	case "taker":
		return s.handleTaker(rec)
	case "maker":
		return s.handleMaker(rec)
	default:
		return nil
	}
}

func (s *Strategy) handleTaker(rec *OrderRecord) error {
	sym := s.symbolMap[rec.Symbol]

	price, err := strconv.ParseFloat(rec.RequestPrc, 64)
	if err != nil {
		s.NowEntry().WithError(err).Errorf("failed to parse RequestPrc %q", rec.RequestPrc)
		return nil
	}
	qty, err := strconv.ParseFloat(rec.RequestQty, 64)
	if err != nil {
		s.NowEntry().WithError(err).Errorf("failed to parse RequestQty %q", rec.RequestQty)
		return nil
	}
	// if rec.Side > 0 {
	// 	price = sym.FormatPrice(price * 1.001)
	// } else if rec.Side < 0 {
	// 	price = sym.FormatPrice(price / 1.001)

	// }

	param := template.OrderParam{
		Symbol:      sym,
		CID:         rec.ClientOrderId,
		Side:        rec.Side,
		Price:       price,
		Qty:         qty,
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	}
	order := s.Context.NewOrder(param)
	s.pendingMap[rec.ClientOrderId] = rec
	if err := s.Client.SendOrder(order); err != nil {
		return err
	}

	s.logDepth(rec.Symbol, rec.OperationId, "taker-send", rec.FilledAmount)
	return nil
}

func (s *Strategy) handleMaker(rec *OrderRecord) error {
	takerSym := s.config.Pairs[rec.Symbol]
	s.logDepth(takerSym, rec.OperationId, "maker-send", rec.FilledAmount)
	s.Context.CallSignal(time.UnixMilli(rec.FinOrderMs), "maker-fin", rec)
	return nil
}

// OnSignal is called at the scheduled FinOrderMs for maker orders.
func (s *Strategy) OnSignal(timeMs int64, tag string, payload interface{}) error {
	if tag != "maker-fin" {
		return nil
	}
	rec, ok := payload.(*OrderRecord)
	if !ok {
		return nil
	}
	takerSym := s.config.Pairs[rec.Symbol]
	s.logDepth(takerSym, rec.OperationId, "maker-fin", rec.FilledAmount)
	return nil
}

func (s *Strategy) OnBBO(bbo *utils.BBO) error {
	s.Context.ReturnBBOToPool(bbo)
	return nil
}

// OnDepth caches the latest depth per symbol, returning the previous one to the pool.
func (s *Strategy) OnDepth(depth *utils.Depth) error {
	symName := depth.GetSymbol().GetName()
	if old := s.depthMap[symName]; old != nil {
		s.Context.ReturnDepthToPool(old)
	}
	s.depthMap[symName] = depth
	return nil
}

func (s *Strategy) OnTrade(trade *utils.Trade) error {
	s.Context.ReturnTradeToPool(trade)
	return nil
}

// OnOrder is called when an order status update arrives.
// When the order is finished, logs the final status via the recorder.
func (s *Strategy) OnOrder(msg *utils.OrderMessage) error {
	defer s.Context.ReturnOrderMessageToPool(msg)

	rec, ok := s.pendingMap[msg.ClientID]
	if !ok {
		return nil
	}
	if !utils.IsFinishedStatus(msg.Status) {
		return nil
	}
	delete(s.pendingMap, msg.ClientID)

	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type":   "order",
			"symbol": rec.Symbol,
		},
		Field: map[string]interface{}{
			"cid":          msg.ClientID,
			"oid":          msg.OrderID,
			"operation_id": rec.OperationId,
			"side":         msg.Side,
			"status":       msg.Status,
			"request_prc":  rec.RequestPrc,
			"request_qty":  rec.RequestQty,
			"avg_price":    msg.AvgFillPrc,
			"filled_qty":   msg.FilledQty,
			"send_ms":      rec.SendOrderMs,
			"fin_ms":       s.Context.Now().UnixMilli(),
			"server_ms":    msg.ServerTime,
		},
		Extra: map[string]interface{}{
			"time": s.Context.Now(),
		},
	})
	return nil
}

// logDepth records a depth snapshot for the given symbol with operationId and depthType labels.
// fillAmountStr is the realtime filled quantity string used to compute impact prices.
// No-ops if no depth is cached for the symbol.
func (s *Strategy) logDepth(symbol, operationId, depthType, fillAmountStr string) {
	depth := s.depthMap[symbol]
	if depth == nil {
		return
	}

	fillQty, _ := strconv.ParseFloat(fillAmountStr, 64)

	var askPrc, askQty, bidPrc, bidQty float64
	if depth.Asks != nil && len(*depth.Asks) > 0 {
		askPrc = (*depth.Asks)[0].Prc
		askQty = (*depth.Asks)[0].Qty
	}
	if depth.Bids != nil && len(*depth.Bids) > 0 {
		bidPrc = (*depth.Bids)[0].Prc
		bidQty = (*depth.Bids)[0].Qty
	}

	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type":   "depth",
			"symbol": symbol,
		},
		Field: map[string]interface{}{
			"operation_id": operationId,
			"optype":       depthType,
			"ask_prc":      askPrc,
			"ask_impact":   impactPrice(depth.Asks, fillQty),
			"ask_qty":      askQty,
			"bid_prc":      bidPrc,
			"bid_impact":   impactPrice(depth.Bids, fillQty),
			"bid_qty":      bidQty,
			"server_ts":    depth.ServerTS,
			"resp_ts":      depth.RespTS,
		},
		Extra: map[string]interface{}{
			"time": s.Context.Now(),
		},
	})
}

// impactPrice computes the volume-weighted average price (VWAP) for consuming targetQty
// from a side of the order book. Returns 0 if levels are nil or targetQty <= 0.
func impactPrice(levels *[]*utils.Level, targetQty float64) float64 {
	if levels == nil || targetQty <= 0 {
		return 0
	}
	var totalCost, totalQty float64
	for _, lvl := range *levels {
		remaining := targetQty - totalQty
		if remaining <= 0 {
			break
		}
		filled := math.Min(lvl.Qty, remaining)
		totalCost += filled * lvl.Prc
		totalQty += filled
	}
	if totalQty == 0 {
		return 0
	}
	return totalCost / totalQty
}

func (s *Strategy) Brief() {
	s.log.Infof("[Config] %+v", s.config)
}

func (s *Strategy) NowEntry() *logrus.Entry {
	return s.log.WithTime(s.Context.Now())
}
