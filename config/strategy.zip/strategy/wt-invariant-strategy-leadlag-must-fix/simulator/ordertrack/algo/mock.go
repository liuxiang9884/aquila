package algo

import (
	"strconv"
	"time"

	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
)

type MockStrategy struct {
	*Strategy
}

func (s *MockStrategy) HandleOrderRecord(timeMs int64, rec *OrderRecord) error {
	sym := s.symbolMap[rec.Symbol]

	price, err := strconv.ParseFloat(rec.RequestPrc, 64)
	if err != nil {
		s.NowEntry().WithError(err).Errorf("failed to parse RequestPrc %q", rec.RequestPrc)
		return nil
	}
	qty, err := strconv.ParseFloat(rec.RequestQty, 64)
	if err != nil {
		s.NowEntry().WithError(err).Errorf("failed to parse RequestQty %q", rec.RequestQty)
		return nil
	}
	// if rec.Side > 0 {
	// 	price = sym.FormatPrice(price * 1.001)
	// } else if rec.Side < 0 {
	// 	price = sym.FormatPrice(price / 1.001)

	// }

	param := template.OrderParam{
		Symbol:      sym,
		CID:         rec.ClientOrderId,
		Side:        rec.Side,
		Price:       price,
		Qty:         qty,
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	}
	switch rec.TradeType {
	case "maker":
		param.TimeInForce = template.GTX
		s.Context.CallSignal(time.UnixMilli(rec.FinOrderMs), "cancel-on-fin", rec)
	case "taker":
		param.TimeInForce = template.IOC
	}

	order := s.Context.NewOrder(param)
	s.pendingMap[rec.ClientOrderId] = rec
	if err := s.Client.SendOrder(order); err != nil {
		return err
	}

	s.logDepth(rec.Symbol, rec.OperationId, "send", rec.FilledAmount)
	return nil
}

func (s *MockStrategy) OnSignal(timeMs int64, tag string, payload interface{}) error {
	if tag != "cancel-on-fin" {
		return nil
	}
	rec, ok := payload.(*OrderRecord)
	if !ok {
		return nil
	}
	if _, ok := s.pendingMap[rec.ClientOrderId]; !ok {
		return nil
	}
	sym, ok := s.symbolMap[rec.Symbol]
	if !ok {
		return nil
	}
	return s.Client.CancelByCID(sym, rec.ClientOrderId)
}
