package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path"
	"sort"

	"git.hashingbot.com/aurthes/xex_mm_go/atom_symbol"
	"git.hashingbot.com/aurthes/xex_mm_go/utils/godotenv"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/backtest"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/simulator/ordertrack/algo"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

var Logger = logrus.New()
var JsonLog = logrus.New()

func init() {
	godotenv.Load(getEnv("ENVFILE", ".env"))
	Logger.SetFormatter(&logrus.TextFormatter{
		TimestampFormat: "2006-01-02 15:04:05.000",
		FullTimestamp:   true,
	})

	logFileName := path.Join(
		getEnv("LOG_DIR", "."),
		getEnv("LOG_FILE", "backtest.log"),
	)

	jsonLogFile, err := os.OpenFile(logFileName, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0666)
	if err != nil {
		Logger.Fatalf("Failed to open json log file: %v", err)
	}
	JsonLog.SetOutput(io.MultiWriter(os.Stdout, jsonLogFile))
	JsonLog.SetFormatter(&logrus.JSONFormatter{
		TimestampFormat:   "2006-01-02 15:04:05.000",
		DisableHTMLEscape: true,
		FieldMap: logrus.FieldMap{
			logrus.FieldKeyTime:  "ts",
			logrus.FieldKeyLevel: "level",
			logrus.FieldKeyMsg:   "msg",
		},
	})
}

func getEnv(key, defaultVal string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return defaultVal
}

func loadStrategyConfig(filename string) (*algo.StrategyConfig, error) {
	data, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("failed to read strategy config: %w", err)
	}
	config := new(algo.StrategyConfig)
	if err = json.Unmarshal(data, config); err != nil {
		return nil, fmt.Errorf("failed to parse strategy config: %w", err)
	}
	return config, nil
}

func loadOrderRecords(filename string, symbolFilter map[string]struct{}) ([]*algo.OrderRecord, error) {
	data, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("failed to read order records: %w", err)
	}
	var all []*algo.OrderRecord
	if err = json.Unmarshal(data, &all); err != nil {
		return nil, fmt.Errorf("failed to parse order records: %w", err)
	}

	filtered := all[:0]
	for _, rec := range all {
		if len(symbolFilter) == 0 {
			filtered = append(filtered, rec)
			continue
		}
		if _, ok := symbolFilter[rec.Symbol]; ok {
			filtered = append(filtered, rec)
		}
	}

	sort.Slice(filtered, func(i, j int) bool {
		return filtered[i].SendOrderMs < filtered[j].SendOrderMs
	})
	return filtered, nil
}

func loadBacktestSetting(filename string) (*backtest.Setting, error) {
	data, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("failed to read backtest setting: %w", err)
	}
	setting := new(backtest.Setting)
	if err = json.Unmarshal(data, setting); err != nil {
		return nil, fmt.Errorf("failed to parse backtest setting: %w", err)
	}
	return setting, nil
}

// buildSymbolMap resolves the atom_symbol.Symbol for each symbol name from the backtest widgets.
func buildSymbolMap(symbols []string, widgets *backtest.Widgets) (map[string]*atom_symbol.Symbol, error) {
	result := make(map[string]*atom_symbol.Symbol, len(symbols))
	allSymbols := widgets.SymbolMap.AllSymbols()
	orgSymbolMaps := make(map[string]*atom_symbol.Symbol, len(allSymbols))
	for _, symbol := range allSymbols {
		orgSymbolMaps[symbol.GetName()] = symbol
	}
	for _, name := range symbols {
		symbol, ok := orgSymbolMaps[name]
		if !ok {
			// return nil, fmt.Errorf("symbol %q not found in backtest data", name)
			continue
		}
		result[name] = symbol
	}
	return result, nil
}

// OrderReader implements backtest.CustomReader[algo.OrderRecord].
// It yields order records in ascending SendOrderMs order.
type OrderReader struct {
	records []*algo.OrderRecord
	idx     int
}

func (r *OrderReader) Next() (timeMs int64, payload *algo.OrderRecord, ok bool) {
	if r.idx >= len(r.records) {
		return 0, nil, false
	}
	rec := r.records[r.idx]
	r.idx++
	return rec.SendOrderMs, rec, true
}

func main() {
	strategyFile := flag.String("s", "", "Path to strategy config JSON file (required)")
	backtestFile := flag.String("b", "", "Path to backtest setting JSON file (required)")
	flag.Parse()

	if *strategyFile == "" || *backtestFile == "" {
		fmt.Fprintf(os.Stderr, "Usage: %s -s <strategy.json> -b <backtest.json>\n", os.Args[0])
		flag.PrintDefaults()
		os.Exit(1)
	}

	config, err := loadStrategyConfig(*strategyFile)
	if err != nil {
		Logger.Fatal(err)
	}

	symbolFilter := make(map[string]struct{}, len(config.Symbols))
	for _, s := range config.Symbols {
		symbolFilter[s] = struct{}{}
	}

	records, err := loadOrderRecords(config.OrdersFile, symbolFilter)
	if err != nil {
		Logger.Fatal(err)
	}
	Logger.Infof("Loaded %d order records", len(records))

	ctx := context.TODO()
	stg := config.New(Logger.WithContext(ctx))

	setting, err := loadBacktestSetting(*backtestFile)
	if err != nil {
		Logger.Fatal(err)
	}

	widgets, err := setting.NewBackTest(stg)
	if err != nil {
		Logger.Fatal(err)
	}

	symbolMap, err := buildSymbolMap(config.Symbols, widgets)
	if err != nil {
		Logger.Fatal(err)
	}
	stg.SetSymbols(symbolMap)

	stg.SetRecorder(&recorder.LogRecorder{
		Log:   JsonLog.WithContext(ctx),
		Level: logrus.InfoLevel,
	})

	reader := &OrderReader{records: records}
	backtest.AddCustomData(widgets.Custom, reader, stg.HandleOrderRecord)

	Logger.Info("Starting backtest")
	widgets.Run()
	stg.Brief()
	Logger.Info("Backtest done")
}
