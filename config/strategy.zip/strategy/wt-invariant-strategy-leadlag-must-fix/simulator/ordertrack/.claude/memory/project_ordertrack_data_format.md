---
name: ordertrack_data_format
description: Order record JSON format and Symbol-to-raw-data-file mapping rules for the ordertrack simulator
type: project
---

## Order Record Format

Each record is a JSON object in an array. Key fields:

| Field           | Type    | Description                                      |
|-----------------|---------|--------------------------------------------------|
| `SendOrderMs`   | int     | Order send time, Unix timestamp in milliseconds (UTC) |
| `FinOrderMs`    | int     | Order finish time, Unix timestamp in milliseconds (UTC) |
| `ClientOrderId` | string  | Unique order identifier                          |
| `Symbol`        | string  | Trading symbol — see format below                |
| `Account`       | string  | `{exchange}.{account_name}`                      |
| `TradeType`     | string  | `"maker"` or `"taker"`                           |
| `Side`          | int     | `-1` = sell, `1` = buy                           |
| `IfOperateEntry`| bool    | Whether this order operates an entry leg         |
| `IfOperateTo`   | bool    | Whether this order operates a to-leg             |
| `RequestPrc`    | string  | Requested price (decimal string)                 |
| `RequestQty`    | string  | Requested quantity (decimal string)              |
| `FilledPrc`     | string  | Actual filled price (decimal string)             |
| `FilledAmount`  | string  | Actual filled quantity (decimal string)          |
| `PriceDetail`   | object  | Pricing metadata (profits, fees, params, etc.)   |

---

## Symbol Format

```
{exchange}.{market}.{base}_{quote}
```

Examples:
- `bybit.spot.xpl_usdt`  → exchange=`bybit`, market=`spot`, base=`xpl`, quote=`usdt`
- `bybit.perp.xpl_usdt`  → exchange=`bybit`, market=`perp`, base=`xpl`, quote=`usdt`

---

## Symbol → Raw Data File Mapping

Raw data root: `/Users/caiming/Works/backtest-go/raw_data_hourly`

**Directory:** `{root}/{YYYYmmddHH}/`
Derived from `SendOrderMs` converted to UTC, formatted as `YYYYmmddHH`.

**Filename:**

| Market | Filename pattern |
|--------|-----------------|
| `spot` | `{exchange}.{base}_{quote}_{YYYYmmddHH}.h5` |
| `perp` | `{exchange}.{base}_{quote}_swap_{YYYYmmddHH}.h5` |

**Full path examples:**
```
# spot
raw_data_hourly/2026031709/bybit.xpl_usdt_2026031709.h5

# perp
raw_data_hourly/2026031709/bybit.xpl_usdt_swap_2026031709.h5
```

**Why:** Used by `scripts/find_raw_data.py` to verify that raw hourly H5 data exists for each order's symbol and time window.
