#!/usr/bin/env python3
"""
Compare backtest order fills against realtime order fills.

Matches orders by ClientOrderId (realtime) / cid (backtest), then reports
differences in fill price, fill quantity, and taker-send slippage.

Slippage definition (taker-send)
---------------------------------
    slippage = (fill_price - base_price) / base_price

    fill_price:
        backtest  -> OrderRecord.avg_price
        realtime  -> taker FilledPrc

    base_price (taker-send):
        backtest  -> DepthRecord(optype=taker-send) bid_impact (sell) / ask_impact (buy)
        realtime  -> taker FloatMsg.market_prc

Status codes (backtest)
-----------------------
    40 = Filled   41 = PartiallyFilled   others = cancelled/rejected/etc.

Usage
-----
    python compare_fills.py live  <realtime.json> <backtest.log> [options]
    python compare_fills.py mock  <realtime.json> <backtest.log> [options]

Subcommands
-----------
    live   Live strategy logs: depth matched on optype=taker-send (taker orders only)
    mock   MockStrategy logs:  depth matched on optype=send (taker + maker orders)

Options
-------
    --symbol SYMBOL     Filter by symbol (e.g. bybit.perp.bard_usdt)
    --csv FILE          Write per-order rows to CSV
    --no-table          Skip per-order table
    --no-summary        Skip aggregate summary
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------

def load_realtime(path, symbol_filter):
    # type: (str, Optional[str]) -> Dict[str, dict]
    """Load taker realtime records keyed by ClientOrderId."""
    with open(path) as fh:
        records = json.load(fh)
    if not isinstance(records, list):
        records = [records]
    result = {}
    for rec in records:
        cid = rec.get("ClientOrderId")
        if not cid:
            continue
        if symbol_filter and rec.get("Symbol") != symbol_filter:
            continue
        result[cid] = rec
    return result


def load_bt_orders(path, symbol_filter):
    # type: (str, Optional[str]) -> Dict[str, dict]
    """Load backtest order records (type=order) keyed by cid."""
    result = {}
    with open(path) as fh:
        for lineno, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as exc:
                print("[WARN] line {}: {}".format(lineno, exc), file=sys.stderr)
                continue
            if obj.get("type") != "order":
                continue
            cid = obj.get("cid")
            if not cid:
                continue
            if symbol_filter and obj.get("symbol") != symbol_filter:
                continue
            result[cid] = obj
    return result


def _load_bt_depth(path, symbol_filter, optype):
    # type: (str, Optional[str], str) -> Dict[str, dict]
    """Load backtest depth records matching optype, keyed by operation_id."""
    result = {}
    with open(path) as fh:
        for lineno, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as exc:
                print("[WARN] line {}: {}".format(lineno, exc), file=sys.stderr)
                continue
            if obj.get("type") != "depth":
                continue
            if obj.get("optype") != optype:
                continue
            op_id = obj.get("operation_id")
            if not op_id:
                continue
            if symbol_filter and obj.get("symbol") != symbol_filter:
                continue
            result[op_id] = obj
    return result


def load_bt_depth_taker_send(path, symbol_filter):
    # type: (str, Optional[str]) -> Dict[str, dict]
    """Load backtest depth records with optype=taker-send keyed by operation_id."""
    return _load_bt_depth(path, symbol_filter, "taker-send")


def load_bt_depth_send(path, symbol_filter):
    # type: (str, Optional[str]) -> Dict[str, dict]
    """Load mock backtest depth records with optype=send keyed by operation_id."""
    return _load_bt_depth(path, symbol_filter, "send")


# ---------------------------------------------------------------------------
# Comparison
# ---------------------------------------------------------------------------

def _f(v, label, cid):
    # type: (object, str, str) -> Optional[float]
    if v is None:
        print("[WARN] cid={} missing {}".format(cid, label), file=sys.stderr)
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        print("[WARN] cid={} bad {}={!r}".format(cid, label, v), file=sys.stderr)
        return None


def _slippage(fill_price, base_price, side):
    # type: (Optional[float], Optional[float], Optional[int]) -> Optional[float]
    """slippage = side * (fill_price - base_price) / base_price. Returns None if inputs invalid."""
    if fill_price is None or base_price is None or base_price == 0 or not side:
        return None
    return side * (fill_price - base_price) / base_price


def build_rows(rt, bt_orders, bt_depth):
    # type: (Dict[str, dict], Dict[str, dict], Dict[str, dict]) -> List[dict]
    rows = []
    for cid, rr in rt.items():
        br = bt_orders.get(cid)
        if br is None:
            continue

        rt_prc = _f(rr.get("FilledPrc"),    "FilledPrc",    cid)
        rt_qty = _f(rr.get("FilledAmount"), "FilledAmount", cid)
        bt_prc = _f(br.get("avg_price"),    "avg_price",    cid)
        bt_qty = _f(br.get("filled_qty"),   "filled_qty",   cid)

        # Only compute price diff/bps when both sides have a non-zero fill price
        prc_diff = bt_prc - rt_prc if bt_prc and rt_prc else None
        prc_bps  = prc_diff / rt_prc * 10_000 if prc_diff is not None else None
        qty_diff  = bt_qty - rt_qty if bt_qty is not None and rt_qty is not None else None
        qty_ratio = (bt_qty / rt_qty - 1) if qty_diff is not None and rt_qty else None

        # --- taker-send slippage ---
        side = rr.get("Side")
        op_id = br.get("operation_id")
        depth = bt_depth.get(op_id) if op_id else None

        # Realtime base price: FloatMsg.market_prc
        float_msg = rr.get("FloatMsg") or {}
        rt_base_prc = _f(float_msg.get("market_prc"), "FloatMsg.market_prc", cid) if float_msg else None

        # Backtest base price: bid_impact (sell) or ask_impact (buy)
        bt_base_prc = None
        if depth is not None:
            impact_key = "bid_impact" if side == -1 else "ask_impact"
            bt_base_prc = _f(depth.get(impact_key), impact_key, cid)

        rt_slp = _slippage(rt_prc, rt_base_prc, side)
        # Skip bt slippage for unfilled orders (avg_price == 0)
        bt_slp = _slippage(bt_prc, bt_base_prc, side) if bt_prc else None
        slp_diff  = bt_slp - rt_slp if bt_slp is not None and rt_slp is not None else None
        slp_ratio = bt_slp / rt_slp - 1 if bt_slp is not None and rt_slp else None

        # --- duration (ms) ---
        rt_send = rr.get("SendOrderMs")
        rt_fin  = rr.get("FinOrderMs")
        rt_dur  = rt_fin - rt_send if rt_fin is not None and rt_send is not None else None

        bt_send_ms   = br.get("send_ms")
        bt_fin_ms = br.get("fin_ms")
        bt_dur = bt_fin_ms - bt_send_ms if bt_fin_ms is not None and bt_send_ms is not None else None

        dur_diff  = bt_dur - rt_dur if bt_dur is not None and rt_dur is not None else None
        dur_ratio = bt_dur / rt_dur - 1 if bt_dur is not None and rt_dur else None
        prc_ratio = bt_prc / rt_prc - 1 if bt_prc and rt_prc else None

        rows.append({
            "cid":           cid,
            "symbol":        rr.get("Symbol", ""),
            "side":          side,
            "trade_type":    rr.get("TradeType", ""),
            "rt_filled_prc": rt_prc,
            "bt_avg_prc":    bt_prc,
            "prc_diff":      prc_diff,
            "prc_diff_bps":  prc_bps,
            "rt_filled_qty": rt_qty,
            "bt_filled_qty": bt_qty,
            "qty_diff":      qty_diff,
            "qty_ratio":     qty_ratio,
            "rt_base_prc":   rt_base_prc,
            "bt_base_prc":   bt_base_prc,
            "rt_slp":        rt_slp,
            "bt_slp":        bt_slp,
            "slp_diff":      slp_diff,
            "slp_ratio":     slp_ratio,
            "rt_dur":        rt_dur,
            "bt_dur":        bt_dur,
            "dur_diff":      dur_diff,
            "dur_ratio":     dur_ratio,
            "prc_ratio":     prc_ratio,
            "bt_status":     br.get("status"),
        })
    return rows


# ---------------------------------------------------------------------------
# Display
# ---------------------------------------------------------------------------

COLUMNS = [
    # (key, header, width, fmt)
    ("cid",           "CID",           26, "{}"),
    ("symbol",        "SYMBOL",        22, "{}"),
    ("side",          "SIDE",           5, "{}"),
    ("rt_filled_prc", "RT_FILL_PRC",  12, "{:.6f}"),
    ("bt_avg_prc",    "BT_AVG_PRC",   12, "{:.6f}"),
    ("prc_ratio",     "FILL_RATIO%",   12, "{:+.4%}"),
    ("rt_filled_qty", "RT_QTY",       12, "{:.4f}"),
    ("bt_filled_qty", "BT_QTY",       12, "{:.4f}"),
    ("qty_ratio",     "QTY_RATIO%",   10, "{:+.2%}"),
    ("rt_base_prc",   "RT_BASE",      12, "{:.6f}"),
    ("bt_base_prc",   "BT_BASE",      12, "{:.6f}"),
    ("rt_slp",        "RT_SLP%",      10, "{:+.4%}"),
    ("bt_slp",        "BT_SLP%",      10, "{:+.4%}"),
    ("slp_diff",      "SLP_DIFF%",    11, "{:+.4%}"),
    ("rt_dur",        "RT_DUR_MS",     9, "{:.0f}"),
    ("bt_dur",        "BT_DUR_MS",     9, "{:.0f}"),
    ("dur_diff",      "DUR_DIFF_MS",  12, "{:+.0f}"),
    ("bt_status",     "STATUS",        6, "{}"),
]


def print_table(rows, columns=None):
    # type: (List[dict], Optional[list]) -> None
    if columns is None:
        columns = COLUMNS
    sep = "  "
    header = sep.join(hdr.ljust(w) for _, hdr, w, _ in columns)
    print(header)
    print("-" * len(header))
    for row in rows:
        parts = []
        for key, _, w, fmt in columns:
            v = row[key]
            if v is None:
                s = "N/A"
            elif isinstance(v, float):
                s = fmt.format(v)
            else:
                s = str(v)
            parts.append(s.ljust(w))
        print(sep.join(parts))


def _percentile(sorted_vals, p):
    # type: (list, float) -> float
    """Linear interpolation percentile on a pre-sorted list."""
    n = len(sorted_vals)
    if n == 1:
        return sorted_vals[0]
    idx = p / 100.0 * (n - 1)
    lo = int(idx)
    hi = lo + 1
    if hi >= n:
        return sorted_vals[-1]
    return sorted_vals[lo] + (idx - lo) * (sorted_vals[hi] - sorted_vals[lo])


def _dist_stats(vals):
    # type: (list) -> Optional[dict]
    """Compute distribution stats dict. Returns None if vals is empty."""
    if not vals:
        return None
    n = len(vals)
    mean = sum(vals) / n
    variance = sum((v - mean) ** 2 for v in vals) / n
    s = sorted(vals)
    return {
        "n":   n,
        "mean": mean,
        "std":  variance ** 0.5,
        "p25":  _percentile(s, 25),
        "p50":  _percentile(s, 50),
        "p75":  _percentile(s, 75),
        "p90":  _percentile(s, 90),
        "p95":  _percentile(s, 95),
    }


# Stat columns: (key, header, width)
_STAT_COLS = [
    ("mean", "MEAN",     11),
    ("std",  "STD",  11),
    ("p25",  "P25",  11),
    ("p50",  "P50",  11),
    ("p75",  "P75",  11),
    ("p90",  "P90",  11),
    ("p95",  "P95",  11),
]


def _fmt_stats(stats, fmt):
    # type: (Optional[dict], str) -> List[str]
    if stats is None:
        return ["N/A".ljust(w) for _, _, w in _STAT_COLS]
    parts = []
    for key, _, w in _STAT_COLS:
        s = fmt.format(stats[key])
        parts.append(s.ljust(w))
    return parts


METRICS = [
    # (label, row-key, fmt)
    ("fill price ratio(bt/rt-1)", "prc_ratio",  "{:+.4%}"),
    ("fill qty ratio(bt/rt-1)",   "qty_ratio",  "{:+.2%}"),
    ("rt slippage",               "rt_slp",     "{:+.4%}"),
    ("bt slippage",               "bt_slp",     "{:+.4%}"),
    ("slippage diff(bt-rt)",      "slp_diff",   "{:+.4%}"),
    ("rt duration (ms)",          "rt_dur",     "{:.1f}"),
    ("bt duration (ms)",          "bt_dur",     "{:.1f}"),
    ("duration diff(bt-rt ms)",   "dur_diff",   "{:+.1f}"),
]

# Column/metric keys that relate to slippage — excluded in mock mode.
_SLIPPAGE_KEYS = {"rt_base_prc", "bt_base_prc", "rt_slp", "bt_slp", "slp_diff"}


def print_summary(rows, metrics=None):
    # type: (List[dict], Optional[list]) -> None
    if metrics is None:
        metrics = METRICS
    groups = defaultdict(list)  # type: Dict[tuple, List[dict]]
    for row in rows:
        key = (row["symbol"], row["side"])
        groups[key].append(row)

    sep = "  "
    metric_w = 26
    stat_header = sep.join(hdr.ljust(w) for _, hdr, w in _STAT_COLS)
    divider = "-" * (metric_w + 2 + len(stat_header))

    print("\n=== Distribution Summary ===")
    for (symbol, side), grp in sorted(groups.items()):
        side_str = "BUY" if side == 1 else "SELL" if side == -1 else str(side)
        print("\n  {} | {} | total n={}".format(symbol, side_str, len(grp)))
        print("  {}  {}".format("METRIC".ljust(metric_w), stat_header))
        print("  " + divider)
        for label, key, fmt in metrics:
            vals = [r[key] for r in grp if r[key] is not None]
            stats = _dist_stats(vals)
            cells = sep.join(_fmt_stats(stats, fmt))
            print("  {}  {}".format(label.ljust(metric_w), cells))


def write_csv(rows, path):
    # type: (List[dict], str) -> None
    if not rows:
        return
    with open(path, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print("\nCSV written -> {}".format(path))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _add_common_args(p):
    # type: (argparse.ArgumentParser) -> None
    p.add_argument("realtime", help="Realtime order records JSON file")
    p.add_argument("backtest", help="Backtest JSON-lines log file")
    p.add_argument("--symbol", default=None, metavar="SYM",
                   help="Filter by symbol (e.g. bybit.perp.bard_usdt)")
    p.add_argument("--csv", default=None, metavar="FILE",
                   help="Write per-order comparison to CSV")
    p.add_argument("--no-table",   action="store_true", help="Skip per-order table")
    p.add_argument("--no-summary", action="store_true", help="Skip aggregate summary")


def _run(args, depth_optype):
    # type: (argparse.Namespace, str) -> None
    is_mock = depth_optype == "send"

    rt     = load_realtime(args.realtime, args.symbol)
    bt_ord = load_bt_orders(args.backtest, args.symbol)
    if is_mock:
        bt_depth = load_bt_depth_send(args.backtest, args.symbol)
    else:
        bt_depth = load_bt_depth_taker_send(args.backtest, args.symbol)

    rows = build_rows(rt, bt_ord, bt_depth)

    rt_only = len(rt) - len(rows)
    bt_only = len(bt_ord) - len(rows)

    print("Realtime records      : {}".format(len(rt)))
    print("Backtest order records: {}".format(len(bt_ord)))
    print("Backtest depth records: {} ({})".format(len(bt_depth), depth_optype))
    print("Matched               : {}".format(len(rows)))
    filled = sum(1 for r in rows if r["bt_filled_qty"] and r["bt_filled_qty"] > 0)
    print("Filled                : {} ({:.0f}%)".format(filled, 100.0 * filled / len(rt) if rt else 0))
    if not is_mock:
        slp_matched = sum(1 for r in rows if r["slp_diff"] is not None)
        print("Slippage comparable   : {} ({:.0f}%)".format(slp_matched, 100.0 * slp_matched / len(rt) if rt else 0))
    if rt_only:
        print("  RT only (no bt)   : {}".format(rt_only))
    if bt_only:
        print("  BT only (no rt)   : {}".format(bt_only))
    print()

    if not rows:
        print("No matched records.")
        return

    columns = [c for c in COLUMNS if not (is_mock and c[0] in _SLIPPAGE_KEYS)]
    metrics = [m for m in METRICS if not (is_mock and m[1] in _SLIPPAGE_KEYS)]

    if not args.no_table:
        print_table(rows, columns=columns)

    if not args.no_summary:
        print_summary(rows, metrics=metrics)

    if args.csv:
        write_csv(rows, args.csv)


def main():
    parser = argparse.ArgumentParser(
        description="Compare backtest fills vs realtime fills.",
    )
    sub = parser.add_subparsers(dest="cmd", metavar="SUBCOMMAND")
    sub.required = True

    p_live = sub.add_parser("live", help="Live strategy logs (depth optype=taker-send)")
    _add_common_args(p_live)

    p_mock = sub.add_parser("mock", help="MockStrategy logs (depth optype=send)")
    _add_common_args(p_mock)

    args = parser.parse_args()

    if args.cmd == "mock":
        _run(args, "send")
    else:
        _run(args, "taker-send")


if __name__ == "__main__":
    main()
