#!/usr/bin/env python3
"""
Subcommands for working with order records and raw hourly data files.

Subcommands
-----------
find
    Check whether each order record's Symbol + SendOrderMs has a matching
    raw data file in the hourly data directory.

    Usage:
        python find_raw_data.py find <record_file> <data_dir>

extract
    Filter order records by symbol and/or date range and write matches to
    an output JSON file.

    Usage:
        python find_raw_data.py extract <record_file> <output> [symbol ...] \\
            [--start YYYY-MM-DD] [--end YYYY-MM-DD]

    Positional arguments:
        record_file Source JSON order record file.
        output      Destination JSON file for extracted records.
        symbol      Zero or more symbols to keep (omit to keep all symbols).

    Options:
        --start     Inclusive start hour in UTC (YYYYmmddHH).
        --end       Inclusive end hour in UTC (YYYYmmddHH).

Symbol format:  {exchange}.{market}.{base}_{quote}
File structure: {data_dir}/{YYYYmmddHH}/{exchange}.{base}_{quote}[_swap]_{YYYYmmddHH}.h5
                spot  -> no suffix
                perp  -> _swap suffix
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone

import pandas as pd


MARKET_SUFFIX = {
    "spot": "",
    "perp": "_swap",
}


def parse_symbol(symbol):
    # type: (str) -> tuple
    """Parse '{exchange}.{market}.{base}_{quote}' into components."""
    parts = symbol.split(".", 2)
    if len(parts) != 3:
        raise ValueError(f"Unexpected symbol format: {symbol!r}")
    exchange, market, pair = parts
    return exchange, market, pair  # pair is already '{base}_{quote}'


def ms_to_hour_tag(send_order_ms):
    # type: (int) -> str
    """Convert millisecond timestamp to YYYYmmddHH string (UTC)."""
    dt = datetime.fromtimestamp(send_order_ms / 1000, tz=timezone.utc)
    return dt.strftime("%Y%m%d%H")


def expected_path(data_dir, exchange, market, pair, hour_tag):
    # type: (str, str, str, str, str) -> str
    suffix = MARKET_SUFFIX.get(market)
    if suffix is None:
        raise ValueError(f"Unknown market type: {market!r}")
    filename = f"{exchange}.{pair}{suffix}_{hour_tag}.h5"
    return os.path.join(data_dir, hour_tag, filename)


def parse_date_utc(date_str, end_of_hour=False):
    # type: (str, bool) -> int
    """Parse 'YYYYmmddHH' to a UTC millisecond timestamp.

    If end_of_hour is True, returns the timestamp for 59:59.999 of that hour.
    """
    dt = datetime.strptime(date_str, "%Y%m%d%H").replace(tzinfo=timezone.utc)
    if end_of_hour:
        dt = dt.replace(minute=59, second=59, microsecond=999000)
    return int(dt.timestamp() * 1000)


# ---------------------------------------------------------------------------
# Subcommand: find
# ---------------------------------------------------------------------------

def _parse_row(row, data_dir):
    # type: (pd.Series, str) -> pd.Series
    """Return hour_tag and path for a record row, or raise ValueError."""
    exchange, market, pair = parse_symbol(row["Symbol"])
    hour_tag = ms_to_hour_tag(int(row["SendOrderMs"]))
    path = expected_path(data_dir, exchange, market, pair, hour_tag)
    return pd.Series({"hour_tag": hour_tag, "path": path})


def cmd_find(args):
    with open(args.record_file, "r") as f:
        records = json.load(f)

    if not isinstance(records, list):
        records = [records]

    df = pd.DataFrame(records)
    mask_valid = df["Symbol"].notna() & df["SendOrderMs"].notna()
    skipped = int((~mask_valid).sum())
    df = df[mask_valid].reset_index(drop=True)

    parsed_rows = []
    for i, row in df.iterrows():
        try:
            parsed_rows.append(_parse_row(row, args.data_dir))
        except ValueError as e:
            print(f"[ERROR] record[{i}]: {e}", file=sys.stderr)
            skipped += 1
            parsed_rows.append(pd.Series({"hour_tag": None, "path": None}))

    parsed = pd.DataFrame(parsed_rows)
    df = df.join(parsed)
    df = df[df["hour_tag"].notna()].copy()

    if df.empty:
        print("No valid records.")
        return

    groups = (
        df.groupby(["Symbol", "hour_tag"], sort=True)
        .agg(records=("Symbol", "count"), path=("path", "first"))
        .reset_index()
    )
    groups["found"] = groups["path"].apply(os.path.isfile)

    col_sym = max(groups["Symbol"].str.len().max(), 6)
    col_date = 10
    print(f"{'STATUS':<8}  {'SYMBOL':<{col_sym}}  {'DATE':<{col_date}}  {'RECORDS':>7}  PATH")
    print("-" * (8 + 2 + col_sym + 2 + col_date + 2 + 7 + 2 + 30))

    for _, row in groups[groups["found"]].iterrows():
        print(
            f"{'FOUND':<8}  {row['Symbol']:<{col_sym}}  {row['hour_tag']:<{col_date}}"
            f"  {row['records']:>7}  {row['path']}"
        )

    total_records = int(groups["records"].sum())
    matched_groups = int(groups["found"].sum())
    missing_groups = int((~groups["found"]).sum())
    matched_records = int(groups.loc[groups["found"], "records"].sum())

    print()
    print(f"Groups : {len(groups)} total, {matched_groups} found, {missing_groups} missing")
    print(
        f"Records: {total_records} total, {matched_records} found,"
        f" {total_records - matched_records} missing"
        + (f", {skipped} skipped" if skipped else "")
    )


# ---------------------------------------------------------------------------
# Subcommand: extract
# ---------------------------------------------------------------------------

def cmd_extract(args):
    with open(args.records, "r") as f:
        records = json.load(f)

    if not isinstance(records, list):
        records = [records]

    # Build a lightweight DataFrame with only the fields needed for filtering,
    # keeping the original record list to preserve JSON field types and ordering.
    index_df = pd.DataFrame(
        {"Symbol": [r.get("Symbol") for r in records],
         "SendOrderMs": [r.get("SendOrderMs") for r in records]}
    )

    mask_valid = index_df["Symbol"].notna() & index_df["SendOrderMs"].notna()
    skipped = int((~mask_valid).sum())
    mask = mask_valid.copy()

    if args.symbols:
        mask &= index_df["Symbol"].isin(args.symbols)

    if args.start:
        start_ms = parse_date_utc(args.start)
        mask &= index_df["SendOrderMs"] >= start_ms

    if args.end:
        end_ms = parse_date_utc(args.end, end_of_hour=True)
        mask &= index_df["SendOrderMs"] <= end_ms

    extracted = [records[i] for i in index_df[mask].index]

    with open(args.output, "w") as f:
        json.dump(extracted, f, indent=2)

    print(
        f"Extracted {len(extracted)} record(s) -> {args.output}"
        + (f"  ({skipped} skipped due to missing fields)" if skipped else "")
    )


# ---------------------------------------------------------------------------
# Subcommand: resample
# ---------------------------------------------------------------------------

_FREQ_FMT = {
    "hour":  "%Y%m%d%H",
    "day":   "%Y-%m-%d",
    "week":  "%G-W%V",
    "month": "%Y-%m",
}


def cmd_resample(args):
    with open(args.record_file, "r") as f:
        records = json.load(f)

    if not isinstance(records, list):
        records = [records]

    df = pd.DataFrame(records)
    mask_valid = df["Symbol"].notna() & df["SendOrderMs"].notna()
    skipped = int((~mask_valid).sum())
    df = df[mask_valid].copy()

    if df.empty:
        print("No records.")
        return

    fmt = _FREQ_FMT.get(args.freq) if args.freq else None

    if fmt is not None:
        df["date_str"] = (
            pd.to_datetime(df["SendOrderMs"], unit="ms", utc=True)
            .dt.strftime(fmt)
        )
        counts = (
            df.groupby(["Symbol", "date_str"], sort=True)
            .size()
            .reset_index(name="count")
        )
        col_sym = max(counts["Symbol"].str.len().max(), 6)
        col_date = counts["date_str"].str.len().max()
        col_cnt = max(counts["count"].astype(str).str.len().max(), 5)

        header = "{:<{s}}  {:<{d}}  {:>{c}}".format(
            "SYMBOL", "DATE", "COUNT", s=col_sym, d=col_date, c=col_cnt
        )
        print(header)
        print("-" * len(header))
        for _, row in counts.iterrows():
            print("{:<{s}}  {:<{d}}  {:>{c}}".format(
                row["Symbol"], row["date_str"], row["count"],
                s=col_sym, d=col_date, c=col_cnt,
            ))
    else:
        df["_hour"] = (
            pd.to_datetime(df["SendOrderMs"], unit="ms", utc=True)
            .dt.strftime("%y%m%d%H")
        )
        counts = (
            df.groupby("Symbol", sort=True)
            .agg(
                count=("Symbol", "size"),
                start=("_hour", "min"),
                end=("_hour", "max"),
                dates=("_hour", "nunique"),
            )
            .reset_index()
            .sort_values("count", ascending=False)
        )
        col_sym  = max(counts["Symbol"].str.len().max(), 6)
        col_cnt  = max(counts["count"].astype(str).str.len().max(), 5)
        col_dt   = 8  # YYmmddHH is always 8 chars
        col_dts  = max(counts["dates"].astype(str).str.len().max(), 5)

        header = "{:<{s}}  {:<{d}}  {:<{d}}  {:>{ds}}  {:>{c}}".format(
            "SYMBOL", "START", "END", "DATES", "COUNT",
            s=col_sym, d=col_dt, ds=col_dts, c=col_cnt,
        )
        print(header)
        print("-" * len(header))
        for _, row in counts.iterrows():
            print("{:<{s}}  {:<{d}}  {:<{d}}  {:>{ds}}  {:>{c}}".format(
                row["Symbol"], row["start"], row["end"], row["dates"], row["count"],
                s=col_sym, d=col_dt, ds=col_dts, c=col_cnt,
            ))

    print()
    print(
        "Total: {} records".format(int(counts["count"].sum()))
        + ("  ({} skipped)".format(skipped) if skipped else "")
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Tools for order records and raw hourly data files.",
    )
    sub = parser.add_subparsers(dest="cmd", metavar="<subcommand>")
    sub.required = True

    # -- find ----------------------------------------------------------------
    p_find = sub.add_parser(
        "find",
        help="Check which order records have matching raw data files.",
    )
    p_find.add_argument("record_file", help="JSON order record file")
    p_find.add_argument("data_dir", help="Root directory of hourly raw data")
    p_find.set_defaults(func=cmd_find)

    # -- extract -------------------------------------------------------------
    p_extract = sub.add_parser(
        "extract",
        help="Filter records by symbol/date range and write to a new file.",
    )
    p_extract.add_argument(
        "records",
        help="Source JSON order record file.",
    )
    p_extract.add_argument(
        "output",
        help="Destination JSON file for extracted records.",
    )
    p_extract.add_argument(
        "symbols",
        nargs="*",
        metavar="symbol",
        help="Symbols to keep (omit to keep all).",
    )
    p_extract.add_argument(
        "--start",
        metavar="YYYYmmddHH",
        help="Inclusive start date in UTC.",
    )
    p_extract.add_argument(
        "--end",
        metavar="YYYYmmddHH",
        help="Inclusive end date in UTC.",
    )
    p_extract.set_defaults(func=cmd_extract)

    # -- resample ------------------------------------------------------------
    p_resample = sub.add_parser(
        "resample",
        help="Count order records by symbol and date bucket.",
    )
    p_resample.add_argument("record_file", help="JSON order record file")
    p_resample.add_argument(
        "--freq",
        choices=["hour", "day", "week", "month"],
        default=None,
        help="Bucket frequency; omit to group by symbol only.",
    )
    p_resample.set_defaults(func=cmd_resample)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
