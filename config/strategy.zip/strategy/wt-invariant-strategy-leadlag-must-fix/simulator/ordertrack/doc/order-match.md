# Order Match

This project's target is to copy order execution in backtest and compare to realtime order excution result.

## Strategy

Need to implement a strategy that copy realtime order execution.

* Realtime order record: @simulator/ordertrack/.claude/memory/project_ordertrack_data_format.md 
* Strategy Config Requires
  * symbols: symbols that need to simulate
  * pairs: map(maker symbol -> taker symbol) 
* Simulate operation, base on realtime order record info: 
  * SendOrderMs, Symbol, RequestQty, RequestPrc, TradeType
  * Use custom data source to schedule sending operation of the real time data.
    * The origin data might not be sorted, should do sort on SendOrderMs
  * In strategy OnOrder callback: when order is finished, log order final status
  * Strategy OnDepth: cache latest depth records in a map
  * Operation by order record TradeType:
    * maker:
      * find taker symbol from pair map, no need to check maker symbol existance.
      * log cached taker depth record as [DepthRecord](#depthrecord-type--depth)(record.OperationID, "maker-send")
      * set a scheduled callback at record.FinOrderMs by function Context.CallSignal
        * when called, log cached taker depth record as [DepthRecord](#depthrecord-type--depth)(record.OperationID, "maker-fin")
    * taker:
      * send order
      * log current cached taker depth record as [DepthRecord](#depthrecord-type--depth)(record.OperationId, "taker-send").
* Log: use package @utils/recorder to store json format record for analysis
  * Order: log [OrderRecord](#orderrecord-type--order) when Order is finished in OnOrderCallBack, wi
  * Depth: log [DepthRecord](#depthrecord-type--depth)(OperationId, optype) record
* Strategy structure, refer to @leadlag


## Log Record Structures

### OrderRecord (type = "order")

Tags:

| Field    | Type   | Description              |
|----------|--------|--------------------------|
| `type`   | string | Always `"order"`         |
| `symbol` | string | Taker symbol name        |

Fields:

| Field          | Type   | Source                         | Description                          |
|----------------|--------|--------------------------------|--------------------------------------|
| `cid`          | string | `msg.ClientID`                 | Client order ID                      |
| `oid`          | string | `msg.OrderID`                  | Exchange order ID                    |
| `operation_id` | string | `rec.OperationId`              | Operation ID from realtime record    |
| `side`         | int    | `msg.Side`                     | `-1` sell / `1` buy                  |
| `status`       | int    | `msg.Status`                   | Final order status code              |
| `request_prc`  | string | `rec.RequestPrc`               | Requested price                      |
| `request_qty`  | string | `rec.RequestQty`               | Requested quantity                   |
| `avg_price`    | float  | `msg.AvgFillPrc`               | Backtest average fill price          |
| `filled_qty`   | float  | `msg.FilledQty`                | Backtest filled quantity             |
| `send_ms`      | int64  | `rec.SendOrderMs`              | Order send time (Unix ms)            |
| `server_ms`    | int64  | `msg.ServerTime`               | Exchange server time (Unix ms)       |

### DepthRecord (type = "depth")

Tags:

| Field    | Type   | Description                                             |
|----------|--------|---------------------------------------------------------|
| `type`   | string | Always `"depth"`                                        |
| `symbol` | string | Taker symbol name (from `pairs` map for maker orders)   |

Fields:

| Field          | Type   | Source               | Description                                                  |
|----------------|--------|----------------------|--------------------------------------------------------------|
| `operation_id` | string | `rec.OperationId`    | Operation ID linking depth to the originating order          |
| `optype`   | string | caller               | `"taker-send"`, `"maker-send"`, or `"maker-fin"`             |
| `ask_prc`      | float  | `depth.Asks[0].Prc`  | Best ask price                                               |
| `ask_impact`   | float  | `depth.Asks` & rec.FillQty        | Average ask price with target qty inpact     |
| `ask_qty`      | float  | `depth.Asks[0].Qty`  | Best ask quantity                                            |
| `bid_prc`      | float  | `depth.Bids[0].Prc`  | Best bid price                                               |
| `bid_impact`   | float  | `depth.Bids`  & rec.FillQty         | Average bid price with target qty inpact     |
| `bid_qty`      | float  | `depth.Bids[0].Qty`  | Best bid quantity                                            |
| `server_ts`    | int64  | `depth.ServerTS`     | Depth server timestamp (Unix ms)                             |
| `resp_ts`      | int64  | `depth.RespTS`       | Depth response timestamp (Unix ms)                           |

`depth_type` values:

| Value          | When logged                                    |
|----------------|------------------------------------------------|
| `taker-send`   | Taker order sent (`HandleOrderRecord`)         |
| `maker-send`   | Maker order send time (`HandleOrderRecord`)    |
| `maker-fin`    | Maker order finish time (`OnSignal` callback)  |


## Analysis

Records should be grouped by OperationID for comparison.

### Slippage Definition

For a taker order:

```
slippage = side * (fill_price - base_price) / base_price 
```

Where `fill_price` is:
- **Backtest**: `OrderRecord.avg_price`
- **Realtime**: taker `FilledPrc`

`base_price` is the taker-side BBO price at a reference point in time, depending on optype.
For sell side (`side = -1`): use `bid_impact`. For buy side (`side = 1`): use `ask_impact`.

### Base Price Assumptions by optype

| optype | Reference time | Backtest base price | Realtime base price |
|---|---|---|---|
| `taker-send` | Taker `SendOrderMs` | DepthRecord(`optype=taker-send`) `bid_impact` / `ask_impact` | taker `FloatMsg.market_prc` |
| `maker-send` | Maker `SendOrderMs` | DepthRecord(`optype=maker-send`) `bid_impact` / `ask_impact` | maker `FloatMsg.depth_bbo_prc_{taker_symbol}` |
| `maker-fin`  | Maker `FinOrderMs`  | DepthRecord(`optype=maker-fin`) `bid_impact` / `ask_impact`  | not recorded in realtime |

Notes:
- `market_prc` in the taker record equals `RequestPrc` — it is the taker-symbol BBO price at order send time.
- `depth_bbo_prc_{taker_symbol}` in the maker record is the taker-symbol BBO price snapshotted when the maker order was placed. Key format: `depth_bbo_prc_` + taker symbol name (e.g. `depth_bbo_prc_bybit.perp.bard_usdt`).
- `maker-fin` has no realtime counterpart; it can only be evaluated in backtest.

### Other Metrics

* `taker_duration`: taker `FinOrderMs` - taker `SendOrderMs` (how long the taker fill took)
