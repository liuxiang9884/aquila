package main

import (
	_ "gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	_ "gitlab.com/hashingbotrepo/backend/xexchange/app/backtest"
)

func main() {

}
