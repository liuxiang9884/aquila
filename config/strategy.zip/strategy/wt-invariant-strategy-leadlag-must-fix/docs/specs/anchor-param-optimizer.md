# Plan: Anchor Strategy Parameter Optimizer

**Date**: 2026-03-17
**Updated**: 2026-03-18
**Status**: done
**Brief**: Python optimization script for anchor strategy parameters

## Context

The anchor strategy has ~15 tunable parameters across signal, tracker, and execution subsystems. Currently these are set manually in `strategy.json`. There is no automated way to sweep the parameter space — each candidate requires modifying the JSON, running the Go backtest, and reading `order.py` output by hand.

The goal is a Python script (`optimize.py`) that:
1. Reads a user-defined `optimize.json` describing explicit parameter choices
2. Runs a backtest for **every combination** (cartesian product) of the parameter space
3. Ranks all results by a chosen objective metric
4. Saves a full results table and the best config

Relevant existing code:
- `anchor/backtest/main.go` — CLI entry point: `go run backtest/main.go strategy -s <strategy.json> -b <backtest.json> -i <indicator.csv>`
- `anchor/backtest/order.py` — log parser and PnL analyzer (reusable as a library)
- `anchor/config/eth-v1/strategy.json` — example baseline strategy config

## Optimize Config File Format

```json
{
    "run": "eth-v1",
    "objective": "pnl_net_total",
    "jobs": 4,
    "opt_result": "/path/to/opt_results/eth-v1",
    "display_fields": ["filled", "pnl_net_total", "net_win_rate"],
    "params": [
        {"key": "signal.slippage.init", "alias": "slip", "type": "values", "values": [0.0001, 0.0002, 0.0003]},
        {"key": "signal.profit_target", "type": "range", "range": [0.00005, 0.0002], "step": 0.00005},
        {"type": "comb", "keys": ["tracker.a", "tracker.b"], "aliases": ["ta", "tb"],
         "values": [[1, 10], [2, 20], [3, 30]]}
    ],
    "backtest": [
        {"key": "period", "type": "values", "values": ["1h", "4h"]}
    ]
}
```

**Top-level fields:**

| Field | Type | Description |
|-------|------|-------------|
| `run` | string | Base run name. Resolves `strategy.json`, `backtest.json`, and indicator CSV via `$ANCHOR_CONFIG/<run>/`. |
| `objective` | string | Metric to rank by — see Objectives section. |
| `jobs` | int | Parallel workers via `ProcessPoolExecutor`. |
| `opt_result` | string | Output directory for results. Defaults to `$ANCHOR_OPT_RESULT/<run>` or `./<run>`. |
| `display_fields` | list | Summary fields to include in `results.csv` and top-10 table. Default: `["filled", "pnl_net_total", "net_win_rate"]`. |
| `params` | list | Strategy parameter search space — list of Description objects. |
| `backtest` | list | Backtest parameter search space — same Description format; placed before strategy params in the cartesian product. |
| `strategy` | string | _(optional)_ Explicit path to `strategy.json`, overrides `$ANCHOR_CONFIG` lookup. |
| `backtest_file` | string | _(optional)_ Explicit path to `backtest.json`, overrides `$ANCHOR_CONFIG` lookup. |
| `indicator` | string | _(optional)_ Explicit path to indicator CSV, overrides `$ANCHOR_CONFIG` lookup. |

## Param Description Format

`params` and `backtest` are both lists of **Description** objects. Each Description has:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | no | `"values"` (default), `"range"`, or `"comb"` |
| `key` | string | yes (except `comb`) | Dot-path into `strategy.json` (or `backtest.json` for `backtest` entries) |
| `alias` | string | no | Display name override for this key in output and CSV |
| `values` | list | yes for `values`; yes for `comb` | Explicit value list (`values` type) or list of correlated rows (`comb` type) |
| `range` | `[start, end]` | yes for `range` | Inclusive bounds |
| `step` | number | yes for `range` | Step size |
| `keys` | list of strings | yes for `comb` | Parallel dot-paths for a correlated group |
| `aliases` | list of strings | no | Per-key display name overrides for `comb`; `null` entries fall back to dot-path |

### Type details

**`values`** — explicit list, each entry is one candidate:
```json
{"key": "signal.slippage.init", "alias": "slip", "type": "values", "values": [0.0001, 0.0002, 0.0003]}
```

**`range`** — generates a sequence from `range[0]` to `range[1]` inclusive:
```json
{"key": "signal.profit_target", "type": "range", "range": [0.0001, 0.0005], "step": 0.0001}
```
Type rule: all-integer bounds and step → `range()`; otherwise → `np.arange()`, rounded to avoid float noise.

**`comb`** — correlated parameter group; each row in `values` is one joint candidate for all `keys`:
```json
{"type": "comb", "keys": ["tracker.fast", "tracker.slow"], "aliases": ["fast", "slow"],
 "values": [[5, 20], [10, 40], [20, 80]]}
```
This produces three candidates `{fast=5, slow=20}`, `{fast=10, slow=40}`, `{fast=20, slow=80}` — they move together as a single dimension in the cartesian product.

### Display name precedence

- `values` / `range`: `alias` field → dot-path (stripped of `bt:` prefix)
- `comb`: `aliases[i]` → dot-path, per key

### Cartesian product ordering

`backtest` entries are placed **before** `params` entries in the product, so backtest dimensions vary slowest (outermost loop) and appear as leading columns in output.

## Environment Variables

| Variable | Description |
|----------|-------------|
| `ANCHOR_CONFIG` | Base directory for named run configs (`$ANCHOR_CONFIG/<run>/`). |
| `ANCHOR_OPT_RESULT` | Default root for optimization output (`$ANCHOR_OPT_RESULT/<run>`). |
| `ANCHOR_INDICATOR` | Quantile file selector for indicator CSV (default: `q95`). |
| `LOG_DIR` / `LOG_FILE` | Set per-worker by the script; passed to the Go subprocess. |

All variables are loaded from `.env` in the current directory at startup (existing env vars are not overwritten).

## Objectives

| Value | Formula |
|-------|---------|
| `pnl_net_total` | `summary["pnl_net_total"]` |
| `pnl_gross_total` | `summary["pnl_gross_total"]` |
| `profit_rate` | `summary["profit_rate"]` |
| `net_win_rate` | `summary["net_win_rate"]` |
| `risk_adjusted` | `pnl_net_total × net_win_rate` |

## Execution Flow

```
optimize.json
      │
      ▼
  expand all param Descriptions → backtest dims first, then strategy dims
      │
      ▼
  itertools.product(*slot_lists)  →  N combinations
      │
      ▼
  ProcessPoolExecutor(max_workers=jobs)
      │
      └─ per combination:
           1. deep-copy base strategy.json, apply strategy param overrides
           2. deep-copy base backtest.json, apply backtest param overrides
           3. write strategy.json  →  opt_result/runs/<combo_id:06d>/strategy.json
           4. write backtest.json  →  opt_result/runs/<combo_id:06d>/backtest.json
           5. print exact go run command to stdout
           6. run Go backtest subprocess
              - cwd: repo root
              - LOG_DIR: opt_result/runs/<combo_id:06d>/ (absolute)
              - LOG_FILE: backtest.log
              - all paths passed as absolute
           7. print subprocess stdout to console
           8. parse log → order.analyze()
           9. return {params, summary, objective_value}
      │
      ▼
  collect all results → sort by objective → save results.csv + best_strategy.json [+ best_backtest.json]
```

On `KeyboardInterrupt` the executor cancels pending futures, each worker terminates its `go run` child process, and the script exits with code 130.

## Output

```
opt_result/
  backtest.json          # copy of base backtest.json used, for reference
  results.csv            # one row per combination, sorted by objective descending
  best_strategy.json     # base strategy with best combination's strategy params applied
  best_backtest.json     # base backtest with best combination's backtest params applied (only when backtest params are varied)
  runs/
    000000/
      strategy.json      # effective strategy config for this combination
      backtest.json      # effective backtest config for this combination
      backtest.log       # JSON-lines log from the Go backtest
    000001/
      ...
```

**`results.csv`** columns: `combo_id`, all display keys (alias or dot-path), `display_fields` metrics, `objective_value`.

Progress line per completed run:
```
[#000000] $ go run ... (exact command)
[1/900] #0  slip=0.0001  fast=5  slow=20  → pnl_net_total=12.345678
```

## CLI

```bash
# Scaffold an optimize config for a given run
python optimize.py init <run> [-s strategy.json] [-o optimize.json] [-r opt_result_dir]

# Preview the full combination space without running
python optimize.py comb <optimize.json>

# Run a grid search
python optimize.py run <optimize.json> [--jobs N] [--opt-result DIR] [--objective STR]
```

**`init`** options:

| Flag | Description |
|------|-------------|
| `-s`/`--strategy` | Explicit `strategy.json` path (overrides `$ANCHOR_CONFIG` lookup) |
| `-o`/`--output` | Output path for the generated `optimize.json` (default: `$ANCHOR_CONFIG/<run>/optimize.json` or `./optimize.json`) |
| `-r`/`--opt-result` | `opt_result` value written into the config (default: `$ANCHOR_OPT_RESULT/<run>` or `./<run>`) |

**`comb`** — loads the optimize config and prints the full combination space as a DataFrame. No backtests are run.

**`run`** flags override the config file: `--jobs`, `--opt-result`, `--objective`. The `params` and `backtest` blocks are config-file only.

## Alternatives Considered

| Approach | Reason ruled out |
|----------|--------------------|
| Optuna / Bayesian search | Samples a subset; doesn't guarantee full coverage of the specified space |
| CLI flags for param space | Verbose for many params; JSON file is cleaner and versionable |
| Nested JSON mirroring strategy.json | Dot-path flat keys are unambiguous; no partial-nesting ambiguity |
| `tempfile.TemporaryDirectory` for per-run files | Deleted on exit; persistent dirs under `opt_result/runs/` allow post-run inspection |
| Map format for params | List of Description objects supports richer metadata (alias, comb grouping) without ambiguity |

## Affected Files

| File | Change Type | Description |
|------|-------------|-------------|
| `anchor/backtest/optimize.py` | create | Main grid-search script |
| `anchor/backtest/test_optimize.py` | create | Unit tests for param expansion and combination building |
| `anchor/backtest/order.py` | none | Imported as a library; no modification |
