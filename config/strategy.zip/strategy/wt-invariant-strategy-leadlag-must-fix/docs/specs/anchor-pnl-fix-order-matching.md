# Spec: Correct PnL Calculation with Fix-Order Matching

## Problem

The anchor strategy executes **spread trades**: simultaneously taking opposite positions on two
exchanges (maker/taker). Each `action_summary` record bundles all orders from one action — maker
leg, taker leg, and optionally one or more **fix orders** that rebalance exchange-level imbalances.

Current `fifo_match_trades` uses `long_qty` (gross buys) or `short_qty` (gross sells) as the
position size for FIFO matching. This is incorrect when a fix order partially offsets one leg
within the same action, causing the position size to be overstated and PnL to be misattributed.

---

## Data Model

### Relevant `action_summary` fields

| Field | Example | Description |
|---|---|---|
| `exec` | `"OpenShort"` | Action type |
| `ids` | `"00000015,00000016"` | Comma-separated order CIDs |
| `maker_fill_qty` | `150` | Net fill on maker exchange (positive = bought) |
| `taker_fill_qty` | `-150` | Net fill on taker exchange (negative = sold) |
| `fix_fill_qty` | `0` | Fill quantity of the fix order (0 when absent) |
| `fix_cid` | `""` | CID of the fix order |

### Relevant `order` fields

| Field | Example | Description |
|---|---|---|
| `cid` | `"00000016"` | Client order ID |
| `exchange` | `"paradex"` | Exchange where the order was placed |
| `side` | `1` | +1 = buy, -1 = sell |
| `filled` | `150` | Filled quantity |
| `avg_price` | `0.4333` | Average fill price |
| `is_maker` | `true` | Whether the order posted as maker (limit resting); false = taker (aggressive) |

### Trade side

| `exec` | Trade side |
|---|---|
| `OpenLong`, `CloseShort` | `+1` |
| `OpenShort`, `CloseLong` | `-1` |

### Order roles within an action

Given `trade_side` from the table above:

| Role | `is_maker` | `side` | Identification rule |
|---|---|---|---|
| Maker leg | `true` | `-trade_side` | `is_maker=true` AND `side == -trade_side` |
| Taker leg | `false` | `+trade_side` | `is_maker=false` AND `side == +trade_side` |
| Fix order | `true` | `+trade_side` | `is_maker=true` AND `side == +trade_side` (wrong side for maker) |

> **Note:** `fix_cid`, `maker_cid`, `taker_cid`, `maker_fill_qty`, `taker_fill_qty` in
> `action_summary` are display/logging fields only. All calculations must be derived from raw
> order records looked up by the CIDs in the `ids` field, using `is_maker` and `side` to
> classify each order's role.

### Two-trade model

Each action produces **at most two trades**:

| Trade | Quantity | Avg prices | PnL | Fate |
|---|---|---|---|---|
| **Unrealized** | `spread_qty` | `maker_unrealized_avg`, `taker_unrealized_avg` | computed by FIFO when matched | Enters FIFO; PnL is realized when a future action closes it |
| **Realized** | `fix_qty` | — | `fix_pnl` (pre-computed) | Already closed within the same action; PnL is known immediately, no FIFO needed |

When `fix_qty == 0` the action produces only one trade (the unrealized spread).
The FIFO matching algorithm operates exclusively on unrealized trades.

---

## Scenarios

### Scenario 1 — Balanced fill (no fix, normal case)

```
OpenShort  trade_side = -1

  order A  is_maker=true,  side=+1 (-trade_side), filled=10, avg_price=P_m  → maker leg
  order B  is_maker=false, side=-1 (trade_side),  filled=10, avg_price=P_t  → taker leg

  maker_net = +10,  taker_net = -10,  fix_qty = 0
  spread_qty = min(10, 10) = 10 lots

  groups by (is_maker, side):
    long_maker:  qty=10, avg=P_m
    short_taker: qty=10, avg=P_t

  fix_pnl_maker = (short_maker.avg − long_maker.avg) * min(0, 10) = 0
  fix_pnl_taker = (short_taker.avg − long_taker.avg) * min(10, 0) = 0

  maker_unrealized_avg = long_maker.avg  = P_m   (trade_side < 0 → long is normal)
  taker_unrealized_avg = short_taker.avg = P_t   (trade_side < 0 → short is normal)

  spread_pnl = (+1) * 10 * (P_t − P_m)

  → unrealized trade: spread_qty=10, maker_avg=P_m, taker_avg=P_t  (enters FIFO)
  → realized trade:   none
```

Current code is correct here. `short_qty = 10` equals the actual spread size.

---

### Scenario 2 — Taker partial fill, fix rebalances maker (core bug)

```
OpenShort  trade_side = -1

  order A  is_maker=true,  side=+1 (-trade_side), filled=10, avg_price=P_m  → maker leg
  order B  is_maker=false, side=-1 (trade_side),  filled=5,  avg_price=P_t  → taker leg
  order C  is_maker=true,  side=-1 (trade_side),  filled=5,  avg_price=P_f  → fix

  maker_net = +10 + (-5) = +5   (fix folds into maker_net via is_maker)
  taker_net = -5
  fix_qty   = 5
  spread_qty = min(5, 5) = 5 lots

  groups by (is_maker, side):
    long_maker:  qty=10, avg=P_m   (order A)
    short_maker: qty=5,  avg=P_f   (order C — fix, wrong side for maker)
    short_taker: qty=5,  avg=P_t   (order B)

  fix_pnl_maker = (short_maker.avg − long_maker.avg) * short_maker.qty
                = (P_f − P_m) * 5
  fix_pnl_taker = 0   (no long_taker group)
  fix_pnl = 5*(P_f − P_m)

  maker_unrealized_avg = long_maker.avg  = P_m   (trade_side < 0 → long is normal)
  taker_unrealized_avg = short_taker.avg = P_t   (trade_side < 0 → short is normal)

  spread_pnl = (+1) * 5 * (P_t − P_m)

  check: spread_pnl + fix_pnl = 5*(P_t−P_m) + 5*(P_f−P_m) = 5*P_t + 5*P_f − 10*P_m = pnl_gross ✓

  → unrealized trade: spread_qty=5, maker_avg=P_m, taker_avg=P_t  (enters FIFO)
  → realized trade:   fix_qty=5, fix_pnl=5*(P_f − P_m)           (PnL known immediately)
```

Current code: `short_qty = 10` (gross sells: taker −5 + fix −5). FIFO uses 10 as position size,
overstating by 2×. The PnL from the internal 5-lot fix round-trip is attributed proportionally
to future close actions that have no relation to it.

---

### Scenario 3 — Fix overcorrects (rare edge case)

```
OpenShort  trade_side = -1

  order A  is_maker=true,  side=+1 (-trade_side), filled=10, avg_price=P_m  → maker leg
  order B  is_maker=false, side=-1 (trade_side),  filled=8,  avg_price=P_t  → taker leg
  order C  is_maker=true,  side=-1 (trade_side),  filled=3,  avg_price=P_f  → fix

  maker_net = +10 + (-3) = +7
  taker_net = -8
  fix_qty   = 3
  spread_qty = min(7, 8) = 7 lots
  Unhedged taker residual = 8 − 7 = 1 lot short on taker with no maker counterpart → unmatched

  groups by (is_maker, side):
    long_maker:  qty=10, avg=P_m   (order A)
    short_maker: qty=3,  avg=P_f   (order C — fix)
    short_taker: qty=8,  avg=P_t   (order B)

  fix_pnl_maker = (P_f − P_m) * 3
  fix_pnl_taker = 0
  fix_pnl = 3*(P_f − P_m)

  maker_unrealized_avg = P_m
  taker_unrealized_avg = P_t

  spread_pnl = (+1) * 7 * (P_t − P_m)

  check: spread_pnl + fix_pnl = 7*P_t + 3*P_f − 10*P_m
         pnl_gross             = 8*P_t + 3*P_f − 10*P_m
         difference            = P_t  ← unhedged taker lot, not attributed to either trade

  → unrealized trade: spread_qty=7, maker_avg=P_m, taker_avg=P_t  (enters FIFO)
  → realized trade:   fix_qty=3, fix_pnl=3*(P_f − P_m)           (PnL known immediately)
  → unhedged:         1 lot  (excluded from both; flag for investigation)
```

---

### Scenario 4 — Close action with its own fix

```
CloseShort  trade_side = +1

  order A  is_maker=true,  side=-1 (-trade_side), filled=10, avg_price=P_m  → maker leg
  order B  is_maker=false, side=+1 (trade_side),  filled=5,  avg_price=P_t  → taker leg
  order C  is_maker=true,  side=+1 (trade_side),  filled=5,  avg_price=P_f  → fix

  maker_net = -10 + 5 = -5   (fix folds into maker_net via is_maker)
  taker_net = +5
  fix_qty   = 5
  spread_qty = min(5, 5) = 5 lots

  groups by (is_maker, side):
    short_maker: qty=10, avg=P_m   (order A)
    long_maker:  qty=5,  avg=P_f   (order C — fix, wrong side for maker)
    long_taker:  qty=5,  avg=P_t   (order B)

  fix_pnl_maker = (short_maker.avg − long_maker.avg) * long_maker.qty
                = (P_m − P_f) * 5
  fix_pnl_taker = 0   (no short_taker group)
  fix_pnl = 5*(P_m − P_f)

  maker_unrealized_avg = short_maker.avg = P_m   (trade_side > 0 → short is normal)
  taker_unrealized_avg = long_taker.avg  = P_t   (trade_side > 0 → long is normal)

  spread_pnl = (-1) * 5 * (P_t − P_m) = 5*(P_m − P_t)

  check: spread_pnl + fix_pnl = 5*(P_m−P_t) + 5*(P_m−P_f) = 10*P_m − 5*P_t − 5*P_f = pnl_gross ✓

  → unrealized trade: spread_qty=5, maker_avg=P_m, taker_avg=P_t  (enters FIFO, matched against OpenShort)
  → realized trade:   fix_qty=5, fix_pnl=5*(P_m − P_f)           (PnL known immediately)
```

The fix is always on the maker exchange with the same side as `trade_side` — the exact opposite
of the normal maker leg, making it identifiable as a fix regardless of close or open direction.

---

## Root Cause

`compute_trade` accumulates global `long_qty` (all buys) and `short_qty` (all sells) across all
orders in an action regardless of exchange. For any spread action, both are always non-zero.
`fifo_match_trades` picks one (`short_qty` for `OpenShort`, `long_qty` for `OpenLong`) to
represent the spread size — but this is the **gross** directional quantity, not the **net
cross-exchange exposure**.

The fix order is always on the maker exchange (`is_maker=true`) with `side == trade_side` —
the same direction as the trade, opposite to the normal maker leg. It partially cancels the
maker-side gross fill, bringing `maker_net` in line with `taker_net`. Because `compute_trade`
does not classify orders by `is_maker` or `side`, it sees only gross directional totals and the
cancellation is invisible to the position-size calculation.

---

## Proposed Solution

### Step 1: Group orders and compute all trade quantities and PnL in `compute_trade`

Group all orders from `ids` by `(is_maker, side)`, accumulating qty and notional per group.
Do **not** use any display fields (`fix_cid`, `maker_cid`, `taker_cid`, `maker_fill_qty`, etc.):

```python
from collections import defaultdict

TRADE_SIDE = {"OpenLong": 1, "CloseShort": 1, "OpenShort": -1, "CloseLong": -1}
trade_side = TRADE_SIDE[row["exec"]]

grp_qty = defaultdict(float)   # (is_maker, side) → total filled
grp_ntl = defaultdict(float)   # (is_maker, side) → total notional

for cid in str(row["ids"]).split(","):
    order = order_index[cid.strip()]
    key   = (bool(order["is_maker"]), int(order["side"]))
    grp_qty[key] += float(order["filled"])
    grp_ntl[key] += float(order["filled"]) * float(order["avg_price"])

def grp_avg(is_maker, side):
    q = grp_qty[(is_maker, side)]
    return grp_ntl[(is_maker, side)] / q if q > 0 else 0.0

long_maker_qty,  long_maker_avg  = grp_qty[(True,  +1)], grp_avg(True,  +1)
short_maker_qty, short_maker_avg = grp_qty[(True,  -1)], grp_avg(True,  -1)
long_taker_qty,  long_taker_avg  = grp_qty[(False, +1)], grp_avg(False, +1)
short_taker_qty, short_taker_avg = grp_qty[(False, -1)], grp_avg(False, -1)

# Net position on each exchange (fix is included, so nets converge after a successful fix)
maker_net  = long_maker_qty  - short_maker_qty
taker_net  = long_taker_qty  - short_taker_qty   # will be negative for trade_side < 0

# Fix qty: the smaller (wrong-side) group on each exchange
fix_qty    = min(long_maker_qty, short_maker_qty) + min(long_taker_qty, short_taker_qty)

# Spread qty: net unrealized cross-exchange position change
spread_qty = min(abs(maker_net), abs(taker_net))

# Realized PnL: internal round-trip on each exchange
fix_pnl_maker = (short_maker_avg - long_maker_avg) * min(short_maker_qty, long_maker_qty)
fix_pnl_taker = (short_taker_avg - long_taker_avg) * min(short_taker_qty, long_taker_qty)
fix_pnl       = fix_pnl_maker + fix_pnl_taker

# Unrealized avg price: the normal-leg group for each exchange
maker_unrealized_avg = long_maker_avg  if trade_side < 0 else short_maker_avg
taker_unrealized_avg = short_taker_avg if trade_side < 0 else long_taker_avg

# Fee: split proportionally between unrealized and realized trades by qty
total_qty  = spread_qty + fix_qty
spread_fee = fee * spread_qty / total_qty if total_qty > 0 else 0.0
fix_fee    = fee - spread_fee
```

Add `spread_qty`, `fix_qty`, `maker_unrealized_avg`, `taker_unrealized_avg`, `spread_fee`,
`fix_pnl`, `fix_fee` as columns on the trades DataFrame. `spread_pnl` is **not**
pre-computed here — the FIFO step derives matched PnL from the avg prices of the open and
close actions.

### Step 2: FIFO matching operates only on unrealized trades

`fifo_match_trades` uses `spread_qty` as position size and the per-exchange unrealized avg
prices to compute matched PnL. Replace the `EXEC_QTY_FIELD` lookup with `spread_qty`:

```python
pos_qty = float(row.get("spread_qty", 0) or 0)
```

Rows where `spread_qty == 0` are skipped.

When a close action is matched against an open, the matched PnL is computed directly from
the avg prices of both actions — no pre-computed `spread_pnl` needed:

```python
# match_qty: overlapping qty between open and close (existing FIFO fraction logic)
open_frac  = match_qty / open_row["spread_qty"]
close_frac = match_qty / pos_qty

pnl_gross = match_qty * (
    (open_row["taker_unrealized_avg"] - open_row["maker_unrealized_avg"]) +   # open leg
    (close_row["maker_unrealized_avg"] - close_row["taker_unrealized_avg"])   # close leg
)
fee     = open_frac * open_row["spread_fee"] + close_frac * close_row["spread_fee"]
pnl_net = pnl_gross - fee
```

For OpenShort/CloseShort: open receives `taker−maker`, close receives `maker−taker`; the
formula is symmetric and handles all exec pairs through the sign embedded in the avg prices.

### Step 3: Surface realized fix PnL directly in the summary

`fix_pnl` is already realized — it bypasses FIFO and is added directly to the summary:

```python
"fix_realized_pnl":   trades["fix_pnl"].sum(),
"fix_realized_fee":   trades["fix_fee"].sum(),
"fix_realized_count": (trades["fix_qty"] > 0).sum(),
```

Reconciliation: `matched_pnl_gross (from FIFO) + fix_realized_pnl = pnl_gross_total`.

---

## Validation

Because fix orders bring the two exchange nets into balance, after a successful fix:

```
abs(maker_net) ≈ abs(taker_net) ≈ spread_qty
```

**Cross-check — nets converge when fix is present:**

```python
if fix_qty > 0:
    assert abs(abs(maker_net) - abs(taker_net)) < 1e-9
```

Optional cross-check using the display field `fix_fill_qty` from `action_summary`:

```python
# display field only — do not use in calculation
assert abs(fix_qty - abs(fix_fill_qty)) < 1e-9
```

In the overcorrect edge case (Scenario 3) the residual lot will violate the nets-converge
assert; flag those rows for separate investigation rather than treating them as fully matched
spread.

---

## Implementation Scope

| Component | Change |
|---|---|
| `compute_trade` | Group orders by `(is_maker, side)`; output `spread_qty`, `fix_qty`, `maker_unrealized_avg`, `taker_unrealized_avg`, `spread_fee`, `fix_pnl`, `fix_fee` |
| `compute_trades` | Pass through new columns |
| `fifo_match_trades` | Use `spread_qty` for position size; compute matched PnL from `maker_unrealized_avg`/`taker_unrealized_avg`; split fee via `spread_fee` |
| `analyze` | Add `fix_realized_pnl`, `fix_realized_fee`, `fix_realized_count` to summary |
| `test_fifo.py` | Add test cases with fix orders; verify split quantities and PnL allocation |

The interface of `fifo_match_trades` output (matched DataFrame columns) is **unchanged**.
