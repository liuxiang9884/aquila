# invariant-strategy

## Environment setup

### Prerequisites

- Go `1.23.4` (see `go.mod`)
- Access to the private GitLab hosting these repos (OAuth2 token recommended)

This project depends on three private Go modules:

- `gitlab.com/hashingbotrepo/backend/pinnaquant` (local checkout recommended)
- `gitlab.com/hashingbotrepo/backend/xexchange` (local checkout recommended)
- `git.hashingbot.com/aurthes/xex_mm_go` (resolved via `replace` to GitLab)

In `go.mod`, `pinnaquant` and `xexchange` are configured with `replace` directives pointing to `../pinnaquant` and `../xexchange`, so they are expected to be cloned next to this repo.

### Directory layout (required)

Clone the repos so they sit side-by-side:

```bash
backtest-go/
	invariant-strategy/
	pinnaquant/
	xexchange/
```

Example:

```bash
cd /path/to/backtest-go
git clone https://gitlab.com/hashingbotrepo/backend/pinnaquant.git
git clone https://gitlab.com/hashingbotrepo/backend/xexchange.git
git clone https://gitlab.com/hashingbotrepo/strategy/invariant-strategy.git
```

### Configure Go for private modules

Tell Go that these module paths are private (skip proxy and checksum DB):

```bash
go env -w GOPRIVATE=gitlab.com/hashingbotrepo/*
go env -w GONOSUMDB=gitlab.com/hashingbotrepo/*
```

Notes:

- Only `gitlab.com/hashingbotrepo/*` needs to be treated as private.
- Even though `go.mod` lists `git.hashingbot.com/aurthes/xex_mm_go`, it is redirected by `replace` to `gitlab.com/hashingbotrepo/strategy/xex_mm_go.git`, so authentication is still only needed for `gitlab.com`.

### Authenticate to the private GitLab (OAuth2)

All repos are hosted on a private GitLab that requires OAuth2 authentication.

The most common setup is to use a GitLab Personal Access Token (PAT) and let `git` supply it when `go` fetches modules.

#### Option B: git URL rewrite (HTTPS)

This makes `git` automatically inject the token for HTTPS fetches.

```bash
git config --global url."https://oauth2:<YOUR_GITLAB_TOKEN>@gitlab.com/".insteadOf "https://gitlab.com/"
```


### Fetch dependencies

Once the sibling repos exist and auth is set up:

```bash
cd invariant-strategy
go mod tidy
```

If `go` still prompts or fails, it usually means:

- `GOPRIVATE` isn’t set for the module path
- Your OAuth2 token lacks read permission
- The sibling repos are not at `../pinnaquant` and `../xexchange`
