#!/usr/bin/env python3
"""
基于 orders_export 的订单数据做回测绩效分析：
- 手续费率单笔 0.00016，计算费前/费后 PnL
- 按 liquidity 做容量放大，得到理论 PnL
- 同 backtest_id 多品种合并得到组合绩效
- 保存分析结果与图表
"""

import csv
import json
import math
import os
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    HAS_PLOT = True
except ImportError:
    HAS_PLOT = False
    mdates = None

import sys
BACKTEST_ROOT = Path(sys.argv[1]) if len(sys.argv) >1 else "."
ORDERS_DIR = BACKTEST_ROOT / "orders_export"
OUTPUT_DIR = BACKTEST_ROOT / "backtest_results"
CHARTS_DIR = OUTPUT_DIR / "charts"
# BACKTEST_ROOT = Path(__file__).resolve().parent / "gate-75"

# ORDERS_DIR = Path(__file__).resolve().parent / "orders_export"
# OUTPUT_DIR = Path(__file__).resolve().parent / "backtest_results"
# CHARTS_DIR = OUTPUT_DIR / "charts"
# BACKTEST_ROOT = Path(__file__).resolve().parent / "gate-75"
FEE_RATE = 0.00016  # 单笔手续费率


def load_latency(species: str, backtest_id: str) -> Optional[dict]:
    """从 gate-75/{species}/{backtest_id}.json 读取 latency 段。"""
    p = BACKTEST_ROOT / species / "{}.json".format(backtest_id)
    if not p.exists():
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("latency")
    except Exception:
        return None


def _num(x: Any) -> float:
    if x is None or x == "":
        return 0.0
    try:
        v = float(x)
        return v if math.isfinite(v) else 0.0
    except (ValueError, TypeError):
        return 0.0


def _latency_to_scalar(lat: Optional[dict]) -> Tuple[Optional[float], float, float, float, float]:
    """
    从 latency  dict 提取: (合计, lead_public, lag_req, lag_resp, lag_public)。
    若 lat 为空则合计为 None，各分量为 0。
    """
    if not lat or not isinstance(lat, dict):
        return (None, 0.0, 0.0, 0.0, 0.0)
    lead_p = _num((lat.get("lead") or {}).get("public", 0))
    lag_req = _num((lat.get("lag") or {}).get("req", 0))
    lag_resp = _num((lat.get("lag") or {}).get("resp", 0))
    lag_pub = _num((lat.get("lag") or {}).get("public", 0))
    total = lead_p + lag_req + lag_resp + lag_pub
    return (total, lead_p, lag_req, lag_resp, lag_pub)


def _corr(xs: List[float], ys: List[float]) -> Optional[float]:
    """Pearson 相关系数，至少 2 点。"""
    pairs = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
    if len(pairs) < 2:
        return None
    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]
    n = len(xs)
    xm = sum(xs) / n
    ym = sum(ys) / n
    cov = sum((x - xm) * (y - ym) for x, y in pairs)
    varx = sum((x - xm) ** 2 for x in xs)
    vary = sum((y - ym) ** 2 for y in ys)
    if varx <= 0 or vary <= 0:
        return None
    return cov / (math.sqrt(varx) * math.sqrt(vary))


def load_all_orders() -> List[dict]:
    """加载 orders_export 下所有 *_orders.csv。"""
    rows = []
    for p in sorted(ORDERS_DIR.glob("*_orders.csv")):
        with open(p, "r", encoding="utf-8-sig") as f:
            r = csv.DictReader(f)
            for d in r:
                d["_file"] = p.stem.replace("_orders", "")
                rows.append(d)
    return rows


def build_round_trips(rows: List[dict]) -> List[dict]:
    """
    按 (backtest_id, species, group) 匹配开-平，只保留 open.filled>0 且至少一个 close.filled>0 的回合。
    返回每笔: open_ts, close_ts, open_avg, close_vwap, qty, side, pnl_gross, commission, pnl_net,
             liq_open, liq_close, species, backtest_id。scale 与 pnl_capacity 在 main 中按 (species, backtest_id) 分组的 liquidity 中位数计算。
    """
    # (backtest_id, species, group) -> { "open": row | None, "closes": [rows] }
    by_group = defaultdict(lambda: {"open": None, "closes": []})
    for r in rows:
        bid = str(r.get("backtest_id", ""))
        sp = str(r.get("species", r.get("_file", "")))
        grp = str(r.get("group", ""))
        pos = str(r.get("position", "")).strip().lower()
        cid = str(r.get("cid", ""))
        if not grp:
            continue
        if pos == "open" and cid == grp:
            by_group[(bid, sp, grp)]["open"] = r
        elif pos == "close" and grp:
            by_group[(bid, sp, grp)]["closes"].append(r)

    trips = []
    for (bid, sp, grp), g in by_group.items():
        op = g["open"]
        closes = [c for c in g["closes"] if _num(c.get("filled", 0)) > 0]
        if op is None or _num(op.get("filled", 0)) <= 0 or not closes:
            continue
        open_avg = _num(op.get("avg", 0)) or _num(op.get("price", 0))
        open_filled = _num(op.get("filled", 0))
        side = _num(op.get("side", 0))
        if side == 0:
            side = 1.0
        close_qty = sum(_num(c.get("filled", 0)) for c in closes)
        if close_qty <= 0:
            continue
        close_vwap = sum(_num(c.get("avg", 0)) * _num(c.get("filled", 0)) for c in closes) / close_qty
        round_qty = min(open_filled, close_qty)
        if round_qty <= 0:
            continue
        # PnL: (close - open) * qty * side
        pnl_gross = (close_vwap - open_avg) * round_qty * side
        notional_open = open_avg * round_qty
        notional_close = close_vwap * round_qty
        commission = (notional_open + notional_close) * FEE_RATE
        pnl_net = pnl_gross - commission

        liq_open = _num(op.get("liquidity", 0))
        best = max(closes, key=lambda c: _num(c.get("filled", 0)))
        liq_close = _num(best.get("liquidity", 0))

        open_ts = str(op.get("ts", ""))
        close_ts = str(best.get("ts", ""))

        trips.append({
            "backtest_id": bid,
            "species": sp,
            "open_ts": open_ts,
            "close_ts": close_ts,
            "open_avg": open_avg,
            "close_vwap": close_vwap,
            "qty": round_qty,
            "side": side,
            "pnl_gross": pnl_gross,
            "commission": commission,
            "pnl_net": pnl_net,
            "liq_open": liq_open,
            "liq_close": liq_close,
        })
    return trips


def to_ts(s: str):
    """解析 '2026-01-08 00:15:58.424' 为可排序/画图用的数值。"""
    if not s or not isinstance(s, str):
        return 0.0
    s = s.strip()
    try:
        from datetime import datetime
        # 支持 2026-01-08 00:15:58.424
        if "." in s and " " in s:
            a, b = s.rsplit(".", 1)
            base = datetime.strptime(a.strip(), "%Y-%m-%d %H:%M:%S")
            frac = int(b.strip()[:6].ljust(6, "0")[:6]) / 1e6
            return base.timestamp() + frac
        return datetime.strptime(s[:19], "%Y-%m-%d %H:%M:%S").timestamp()
    except Exception:
        return 0.0


def run_single(sub: List[dict], species: str, backtest_id: str) -> Tuple[dict, Optional[Path], Optional[Path]]:
    """单品种-回测: 汇总统计 + PnL 曲线图 + 容量理论 PnL 图。传入已按 (species, backtest_id) 过滤的 trades。"""
    if not sub:
        return {}, None, None

    sub = sorted(sub, key=lambda t: to_ts(t["close_ts"]))
    total_gross = sum(t["pnl_gross"] for t in sub)
    total_comm = sum(t["commission"] for t in sub)
    total_net = sum(t["pnl_net"] for t in sub)
    total_cap = sum(t["pnl_capacity"] for t in sub)

    cum_gross = 0.0
    cum_net = 0.0
    cum_cap = 0.0
    curve_ts = []
    curve_gross = []
    curve_net = []
    curve_cap = []
    for t in sub:
        cum_gross += t["pnl_gross"]
        cum_net += t["pnl_net"]
        cum_cap += t["pnl_capacity"]
        ts = to_ts(t["close_ts"])
        curve_ts.append(ts)
        curve_gross.append(cum_gross)
        curve_net.append(cum_net)
        curve_cap.append(cum_cap)

    summary = {
        "species": species,
        "backtest_id": backtest_id,
        "trades": len(sub),
        "pnl_gross": total_gross,
        "commission": total_comm,
        "pnl_net": total_net,
        "pnl_capacity": total_cap,
    }

    # 保存单品种-回测的交易明细
    trades_subdir = OUTPUT_DIR / "trades"
    os.makedirs(trades_subdir, exist_ok=True)
    cols = ["open_ts", "close_ts", "open_avg", "close_vwap", "qty", "side", "pnl_gross", "commission", "pnl_net", "liq_open", "liq_close", "scale", "pnl_capacity"]
    with open(trades_subdir / f"trades_{species}_backtest_{backtest_id}.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for t in sub:
            w.writerow({k: t.get(k) for k in cols})

    fig1, fig2 = None, None
    if HAS_PLOT and curve_ts and mdates is not None:
        from datetime import datetime
        base = min(curve_ts)
        if base <= 0:
            base = 1
        x = [datetime.utcfromtimestamp(t) if t > 0 else datetime.utcfromtimestamp(1) for t in curve_ts]
        fig1, ax1 = plt.subplots(figsize=(10, 5))
        ax1.plot(x, curve_gross, label="PnL (before fee)", color="steelblue")
        ax1.plot(x, curve_net, label="PnL (after fee)", color="coral")
        ax1.axhline(0, color="gray", linestyle="--")
        ax1.legend()
        ax1.set_title(f"PnL Curve — {species} backtest_{backtest_id}")
        ax1.set_ylabel("Cumulative PnL")
        ax1.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
        plt.xticks(rotation=45)
        plt.tight_layout()
        p1 = CHARTS_DIR / f"pnl_{species}_backtest_{backtest_id}.png"
        fig1.savefig(str(p1), dpi=120, bbox_inches="tight")
        plt.close(fig1)

        fig2, ax2 = plt.subplots(figsize=(10, 5))
        ax2.plot(x, curve_cap, label="Theoretical PnL at capacity", color="green")
        ax2.axhline(0, color="gray", linestyle="--")
        ax2.legend()
        ax2.set_title(f"Theoretical PnL at Capacity — {species} backtest_{backtest_id}")
        ax2.set_ylabel("Cumulative PnL (capacity-scaled)")
        ax2.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
        plt.xticks(rotation=45)
        plt.tight_layout()
        p2 = CHARTS_DIR / f"pnl_capacity_{species}_backtest_{backtest_id}.png"
        fig2.savefig(str(p2), dpi=120, bbox_inches="tight")
        plt.close(fig2)
        fig1, fig2 = p1, p2

    return summary, (CHARTS_DIR / f"pnl_{species}_backtest_{backtest_id}.png") if HAS_PLOT and curve_ts else None, (CHARTS_DIR / f"pnl_capacity_{species}_backtest_{backtest_id}.png") if HAS_PLOT and curve_ts else None


def run_portfolio(trips: List[dict], backtest_id: str) -> Tuple[dict, Optional[Path], Optional[Path]]:
    """同 backtest_id 多品种合并：按 close_ts 排序后做累计 PnL，画组合曲线。"""
    sub = [t for t in trips if t["backtest_id"] == backtest_id]
    if not sub:
        return {}, None, None

    sub = sorted(sub, key=lambda t: to_ts(t["close_ts"]))
    total_gross = sum(t["pnl_gross"] for t in sub)
    total_comm = sum(t["commission"] for t in sub)
    total_net = sum(t["pnl_net"] for t in sub)
    total_cap = sum(t["pnl_capacity"] for t in sub)

    cum_gross = 0.0
    cum_net = 0.0
    cum_cap = 0.0
    curve_ts = []
    curve_gross = []
    curve_net = []
    curve_cap = []
    for t in sub:
        cum_gross += t["pnl_gross"]
        cum_net += t["pnl_net"]
        cum_cap += t["pnl_capacity"]
        curve_ts.append(to_ts(t["close_ts"]))
        curve_gross.append(cum_gross)
        curve_net.append(cum_net)
        curve_cap.append(cum_cap)

    summary = {
        "backtest_id": backtest_id,
        "trades": len(sub),
        "pnl_gross": total_gross,
        "commission": total_comm,
        "pnl_net": total_net,
        "pnl_capacity": total_cap,
    }

    # 保存组合的交易明细（按 close_ts 排序的合并结果）
    trades_subdir = OUTPUT_DIR / "trades"
    os.makedirs(trades_subdir, exist_ok=True)
    cols = ["species", "open_ts", "close_ts", "open_avg", "close_vwap", "qty", "side", "pnl_gross", "commission", "pnl_net", "liq_open", "liq_close", "scale", "pnl_capacity"]
    with open(trades_subdir / f"trades_portfolio_backtest_{backtest_id}.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for t in sub:
            w.writerow({k: t.get(k) for k in cols})

    p1, p2 = None, None
    if HAS_PLOT and curve_ts and mdates is not None:
        from datetime import datetime
        x = [datetime.utcfromtimestamp(t) if t > 0 else datetime.utcfromtimestamp(1) for t in curve_ts]
        fig1, ax1 = plt.subplots(figsize=(10, 5))
        ax1.plot(x, curve_gross, label="PnL (before fee)", color="steelblue")
        ax1.plot(x, curve_net, label="PnL (after fee)", color="coral")
        ax1.axhline(0, color="gray", linestyle="--")
        ax1.legend()
        ax1.set_title(f"Portfolio PnL Curve — backtest_{backtest_id}")
        ax1.set_ylabel("Cumulative PnL")
        ax1.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
        plt.xticks(rotation=45)
        plt.tight_layout()
        p1 = CHARTS_DIR / f"pnl_portfolio_backtest_{backtest_id}.png"
        fig1.savefig(str(p1), dpi=120, bbox_inches="tight")
        plt.close(fig1)

        fig2, ax2 = plt.subplots(figsize=(10, 5))
        ax2.plot(x, curve_cap, label="Theoretical PnL at capacity", color="green")
        ax2.axhline(0, color="gray", linestyle="--")
        ax2.legend()
        ax2.set_title(f"Portfolio Theoretical PnL at Capacity — backtest_{backtest_id}")
        ax2.set_ylabel("Cumulative PnL (capacity-scaled)")
        ax2.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
        plt.xticks(rotation=45)
        plt.tight_layout()
        p2 = CHARTS_DIR / f"pnl_capacity_portfolio_backtest_{backtest_id}.png"
        fig2.savefig(str(p2), dpi=120, bbox_inches="tight")
        plt.close(fig2)

    return summary, p1, p2


def run_latency_analysis(single_summaries: List[dict]) -> None:
    """
    分析延迟与回测结果的关系，重点关注：各品种 pnl_net 与 latency_lead_public、latency_lag_req 的关系。
    """
    rows = []
    for sm in single_summaries:
        lat = load_latency(sm["species"], sm["backtest_id"])
        total, lead_p, lag_req, lag_resp, lag_pub = _latency_to_scalar(lat)
        if total is None:
            continue
        rows.append({
            "species": sm["species"],
            "backtest_id": sm["backtest_id"],
            "latency_lead_public": lead_p,
            "latency_lag_req": lag_req,
            "latency_lag_resp": lag_resp,
            "latency_lag_public": lag_pub,
            "latency_total": total,
            "trades": sm["trades"],
            "pnl_gross": sm["pnl_gross"],
            "commission": sm["commission"],
            "pnl_net": sm["pnl_net"],
            "pnl_capacity": sm["pnl_capacity"],
        })
    if not rows:
        return

    cols = ["species", "backtest_id", "latency_lead_public", "latency_lag_req", "latency_lag_resp", "latency_lag_public",
            "latency_total", "trades", "pnl_gross", "commission", "pnl_net", "pnl_capacity"]
    with open(OUTPUT_DIR / "latency_analysis.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

    # 各品种：pnl_net 与 latency_lead_public、pnl_net 与 latency_lag_req 的相关系数
    species_list = sorted(set(r["species"] for r in rows))
    lines = [
        "Latency vs pnl_net (focus: latency_lead_public, latency_lag_req)",
        "Per-species: Correlation(pnl_net, latency_lead_public), Correlation(pnl_net, latency_lag_req)",
        "N = %d" % len(rows),
        "",
    ]
    for s in species_list:
        sub = [r for r in rows if r["species"] == s]
        x_lead = [r["latency_lead_public"] for r in sub]
        x_lag = [r["latency_lag_req"] for r in sub]
        y = [r["pnl_net"] for r in sub]
        c_lead = _corr(x_lead, y)
        c_lag = _corr(x_lag, y)
        lines.append("%s:  corr(pnl_net, latency_lead_public)=%s,  corr(pnl_net, latency_lag_req)=%s  (n=%d)" % (
            s,
            ("%.4f" % c_lead) if c_lead is not None else "N/A",
            ("%.4f" % c_lag) if c_lag is not None else "N/A",
            len(sub),
        ))
    # 全体
    x_lead_all = [r["latency_lead_public"] for r in rows]
    x_lag_all = [r["latency_lag_req"] for r in rows]
    y_all = [r["pnl_net"] for r in rows]
    c_lead_all = _corr(x_lead_all, y_all)
    c_lag_all = _corr(x_lag_all, y_all)
    lines.extend([
        "",
        "Overall:  corr(pnl_net, latency_lead_public)=%s,  corr(pnl_net, latency_lag_req)=%s" % (
            ("%.4f" % c_lead_all) if c_lead_all is not None else "N/A",
            ("%.4f" % c_lag_all) if c_lag_all is not None else "N/A",
        ),
    ])
    with open(OUTPUT_DIR / "latency_correlation.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # 绘图：pnl_net vs latency_lead_public、pnl_net vs latency_lag_req，按品种着色
    if not HAS_PLOT or not rows:
        return

    def _regress(xs, ys):
        n = len(xs)
        if n == 0:
            return 0.0, 0.0
        xm = sum(xs) / n
        ym = sum(ys) / n
        cov = sum((x - xm) * (y - ym) for x, y in zip(xs, ys))
        varx = sum((x - xm) ** 2 for x in xs)
        if varx <= 0:
            return 0.0, ym
        a = cov / varx
        b = ym - a * xm
        return a, b

    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"]
    color_map = {s: colors[i % len(colors)] for i, s in enumerate(species_list)}

    x_lead = [r["latency_lead_public"] for r in rows]
    x_lag = [r["latency_lag_req"] for r in rows]
    y_pnl = [r["pnl_net"] for r in rows]

    a1, b1 = _regress(x_lead, y_pnl)
    a2, b2 = _regress(x_lag, y_pnl)
    x1_min, x1_max = min(x_lead), max(x_lead)
    x2_min, x2_max = min(x_lag), max(x_lag)
    x1_line = [x1_min, x1_max] if x1_min < x1_max else [x1_min]
    x2_line = [x2_min, x2_max] if x2_min < x2_max else [x2_min]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    for s in species_list:
        sub = [r for r in rows if r["species"] == s]
        if not sub:
            continue
        x1 = [r["latency_lead_public"] for r in sub]
        y1 = [r["pnl_net"] for r in sub]
        ax1.scatter(x1, y1, alpha=0.7, color=color_map[s], label=s, s=50)
    ax1.plot(x1_line, [a1 * xx + b1 for xx in x1_line], "k--", linewidth=1.5, label="trend (all)")
    ax1.axhline(0, color="gray", linestyle=":")
    ax1.set_xlabel("latency_lead_public")
    ax1.set_ylabel("pnl_net")
    ax1.set_title("pnl_net vs latency_lead_public (by species)")
    ax1.legend(loc="best", fontsize=7)

    for s in species_list:
        sub = [r for r in rows if r["species"] == s]
        if not sub:
            continue
        x2 = [r["latency_lag_req"] for r in sub]
        y2 = [r["pnl_net"] for r in sub]
        ax2.scatter(x2, y2, alpha=0.7, color=color_map[s], label=s, s=50)
    ax2.plot(x2_line, [a2 * xx + b2 for xx in x2_line], "k--", linewidth=1.5, label="trend (all)")
    ax2.axhline(0, color="gray", linestyle=":")
    ax2.set_xlabel("latency_lag_req")
    ax2.set_ylabel("pnl_net")
    ax2.set_title("pnl_net vs latency_lag_req (by species)")
    ax2.legend(loc="best", fontsize=7)

    plt.tight_layout()
    fig.savefig(str(CHARTS_DIR / "latency_vs_metrics.png"), dpi=120, bbox_inches="tight")
    plt.close(fig)


def main():

    # print(BACKTEST_ROOT)
    # print(ORDERS_DIR)
    # print(OUTPUT_DIR)
    # print(CHARTS_DIR)
    # return 
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(CHARTS_DIR, exist_ok=True)

    rows = load_all_orders()
    # 兼容: 若无 backtest_id/species，从 _file 解析 species，backtest_id 需要从文件名推断则缺省
    for r in rows:
        if not r.get("species"):
            r["species"] = r.get("_file", "unknown")
        if r.get("backtest_id") is None or r.get("backtest_id") == "":
            r["backtest_id"] = "0"

    trips = build_round_trips(rows)

    # 按 (species, backtest_id) 分组计算 liquidity 中位数，再据此算 scale 与 pnl_capacity
    def _median(s):
        if not s:
            return 0.0
        s = sorted(s)
        n = len(s)
        return (s[(n - 1) // 2] + s[n // 2]) / 2.0

    liq_by_group = defaultdict(list)
    for r in rows:
        v = _num(r.get("liquidity", 0))
        if v > 0:  # 剔除 0 等异常值后再参与中位数计算
            k = (str(r.get("species", "")), str(r.get("backtest_id", "")))
            liq_by_group[k].append(v)
    median_by_group = {k: _median(liq_list) for k, liq_list in liq_by_group.items()}

    for t in trips:
        key = (t["species"], t["backtest_id"])
        median_liq = median_by_group.get(key, 0.0) or 0.0
        notional = t["open_avg"] * t["qty"]
        scale = (median_liq / notional) if (notional > 0 and median_liq > 0) else 1.0
        t["scale"] = scale
        t["pnl_capacity"] = t["pnl_net"] * scale

    # 写所有回合明细
    if trips:
        cols = ["backtest_id", "species", "open_ts", "close_ts", "open_avg", "close_vwap", "qty", "side",
                "pnl_gross", "commission", "pnl_net", "liq_open", "liq_close", "scale", "pnl_capacity"]
        with open(OUTPUT_DIR / "trades_all.csv", "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            for t in trips:
                w.writerow({k: t.get(k) for k in cols})

    # 单品种-回测：预索引，避免重复过滤
    idx = defaultdict(list)
    for t in trips:
        idx[(t["species"], t["backtest_id"])].append(t)
    single_summaries = []
    for (species, bid), sub in idx.items():
        sm, _, _ = run_single(sub, species, bid)  # 传入该 (s,b) 的 sub，不再全量过滤
        if sm:
            single_summaries.append(sm)

    # 组合
    bid_done = set()
    port_summaries = []
    for t in trips:
        bid = t["backtest_id"]
        if bid in bid_done:
            continue
        bid_done.add(bid)
        ps, pp1, pp2 = run_portfolio(trips, bid)
        if ps:
            port_summaries.append(ps)

    # 保存汇总：将 backtest_id 与 gate-75/{species}/{backtest_id}.json 中的 latency 关联后输出
    for sm in single_summaries:
        lat = load_latency(sm["species"], sm["backtest_id"])
        sm["latency"] = json.dumps(lat, ensure_ascii=False) if lat else ""

    with open(OUTPUT_DIR / "summary_single.csv", "w", newline="", encoding="utf-8-sig") as f:
        if single_summaries:
            w = csv.DictWriter(f, fieldnames=["species", "backtest_id", "latency", "trades", "pnl_gross", "commission", "pnl_net", "pnl_capacity"], extrasaction="ignore")
            w.writeheader()
            w.writerows(single_summaries)

    # 延迟与回测结果关系：分析、绘图并保存
    run_latency_analysis(single_summaries)

    for ps in port_summaries:
        bid = ps["backtest_id"]
        species_for_bid = [s for (s, b) in idx if b == bid]
        lat_by_species = {}
        for s in species_for_bid:
            lat = load_latency(s, bid)
            if lat is not None:
                lat_by_species[s] = lat
        ps["latency"] = json.dumps(lat_by_species, ensure_ascii=False) if lat_by_species else ""

    with open(OUTPUT_DIR / "summary_portfolio.csv", "w", newline="", encoding="utf-8-sig") as f:
        if port_summaries:
            w = csv.DictWriter(f, fieldnames=["backtest_id", "latency", "trades", "pnl_gross", "commission", "pnl_net", "pnl_capacity"], extrasaction="ignore")
            w.writeheader()
            w.writerows(port_summaries)

    # 简单文字报告
    report = [
        "Backtest Performance Report",
        "Fee rate per side: %.5f" % FEE_RATE,
        "Round trips: %d" % len(trips),
        "",
        "Single (species x backtest_id) summaries: %d" % len(single_summaries),
        "Portfolio (by backtest_id) summaries: %d" % len(port_summaries),
        "Charts and CSVs saved under: %s" % OUTPUT_DIR,
        "",
        "Latency vs results: latency_analysis.csv, latency_correlation.txt, charts/latency_vs_metrics.png",
    ]
    with open(OUTPUT_DIR / "report.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(report))

    print("Done. Results in: %s" % OUTPUT_DIR)
    print("  trades_all.csv, summary_single.csv, summary_portfolio.csv, report.txt")
    print("  latency_analysis.csv, latency_correlation.txt")
    print("  charts/: pnl_*, pnl_capacity_*, pnl_portfolio_*, pnl_capacity_portfolio_*, latency_vs_metrics.png")


if __name__ == "__main__":
    main()
