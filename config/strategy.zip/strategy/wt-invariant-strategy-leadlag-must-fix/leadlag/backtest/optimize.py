#!/usr/bin/env python3
"""
Optimization script for lead-lag strategy latency parameters.

This script runs backtests with different latency combinations and collects
performance metrics to find optimal latency settings.

Usage:
    # Single optimization
    python optimize.py -s config/strategy/river.json -b config/backtest/0.json -o config/optimization/latency_search.json
    
    # Batch optimization from group file
    python optimize.py -g target.json -s config/strategy/template.json -b config/backtest/template.json -o config/optimization/latency_search.json --processes 4
    
    # Merge all summary results
    python optimize.py merge --results-dir results/optimization --output merged_summary.csv
"""

import argparse
import json
import os
import signal
import subprocess
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from contextlib import redirect_stderr, redirect_stdout
from itertools import product
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import pandas as pd


_ACTIVE_SUBPROCS: "set[subprocess.Popen]" = set()


def _terminate_process_group(proc: subprocess.Popen, sig: int) -> None:
    """Best-effort terminate a process group started via start_new_session=True."""
    try:
        os.killpg(proc.pid, sig)
    except ProcessLookupError:
        return
    except Exception:
        # Fall back to signaling the direct process.
        try:
            proc.send_signal(sig)
        except Exception:
            return


def _cleanup_active_subprocs(sig: int) -> None:
    # Copy to avoid mutation during iteration.
    procs = list(_ACTIVE_SUBPROCS)
    for proc in procs:
        _terminate_process_group(proc, sig)


def _install_signal_handlers() -> None:
    """Install handlers that terminate child subprocesses on SIGINT/SIGTERM."""

    def _handler(signum, _frame):
        # Forward the signal to any active subprocesses, then exit.
        _cleanup_active_subprocs(signum)

        if signum == signal.SIGINT:
            raise KeyboardInterrupt
        raise SystemExit(143)  # conventional exit code for SIGTERM

    # Only install once per process.
    for sig in (signal.SIGINT, signal.SIGTERM):
        current = signal.getsignal(sig)
        if current is _handler:
            continue
        signal.signal(sig, _handler)


def _run_command(
    cmd: List[str],
    *,
    env: Optional[dict] = None,
    cwd: Optional[str] = None,
    quiet: bool = False,
    capture_stderr: bool = False,
    timeout: Optional[float] = None,
) -> subprocess.CompletedProcess:
    """Run a subprocess that is reliably terminated on Ctrl-C.

    Uses a new process session so we can signal the whole group.
    """
    _install_signal_handlers()

    popen_kwargs = {
        "env": env,
        "cwd": cwd,
        "text": True,
        "start_new_session": True,
    }
    if quiet:
        popen_kwargs["stdout"] = subprocess.PIPE
        popen_kwargs["stderr"] = subprocess.PIPE
    elif capture_stderr:
        popen_kwargs["stderr"] = subprocess.PIPE

    proc = subprocess.Popen(cmd, **popen_kwargs)
    _ACTIVE_SUBPROCS.add(proc)

    try:
        stdout, stderr = proc.communicate(timeout=timeout)
        return subprocess.CompletedProcess(cmd, proc.returncode, stdout, stderr)
    except subprocess.TimeoutExpired:
        _terminate_process_group(proc, signal.SIGTERM)
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            _terminate_process_group(proc, signal.SIGKILL)
            proc.wait(timeout=2)
        raise
    except KeyboardInterrupt:
        # Forward SIGINT to the child process group, then escalate if needed.
        _terminate_process_group(proc, signal.SIGINT)
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            _terminate_process_group(proc, signal.SIGTERM)
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                _terminate_process_group(proc, signal.SIGKILL)
                proc.wait(timeout=2)
        raise
    finally:
        _ACTIVE_SUBPROCS.discard(proc)


def load_json(filepath: str) -> dict:
    """Load JSON configuration file."""
    with open(filepath, 'r') as f:
        return json.load(f)


def save_json(filepath: str, data: dict):
    """Save data to JSON file."""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)


def generate_latency_combinations(opt_config: dict) -> List[Tuple[int, Dict]]:
    """
    Generate all combinations of latency settings with unique indices.
    
    Returns:
        List of (index, latency_config) tuples
    """
    lead_latencies = opt_config['lead_latencies']
    lag_latencies = opt_config['lag_latencies']
    
    # Generate all combinations
    combinations = []
    index = 0
    
    for lead_profile in lead_latencies:
        for lag_profile in lag_latencies:
            config = {
                'lead': lead_profile,
                'lag': lag_profile
            }
            combinations.append((index, config))
            index += 1
    
    return combinations


def generate_backtest_config(base_config: dict, strategy_config: dict, latency_config: dict) -> dict:
    """
    Generate backtest configuration with specified latencies.
    
    Parameters:
        base_config: Base backtest configuration template
        strategy_config: Strategy configuration
        latency_config: Latency settings for lead and lag
    
    Returns:
        Modified backtest configuration
    """
    config = json.loads(json.dumps(base_config))  # Deep copy
    
    # Update latencies for lead exchange
    lead_exchange = strategy_config['lead']
    if 'latencies' not in config:
        config['latencies'] = {}
    
    lead_latency = latency_config.get('lead', {})
    config['latencies'][lead_exchange] = {
        'req': {
            'type': 'fixed',
            'fixed': lead_latency.get('req', 0),
            'real': False
        },
        'resp': {
            'type': 'fixed',
            'fixed': lead_latency.get('resp', 0),
            'real': False
        },
        'public': {
            'type': 'fixed',
            'fixed': lead_latency.get('public', 0),
            'real': False
        }
    }
    
    # Update latencies for lag exchange
    lag_exchange = strategy_config.get('lag', '')
    lag_latency = latency_config.get('lag', {})
    config['latencies'][lag_exchange] = {
        'req': {
            'type': 'fixed',
            'fixed': lag_latency.get('req', 0),
            'real': False
        },
        'resp': {
            'type': 'fixed',
            'fixed': lag_latency.get('resp', 0),
            'real': False
        },
        'public': {
            'type': 'fixed',
            'fixed': lag_latency.get('public', 0),
            'real': False
        }
    }
    
    return config


def run_backtest(strategy_file: str, backtest_file: str, log_dir: str, log_file: str, quiet: bool = False) -> bool:
    """
    Run the Go backtest simulation.
    
    Parameters:
        strategy_file: Path to strategy config
        backtest_file: Path to backtest config
        log_dir: Log directory
        log_file: Log file name
        quiet: If True, suppress backtest output
    
    Returns:
        True if successful, False otherwise
    """
    env = os.environ.copy()
    env['LOG_DIR'] = log_dir
    env['LOG_FILE'] = log_file
    
    cmd = ['go', 'run', 'backtest/main.go', '-s', strategy_file, '-b', backtest_file]
    print("Running command:", ' '.join(cmd))
    
    try:
        start_time = time.time()
        result = _run_command(cmd, env=env, quiet=quiet, capture_stderr=True)
        duration = time.time() - start_time
        
        print(f"Backtest completed in {duration:.2f}s")
        
        if result.returncode != 0:
            print(f"Error running backtest (exit code: {result.returncode})")
            if result.stderr:
                print(result.stderr)
            return False
        return True
    except subprocess.TimeoutExpired:
        print("Backtest timeout")
        return False
    except KeyboardInterrupt:
        print("Interrupted by user (Ctrl-C). Stopping backtest...")
        raise
    except Exception as e:
        print(f"Error running backtest: {e}")
        return False


def analyze_performance(strategy_file: str, log_dir: str, log_file: str, output_file: str) -> dict:
    """
    Analyze performance using order.py script.
    
    Parameters:
        strategy_file: Path to strategy config
        log_dir: Log directory
        log_file: Log file name
        output_file: Path to save JSON results
    
    Returns:
        Performance summary dictionary
    """
    logfile_path = os.path.join(log_dir, log_file)
    
    # Run order.py with JSON output to file (displays summary to console)
    cmd = [sys.executable, 'backtest/order.py', '-s', strategy_file, '-l', logfile_path, '-j', '-o', output_file]
    
    try:
        result = _run_command(cmd)
        if result.returncode != 0:
            print("Error analyzing performance")
            return None
        
        # Load JSON from output file
        with open(output_file, 'r') as f:
            output = json.load(f)
        
        return output
    except subprocess.TimeoutExpired:
        print("Analysis timeout")
        return None
    except KeyboardInterrupt:
        print("Interrupted by user (Ctrl-C). Stopping analysis...")
        raise
    except Exception as e:
        print(f"Error analyzing performance: {e}")
        return None


def merge_summaries(results_dir: str, output_file: str):
    """Merge all summary.csv files from optimization results into one file."""
    print(f"Scanning {results_dir} for summary files...")
    
    all_summaries = []
    
    # Walk through results directory
    for dirpath, dirnames, filenames in os.walk(results_dir):
        if 'summary.csv' in filenames:
            summary_path = os.path.join(dirpath, 'summary.csv')
            
            # Extract lead, lag, symbol from directory name
            # Format: {lead}-{lag}-{symbol}
            dirname = os.path.basename(dirpath)
            parts = dirname.split('-', 2)  # Split into 3 parts max
            
            if len(parts) == 3:
                lead, lag, symbol = parts
                
                # Read summary CSV
                try:
                    df = pd.read_csv(summary_path)
                    
                    # Add metadata columns at the beginning
                    df.insert(0, 'symbol', symbol)
                    df.insert(0, 'lag', lag)
                    df.insert(0, 'lead', lead)
                    
                    all_summaries.append(df)
                    print(f"Loaded: {dirname} ({len(df)} rows)")
                except Exception as e:
                    print(f"Error reading {summary_path}: {e}")
            else:
                print(f"Skipping {dirname}: unexpected format")
    
    if not all_summaries:
        print("No summary files found!")
        return
    
    # Concatenate all summaries
    merged_df = pd.concat(all_summaries, ignore_index=True)
    
    # Save merged summary
    merged_df.to_csv(output_file, index=False)
    print(f"\nMerged {len(all_summaries)} summaries into {output_file}")
    print(f"Total rows: {len(merged_df)}")
    print(f"Columns: {', '.join(merged_df.columns)}")
    
    # Show top performers
    if 'net_profit_rate' in merged_df.columns:
        print("\nTop 10 configurations by net profit rate:")
        top10 = merged_df.nlargest(10, 'net_profit_rate')[['lead', 'lag', 'symbol', 'index', 
                                                             'lead_req', 'lead_resp', 'lead_pub',
                                                             'lag_req', 'lag_resp', 'lag_pub',
                                                             'net_profit_rate', 'total_trades']]
        print(top10.to_string(index=False))


def main():
    parser = argparse.ArgumentParser(description='Optimize latency parameters for lead-lag strategy')
    
    # Add subcommands
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Merge command
    merge_parser = subparsers.add_parser('merge', help='Merge all summary files into one')
    merge_parser.add_argument('--results-dir', required=True, help='Directory containing optimization results')
    merge_parser.add_argument('--output', default='merged_summary.csv', help='Output CSV file (default: merged_summary.csv)')
    
    # Optimize command (default)
    parser.add_argument('-s', '--strategy', help='Path to strategy config JSON file')
    parser.add_argument('-b', '--backtest', help='Path to base backtest config JSON file')
    parser.add_argument('-o', '--optimization', help='Path to optimization config JSON file')
    parser.add_argument('-g', '--group', help='Path to group/search file (for batch mode)')
    parser.add_argument('--processes', type=int, default=1, help='Number of concurrent processes (default: 1)')
    parser.add_argument('--output-dir', default='results/optimization',
                       help='Output directory for results (default: results/optimization)')
    parser.add_argument('--log-dir', help='Log directory (default: from environment or current dir)')
    parser.add_argument('--log-file', help='Temporary log file name (default: auto-generated based on strategy)')
    parser.add_argument('-q', '--quiet', action='store_true',
                       help='Suppress backtest output (only show summary)')
    args = parser.parse_args()
    
    try:
        # Handle merge command
        if args.command == 'merge':
            merge_summaries(args.results_dir, args.output)
            return
    
        # Handle optimization commands
        if not args.optimization:
            parser.error("the following arguments are required: -o/--optimization (unless using merge command)")

        if not args.strategy or not args.backtest:
            parser.error("the following arguments are required: -s/--strategy and -b/--backtest")

        # Check if batch mode
        if args.group:
            run_batch_optimization(args)
        else:
            run_single_optimization(args)
    except KeyboardInterrupt:
        # Ensure any child processes are terminated.
        _cleanup_active_subprocs(signal.SIGINT)
        print("\nStopped by user (Ctrl-C).")
        raise


def run_batch_optimization(args):
    """Run optimization for multiple symbols from group file."""
    print("Loading batch configuration...")
    search_data = load_json(args.group)
    strategy_template = load_json(args.strategy)
    backtest_template = load_json(args.backtest)
    opt_config = load_json(args.optimization)
    
    # Parse search results
    tasks = []
    for symbol_key, results_list in search_data.get('results', {}).items():
        # Extract symbol name (remove _swap suffix if present)
        symbol = symbol_key.replace('_swap', '')
        
        for result in results_list:
            exchanges = result.get('exchanges', [])
            if len(exchanges) < 2:
                print(f"Skipping {symbol_key}: insufficient exchanges")
                continue
            
            lead_exchange = exchanges[0]
            lag_exchange = exchanges[1]
            date_range = result.get('date_range', {})
            
            task = {
                'symbol': symbol,
                'lead': lead_exchange,
                'lag': lag_exchange,
                'date_range': date_range,
                'strategy_template': strategy_template,
                'backtest_template': backtest_template,
                'opt_config': opt_config,
                'args': args
            }
            tasks.append(task)
    
    total_tasks = len(tasks)
    print(f"\nGenerated {total_tasks} optimization tasks")
    
    if args.processes == 1:
        # Sequential execution
        for i, task in enumerate(tasks):
            print(f"\n{'='*80}")
            print(f"Processing task {i+1}/{total_tasks}: {task['symbol']} "
                  f"({task['lead']}-{task['lag']})")
            run_optimization_task(task)
    else:
        # Parallel execution
        print(f"Running optimizations with {args.processes} concurrent processes...")
        with ProcessPoolExecutor(max_workers=args.processes) as executor:
            futures = {executor.submit(run_optimization_task, task): task for task in tasks}

            try:
                for i, future in enumerate(as_completed(futures)):
                    task = futures[future]
                    try:
                        future.result()
                        print(f"Completed {i+1}/{total_tasks}: {task['symbol']} "
                              f"({task['lead']}-{task['lag']})")
                    except Exception as e:
                        print(f"Failed {task['symbol']} ({task['lead']}-{task['lag']}): {e}")
            except KeyboardInterrupt:
                print("\nInterrupted by user (Ctrl-C). Shutting down workers...")
                # Stop scheduling and cancel pending futures.
                executor.shutdown(wait=False, cancel_futures=True)
                # Best-effort terminate worker processes (private API).
                processes = getattr(executor, "_processes", None)
                if processes:
                    for p in processes.values():
                        try:
                            p.terminate()
                        except Exception:
                            pass
                raise
    
    print(f"\n{'='*80}")
    print("Batch optimization complete!")


def run_optimization_task(task):
    """Run optimization for a single task (used in batch mode)."""
    # Generate strategy config
    strategy_config = task['strategy_template'].copy()
    strategy_config['symbol'] = task['symbol']
    strategy_config['lead'] = task['lead']
    strategy_config['lag'] = task['lag']
    
    # Use backtest template and update date range
    backtest_config = json.loads(json.dumps(task['backtest_template']))  # Deep copy
    if 'group' in backtest_config and 'hourly' in backtest_config['group']:
        backtest_config['group']['hourly']['range'] = [
            task['date_range'].get('start', ''),
            task['date_range'].get('end', '')
        ]
    
    # Save temporary configs
    args = task['args']

    # For batch mode, redirect all stdout/stderr into this symbol-pair's output dir,
    # and also write Go backtest logs under the same tree.
    output_base = os.path.join(args.output_dir, f"{task['lead']}-{task['lag']}-{task['symbol']}")
    os.makedirs(output_base, exist_ok=True)
    task_log_dir = os.path.join(output_base, "logs")
    os.makedirs(task_log_dir, exist_ok=True)
    
    temp_strategy_file = os.path.join(task_log_dir, 
        f'strategy_temp_{task["lead"]}_{task["lag"]}_{task["symbol"]}.json')
    temp_backtest_file = os.path.join(task_log_dir,
        f'backtest_temp_{task["lead"]}_{task["lag"]}_{task["symbol"]}.json')
    
    save_json(temp_strategy_file, strategy_config)
    save_json(temp_backtest_file, backtest_config)
    
    # Run optimization
    opt_args = argparse.Namespace(
        strategy=temp_strategy_file,
        backtest=temp_backtest_file,
        optimization=task['opt_config'],
        output_dir=args.output_dir,
        # Force logs to live under this symbol-pair's results dir.
        log_dir=task_log_dir,
        log_file=f'backtest_temp_{task["lead"]}_{task["lag"]}_{task["symbol"]}.log',
        quiet=args.quiet,
    )

    # Redirect the whole task's console output into the symbol-pair output dir.
    optimize_log_path = os.path.join(output_base, "optimize.log")
    with open(optimize_log_path, "w") as log_fp, redirect_stdout(log_fp), redirect_stderr(log_fp):
        run_single_optimization(opt_args)
    
    # Clean up temporary files
    if os.path.exists(temp_strategy_file):
        os.remove(temp_strategy_file)
    if os.path.exists(temp_backtest_file):
        os.remove(temp_backtest_file)


def run_single_optimization(args):
    """Run optimization for a single strategy configuration."""
    
    # Load configurations
    strategy_config = load_json(args.strategy)
    base_backtest_config = load_json(args.backtest)
    
    if isinstance(args.optimization, str):
        opt_config = load_json(args.optimization)
    else:
        opt_config = args.optimization
    
    # Extract metadata
    lead_exchange = strategy_config['lead']
    lag_exchange = strategy_config.get('lag', '')
    symbol = strategy_config['symbol']
    
    # Generate unique temp file names based on strategy
    if args.log_file is None:
        args.log_file = f'backtest_temp_{lead_exchange}_{lag_exchange}_{symbol}.log'
    
    print(f"Strategy: {lead_exchange} (lead) - {lag_exchange} (lag) on {symbol}")
    
    # Setup directories
    # log_dir = args.log_dir or os.getenv('LOG_DIR', '.')
    # os.makedirs(log_dir, exist_ok=True)
    
    # # Create separate log subdirectory for this trading pair
    # pair_log_dir = os.path.join(log_dir, f"{lead_exchange}-{lag_exchange}-{symbol}")
    # os.makedirs(pair_log_dir, exist_ok=True)
    
    output_base = os.path.join(args.output_dir, f"{lead_exchange}-{lag_exchange}-{symbol}")
    os.makedirs(output_base, exist_ok=True)
    log_dir = os.path.join(output_base, "logs")
    pair_log_dir = os.path.join(log_dir, f"{lead_exchange}-{lag_exchange}-{symbol}")
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(pair_log_dir, exist_ok=True)
    
    # Generate all latency combinations
    combinations = generate_latency_combinations(opt_config)
    total_combinations = len(combinations)
    print(f"\nGenerated {total_combinations} latency combinations to test")
    
    # Store all results
    all_results = []
    
    # Run optimization
    for idx, (combo_idx, latency_config) in enumerate(combinations):
        print(f"\n{'='*60}")
        print(f"Running combination {idx+1}/{total_combinations} (index: {combo_idx})")
        lead_lat = latency_config.get('lead', {})
        lag_lat = latency_config.get('lag', {})
        print(f"Lead latencies: req={lead_lat.get('req', 0)}ms, "
              f"resp={lead_lat.get('resp', 0)}ms, public={lead_lat.get('public', 0)}ms")
        print(f"Lag latencies: req={lag_lat.get('req', 0)}ms, "
              f"resp={lag_lat.get('resp', 0)}ms, public={lag_lat.get('public', 0)}ms")
        
        # Generate backtest config
        backtest_config = generate_backtest_config(base_backtest_config, strategy_config, latency_config)
        
        # Save temporary backtest config with unique name in pair log directory
        temp_backtest_file = os.path.join(pair_log_dir, f'backtest_temp_{combo_idx}.json')
        save_json(temp_backtest_file, backtest_config)
        
        # Generate unique log file name for this combination in pair log directory
        combo_log_file = f'backtest_{combo_idx}.log'
        
        # Run backtest
        print("Running backtest...")
        success = run_backtest(args.strategy, temp_backtest_file, pair_log_dir, combo_log_file, args.quiet)
        
        if not success:
            print("Backtest failed, skipping...")
            continue
        
        # Analyze performance and save results
        result_file = os.path.join(output_base, f"{combo_idx}.json")
        print("Analyzing performance...")
        performance = analyze_performance(args.strategy, pair_log_dir, combo_log_file, result_file)
        
        if performance is None:
            print("Analysis failed, skipping...")
            continue
        
        # Add latency config to performance results
        performance['latency'] = latency_config
        performance['index'] = combo_idx
        
        # Save complete result (order.py already saved performance, now add latency info)
        with open(result_file, 'r') as f:
            saved_data = json.load(f)
        saved_data['index'] = combo_idx
        saved_data['latency'] = latency_config
        save_json(result_file, saved_data)
        print(f"Results saved to {result_file}")
        
        # Store result for summary
        all_results.append({
            'index': combo_idx,
            'latency': latency_config,
            'performance': performance
        })
        
        # Log files are preserved for future reference
        print(f"Log file: {os.path.join(pair_log_dir, combo_log_file)}")
    
    print(f"\nAll logs saved to: {pair_log_dir}")
    
    # Save combined results
    combined_file = os.path.join(output_base, 'all_results.json')
    date_range = base_backtest_config.get('group', {}).get('hourly', {}).get('range', [])
    save_json(combined_file, {
        'metadata': {
            'lead_exchange': lead_exchange,
            'lag_exchange': lag_exchange,
            'symbol': symbol,
            'start_time': date_range[0] if len(date_range) > 0 else '',
            'end_time': date_range[1] if len(date_range) > 1 else '',
            'total_combinations': total_combinations,
            'successful_runs': len(all_results)
        },
        'results': all_results
    })
    print(f"\n{'='*60}")
    print(f"Optimization complete!")
    print(f"Combined results saved to {combined_file}")
    
    # Generate summary DataFrame and find best configuration
    if all_results:
        summary_data = []
        for result in all_results:
            summary = result['performance'].get('summary', {})
            latency = result['latency']
            lead_lat = latency.get('lead', {})
            lag_lat = latency.get('lag', {})
            summary_data.append({
                'index': result['index'],
                'lead_req': lead_lat.get('req', 0),
                'lead_resp': lead_lat.get('resp', 0),
                'lead_pub': lead_lat.get('public', 0),
                'lag_req': lag_lat.get('req', 0),
                'lag_resp': lag_lat.get('resp', 0),
                'lag_pub': lag_lat.get('public', 0),
                'avg_open_liquidity': summary.get('avg open liquidity', 0),
                'avg_close_liquidity': summary.get('avg close liquidity', 0),
                'profit_total': summary.get('profit_total', 0),
                'profit_rate': summary.get('profit_rate', 0),
                'net_profit_total': summary.get('net_profit_total', 0),
                'net_profit_rate': summary.get('net_profit_rate', 0),
                'win_rate': summary.get('win_rate', 0),
                'net_win_rate': summary.get('net_win_rate', 0),
                'total_orders': summary.get('total_orders', 0),
                'total_trades': summary.get('total_trades', 0)
            })
        
        df = pd.DataFrame(summary_data)
        
        # Save summary CSV
        summary_csv = os.path.join(output_base, 'summary.csv')
        df.to_csv(summary_csv, index=False)
        print(f"Summary CSV saved to {summary_csv}")
        
        # Show results with no orders
        no_orders = df[df['total_orders'] == 0]
        if len(no_orders) > 0:
            print(f"\n{len(no_orders)} configuration(s) with no orders:")
            print(no_orders[['index', 'lead_req', 'lead_resp', 'lead_pub', 
                           'lag_req', 'lag_resp', 'lag_pub', 'total_orders']].to_string(index=False))
        
        # Find best configurations
        print("\nTop 10 configurations by net profit rate:")
        top5 = df.nlargest(10, 'net_profit_rate')
        print(top5[['index', 'lead_req', 'lead_resp', 'lead_pub',
                   'lag_req', 'lag_resp', 'lag_pub', 'net_profit_total',
                   'net_profit_rate', 'total_orders', 'total_trades']].to_string(index=False))


if __name__ == '__main__':
    main()
