package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path"
	"runtime/pprof"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/utils/godotenv"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/backtest"
	"gitlab.com/hashingbotrepo/backend/xexchange/utils/tableview"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/leadlag/algo"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

// var setting backtest.Setting

var Logger = logrus.New()
var JsonLog = logrus.New()

func init() {

	godotenv.Load(GetEnv("ENVFILE", ".env"))
	Logger.SetFormatter(&logrus.TextFormatter{
		TimestampFormat: "2006-01-02 15:04:05.000",
		FullTimestamp:   true,
	})
	logFileName := path.Join(
		GetEnv("LOG_DIR", "."),
		GetEnv("LOG_FILE", "backtest.log"),
	)
	// Setup JsonLog to output to both console and file
	jsonLogFile, err := os.OpenFile(logFileName, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0666)
	if err != nil {
		Logger.Fatalf("Failed to open json log file: %v", err)
	}
	JsonLog.SetOutput(io.MultiWriter(os.Stdout, jsonLogFile))
	JsonLog.SetFormatter(&logrus.JSONFormatter{
		TimestampFormat:   "2006-01-02 15:04:05.000",
		DisableHTMLEscape: true,
		FieldMap: logrus.FieldMap{
			logrus.FieldKeyTime:  "ts",
			logrus.FieldKeyLevel: "level",
			logrus.FieldKeyMsg:   "msg",
		},
	})
}

func GetEnv(key, _default string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	} else {
		return _default
	}

}

func loadStrategyConfig(filename string) (*algo.StrategyConfig, error) {
	data, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("failed to read strategy config: %w", err)
	}

	config := new(algo.StrategyConfig)
	err = json.Unmarshal(data, config)
	if err != nil {
		return nil, fmt.Errorf("failed to parse strategy config: %w", err)
	}

	return config, nil
}

func generateSetting(config *algo.StrategyConfig, backtestTemplate string) (*backtest.Setting, error) {
	data, err := os.ReadFile(backtestTemplate)
	if err != nil {
		return nil, fmt.Errorf("failed to read backtest template: %w", err)
	}

	setting := new(backtest.Setting)
	err = json.Unmarshal(data, setting)
	if err != nil {
		return nil, fmt.Errorf("failed to parse backtest template: %w", err)
	}

	setting.Group.Hourly.Data = backtest.GroupFiles{
		config.Lead: {
			"perp": {fmt.Sprintf("%s_swap", config.Symbol)},
		},
		config.Lag: {
			"perp": {fmt.Sprintf("%s_swap", config.Symbol)},
		},
	}

	return setting, nil
}

func main() {
	// Parse command-line arguments
	strategyFile := flag.String("s", "", "Path to strategy config JSON file (required)")
	backtestFile := flag.String("b", "", "Path to backtest setting JSON file (required)")
	cpuProfile := flag.String("cpuprofile", "", "Write CPU profile to file")
	memProfile := flag.String("memprofile", "", "Write memory profile to file")
	flag.Parse()

	// Validate required arguments
	if *strategyFile == "" || *backtestFile == "" {
		fmt.Fprintf(os.Stderr, "Usage: %s -s <strategy.json> -b <backtest.json> [-cpuprofile <file>] [-memprofile <file>]\n", os.Args[0])
		flag.PrintDefaults()
		os.Exit(1)
	}

	// Start CPU profiling if requested
	if *cpuProfile != "" {
		f, err := os.Create(*cpuProfile)
		if err != nil {
			Logger.Fatalf("Could not create CPU profile: %v", err)
		}
		defer f.Close()
		if err := pprof.StartCPUProfile(f); err != nil {
			Logger.Fatalf("Could not start CPU profile: %v", err)
		}
		defer pprof.StopCPUProfile()
		Logger.Infof("CPU profiling enabled, writing to %s", *cpuProfile)
	}

	// Load strategy configuration
	config, err := loadStrategyConfig(*strategyFile)
	if err != nil {
		Logger.Fatal(err)
	}

	config.SetDefault()
	ctx := context.TODO()
	stg := config.New(Logger.WithContext(context.TODO()))
	stg.SetRecorder(&recorder.LogRecorder{
		Log:   JsonLog.WithContext(ctx),
		Level: logrus.InfoLevel,
	})

	// Generate backtest setting from template and config
	setting, err := generateSetting(config, *backtestFile)
	if err != nil {
		Logger.Fatal(err)
	}

	widgets, err := setting.NewBackTest(stg)
	if err != nil {
		panic(err)
	}

	start := time.Now()
	widgets.Run()
	end := time.Now()
	stg.Brief()
	// Step 10: Display order history
	orders := widgets.AllHistoryOrders()
	orderCounts := len(orders[1])
	startIdx := orderCounts - 10
	if startIdx < 0 {
		startIdx = 0
	}

	Logger.Infof("History<Total=%d>:\n%s", orderCounts, tableview.ArrayToTableText(
		orders[1][startIdx:], // Show first 10 orders
		"Ex", "HostType", "ExchangePair",
		"OrderID", "ServerTime", "Contract",
		"Price", "Side", "Qty", "AvgFillPrc", "FilledQty", "Status",
		"OrderType",
	))

	period := end.Sub(start)
	Logger.Infof("Backtest done in %s", period)

	// Write memory profile if requested
	if *memProfile != "" {
		f, err := os.Create(*memProfile)
		if err != nil {
			Logger.Fatalf("Could not create memory profile: %v", err)
		}
		defer f.Close()
		if err := pprof.WriteHeapProfile(f); err != nil {
			Logger.Fatalf("Could not write memory profile: %v", err)
		}
		Logger.Infof("Memory profile written to %s", *memProfile)
	}
}
