#!/usr/bin/env python3
"""
从 gate-75 下各品种的回测 log 中提取订单信息，按 cid 合并后按品种导出为 CSV。

目录结构: gate-75/{species}/logs/{species}/backtest_0.log, backtest_1.log, ...
同一 cid 的多条 JSON（如 trigger + order）会合并为一条订单记录。
"""

import csv
import json
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

# GATE75 = Path(__file__).resolve().parent / "gate-75"
# OUTPUT_DIR = Path(__file__).resolve().parent / "orders_export"


def find_backtest_logs(root: Path) -> List[Tuple[str, Path]]:
    """返回 [(species, log_path), ...]，只匹配 logs/{species}/backtest_*.log"""
    found = []
    for species_dir in root.iterdir():
        if not species_dir.is_dir() or species_dir.name.startswith("."):
            continue
        logs_sub = species_dir / "logs" / species_dir.name
        if not logs_sub.is_dir():
            continue
        for p in logs_sub.glob("backtest_*.log"):
            if p.is_file():
                found.append((species_dir.name, p))
    return found


def parse_log(log_path: Path) -> List[dict]:
    """解析 log：每行一个 JSON，只保留含 cid 的订单相关记录。"""
    rows = []
    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "cid" not in obj:
                continue
            rows.append(obj)
    return rows


def merge_by_cid(rows: List[dict]) -> List[dict]:
    """
    将相同 cid 的多条记录合并为一条。
    - type=trigger 提供 position, base_price, base_time, entry, exit 等
    - type=order 提供 oid, filled, avg, staus 等
    合并时：按行顺序，同名字段后出现的覆盖（通常 order 在 trigger 后，故 filled/avg/oid 等以 order 为准）。
    """
    by_cid = defaultdict(dict)
    for r in rows:
        cid = r.get("cid")
        if cid is None:
            continue
        for k, v in r.items():
            by_cid[cid][k] = v
    return [v for v in by_cid.values()]


def extract_backtest_id(log_path: Path) -> str:
    """从 backtest_3.log 提取 3。"""
    m = re.search(r"backtest_(\d+)\.log$", log_path.name, re.I)
    return m.group(1) if m else ""


def run():
    import sys
    logs_dir = Path(sys.argv[1]) if len(sys.argv) >1 else "."
    output_dir = logs_dir / "orders_export"
    print(logs_dir, output_dir)
    os.makedirs(output_dir, exist_ok=True)
    pairs = find_backtest_logs(logs_dir)

    # 按品种聚合: species -> [ { backtest_id, merged_rows } ]
    by_species = defaultdict(list)
    for species, log_path in sorted(pairs):
        rows = parse_log(log_path)
        if not rows:
            continue
        merged = merge_by_cid(rows)
        if not merged:
            continue
        backtest_id = extract_backtest_id(log_path)
        for m in merged:
            m["backtest_id"] = backtest_id
            m["species"] = species
        by_species[species].extend(merged)

    # 为每种品种生成一个 CSV
    preferred = ["backtest_id", "species", "cid", "group", "type", "position", "ts", "price", "qty", "side", "filled", "avg", "oid", "staus"]
    for species, rows in sorted(by_species.items()):
        if not rows:
            continue
        # 收集所有列并排序
        all_keys = set()
        for r in rows:
            all_keys.update(r.keys())
        pre = [c for c in preferred if c in all_keys]
        rest = sorted(all_keys - set(pre))
        cols = pre + rest
        out = output_dir / f"{species}_orders.csv"
        with open(out, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            for r in rows:
                w.writerow({k: r.get(k) for k in cols})
        print(f"已导出: {out}  ({len(rows)} 条)")

    print(f"\n共处理 {len(by_species)} 个品种，输出目录: {output_dir}")


if __name__ == "__main__":
    run()
