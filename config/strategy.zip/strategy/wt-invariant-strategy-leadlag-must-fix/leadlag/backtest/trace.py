#!/usr/bin/env python3
"""
Trace visualization for lead-lag strategy backtest results.

This script provides utilities to:
1. Load BBO (Best Bid/Offer) data from HDF5 files
2. Parse JSON log files containing orders and triggers
3. Visualize BBO prices with strategy execution points (orders and triggers)
"""

import argparse
import json
import os
from typing import Dict, List, Optional

import matplotlib.pyplot as plt
import mplcursors
import pandas as pd
from dateutil import tz


taker_fees = {
    "bybit": 1.5 * (1e-4),
    "gateio": 1.6 * (1e-4)
}

# Read paths from environment variables
DEFAULT_DATA_ROOT = os.getenv("DATA_DIR", "/Users/caiming/Works/backtest-go/raw_data_hourly")
DEFAULT_LOG_FILE = os.path.join(
    os.getenv("LOG_DIR", "/Users/caiming/Works/backtest-go/invariant-strategy/logs"),
    os.getenv("LOG_FILE", "backtest.log")
)


def read_jsons(logfile: str, groupby: str) -> Dict[str, pd.DataFrame]:
    """
    Read JSON lines from log file and group by specified field.
    
    Parameters:
    - logfile: Path to JSON log file
    - groupby: Field name to group by (e.g., 'type')
    
    Returns:
    - Dictionary mapping group values to DataFrames
    """
    with open(logfile, "r") as f:
        lines = f.readlines()
    
    rows = {}
    for text in lines:
        doc = json.loads(text)
        dtype = doc.get(groupby, "")
        rows.setdefault(dtype, []).append(doc)
    
    dfs = {}
    for k, v in rows.items():
        dfs[k] = pd.DataFrame(v)
        if 'ts' in dfs[k].columns:
            dfs[k].index = pd.to_datetime(dfs[k]["ts"])
    
    return dfs


def load_hdf_config(datehour: str, symbol: str, root: str = DEFAULT_DATA_ROOT) -> pd.Series:
    """
    Load configuration from HDF5 file.
    
    Parameters:
    - datehour: Date-hour string (e.g., '2026010800')
    - symbol: Symbol name (e.g., 'binance.eth_usdt_swap')
    - root: Root directory for data files
    
    Returns:
    - Series containing configuration
    """
    file_path = f"{datehour}/{symbol}_{datehour}.h5"
    filename = os.path.join(root, file_path)
    df = pd.read_hdf(filename, key="config")
    return df.iloc[0]


def load_hdf_bbo(datehour: str, symbol: str, root: str = DEFAULT_DATA_ROOT) -> pd.DataFrame:
    """
    Load BBO (Best Bid/Offer) data from HDF5 file.
    
    Parameters:
    - datehour: Date-hour string (e.g., '2026010800')
    - symbol: Symbol name (e.g., 'binance.eth_usdt_swap')
    - root: Root directory for data files
    
    Returns:
    - DataFrame with BBO data indexed by local time
    """
    file_path = f"{datehour}/{symbol}_{datehour}.h5"
    filename = os.path.join(root, file_path)
    df = pd.read_hdf(filename, key="bbo")
    config = load_hdf_config(datehour, symbol, root)
    
    # Normalize prices and quantities
    df["ask_price"] = df["ask_price"].apply(float) / config["price_multiplier"]
    df["bid_price"] = df["bid_price"].apply(float) / config["price_multiplier"]
    df["ask_qty"] = df["ask_qty"].apply(float) / config["qty_multiplier"] * config["contract_value"]
    df["bid_qty"] = df["bid_qty"].apply(float) / config["qty_multiplier"] * config["contract_value"]
    
    # Convert UTC timestamp to local timezone
    df.index = pd.to_datetime(df["localtime"], unit='ms', utc=True).dt.tz_convert(tz.tzlocal()).dt.tz_localize(None)
    
    return df


def batch_read_bbo(symbol: str, dates: List[str], root: str = DEFAULT_DATA_ROOT) -> pd.DataFrame:
    """
    Load BBO data from multiple date-hour files.
    
    Parameters:
    - symbol: Symbol name
    - dates: List of date-hour strings
    - root: Root directory for data files
    
    Returns:
    - Concatenated DataFrame with BBO data
    """
    result = []
    for datehour in dates:
        df = load_hdf_bbo(datehour, symbol, root)
        result.append(df)
    return pd.concat(result)


def align_shift(lead: pd.DataFrame, lag: pd.DataFrame) -> float:
    """
    Calculate alignment shift factor between lead and lag exchanges.
    
    This computes the average price ratio to normalize prices between exchanges.
    
    Parameters:
    - lead: Lead exchange BBO DataFrame
    - lag: Lag exchange BBO DataFrame
    
    Returns:
    - Alignment shift factor
    """
    align_lead = lead.groupby(lead.index.floor('s'))[['ask_price', 'bid_price']].mean()
    align_lag = lag.groupby(lag.index.floor('s'))[['ask_price', 'bid_price']].mean()
    return (align_lag / align_lead).mean().mean()


def cal_diff(lead: pd.DataFrame, lag: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate price differences between lead and lag exchanges.
    
    Parameters:
    - lead: Lead exchange BBO DataFrame
    - lag: Lag exchange BBO DataFrame
    
    Returns:
    - DataFrame with 'long' and 'short' difference columns
    """
    lead_clean = lead[~lead.index.duplicated(keep='last')]
    lag_clean = lag[~lag.index.duplicated(keep='last')]
    
    longDiff = pd.DataFrame({
        "lead": lead_clean['bid_price'],
        "lag": lag_clean['ask_price']
    }).ffill()
    
    shortDiff = pd.DataFrame({
        "lead": lead_clean['ask_price'],
        "lag": lag_clean['bid_price']
    }).ffill()
    
    return pd.DataFrame({
        "long": longDiff["lead"] / longDiff["lag"] - 1,
        "short": shortDiff["lead"] / shortDiff["lag"] - 1
    }).dropna()


def axis_bbo_prices(ax, lead_df: pd.DataFrame, lag_df: pd.DataFrame, 
                   title: str = 'BBO Prices: Lead vs Lag'):
    """
    Plot ask and bid prices for lead and lag exchanges on given axis.
    
    Parameters:
    - ax: Matplotlib axis
    - lead_df: DataFrame with 'ask_price' and 'bid_price' columns (lead exchange)
    - lag_df: DataFrame with 'ask_price' and 'bid_price' columns (lag exchange)
    - title: Plot title
    
    Returns:
    - Modified axis
    """
    # Plot lag prices
    ax.plot(lag_df.index, lag_df['ask_price'], label='Lag Ask', 
            color='red', alpha=0.7, linewidth=1)
    ax.plot(lag_df.index, lag_df['bid_price'], label='Lag Bid', 
            color='coral', alpha=0.7, linewidth=1)
    
    # Plot lead prices
    ax.plot(lead_df.index, lead_df['ask_price'], label='Lead Ask', 
            color='blue', alpha=0.7, linewidth=1)
    ax.plot(lead_df.index, lead_df['bid_price'], label='Lead Bid', 
            color='green', alpha=0.7, linewidth=1)
    
    ax.set_xlabel('Time')
    ax.set_ylabel('Price')
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    return ax


def plot_orders_triggers(ax, orders_df: pd.DataFrame, triggers_df: pd.DataFrame):
    """
    Plot orders and triggers on the given axis.
    
    Parameters:
    - ax: Matplotlib axis to plot on
    - orders_df: DataFrame with order data (columns: ts, avg, side, filled, status)
    - triggers_df: DataFrame with trigger data (columns: ts, price, side, position, by)
    
    Returns:
    - Modified axis
    """
    # Filter filled orders only
    filled_select = orders_df['filled'] > 0
    filled_orders = orders_df[filled_select].copy()
    canceld_orders = orders_df[~filled_select].copy() 
    
    if not filled_orders.empty:
        # Separate long and short orders
        long_orders = filled_orders[filled_orders['side'] == 1]
        short_orders = filled_orders[filled_orders['side'] == -1]
        
        # Plot filled orders
        long_scatter = ax.scatter(long_orders.index, long_orders['avg'], 
                  marker='^', s=100, c='green', alpha=0.8, 
                  label='Long Fill', edgecolors='darkgreen', linewidths=1.5, zorder=5)
        short_scatter = ax.scatter(short_orders.index, short_orders['avg'], 
                  marker='v', s=100, c='red', alpha=0.8, 
                  label='Short Fill', edgecolors='darkred', linewidths=1.5, zorder=5)
        
        # Add interactive hover tooltips for CID
        if 'cid' in long_orders.columns and not long_orders.empty:
            cursor_long = mplcursors.cursor(long_scatter, hover=mplcursors.HoverMode.Transient)
            @cursor_long.connect("add")
            def on_add_long(sel):
                idx = sel.index
                row = long_orders.iloc[idx]
                sel.annotation.set_text(f"CID: {row['cid']}\nPrice: {row['avg']:.4f}\nQty: {row['filled']:.2f}")
                sel.annotation.get_bbox_patch().set(fc="lightgreen", alpha=0.9)
        
        if 'cid' in short_orders.columns and not short_orders.empty:
            cursor_short = mplcursors.cursor(short_scatter, hover=mplcursors.HoverMode.Transient)
            @cursor_short.connect("add")
            def on_add_short(sel):
                idx = sel.index
                row = short_orders.iloc[idx]
                sel.annotation.set_text(f"CID: {row['cid']}\nPrice: {row['avg']:.4f}\nQty: {row['filled']:.2f}")
                sel.annotation.get_bbox_patch().set(fc="lightcoral", alpha=0.9)
    
    # Plot canceled orders
    if not canceld_orders.empty:
        # Separate long and short canceled orders
        long_canceled = canceld_orders[canceld_orders['side'] == 1]
        short_canceled = canceld_orders[canceld_orders['side'] == -1]
        
        # Plot canceled orders with grey color
        if not long_canceled.empty and 'price' in long_canceled.columns:
            long_cancel_scatter = ax.scatter(long_canceled.index, long_canceled['price'], 
                      marker='^', s=80, c='grey', alpha=0.5, 
                      label='Long Cancel', edgecolors='darkgrey', linewidths=1.5, zorder=3)
            
            # Add interactive hover tooltips for canceled long orders
            if 'cid' in long_canceled.columns:
                cursor_long_cancel = mplcursors.cursor(long_cancel_scatter, hover=mplcursors.HoverMode.Transient)
                @cursor_long_cancel.connect("add")
                def on_add_long_cancel(sel):
                    idx = sel.index
                    row = long_canceled.iloc[idx]
                    sel.annotation.set_text(f"CID: {row['cid']}\nPrice: {row['price']:.4f}\nQty: {row['qty']:.2f}\nStatus: Canceled")
                    sel.annotation.get_bbox_patch().set(fc="lightgrey", alpha=0.9)
        
        if not short_canceled.empty and 'price' in short_canceled.columns:
            short_cancel_scatter = ax.scatter(short_canceled.index, short_canceled['price'], 
                      marker='v', s=80, c='grey', alpha=0.5, 
                      label='Short Cancel', edgecolors='darkgrey', linewidths=1.5, zorder=3)
            
            # Add interactive hover tooltips for canceled short orders
            if 'cid' in short_canceled.columns:
                cursor_short_cancel = mplcursors.cursor(short_cancel_scatter, hover=mplcursors.HoverMode.Transient)
                @cursor_short_cancel.connect("add")
                def on_add_short_cancel(sel):
                    idx = sel.index
                    row = short_canceled.iloc[idx]
                    sel.annotation.set_text(f"CID: {row['cid']}\nPrice: {row['price']:.4f}\nQty: {row['qty']:.2f}\nStatus: Canceled")
                    sel.annotation.get_bbox_patch().set(fc="lightgrey", alpha=0.9)
    
    # Plot triggers
    if not triggers_df.empty:
        triggers_df = triggers_df.copy()
        
        # Separate open and close triggers for long positions
        open_long = triggers_df[(triggers_df['position'] == 'open') & (triggers_df['side'] == 1)]
        close_long = triggers_df[(triggers_df['position'] == 'close') & (triggers_df['side'] == -1)]
        
        # Plot lines from base_time to trigger time for open long triggers
        if not open_long.empty and 'base_time' in open_long.columns:
            for idx, row in open_long.iterrows():
                base_time = pd.to_datetime(row['base_time'])
                trigger_time = idx
                ax.plot([base_time, trigger_time], [row['base_price'], row['lead_bid'] * row["drift"]], 
                       color='green', alpha=0.4, linewidth=1, linestyle='--', zorder=3)
        
        # Plot base scatter points at (base_time, base_price)
        if not open_long.empty and 'base_time' in open_long.columns:
            base_times = [pd.to_datetime(row['base_time']) for _, row in open_long.iterrows()]
            base_prices = open_long['base_price'].values
            base_long_scatter = ax.scatter(base_times, base_prices, 
                      marker='o', s=60, c='lightgreen', alpha=0.6, 
                      label='Open Long Base', edgecolors='green', linewidths=1, zorder=4)
            
            # Add tooltips for base points
            cursor_base_long = mplcursors.cursor(base_long_scatter, hover=mplcursors.HoverMode.Transient)
            @cursor_base_long.connect("add")
            def on_add_base_long(sel):
                idx = sel.index
                row = open_long.iloc[idx]
                text = f"Base Price: {row['base_price']:.4f}"
                sel.annotation.set_text(text)
                sel.annotation.get_bbox_patch().set(fc="lightgreen", alpha=0.9)
        
        # Plot trigger scatter points at (ts, price)
        open_long_scatter = ax.scatter(open_long.index, open_long['lead_bid'] * open_long['drift'], 
                  marker='o', s=60, c='green', alpha=0.8, 
                  label='Open Long Trigger', edgecolors='darkgreen', linewidths=1, zorder=4)
        ax.scatter(close_long.index, close_long['base_price'], 
                  marker='x', s=60, c='lightgreen', alpha=0.6, 
                  label='Close Long', edgecolors='green', linewidths=1.5, zorder=4)
        
        # Add interactive tooltips for open long triggers
        if 'lead_diff' in open_long.columns and 'lag_diff' in open_long.columns and not open_long.empty:
            cursor_open_long = mplcursors.cursor(open_long_scatter, hover=mplcursors.HoverMode.Transient)
            @cursor_open_long.connect("add")
            def on_add_open_long(sel):
                idx = sel.index
                row = open_long.iloc[idx]
                text = f"Lead: {row['lead_diff']*100:.2f}%\nLag: {row['lag_diff']*100:.2f}%\nTrig Price: {row['price']:.4f}"
                sel.annotation.set_text(text)
                sel.annotation.get_bbox_patch().set(fc="lightgreen", alpha=0.9)
        
        # Separate open and close triggers for short positions
        open_short = triggers_df[(triggers_df['position'] == 'open') & (triggers_df['side'] == -1)]
        close_short = triggers_df[(triggers_df['position'] == 'close') & (triggers_df['side'] == 1)]
        
        # Plot lines from base_time to trigger time for open short triggers
        if not open_short.empty and 'base_time' in open_short.columns:
            for idx, row in open_short.iterrows():
                base_time = pd.to_datetime(row['base_time'])
                trigger_time = idx
                ax.plot([base_time, trigger_time], [row['base_price'], row['lead_ask'] * row["drift"]], 
                       color='red', alpha=0.4, linewidth=1, linestyle='--', zorder=3)
        
        # Plot base scatter points at (base_time, base_price)
        if not open_short.empty and 'base_time' in open_short.columns:
            base_times = [pd.to_datetime(row['base_time']) for _, row in open_short.iterrows()]
            base_prices = open_short['base_price'].values
            base_short_scatter = ax.scatter(base_times, base_prices, 
                      marker='o', s=60, c='lightcoral', alpha=0.6, 
                      label='Open Short Base', edgecolors='darkred', linewidths=1, zorder=4)
            
            # Add tooltips for base points
            cursor_base_short = mplcursors.cursor(base_short_scatter, hover=mplcursors.HoverMode.Transient)
            @cursor_base_short.connect("add")
            def on_add_base_short(sel):
                idx = sel.index
                row = open_short.iloc[idx]
                text = f"Base Price: {row['base_price']:.4f}"
                sel.annotation.set_text(text)
                sel.annotation.get_bbox_patch().set(fc="lightcoral", alpha=0.9)
        
        # Plot trigger scatter points at (ts, price)
        open_short_scatter = ax.scatter(open_short.index, open_short['lead_ask'] * open_short['drift'], 
                  marker='o', s=60, c='red', alpha=0.8, 
                  label='Open Short Trigger', edgecolors='darkred', linewidths=1, zorder=4)
        ax.scatter(close_short.index, close_short['base_price'], 
                  marker='x', s=60, c='lightcoral', alpha=0.6, 
                  label='Close Short', edgecolors='darkred', linewidths=1.5, zorder=4)
        
        # Add interactive tooltips for open short triggers
        if 'lead_diff' in open_short.columns and 'lag_diff' in open_short.columns and not open_short.empty:
            cursor_open_short = mplcursors.cursor(open_short_scatter, hover=mplcursors.HoverMode.Transient)
            @cursor_open_short.connect("add")
            def on_add_open_short(sel):
                idx = sel.index
                row = open_short.iloc[idx]
                # text = f"Lead: {row['lead_diff']*100:.2f}%\nLag: {row['lag_diff']*100:.2f}%\nPrice: {row['base_price']:.4f}"
                text = "\n".join([
                    f"Group: {row['group']}",
                    f"Lead: {row['lead_diff']*100:.2f}%",
                    f"Lag: {row['lag_diff']*100:.2f}%",
                    f"Drift: {row['drift']:.4f}",
                    f"Base: {row['base_price']:.4f}",
                    f"Trig: {row['price']:.4f}",
                    f"Lead Ask: {row['lead_ask']:.4f}",
                    f"Lead Bid: {row['lead_bid']:.4f}",
                    f"Lag Ask: {row['lag_ask']:.4f}",
                    f"Lag Bid: {row['lag_bid']:.4f}",
                    f"Target Space: {row['target_space']*100:.2f}%",
                ])
                sel.annotation.set_text(text)
                sel.annotation.get_bbox_patch().set(fc="lightcoral", alpha=0.9)
    
    ax.legend(loc='best')
    return ax


def plot_profit_distribution_only(trades_df: Optional[pd.DataFrame] = None, 
                                  summary: pd.Series = None,
                                  title: str = 'Trade Profit Distribution', figsize: tuple = (10, 6)):
    """
    Plot trade profit distribution histogram in a standalone figure.
    
    Parameters:
    - trades_df: Optional DataFrame with trade statistics (from analyze_trades)
    - filled_rate: Order fill rate percentage
    - summary: Optional Series with summary statistics from analyze_trades
    - title: Plot title
    - figsize: Figure size (width, height)
    """
    fig, ax = plt.subplots(figsize=figsize)
    plot_profit_distribution(ax, trades_df, summary)
    ax.set_title(title)
    plt.tight_layout()
    plt.show()


def plot_profit_distribution(ax, trades_df: Optional[pd.DataFrame] = None, 
                           summary: pd.Series = None):
    """
    Plot trade profit distribution histogram on the given axis.
    
    Parameters:
    - ax: Matplotlib axis to plot on
    - trades_df: Optional DataFrame with trade statistics (from analyze_trades)
    - filled_rate: Order fill rate percentage
    - summary: Optional Series with summary statistics from analyze_trades
    
    Returns:
    - Modified axis
    """
    if trades_df is not None and not trades_df.empty:
        profits = trades_df['profit']

        # Create histogram with bins that don't cross zero
        import numpy as np
        profit_min, profit_max = profits.min(), profits.max()
        
        # Create separate bins for negative and positive profits with same bin size
        if profit_min < 0 and profit_max > 0:
            # Calculate bin size based on the larger range
            max_abs = max(abs(profit_min), abs(profit_max))
            bin_size = max_abs / 15  # 15 bins on each side
            
            # Create bins with consistent width
            negative_bins = np.arange(profit_min, 0, bin_size)
            if negative_bins[-1] != 0:
                negative_bins = np.append(negative_bins, 0)
            positive_bins = np.arange(0, profit_max + bin_size, bin_size)
            
            bins = np.concatenate([negative_bins[:-1], positive_bins])
        else:
            bins = 30
        
        ax.hist(profits, bins=bins, alpha=0.7, color='steelblue', edgecolor='black')
        ax.axvline(0, color='red', linestyle='--', linewidth=2, label='Break-even')
        ax.axvline(summary['profit_mean'], color='green', linestyle='--', linewidth=2, 
                   label=f'Mean: {summary["profit_mean"]:.2f}')
        
        # Display all summary statistics dynamically
        stats_lines = []
        for key, value in summary.items():
            # Format key: convert snake_case to Title Case
            display_key = ' '.join(word.capitalize() for word in key.split('_'))
            
            # Format value based on key name
            if 'rate' in key.lower():
                formatted_value = f'{value*100:.2f}%'
            elif key == 'total_trades':
                formatted_value = f'{int(value)}'
            else:
                formatted_value = f'{value:.2f}'
            
            stats_lines.append(f'{display_key}: {formatted_value}')
        
        stats_text = "\n".join(stats_lines)
        
        ax.text(0.02, 0.98, stats_text, transform=ax.transAxes,
                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8),
                fontsize=9, family='monospace')
        
        ax.set_xlabel('Profit')
        ax.set_ylabel('Frequency')
        ax.set_title('Trade Profit Distribution')
        ax.legend()
        ax.grid(True, alpha=0.3)
    else:
        ax.text(0.5, 0.5, 'No trade data available', 
                transform=ax.transAxes, ha='center', va='center', fontsize=12)
        ax.set_title('Trade Profit Distribution')
    
    return ax


def plot_executions(lead_df: pd.DataFrame, lag_df: pd.DataFrame, 
                   orders_df: Optional[pd.DataFrame] = None, 
                   triggers_df: Optional[pd.DataFrame] = None, 
                   trades_df: Optional[pd.DataFrame] = None,
                   summary: pd.Series = None,
                   title: str = 'BBO Prices: Lead vs Lag',
                   figsize: tuple = (14, 10)):
    """
    Plot BBO prices with optional order and trigger overlays, plus profit distribution.
    
    Parameters:
    - lead_df: Lead exchange BBO DataFrame
    - lag_df: Lag exchange BBO DataFrame
    - orders_df: Optional DataFrame with order data
    - triggers_df: Optional DataFrame with trigger data
    - trades_df: Optional DataFrame with trade statistics (from analyze_trades)
    - summary: Optional Series with summary statistics from analyze_trades
    - title: Plot title
    - figsize: Figure size (width, height)
    """
    # Create 2 subplots stacked vertically
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=figsize)
    
    # Plot BBO prices on the first subplot
    axis_bbo_prices(ax1, lead_df, lag_df, title)
    
    if orders_df is not None and triggers_df is not None:
        plot_orders_triggers(ax1, orders_df, triggers_df)
    
    # Plot profit distribution on the second subplot
    plot_profit_distribution(ax2, trades_df, summary)
    
    plt.tight_layout()
    plt.show()


def handle_trades(df: pd.DataFrame) -> pd.Series:
    """
    Calculate trade statistics for a group of orders.
    
    Parameters:
    - df: DataFrame with order data
    
    Returns:
    - Series with profit, duration, and count
    """
    openOrder = df.iloc[0]
    notional = df["avg"] * df["filled"] * df["side"]
    total = notional.abs().sum() / 2
    flow = (- notional).sum()
    return pd.Series({
        "qty": openOrder["qty"],
        "filled": openOrder["filled"],
        "filled%": openOrder["filled"] / openOrder["qty"],
        "avg": openOrder["avg"],
        "profit": flow,
        "profit%": flow / total if total != 0 else 0,
        "duration": df["server_ms"].max() - df["server_ms"].min(),
        "count": len(df),
    })


def analyze_trades(orders_df: pd.DataFrame, trigger_df: pd.DataFrame, lag_exchange: str = None):
    """
    Analyze trades grouped by trade group ID.
    
    Parameters:
    - orders_df: DataFrame with order data
    - lag_exchange: Lag exchange name for fee calculation (e.g., 'bybit', 'gateio')
    
    Returns:
    - Tuple of (DataFrame with trade statistics, Series with summary statistics)
    """
    df = orders_df[orders_df.filled > 0]
    trades_df = df.groupby("group").apply(handle_trades)
    
    # Calculate fees for each trade
    fee_rate = taker_fees.get(lag_exchange, 0) if lag_exchange else 0
    trades_df['fee'] = trades_df["avg"] * trades_df["filled"] * fee_rate * 2  # 2 legs per trade
    trades_df['profit_after_fee'] = trades_df['profit'] - trades_df['fee']
    
    # Calculate summary statistics
    profits = trades_df['profit']
    profits_after_fee = trades_df['profit_after_fee']
    notional = trades_df["avg"] * trades_df["filled"]
    filled_rate = orders_df['filled'].sum() / orders_df['qty'].sum() if orders_df['qty'].sum() > 0 else 0
    win_rate = (profits > 0).sum() / len(profits) if len(profits) > 0 else 0
    win_rate_after_fee = (profits_after_fee > 0).sum() / len(profits_after_fee) if len(profits_after_fee) > 0 else 0
    profit_rate = profits.sum() / notional.abs().sum() if notional.abs().sum() > 0 else 0
    profit_rate_after_fee = profits_after_fee.sum() / notional.abs().sum() if notional.abs().sum() > 0 else 0
    
    open_orders = orders_df[orders_df["cid"] == orders_df["group"]]
    open_long = sum(open_orders["side"] == 1)
    open_short = len(open_orders) - open_long

    doc = {
        "total_orders": len(orders_df),
        "filled_orders": len(df),
        "open_long": open_long,
        "open_short": open_short,
        'total_trades': len(profits),
        'filled_rate': filled_rate,
        'win_rate': win_rate,
        'net_win_rate': win_rate_after_fee,
        'profit_mean': profits.mean() if len(profits) > 0 else 0,
        "net_profit_mean": profits_after_fee.mean() if len(profits_after_fee) > 0 else 0,
        'profit_total': profits.sum(),
        'net_profit_total': profits_after_fee.sum(),
        'profit_rate': profit_rate,
        'net_profit_rate': profit_rate_after_fee,
        "holding_period(ms)": trades_df["duration"].mean() if len(trades_df) > 0 else 0
    }

    if len(df) > 0 :
        liquidity = trigger_df.set_index("cid").loc[list(df["cid"])].groupby("position")["liquidity"].mean()
        doc["avg open liquidity"] = liquidity.get("open", 0)
        doc["avg close liquidity"] = liquidity.get("close", 0)

    summary = pd.Series(doc)
    
    return trades_df, summary


def load_strategy_config(filename: str) -> dict:
    """
    Load strategy configuration from JSON file.
    
    Parameters:
    - filename: Path to strategy config file
    
    Returns:
    - Dictionary with strategy configuration
    """
    with open(filename, 'r') as f:
        return json.load(f)


def load_backtest_setting(filename: str) -> dict:
    """
    Load backtest setting from JSON file.
    
    Parameters:
    - filename: Path to backtest setting file
    
    Returns:
    - Dictionary with backtest settings
    """
    with open(filename, 'r') as f:
        return json.load(f)


def generate_date_range(start: str, end: str) -> List[str]:
    """
    Generate list of date-hour strings between start and end (inclusive).
    
    Parameters:
    - start: Start date-hour string (e.g., '2026010800')
    - end: End date-hour string (e.g., '2026010802')
    
    Returns:
    - List of date-hour strings
    """
    start_dt = pd.to_datetime(start, format='%Y%m%d%H')
    end_dt = pd.to_datetime(end, format='%Y%m%d%H')
    date_range = pd.date_range(start=start_dt, end=end_dt, freq='h')
    return [dt.strftime('%Y%m%d%H') for dt in date_range]


def extract_params_from_configs(strategy_file: str, backtest_file: str) -> tuple:
    """
    Extract dates, lead_symbol, and lag_symbol from config files.
    
    Parameters:
    - strategy_file: Path to strategy config JSON file
    - backtest_file: Path to backtest setting JSON file
    
    Returns:
    - Tuple of (dates, lead_symbol, lag_symbol)
    """
    strategy = load_strategy_config(strategy_file)
    backtest = load_backtest_setting(backtest_file)
    
    # Extract date range
    date_range = backtest['group']['hourly']['range']
    dates = generate_date_range(date_range[0], date_range[1])
    
    # Extract lead and lag symbols
    symbol = strategy['symbol']
    lead_exchange = strategy['lead']
    lag_exchange = strategy.get('lag', '')  # Handle typo in config
    
    lead_symbol = f"{lead_exchange}.{symbol}_swap"
    lag_symbol = f"{lag_exchange}.{symbol}_swap"
    
    return dates, lead_symbol, lag_symbol


# Example usage
if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Visualize lead-lag strategy backtest results')
    parser.add_argument('-s', '--strategy', required=True, help='Path to strategy config JSON file')
    parser.add_argument('-b', '--backtest', required=True, help='Path to backtest setting JSON file')
    parser.add_argument('-p', '--plot-type', type=int, choices=[1, 2], default=1,
                       help='Plot type: 1=price and trade distribution (default), 2=trade distribution only')
    args = parser.parse_args()
    
    # Extract parameters from config files
    dates, lead_symbol, lag_symbol = extract_params_from_configs(args.strategy, args.backtest)
    logfile = DEFAULT_LOG_FILE
    
    # Extract lag exchange name from symbol (e.g., "bybit.eth_usdt_swap" -> "bybit")
    lag_exchange = lag_symbol.split('.')[0] if '.' in lag_symbol else None
    
    print(f"Dates: {dates[0]} to {dates[-1]} ({len(dates)} hours)")
    print(f"Lead symbol: {lead_symbol}")
    print(f"Lag symbol: {lag_symbol}")
    print(f"Lag exchange: {lag_exchange}")
    print(f"Fee rate: {taker_fees.get(lag_exchange, 0)*100:.2f}%" if lag_exchange else "Fee rate: 0%")
    
    # Load logs
    print("Loading log data...")
    dfs = read_jsons(logfile, "type")
    
    trades = None
    summary = None
    filled_rate = 0
    if "order" in dfs:
        trades, summary = analyze_trades(dfs["order"], dfs["trigger"], lag_exchange)
        filled_rate = dfs["order"]['filled'].sum() / dfs["order"]['qty'].sum() * 100 if dfs["order"]['qty'].sum() > 0 else 0
        print(f"\nTrade statistics:")
        trades_filtered = trades[trades["count"] > 1]
        print(trades_filtered)
        print(trades_filtered.describe())
        print("Win rate:", len(trades[trades["profit"] > 0]) / len(trades))
        print("\nSummary statistics:")
        print(summary)
    
    # Plot based on plot type
    if args.plot_type == 2:
        # Trade distribution only
        print("Plotting trade distribution only...")
        plot_profit_distribution_only(trades, summary,
                                     f'Trade Profit Distribution ({lead_symbol} / {lag_symbol})')
    else:
        # Full plot with BBO prices and trade distribution
        print("Plotting executions with trade distribution...")
        
        # Load BBO data
        print("Loading BBO data...")
        lead = batch_read_bbo(lead_symbol, dates)
        lag = batch_read_bbo(lag_symbol, dates)
        
        # Calculate alignment shift
        shift = align_shift(lead, lag)
        print(f"Alignment shift: {shift:.6f}")
        
        # Define time range for plotting
        start = lead.index[0]
        end = lead.index[-1]
        print(f"Time range: {start} to {end}")
        
        # Plot executions
        plot_executions(
            lead.loc[start:end],
            lag.loc[start:end],
            dfs.get("order", pd.DataFrame()).loc[start:end],
            dfs.get("trigger", pd.DataFrame()).loc[start:end],
            trades,
            summary,
            f'BBO Prices: Lead vs Lag ({lead_symbol} / {lag_symbol})',
        )
    
