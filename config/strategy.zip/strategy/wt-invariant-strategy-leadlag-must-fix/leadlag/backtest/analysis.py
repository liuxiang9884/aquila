import os
import json
from typing import List, Dict, Tuple, Optional
from datetime import datetime, timedelta
import time

# Check tables version (pandas reads HDF5 via pytables)
try:
    import tables

    tables_version = tables.__version__
    # pandas generally requires tables >= 3.4.3
    version_parts = [int(x) for x in tables_version.split('.')]
    required_version = [3, 4, 3]
    version_ok = (
        version_parts[0] > required_version[0]
        or (version_parts[0] == required_version[0] and version_parts[1] > required_version[1])
        or (
            version_parts[0] == required_version[0]
            and version_parts[1] == required_version[1]
            and version_parts[2] >= required_version[2]
        )
    )
    if not version_ok:
        print("=" * 80)
        print("Error: tables version too old!")
        print(f"Current version: {tables_version}")
        print("pandas requires tables >= 3.4.3")
        print("=" * 80)
        print("\nSuggested fixes:")
        print("1) Use the intended environment (e.g. conda activate excel_env)")
        print("2) Upgrade: conda update tables -y  (or pip install --upgrade tables)")
        print("3) Verify: python -c 'import tables; print(tables.__version__)'")
        raise ImportError(f"tables version {tables_version} is too old; need >= 3.4.3")
except ImportError as e:
    # If this is the explicit version check failure, re-raise.
    if "tables" in str(e) or "too old" in str(e) or "need" in str(e):
        raise
    print("Warning: failed to import tables; HDF5 read may fail")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from dateutil import tz


# ===== Basic Parameters =====

# PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
# RESULT_DIR = os.path.join(PROJECT_ROOT, "results")
DEFAULT_DATA_DIR = os.getenv("DATA_DIR", "./data")
DEFAULT_RESULT_DIR = os.getenv("RESULT_DIR", "./results")

DEFAULT_LEAD_SYMBOL = "binance.eth_usdt_swap"
DEFAULT_LAG_SYMBOL = "gateio.eth_usdt_swap"


def _load_target_json(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _unique_sorted_datehours(datehours: List[str]) -> List[str]:
    # Keep order stable by sorting on parsed datetime.
    uniq = sorted(set(datehours), key=_parse_datehour)
    return uniq


def run_batch_from_target_json(
    target_json_path: str,
    *,
    result_dir: str = DEFAULT_RESULT_DIR,
    data_dir: str = DEFAULT_DATA_DIR,
) -> None:
    """Run analysis for each symbol described in a target.json-like config.

    Expected shape (subset):
      {
        "results": {
          "eth_usdt_swap": [
            {"exchanges": ["binance", "bybit"], "date_range": {"start": "YYYYMMDDHH", "end": "YYYYMMDDHH"}}
          ]
        }
      }

    Output for each symbol is written to:
      f"{result_dir}/{lead_exchange}/{lag_exchange}/{symbol}".
    """
    cfg = _load_target_json(target_json_path)
    search_params = cfg.get("search_params")
    if isinstance(search_params, dict) and search_params.get("root"):
        data_dir = str(search_params.get("root"))
    results = cfg.get("results")
    if not isinstance(results, dict) or not results:
        raise ValueError("target json must contain non-empty object field 'results'")

    base_result_root = result_dir

    for symbol, entries in results.items():
        if not isinstance(symbol, str) or not symbol.strip():
            continue
        if not isinstance(entries, list) or not entries:
            continue

        all_datehours: List[str] = []
        lead_exchange = None
        lag_exchange = None

        for entry in entries:
            if not isinstance(entry, dict):
                continue
            exchanges = entry.get("exchanges")
            date_range = entry.get("date_range")

            if lead_exchange is None and isinstance(exchanges, list) and len(exchanges) >= 2:
                lead_exchange = str(exchanges[0])
                lag_exchange = str(exchanges[1])

            if not isinstance(date_range, dict):
                continue
            start = date_range.get("start")
            end = date_range.get("end")
            if not start or not end:
                continue
            all_datehours.extend(_expand_datehour_range(str(start), str(end)))

        if not all_datehours:
            print(f"Skipping symbol {symbol}: no valid date ranges")
            continue
        if not lead_exchange or not lag_exchange:
            print(f"Skipping symbol {symbol}: missing exchanges")
            continue

        symbol_result_root = os.path.join(base_result_root, lead_exchange, lag_exchange, symbol)

        lead_symbol = f"{lead_exchange}.{symbol}"
        lag_symbol = f"{lag_exchange}.{symbol}"
        datehours = _unique_sorted_datehours(all_datehours)

        print("\n===== Batch run =====")
        print(f"Symbol: {symbol}")
        print(f"Lead: {lead_symbol}")
        print(f"Lag: {lag_symbol}")
        print(f"Result root: {symbol_result_root}")
        print(f"Hours: {datehours[0]} .. {datehours[-1]} (n={len(datehours)})")

        main(
            datehours=datehours,
            datehour_start=None,
            datehour_end=None,
            lead_symbol=lead_symbol,
            lag_symbol=lag_symbol,
            result_dir=symbol_result_root,
            data_dir=data_dir,
        )


def _hdf_path(datehour: str, symbol: str, *, data_dir: str) -> str:
    file_name = f"{symbol}_{datehour}.h5"
    return os.path.join(data_dir, datehour, file_name)


def _hdf_exists(datehour: str, symbol: str, *, data_dir: str) -> bool:
    return os.path.exists(_hdf_path(datehour, symbol, data_dir=data_dir))


def _parse_datehour(datehour: str) -> datetime:
    # Expected format: YYYYMMDDHH
    return datetime.strptime(datehour, "%Y%m%d%H")


def _expand_datehour_range(start: str, end: str) -> List[str]:
    start_dt = _parse_datehour(start)
    end_dt = _parse_datehour(end)
    if start_dt > end_dt:
        raise ValueError(f"start datehour {start} is after end datehour {end}")

    out: List[str] = []
    cur = start_dt
    while cur <= end_dt:
        out.append(cur.strftime("%Y%m%d%H"))
        cur += timedelta(hours=1)
    return out


def _fmt_wall_time(ts: datetime) -> str:
    return ts.strftime("%Y-%m-%d %H:%M:%S")


def _fmt_duration(seconds: float) -> str:
    if seconds < 0:
        seconds = 0.0
    total = int(round(seconds))
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


# ===== Utility Functions: IO and Directories =====

def ensure_dir(path: str) -> None:
    """Ensure directory exists."""
    os.makedirs(path, exist_ok=True)


def save_json(obj, path: str) -> None:
    """Save JSON file (with indentation, UTF-8 encoding)."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


# ===== Data Loading Functions (aligned with notebook) =====

def load_hdf_config(datehour: str, symbol: str) -> pd.Series:
    """
    Read config from a single HDF file (consistent with read_data.ipynb logic).
    """
def load_hdf_config(datehour: str, symbol: str, *, data_dir: str) -> pd.Series:
    """Read config from a single HDF file (consistent with read_data.ipynb logic)."""
    file_path = _hdf_path(datehour, symbol, data_dir=data_dir)
    df = pd.read_hdf(file_path, key="config")
    return df.iloc[0]


def load_hdf_bbo(datehour: str, symbol: str, *, data_dir: str) -> pd.DataFrame:
    """
    Read bbo from a single HDF file and apply price/quantity conversion based on config.
    Index is local time (consistent with notebook), original columns include tx_time (millisecond timestamp).
    """
    file_path = _hdf_path(datehour, symbol, data_dir=data_dir)
    df = pd.read_hdf(file_path, key="bbo")
    cfg = load_hdf_config(datehour, symbol, data_dir=data_dir)

    df = df.copy()
    df["ask_price"] = df["ask_price"].astype(float) / cfg["price_multiplier"]
    df["bid_price"] = df["bid_price"].astype(float) / cfg["price_multiplier"]
    df["ask_qty"] = df["ask_qty"].astype(float) / cfg["qty_multiplier"] * cfg["contract_value"]
    df["bid_qty"] = df["bid_qty"].astype(float) / cfg["qty_multiplier"] * cfg["contract_value"]

    # Consistent with notebook: localtime (ms) -> local timezone time index
    df.index = (
        pd.to_datetime(df["localtime"], unit="ms", utc=True)
        .dt.tz_convert(tz.tzlocal())
        .dt.tz_localize(None)
    )
    return df


def read_pair_for_datehour(
    datehour: str,
    lead_symbol: str = DEFAULT_LEAD_SYMBOL,
    lag_symbol: str = DEFAULT_LAG_SYMBOL,
    *,
    data_dir: str = DEFAULT_DATA_DIR,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Read bbo data from two exchanges for a single datehour.
    """
    lead = load_hdf_bbo(datehour, lead_symbol, data_dir=data_dir)
    lag = load_hdf_bbo(datehour, lag_symbol, data_dir=data_dir)
    return lead, lag


# ===== Core Calculation Process (single datehour) =====

def build_merged_df(lead: pd.DataFrame, lag: pd.DataFrame) -> pd.DataFrame:
    """
        Merge bbo from two exchanges horizontally using tx_time as the axis, with basic cleaning.
        Alignment logic consistent with notebook:
      - outer merge on 'tx_time'
            - forward fill
            - drop rows with remaining missing values
    """
    # Keep merge stable by ensuring tx_time is numeric int64 and other numeric fields are float64.
    lead = lead.copy()
    lag = lag.copy()

    if "tx_time" in lead.columns:
        lead["tx_time"] = pd.to_numeric(lead["tx_time"], errors="coerce").astype("int64")
    if "tx_time" in lag.columns:
        lag["tx_time"] = pd.to_numeric(lag["tx_time"], errors="coerce").astype("int64")

    for col in lead.select_dtypes(include=[np.number]).columns:
        if col != "tx_time":
            lead[col] = pd.to_numeric(lead[col], errors="coerce").astype("float64")
    for col in lag.select_dtypes(include=[np.number]).columns:
        if col != "tx_time":
            lag[col] = pd.to_numeric(lag[col], errors="coerce").astype("float64")

    try:
        merged_df = pd.merge(
            lead,
            lag,
            on="tx_time",
            how="outer",
            suffixes=("_lead", "_lag"),
            sort=True,
        )
    except Exception:
        # Fallback: reset index if merge fails due to index alignment quirks.
        merged_df = pd.merge(
            lead.reset_index(drop=True),
            lag.reset_index(drop=True),
            on="tx_time",
            how="outer",
            suffixes=("_lead", "_lag"),
            sort=True,
        )

    for col in merged_df.select_dtypes(include=[np.number]).columns:
        if col != "tx_time":
            merged_df[col] = pd.to_numeric(merged_df[col], errors="coerce").astype("float64")

    merged_df = merged_df.ffill()
    merged_df = merged_df.dropna()
    return merged_df


def add_long_term_basis(merged_df: pd.DataFrame, window_minutes: int = 10) -> pd.DataFrame:
    """
        Calculate long_term_basis_adj:
      basis_ratio = (bid_price_lag + ask_price_lag) / (bid_price_lead + ask_price_lead)
            long_term_basis_adj = median of basis_ratio over past window_minutes minutes
    """
    df = merged_df.copy()
    # Convert tx_time to timestamp, use NaT for invalid values, then drop these rows to avoid rolling on DatetimeIndex errors
    df["tx_time_dt"] = pd.to_datetime(df["tx_time"], unit="ms", errors="coerce")
    df = df[df["tx_time_dt"].notna()].copy()
    df_indexed = df.set_index("tx_time_dt").sort_index()

    df_indexed["basis_ratio"] = (
        (df_indexed["bid_price_lag"] + df_indexed["ask_price_lag"])
        / (df_indexed["bid_price_lead"] + df_indexed["ask_price_lead"])
    )

    df_indexed["long_term_basis_adj"] = (
        df_indexed["basis_ratio"]
        .rolling(window=f"{window_minutes}T", min_periods=1)
        .median()
    )

    df_indexed = df_indexed.reset_index()
    df["tx_time_dt"] = df_indexed["tx_time_dt"]
    df["long_term_basis_adj"] = df_indexed["long_term_basis_adj"]
    return df


def add_price_adjustments(df: pd.DataFrame) -> pd.DataFrame:
    """
    Construct bid_price_lead_adj and ask_price_lead_adj.
    """
    out = df.copy()
    out["bid_price_lead_adj"] = out["bid_price_lead"] * out["long_term_basis_adj"]
    out["ask_price_lead_adj"] = out["ask_price_lead"] * out["long_term_basis_adj"]
    return out


def add_bid_price_vol(
    df: pd.DataFrame,
    vol_window: str = "1s",
    agg_window: str = "30s",
    quantile: float = 0.75,
) -> pd.DataFrame:
    """
        Calculate bid_price_vol and its rolling quantile:
            - bid_price_vol = (max value of bid_price_lead in past vol_window / min value) - 1
            - bid_price_vol_agg = given quantile of bid_price_vol in past agg_window (default 0.75)

        Parameters:
            - vol_window: time window for calculating single-point volatility range, e.g., "1s", "2s", "500ms"
            - agg_window: time window for rolling aggregation of bid_price_vol, e.g., "30s", "1min"
            - quantile: quantile used for aggregation, default 0.75
    """
    out = df.copy()
    if "tx_time_dt" not in out.columns:
        out["tx_time_dt"] = pd.to_datetime(out["tx_time"], unit="ms", errors="coerce")

    # Drop rows that cannot be converted to valid time to avoid NaT in DatetimeIndex
    out = out[out["tx_time_dt"].notna()].copy()
    vol_df = out.set_index("tx_time_dt").sort_index()

    max_win = (
        vol_df["bid_price_lead"]
        .rolling(window=vol_window, min_periods=1)
        .max()
    )
    min_win = (
        vol_df["bid_price_lead"]
        .rolling(window=vol_window, min_periods=1)
        .min()
    )

    vol_df["bid_price_vol"] = max_win / min_win - 1

    vol_df["bid_price_vol_30s_p75"] = (
        vol_df["bid_price_vol"]
        .rolling(window=agg_window, min_periods=1)
        .quantile(quantile)
    )

    vol_df = vol_df.reset_index()
    out["bid_price_vol"] = vol_df["bid_price_vol"]
    out["bid_price_vol_30s_p75"] = vol_df["bid_price_vol_30s_p75"]
    return out


def add_spread_and_fee(
    df: pd.DataFrame,
    fee: float = 0.00016,
) -> pd.DataFrame:
    """Add fee and spread columns."""
    out = df.copy()
    out["fee"] = float(fee)
    out["spread"] = out["ask_price_lag"] / out["bid_price_lag"] - 1
    return out


def add_spread_rolling_median(
    df: pd.DataFrame,
    window_minutes: int = 10,
) -> pd.DataFrame:
    """Rolling median of spread over the past window_minutes."""
    out = df.copy()

    if "tx_time_dt" not in out.columns:
        out["tx_time_dt"] = pd.to_datetime(out["tx_time"], unit="ms", errors="coerce")
    out = out[out["tx_time_dt"].notna()].copy()

    spread_df = out.set_index("tx_time_dt").sort_index()
    spread_df["spread_rolling_median"] = (
        spread_df["spread"].rolling(window=f"{window_minutes}min", min_periods=1).median()
    )
    spread_df = spread_df.reset_index()
    out["tx_time_dt"] = spread_df["tx_time_dt"]
    out["spread_rolling_median"] = spread_df["spread_rolling_median"]
    return out


def add_spread_change(df: pd.DataFrame) -> pd.DataFrame:
    """spread_change = max(spread - spread_rolling_median, 0)."""
    out = df.copy()
    out["spread"] = pd.to_numeric(out["spread"], errors="coerce").astype("float64")
    out["spread_rolling_median"] = pd.to_numeric(out["spread_rolling_median"], errors="coerce").astype(
        "float64"
    )
    spread_diff = out["spread"] - out["spread_rolling_median"]
    out["spread_change"] = np.where(spread_diff > 0, spread_diff, 0.0).astype("float64")
    return out


def add_opp_cost_metrics(
    df: pd.DataFrame,
    fee: float = 0.00016,
) -> pd.DataFrame:
    """
        Calculate according to notebook logic:
      - fee, spread, cost
      - opp  = bid_price_lead_adj / bid_price_lag - 1
      - opp_sell = ask_price_lag / ask_price_lead_adj - 1
    """
    out = df.copy()

    # Ensure fee/spread exist (may be precomputed).
    if "fee" not in out.columns:
        out["fee"] = float(fee)
    if "spread" not in out.columns:
        out["spread"] = (out["ask_price_lag"] / out["bid_price_lag"] - 1).astype("float64")

    # Ensure numeric types are stable for arithmetic.
    for col in ("fee", "spread", "bid_price_vol_30s_p75"):
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce").astype("float64")

    if "spread_change" in out.columns:
        out["spread_change"] = pd.to_numeric(out["spread_change"], errors="coerce").astype("float64")
        out["cost"] = (
            out["fee"] * 2 + out["spread"] + out["bid_price_vol_30s_p75"] + out["spread_change"]
        ).astype("float64")
    else:
        out["cost"] = (out["fee"] * 2 + out["spread"] + out["bid_price_vol_30s_p75"]).astype("float64")

    for col in ("bid_price_lead_adj", "bid_price_lag", "ask_price_lag", "ask_price_lead_adj"):
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce").astype("float64")

    out["opp"] = (out["bid_price_lead_adj"] / out["bid_price_lag"] - 1).astype("float64")
    out["opp_sell"] = (out["ask_price_lag"] / out["ask_price_lead_adj"] - 1).astype("float64")
    return out


# ===== Process Detection and Statistics =====

def detect_processes(
    df: pd.DataFrame,
    signal_col: str,
    cost_col: str = "cost",
    prefix: str = "",
) -> Tuple[pd.DataFrame, pd.core.groupby.generic.DataFrameGroupBy]:
    """
        Detect processes where signal_col > cost_col, and add several columns to df:
      - {prefix}gt_cost
      - {prefix}minus_cost
      - {prefix}process_start
      - {prefix}process_id
        Returns:
            - DataFrame with new columns (copy)
            - groupby object containing only signal>cost rows
    """
    col_gt = f"{prefix}gt_cost"
    col_minus = f"{prefix}minus_cost"
    col_prev = f"prev_{prefix}gt_cost"
    col_start = f"{prefix}process_start"
    col_pid = f"{prefix}process_id"

    out = df.sort_values("tx_time").reset_index(drop=True).copy()

    out[col_gt] = out[signal_col] > out[cost_col]
    out[col_minus] = out[signal_col] - out[cost_col]

    out[col_prev] = out[col_gt].shift(1).fillna(False)
    out[col_start] = ~out[col_prev] & out[col_gt]

    out[col_pid] = out[col_start].cumsum()
    out.loc[~out[col_gt], col_pid] = np.nan
    out[col_pid] = out[col_pid].ffill()

    groups = out[out[col_gt]].groupby(col_pid)
    return out, groups


def summarize_process_groups(
    groups: pd.core.groupby.generic.DataFrameGroupBy,
    tx_col: str,
    minus_col: str,
) -> Tuple[pd.DataFrame, Dict]:
    """
        Statistics for given process groups:
            - duration of each process (seconds)
            - maximum value of minus_col in each process and its relative position within the process
        Returns:
            - per_process_df: detailed table with one row per process
            - summary: overall statistics (mean, median, percentiles, etc.)
    """
    records = []

    for pid, g in groups:
        g = g.sort_values(tx_col).reset_index(drop=True)
        start_ts = g[tx_col].iloc[0]
        end_ts = g[tx_col].iloc[-1]
        duration_sec = (end_ts - start_ts) / 1000.0

        # Find maximum value of minus_col and its relative position within this process
        arr = g[minus_col].to_numpy()
        local_idx = int(arr.argmax())
        max_value = float(arr[local_idx])
        position = local_idx / (len(g) - 1) if len(g) > 1 else 0.0

        records.append(
            {
                "process_id": pid,
                "start_tx_time": int(start_ts),
                "end_tx_time": int(end_ts),
                "duration_sec": float(duration_sec),
                "max_minus_value": max_value,
                "max_position": float(position),
            }
        )

    per_process_df = pd.DataFrame(records)

    summary: Dict[str, Dict[str, float]] = {}
    if not per_process_df.empty:
        def s_stats(series: pd.Series) -> Dict[str, float]:
            return {
                "count": int(series.shape[0]),
                "mean": float(series.mean()),
                "median": float(series.median()),
                "min": float(series.min()),
                "max": float(series.max()),
                "std": float(series.std(ddof=0)),
                "p25": float(series.quantile(0.25)),
                "p75": float(series.quantile(0.75)),
            }

        summary = {
            "duration_sec": s_stats(per_process_df["duration_sec"]),
            "max_minus_value": s_stats(per_process_df["max_minus_value"]),
            "max_position": s_stats(per_process_df["max_position"]),
        }

    return per_process_df, summary


# ===== Plotting Functions =====

def plot_opp_cost_analysis(
    per_process_df: pd.DataFrame,
    summary: Dict,
    out_dir: str,
    prefix: str,
) -> None:
    """
    Plot process duration / maximum value / position distribution charts in notebook style.
    """
    if per_process_df.empty:
        return

    ensure_dir(out_dir)

    durations = per_process_df["duration_sec"].to_numpy()
    max_vals = per_process_df["max_minus_value"].to_numpy()
    positions = per_process_df["max_position"].to_numpy()

    plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    fig = plt.figure(figsize=(16, 12))

    # 1. Process duration distribution
    ax1 = plt.subplot(2, 3, 1)
    ax1.hist(durations, bins=50, edgecolor="black", alpha=0.7)
    ax1.set_xlabel("Duration (seconds)")
    ax1.set_ylabel("Frequency")
    ax1.set_title(f"1. {prefix}>cost Process Duration Distribution", fontweight="bold")
    ax1.axvline(durations.mean(), color="r", linestyle="--", linewidth=2, label=f"Mean: {durations.mean():.3f}s")
    ax1.axvline(np.median(durations), color="g", linestyle="--", linewidth=2, label=f"Median: {np.median(durations):.3f}s")
    ax1.legend()

    # 2. Duration boxplot
    ax2 = plt.subplot(2, 3, 2)
    bp = ax2.boxplot(durations, patch_artist=True, widths=0.5)
    bp["boxes"][0].set_facecolor("lightblue")
    ax2.set_ylabel("Duration (seconds)")
    ax2.set_title(f"2. {prefix}>cost Process Duration Boxplot", fontweight="bold")
    ax2.grid(True, alpha=0.3)

    # 3. Maximum value distribution
    ax3 = plt.subplot(2, 3, 3)
    ax3.hist(max_vals, bins=50, edgecolor="black", alpha=0.7, color="orange")
    ax3.set_xlabel(f"{prefix} - cost Maximum Value")
    ax3.set_ylabel("Frequency")
    ax3.set_title(f"3. {prefix}-cost Maximum Value Distribution", fontweight="bold")
    ax3.axvline(max_vals.mean(), color="r", linestyle="--", linewidth=2, label=f"Mean: {max_vals.mean():.6f}")
    ax3.axvline(np.median(max_vals), color="g", linestyle="--", linewidth=2, label=f"Median: {np.median(max_vals):.6f}")
    ax3.legend()

    # 4. Maximum value boxplot
    ax4 = plt.subplot(2, 3, 4)
    bp2 = ax4.boxplot(max_vals, patch_artist=True, widths=0.5)
    bp2["boxes"][0].set_facecolor("lightcoral")
    ax4.set_ylabel(f"{prefix}-cost Maximum Value")
    ax4.set_title(f"4. {prefix}-cost Maximum Value Boxplot", fontweight="bold")
    ax4.grid(True, alpha=0.3)

    # 5. Position distribution
    ax5 = plt.subplot(2, 3, 5)
    ax5.hist(positions, bins=30, edgecolor="black", alpha=0.7, color="purple")
    ax5.set_xlabel("Position (0=start, 1=end)")
    ax5.set_ylabel("Frequency")
    ax5.set_title(f"5. {prefix}-cost Maximum Value Position Distribution in Process", fontweight="bold")
    ax5.axvline(0.5, color="gray", linestyle="--", linewidth=2, label="Midpoint")
    ax5.axvline(positions.mean(), color="r", linestyle="--", linewidth=2, label=f"Mean Position: {positions.mean():.3f}")
    ax5.legend()

    # 6. Scatter plot: duration vs maximum value
    ax6 = plt.subplot(2, 3, 6)
    ax6.scatter(durations, max_vals, alpha=0.5, s=20)
    ax6.set_xlabel("Process Duration (seconds)")
    ax6.set_ylabel(f"{prefix}-cost Maximum Value")
    ax6.set_title(f"6. Duration vs {prefix}-cost Maximum Value", fontweight="bold")
    ax6.grid(True, alpha=0.3)

    plt.tight_layout()
    out_path = os.path.join(out_dir, f"{prefix}_cost_analysis.png")
    plt.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_signal_vs_cost_scatter(
    df: pd.DataFrame,
    out_dir: str,
    signal_col: str,
    cost_col: str = "cost",
    prefix: str = "",
) -> None:
    """
    Plot scatter plot of signal vs cost over time.
    """
    if df.empty:
        return

    ensure_dir(out_dir)

    if "tx_time_dt" not in df.columns:
        df = df.copy()
        df["tx_time_dt"] = pd.to_datetime(df["tx_time"], unit="ms")

    plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    fig, ax = plt.subplots(figsize=(16, 6))

    # Sample appropriately to avoid oversized images
    # sample_size = min(500_000, len(df))
    # if len(df) > sample_size:
    #     step = len(df) // sample_size
    #     df_plot = df.iloc[::step].copy()
    # else:
    #     df_plot = df
    df_plot = df

    ax.scatter(df_plot["tx_time_dt"], df_plot[signal_col], s=1, alpha=0.4, label=signal_col, color="blue")
    ax.scatter(df_plot["tx_time_dt"], df_plot[cost_col], s=1, alpha=0.4, label=cost_col, color="red")

    ax.set_xlabel("Time (tx_time_dt)")
    ax.set_ylabel("Value")
    ax.set_title(f"{prefix} and cost Time Series Scatter Plot", fontweight="bold")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.xticks(rotation=45)
    plt.tight_layout()

    out_path = os.path.join(out_dir, f"{prefix}_vs_cost_scatter.png")
    plt.savefig(out_path, dpi=150)
    plt.close(fig)


# ===== Single Batch Processing (single datehour) =====

def process_single_datehour(
    datehour: str,
    lead_symbol: str = DEFAULT_LEAD_SYMBOL,
    lag_symbol: str = DEFAULT_LAG_SYMBOL,
    *,
    result_dir: str = DEFAULT_RESULT_DIR,
    data_dir: str = DEFAULT_DATA_DIR,
) -> Dict:
    """
        Process a single datehour:
            - Read data
            - Build merged_df
            - Calculate long_term_basis_adj / bid_price_vol and other indicators
            - Calculate statistical results for opp / opp_sell vs cost
            - Generate charts
            - Persist per-process statistics and summary

        Returns:
            - A dict containing batch summary information for subsequent cross-batch aggregation.
    """
    # Skip missing input files early.
    missing = []
    if not _hdf_exists(datehour, lead_symbol, data_dir=data_dir):
        missing.append(_hdf_path(datehour, lead_symbol, data_dir=data_dir))
    if not _hdf_exists(datehour, lag_symbol, data_dir=data_dir):
        missing.append(_hdf_path(datehour, lag_symbol, data_dir=data_dir))
    if missing:
        print(f"Skipping {datehour}: missing input file(s):")
        for p in missing:
            print(f"  - {p}")
        return {}

    batch_dir = os.path.join(result_dir, datehour)
    ensure_dir(batch_dir)

    # 1. Read data and merge
    lead, lag = read_pair_for_datehour(
        datehour,
        lead_symbol=lead_symbol,
        lag_symbol=lag_symbol,
        data_dir=data_dir,
    )
    merged = build_merged_df(lead, lag)

    # 2. Various indicators
    merged = add_long_term_basis(merged, window_minutes=10)
    merged = add_price_adjustments(merged)
    # Default: use 1-second window to calculate single-point volatility, take 0.75 quantile within 30-second window
    merged = add_bid_price_vol(merged, vol_window="1s", agg_window="30s", quantile=0.75)
    merged = add_spread_and_fee(merged)
    merged = add_spread_rolling_median(merged, window_minutes=10)
    merged = add_spread_change(merged)
    merged = add_opp_cost_metrics(merged)

    # 3. opp process detection and statistics
    merged_opp, opp_groups = detect_processes(merged, signal_col="opp", cost_col="cost", prefix="opp_")
    opp_per_process_df, opp_summary = summarize_process_groups(
        opp_groups,
        tx_col="tx_time",
        minus_col="opp_minus_cost",
    )

    # 4. opp_sell process detection and statistics
    merged_both, opp_sell_groups = detect_processes(merged_opp, signal_col="opp_sell", cost_col="cost", prefix="opp_sell_")
    opp_sell_per_process_df, opp_sell_summary = summarize_process_groups(
        opp_sell_groups,
        tx_col="tx_time",
        minus_col="opp_sell_minus_cost",
    )

    # 5. Save per-process results to CSV
    if not opp_per_process_df.empty:
        opp_per_process_df.to_csv(os.path.join(batch_dir, "opp_per_process.csv"), index=False)
    if not opp_sell_per_process_df.empty:
        opp_sell_per_process_df.to_csv(os.path.join(batch_dir, "opp_sell_per_process.csv"), index=False)

    # 6. Save summary to JSON
    batch_summary = {
        "datehour": datehour,
        "num_rows": int(merged_both.shape[0]),
        "opp": opp_summary,
        "opp_sell": opp_sell_summary,
    }
    save_json(batch_summary, os.path.join(batch_dir, "summary.json"))

    # 7. Plotting (save as PNG)
    plot_opp_cost_analysis(
        opp_per_process_df,
        opp_summary,
        out_dir=batch_dir,
        prefix="opp",
    )
    plot_opp_cost_analysis(
        opp_sell_per_process_df,
        opp_sell_summary,
        out_dir=batch_dir,
        prefix="opp_sell",
    )
    plot_signal_vs_cost_scatter(
        merged_both,
        out_dir=batch_dir,
        signal_col="opp",
        prefix="opp",
    )
    plot_signal_vs_cost_scatter(
        merged_both,
        out_dir=batch_dir,
        signal_col="opp_sell",
        prefix="opp_sell",
    )

    # 8. Return per-process results from this batch for subsequent aggregation
    batch_summary["opp_per_process"] = opp_per_process_df.to_dict(orient="records")
    batch_summary["opp_sell_per_process"] = opp_sell_per_process_df.to_dict(orient="records")
    return batch_summary


# ===== Multi-batch Aggregation =====

def aggregate_batches(batch_summaries: List[Dict]) -> None:
    """
    Merge per-process results from multiple datehours for overall statistics and plotting.
    """
def aggregate_batches(batch_summaries: List[Dict], *, result_dir: str = DEFAULT_RESULT_DIR) -> None:
    """Merge per-process results from multiple datehours for overall statistics and plotting."""
    if not batch_summaries:
        return

    agg_dir = os.path.join(result_dir, "aggregate")
    ensure_dir(agg_dir)

    # Aggregate per-process results
    opp_all = []
    opp_sell_all = []
    for bs in batch_summaries:
        for r in bs.get("opp_per_process", []):
            r2 = r.copy()
            r2["datehour"] = bs["datehour"]
            r2["signal"] = "opp"
            opp_all.append(r2)
        for r in bs.get("opp_sell_per_process", []):
            r2 = r.copy()
            r2["datehour"] = bs["datehour"]
            r2["signal"] = "opp_sell"
            opp_sell_all.append(r2)

    opp_all_df = pd.DataFrame(opp_all)
    opp_sell_all_df = pd.DataFrame(opp_sell_all)

    if not opp_all_df.empty:
        opp_all_df.to_csv(os.path.join(agg_dir, "opp_all_per_process.csv"), index=False)
    if not opp_sell_all_df.empty:
        opp_sell_all_df.to_csv(os.path.join(agg_dir, "opp_sell_all_per_process.csv"), index=False)

    # Can create overall distribution plots based on merged data, here using duration and max_minus_value for opp / opp_sell as examples
    def _plot_aggregate(df: pd.DataFrame, signal_name: str) -> None:
        if df.empty:
            return
        durations = df["duration_sec"].to_numpy()
        max_vals = df["max_minus_value"].to_numpy()

        plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "DejaVu Sans"]
        plt.rcParams["axes.unicode_minus"] = False

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        ax1 = axes[0]
        ax1.hist(durations, bins=60, edgecolor="black", alpha=0.7)
        ax1.set_xlabel("Duration (seconds)")
        ax1.set_ylabel("Frequency")
        ax1.set_title(f"Aggregate {signal_name}>cost Process Duration Distribution")
        # Mark mean and median
        mean_dur = durations.mean()
        median_dur = np.median(durations)
        ax1.axvline(mean_dur, color="r", linestyle="--", linewidth=2, label=f"Mean: {mean_dur:.3f}s")
        ax1.axvline(median_dur, color="g", linestyle="--", linewidth=2, label=f"Median: {median_dur:.3f}s")
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        ax2 = axes[1]
        ax2.hist(max_vals, bins=60, edgecolor="black", alpha=0.7, color="orange")
        ax2.set_xlabel(f"{signal_name}-cost Maximum Value")
        ax2.set_ylabel("Frequency")
        ax2.set_title(f"Aggregate {signal_name}-cost Maximum Value Distribution")
        # Mark mean and median
        mean_max = max_vals.mean()
        median_max = np.median(max_vals)
        ax2.axvline(mean_max, color="r", linestyle="--", linewidth=2, label=f"Mean: {mean_max:.6f}")
        ax2.axvline(median_max, color="g", linestyle="--", linewidth=2, label=f"Median: {median_max:.6f}")
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        out_path = os.path.join(agg_dir, f"{signal_name}_aggregate_hist.png")
        plt.savefig(out_path, dpi=150)
        plt.close(fig)

    _plot_aggregate(opp_all_df, "opp")
    _plot_aggregate(opp_sell_all_df, "opp_sell")

    # Save a simple overview JSON (summary of each batch's summary)
    save_json(batch_summaries, os.path.join(agg_dir, "batch_summaries.json"))


# ===== Command Line Entry Point =====

def main(
    datehours: List[str] = None,
    datehour_start: Optional[str] = None,
    datehour_end: Optional[str] = None,
    lead_symbol: str = DEFAULT_LEAD_SYMBOL,
    lag_symbol: str = DEFAULT_LAG_SYMBOL,
    *,
    result_dir: str = DEFAULT_RESULT_DIR,
    data_dir: str = DEFAULT_DATA_DIR,
) -> None:
    """
        Main process:
            - Process each datehour sequentially
            - Save each batch's results to results/<datehour> directory
            - Finally perform aggregated analysis and plotting for all batch results, save to results/aggregate
    """
    if datehour_start and datehour_end:
        datehours = _expand_datehour_range(datehour_start, datehour_end)
    elif (datehour_start is None) ^ (datehour_end is None):
        raise ValueError("Both datehour_start and datehour_end must be provided together")
    elif datehours is None or len(datehours) == 0:
        # Default example: consistent with notebook
        datehours = ["2026011822", "2026011823", "2026011900"]

    print(f"Data root directory: {data_dir}")
    print(f"Results output directory: {result_dir}")
    print(f"Processing batches: {datehours}")

    batch_summaries: List[Dict] = []

    for dh in datehours:
        wall_start = datetime.now()
        perf_start = time.perf_counter()
        print(f"\n===== Starting to process batch {dh} =====")
        print(f"Batch start: {_fmt_wall_time(wall_start)}")
        try:
            bs = process_single_datehour(
                dh,
                lead_symbol=lead_symbol,
                lag_symbol=lag_symbol,
                result_dir=result_dir,
                data_dir=data_dir,
            )
            if bs:
                batch_summaries.append(bs)
                print(f"Batch {dh} processing completed, results saved to: {os.path.join(result_dir, dh)}")
        except Exception as e:
            print(f"Batch {dh} processing failed: {e}")
        finally:
            wall_end = datetime.now()
            elapsed = time.perf_counter() - perf_start
            print(f"Batch end:   {_fmt_wall_time(wall_end)}")
            print(f"Duration:    {_fmt_duration(elapsed)}")

    print("\n===== All batch processing completed, starting aggregated analysis =====")
    aggregate_batches(batch_summaries, result_dir=result_dir)
    print(f"Aggregated results saved to: {os.path.join(result_dir, 'aggregate')}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description=(
            "Analyze lead/lag arbitrage signals from HDF bbo data.\n\n"
            "Common usage:\n"
            "  python analysis.py -r 2026011822,2026011823 --lead binance.eth_usdt_swap --lag gateio.eth_usdt_swap\n\n"
            "Data/Result dirs default to $DATA_DIR and $RESULT_DIR (or ./data ./results)."
        )
    )

    parser.add_argument(
        "-r",
        "--range",
        dest="datehour_range",
        default=None,
        help="Datehour range (inclusive) as START,END (comma-separated), format YYYYMMDDHH",
    )

    parser.add_argument(
        "--batch-config",
        default=None,
        help="Path to target.json; runs analysis for each symbol and writes to ${RESULT_DIR}/${SYMBOL}",
    )

    # Shorter flags; keep old names as aliases.
    parser.add_argument(
        "--lead",
        "--lead_symbol",
        dest="lead_symbol",
        default=DEFAULT_LEAD_SYMBOL,
        help=f"Lead exchange contract identifier (default: {DEFAULT_LEAD_SYMBOL})",
    )
    parser.add_argument(
        "--lag",
        "--lag_symbol",
        dest="lag_symbol",
        default=DEFAULT_LAG_SYMBOL,
        help=f"Lag exchange contract identifier (default: {DEFAULT_LAG_SYMBOL})",
    )

    parser.add_argument(
        "--data-dir",
        default=None,
        help="Override input data directory (default: $DATA_DIR or ./data)",
    )
    parser.add_argument(
        "--result-dir",
        default=None,
        help="Override output results directory (default: $RESULT_DIR or ./results)",
    )

    args = parser.parse_args()

    data_dir = args.data_dir if args.data_dir is not None else DEFAULT_DATA_DIR
    result_dir = args.result_dir if args.result_dir is not None else DEFAULT_RESULT_DIR

    if args.batch_config is not None:
        run_batch_from_target_json(args.batch_config, result_dir=result_dir, data_dir=data_dir)
    else:
        datehour_start = None
        datehour_end = None
        if args.datehour_range is not None:
            parts = [p.strip() for p in str(args.datehour_range).split(",") if p.strip()]
            if len(parts) != 2:
                raise SystemExit("--range must be in the form START,END (e.g. 2026011822,2026011823)")
            datehour_start, datehour_end = parts

        main(
            datehours=None,
            datehour_start=datehour_start,
            datehour_end=datehour_end,
            lead_symbol=args.lead_symbol,
            lag_symbol=args.lag_symbol,
            result_dir=result_dir,
            data_dir=data_dir,
        )
