#!/usr/bin/env python3
"""
Order analyzer for lead-lag strategy backtest results.

This is a simplified version of trace.py that only reads order files
and outputs trade summary from the analyze_trades function.

Usage:
    python order.py -s config/strategy/river.json -b config/backtest/0.json
"""

import argparse
import json
import os
from typing import Dict

import pandas as pd

# Taker fee rates by exchange
taker_fees = {
    "bybit": 1.5 * (1e-4),
    "gateio": 1.6 * (1e-4)
}


# Read paths from environment variables
DEFAULT_LOG_FILE = os.path.join(
    os.getenv("LOG_DIR", os.path.join( os.path.dirname(os.path.abspath(__file__)) , "logs")),
    os.getenv("LOG_FILE", "backtest.log")
)


def read_jsons(logfile: str, groupby: str) -> Dict[str, pd.DataFrame]:
    """
    Read JSON lines from log file and group by specified field.
    
    Parameters:
    - logfile: Path to JSON log file
    - groupby: Field name to group by (e.g., 'type')
    
    Returns:
    - Dictionary mapping group values to DataFrames
    """
    with open(logfile, "r") as f:
        lines = f.readlines()
    
    rows = {}
    for text in lines:
        doc = json.loads(text)
        dtype = doc.get(groupby, "")
        rows.setdefault(dtype, []).append(doc)
    
    dfs = {}
    for k, v in rows.items():
        dfs[k] = pd.DataFrame(v)
        if 'ts' in dfs[k].columns:
            dfs[k].index = pd.to_datetime(dfs[k]["ts"])
    
    return dfs


def handle_trades(df: pd.DataFrame) -> pd.Series:
    """
    Calculate trade statistics for a group of orders.
    
    Parameters:
    - df: DataFrame with order data
    
    Returns:
    - Series with profit, duration, fee, and count
    """
    openOrder = df.iloc[0]
    notional = df["avg"] * df["filled"] * df["side"]
    total = notional.abs().sum() / 2
    flow = (- notional).sum()
    total_fee = df['fee'].sum() if 'fee' in df.columns else 0
    return pd.Series({
        "qty": openOrder["qty"],
        "filled": openOrder["filled"],
        "filled%": openOrder["filled"] / openOrder["qty"],
        "avg": openOrder["avg"],
        "profit": flow,
        "profit%": flow / total if total != 0 else 0,
        "fee": total_fee,
        "duration": df["server_ms"].max() - df["server_ms"].min(),
        "count": len(df),
    })


def analyze_trades(orders_df: pd.DataFrame, trigger_df: pd.DataFrame = None, lag_exchange: str = None):
    """
    Analyze trades grouped by trade group ID.
    
    Parameters:
    - orders_df: DataFrame with order data
    - trigger_df: DataFrame with trigger data (optional, for liquidity stats)
    - lag_exchange: Lag exchange name for fee calculation (e.g., 'bybit', 'gateio')
    
    Returns:
    - Tuple of (DataFrame with trade statistics, Series with summary statistics)
    """
    df = orders_df[orders_df.filled > 0].copy()
    
    # Calculate fee for each order: fee = abs(filled * avg) * fee_rate
    fee_rate = taker_fees.get(lag_exchange, 0) if lag_exchange else 0
    df['fee'] = (df['filled'] * df['avg']).abs() * fee_rate
    
    trades_df = df.groupby("group").apply(handle_trades)
    
    # Calculate profit after fee
    trades_df['profit_after_fee'] = trades_df['profit'] - trades_df['fee']
    
    # Calculate summary statistics
    profits = trades_df['profit']
    profits_after_fee = trades_df['profit_after_fee']
    notional = trades_df["avg"] * trades_df["filled"]
    filled_rate = orders_df['filled'].sum() / orders_df['qty'].sum() if orders_df['qty'].sum() > 0 else 0
    win_rate = (profits > 0).sum() / len(profits) if len(profits) > 0 else 0
    win_rate_after_fee = (profits_after_fee > 0).sum() / len(profits_after_fee) if len(profits_after_fee) > 0 else 0
    profit_rate = profits.sum() / notional.abs().sum() if notional.abs().sum() > 0 else 0
    profit_rate_after_fee = profits_after_fee.sum() / notional.abs().sum() if notional.abs().sum() > 0 else 0
    
    # Calculate open long/short orders
    open_orders = orders_df[orders_df["cid"] == orders_df["group"]]
    open_long = sum(open_orders["side"] == 1)
    open_short = len(open_orders) - open_long
    
    doc = {
        "total_orders": len(orders_df),
        "filled_orders": len(df),
        "open_long": open_long,
        "open_short": open_short,
        'total_trades': len(profits),
        'filled_rate': filled_rate,
        'win_rate': win_rate,
        'net_win_rate': win_rate_after_fee,
        'profit_mean': profits.mean() if len(profits) > 0 else 0,
        "net_profit_mean": profits_after_fee.mean() if len(profits_after_fee) > 0 else 0,
        'profit_total': profits.sum(),
        'net_profit_total': profits_after_fee.sum(),
        'profit_rate': profit_rate,
        'net_profit_rate': profit_rate_after_fee,
        "holding_period(ms)": trades_df["duration"].mean() if len(trades_df) > 0 else 0
    }
    
    # Calculate liquidity statistics if trigger data is available
    if len(df) > 0 and trigger_df is not None and "liquidity" in trigger_df.columns:
        liquidity = trigger_df.set_index("cid").loc[list(df["cid"])].groupby("position")["liquidity"].mean()
        doc["avg open liquidity"] = liquidity.get("open", 0)
        doc["avg close liquidity"] = liquidity.get("close", 0)
    
    summary = pd.Series(doc)
    
    return trades_df, summary


def load_strategy_config(filename: str) -> dict:
    """
    Load strategy configuration from JSON file.
    
    Parameters:
    - filename: Path to strategy config file
    
    Returns:
    - Dictionary with strategy configuration
    """
    with open(filename, 'r') as f:
        return json.load(f)

def main():
    parser = argparse.ArgumentParser(description='Analyze lead-lag strategy order results')
    parser.add_argument('-s', '--strategy', required=True, help='Path to strategy config JSON file')
    parser.add_argument('-b', '--backtest', help='Path to backtest setting JSON file (optional)')
    parser.add_argument('-l', '--logfile', default=DEFAULT_LOG_FILE,
                       help=f'Path to log file (default: $LOG_DIR/$LOG_FILE or {DEFAULT_LOG_FILE})')
    parser.add_argument('-v', '--verbose', action='store_true',
                       help='Show detailed trade statistics')
    parser.add_argument('-j', '--json', action='store_true',
                       help='Output results in JSON format')
    parser.add_argument('-o', '--output', help='Output file path (if not specified, prints to stdout)')
    args = parser.parse_args()
    
    # Extract lag exchange from strategy config
    strategy = load_strategy_config(args.strategy)
    lag_exchange = strategy.get('lag', "")
    lead_exchange = strategy.get('lead', "")

    
    print(f"Log file: {args.logfile}")
    print(f"Lag exchange: {lag_exchange}")
    print(f"Fee rate: {taker_fees.get(lag_exchange, 0)*100:.3f}%" if lag_exchange else "Fee rate: 0%")
    print()
    
    # Load logs
    print("Loading order data...")
    dfs = read_jsons(args.logfile, "type")
    
    if "order" not in dfs:
        print("Error: No order data found in log file")
        return
    
    # Get trigger data if available
    trigger_df = dfs.get("trigger", None)
    
    # Analyze trades
    trades, summary = analyze_trades(dfs["order"], trigger_df, lag_exchange)
    
    # Output in JSON format
    if args.json:
        output = {
            'metadata': {
                'log_file': args.logfile,
                'lag': lag_exchange,
                'lead': lead_exchange,
                'fee_rate': taker_fees.get(lag_exchange, 0) if lag_exchange else 0
            },
            'summary': summary.to_dict(),
            'trades': trades.to_dict(orient='index') if args.verbose else None
        }
        
        json_str = json.dumps(output, indent=2)
        
        if args.output:
            with open(args.output, 'w') as f:
                f.write(json_str)
            print(f"Results saved to {args.output}")
        else:
            print(json_str)
    else:
        # Display results in human-readable format
        print("\n" + "="*60)
        print("SUMMARY STATISTICS")
        print("="*60)
        for key, value in summary.items():
            display_key = ' '.join(word.capitalize() for word in key.split('_'))
            if 'rate' in key.lower():
                print(f"{display_key}: {value*100:.2f}%")
            elif key in ['total_orders', 'filled_orders', 'total_trades']:
                print(f"{display_key}: {int(value)}")
            else:
                print(f"{display_key}: {value:.2f}")
        
        if args.verbose:
            print("\n" + "="*60)
            print("DETAILED TRADE STATISTICS")
            print("="*60)
            trades_filtered = trades[trades["count"] > 1]
            print(trades_filtered)
            print("\nDescriptive Statistics:")
            print(trades_filtered.describe())
            print(f"\nWin rate (before fees): {(trades['profit'] > 0).sum() / len(trades):.2%}")
            print(f"Win rate (after fees): {(trades['profit_after_fee'] > 0).sum() / len(trades):.2%}")


if __name__ == '__main__':
    main()