# Lead-Lag Strategy Quoting Logic

This document summarizes when the lead-lag strategy decides to quote (send orders) based on the implementation in `lead_lag_controller.go`.

## Overview

The strategy uses a **fair price** calculated from lead symbols (weighted average) and compares it against **lag symbol** prices to identify trading opportunities. Quotes are sent when entry or exit conditions are met.

## Market Data Flow

1. **Lead symbol updates** (BBO/Depth) → Update fair price → Check all lag symbols
2. **Lag symbol updates** (BBO/Depth) → Update deviation/spread → Check trading signals for that symbol

## When to Quote: Entry Signals

### Long Entry Conditions

Quotes a **buy order** (Long) when **all** of the following are met:

1. **Price crossing**: `targetBid >= lagAsk`
   - `targetBid` = break-even bid price adjusted by buffer: `breakEvenBid * exp(-buffer)`
   - `breakEvenBid` accounts for trading fees and projected spread

2. **Projected return strength**: `proxyLeadBidMove >= projectedReturn/2`
   - Ensures the lead bid move is the main contributor to projected return

3. **Move spread**: `moveSpread > projectedReturn/2` where `moveSpread = proxyLeadBidMove - lagAskMove`
   - Ensures lead is moving up faster than lag, avoiding cases where lag is also moving strongly

4. **Position limit**: `currentPositionAmount < maxPositionAmount`
   - Prevents exceeding maximum position size

5. **Data freshness**: Both lead and lag market data must be fresh (within tolerance)

6. **No active order**: No existing active executor for this symbol

### Short Entry Conditions

Quotes a **sell order** (Short) when **all** of the following are met:

1. **Price crossing**: `targetAsk <= lagBid`
   - `targetAsk` = break-even ask price adjusted by buffer: `breakEvenAsk * exp(buffer)`

2. **Projected return strength**: `proxyLeadAskMove <= -projectedReturnShort/2` (negative move)
   - Ensures the lead ask move is the main contributor to projected return

3. **Move spread**: `moveSpread < -projectedReturnShort/2` where `moveSpread = proxyLeadAskMove - lagBidMove`
   - Ensures lead is moving down faster than lag

4. **Position limit**: `currentPositionAmount > -maxPositionAmount`

5. **Data freshness**: Both lead and lag market data must be fresh

6. **No active order**: No existing active executor for this symbol

## When to Quote: Exit Signals

### Long Position Exit

Quotes a **sell order** (to close long) when **any** of the following are met:

1. **Unwind signal**: `lagBid > projectedLagBid`
   - Market bid exceeds projected bid, indicating convergence/opportunity to exit

2. **Take profit**: `unrealizedReturn > takeProfitTolerance`
   - Position has reached profit target

### Short Position Exit

Quotes a **buy order** (to close short) when **any** of the following are met:

1. **Unwind signal**: `lagAsk < projectedLagAskShort`
   - Market ask below projected ask, indicating convergence

2. **Take profit**: `unrealizedReturn > takeProfitTolerance`

## Additional Quote Blocking Conditions

Even if entry/exit conditions are met, quotes may be blocked by:

1. **Order rate cap**: Current EMA order rate must be below cap (`orderRateCapPerTOpen` or `orderRateCapPerTClose`)

2. **Global block**: `blockUntilMs` prevents sending if `currentTime < blockUntilMs` (used for error handling)

3. **Early startup protection**: Blocks orders within `2 * deviationAdjustmentHalfLifeMs` after first deviation adjustment to avoid early instability

4. **Portfolio lock**: For opening orders, must acquire portfolio lock (prevents concurrent opening orders across instances)

5. **Minimum quantity**: Order quantity must exceed exchange minimum

6. **Strategy/algo enabled**: Both the controller instance and the overall algo must be enabled

## Price Calculations

### Fair Price (Proxy Lead Price)
- Weighted average of lead symbol prices with impact spread adjustments
- Updated incrementally on each lead BBO update

### Target Prices
- **Long targetBid**: Accounts for proxy lead bid, maker fees, lag taker fees, spread, and buffer
- **Short targetAsk**: Accounts for proxy lead ask, maker fees, lag taker fees, spread, and buffer

### Buffer
- Dynamic buffer: `volBufferMultiplier * volatilityEMA + constBuffer`
- Increases with volatility to provide wider margin

### Deviation Adjustment
- Long-term deviation adjustment accounts for persistent price differences between lead and lag exchanges
- Applied to adjust proxy lead prices before calculating targets

## Priority Order

1. **Entry signals** (long/short) are checked first and have priority over exits
2. **Exit signals** are only checked if no entry signal is triggered and position exists
3. If entry signal triggers, function returns early (no exit check for that update)

## Key Functions

- `checkTradingSignalsForLag()`: Main decision logic, called on every market data update
- `shouldEnterLong()` / `shouldEnterShort()`: Entry condition validators
- `submitIOCOrder()`: Final order submission with additional safety checks
- `CalculateTargetPrices()`: Shared calculation logic for projected prices

## Notes

- Uses **IOC (Immediate-or-Cancel)** orders - no resting quotes
- Only **one active order per symbol** at a time (enforced by atomic executor tracking)
- Entry signals require **both price crossing AND move spread conditions** to avoid false signals
- Exit signals are simpler (price-based unwind or take profit)
