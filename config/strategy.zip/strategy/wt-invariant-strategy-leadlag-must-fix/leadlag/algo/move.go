package algo

import (
	"sort"
	"time"

	"gonum.org/v1/gonum/stat"
)

type MoveQueue struct {
	RollAt time.Time
	Window time.Duration
	Up     []float64
	Down   []float64
}

func (q *MoveQueue) Push(up, down float64) {
	q.Up = append(q.Up, up)
	q.Down = append(q.Down, down)
}

func (q *MoveQueue) ShouldRoll(t time.Time) bool {
	return t.After(q.RollAt)
}

func (q *MoveQueue) Size() int {
	return len(q.Up)
}

func (q *MoveQueue) Init(t time.Time, window time.Duration) {
	q.Window = window
	q.Up = []float64{}
	q.Down = []float64{}
	q.Roll(t)
}

func (q *MoveQueue) Sort() {

	if len(q.Up) > 0 {
		sort.Float64s(q.Up)
	}
	if len(q.Down) > 0 {
		sort.Float64s(q.Down)
	}
}

func (q *MoveQueue) Qunatile(p float64) (upQunatile, downQunatile float64) {

	if len(q.Up) > 0 {
		upQunatile = stat.Quantile(p, stat.Empirical, q.Up, nil)
	}
	if len(q.Down) > 0 {
		downQunatile = stat.Quantile(1-p, stat.Empirical, q.Down, nil)
	}
	return
}

func (q *MoveQueue) Roll(t time.Time) {
	q.Up = q.Up[:0]
	q.Down = q.Down[:0]
	q.RollAt = t.Truncate(q.Window).Add(q.Window)
}
