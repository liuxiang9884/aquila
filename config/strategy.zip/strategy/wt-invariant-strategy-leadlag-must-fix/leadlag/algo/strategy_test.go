package algo

import (
	"io"
	"math"
	"net/http"
	"testing"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/atom"
	"git.hashingbot.com/aurthes/xex_mm_go/atom_symbol"
	"git.hashingbot.com/aurthes/xex_mm_go/marginmemoryclient/marginconstant"
	"git.hashingbot.com/aurthes/xex_mm_go/requests"
	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/shopspring/decimal"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/jsontype"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

const testServerTime = int64(1_700_000_000_000)

type testClient struct {
	sendOrderCount int
}

func (c *testClient) SendOrder(order requests.Order) error {
	c.sendOrderCount++
	return nil
}

func (c *testClient) Cancel(symbol *atom_symbol.Symbol, orderId string) error { return nil }

func (c *testClient) CancelByCID(symbol *atom_symbol.Symbol, cid string) error { return nil }

type testOrder struct {
	cid            string
	oid            string
	cancel         bool
	price          float64
	filledNotional float64
	filledQuantity float64
	quantity       float64
	status         int
	finishTs       int64
	sendTs         int64
	isMaker        bool
	filledUnit     int64
	firstCancelMs  int64
	firstQueryMs   int64
}

func (o *testOrder) GetMakeOrderParam(int, int) map[string]interface{} { return nil }

func (o *testOrder) MakeOrder(atom.IHttpClient, int, int) (*utils.OrderResponse, *http.Response, error) {
	return nil, nil, nil
}

func (o *testOrder) GetCID() string                            { return o.cid }
func (o *testOrder) SetCID(cid string)                         { o.cid = cid }
func (o *testOrder) SetOID(oid string)                         { o.oid = oid }
func (o *testOrder) GetOID() string                            { return o.oid }
func (o *testOrder) SetCancel(cancel bool)                     { o.cancel = cancel }
func (o *testOrder) GetCancel() bool                           { return o.cancel }
func (o *testOrder) GetExchangePair() string                   { return "test_exchange_pair" }
func (o *testOrder) GetOrderType() string                      { return "test_order_type" }
func (o *testOrder) SetOrderType(string)                       {}
func (o *testOrder) GetPrice() float64                         { return o.price }
func (o *testOrder) GetFilledNotional() float64                { return o.filledNotional }
func (o *testOrder) GetFilledQuantity() float64                { return o.filledQuantity }
func (o *testOrder) SetFilledNotional(v float64)               { o.filledNotional = v }
func (o *testOrder) SetFilledQuantity(v float64)               { o.filledQuantity = v }
func (o *testOrder) GetQuantity() float64                      { return o.quantity }
func (o *testOrder) SetQuantity(v float64)                     { o.quantity = v }
func (o *testOrder) GetSide() int                              { return 0 }
func (o *testOrder) GetTag() string                            { return "test_order" }
func (o *testOrder) GetSendTs() int64                          { return o.sendTs }
func (o *testOrder) SetSendTs(v int64)                         { o.sendTs = v }
func (o *testOrder) GetIncrFilled(*utils.OrderMessage) float64 { return 0 }
func (o *testOrder) GetIncrNotioanlFilled(*utils.OrderMessage) float64 {
	return 0
}
func (o *testOrder) GetSymbol() *atom_symbol.Symbol {
	return atom_symbol.MockSymbolViaBaseQuote(1, "test-order", "test", "spot", "BTC", "USDT", marginconstant.SpotTokenUnit)
}
func (o *testOrder) String() string                { return "testOrder" }
func (o *testOrder) SetPrice(v float64)            { o.price = v }
func (o *testOrder) SetFilledUnit(v float64) int64 { o.filledUnit = int64(v); return o.filledUnit }
func (o *testOrder) GetFilledUnit() int64          { return o.filledUnit }
func (o *testOrder) SetStatus(v int)               { o.status = v }
func (o *testOrder) GetStatus() int                { return o.status }
func (o *testOrder) Finished() bool                { return false }
func (o *testOrder) GetFinishTs() int64            { return o.finishTs }
func (o *testOrder) SetFinishTs(v int64)           { o.finishTs = v }
func (o *testOrder) GetIsMaker() bool              { return o.isMaker }
func (o *testOrder) Clone() requests.Order {
	return &testOrder{
		cid:            o.cid,
		oid:            o.oid,
		cancel:         o.cancel,
		price:          o.price,
		filledNotional: o.filledNotional,
		filledQuantity: o.filledQuantity,
		quantity:       o.quantity,
		status:         o.status,
		finishTs:       o.finishTs,
		sendTs:         o.sendTs,
		isMaker:        o.isMaker,
		filledUnit:     o.filledUnit,
		firstCancelMs:  o.firstCancelMs,
		firstQueryMs:   o.firstQueryMs,
	}
}
func (o *testOrder) SetFirstCancelMs(v int64) {
	if o.firstCancelMs < 1 {
		o.firstCancelMs = v
	}
}
func (o *testOrder) GetFirstCancelMs() int64 { return o.firstCancelMs }
func (o *testOrder) SetFirstQueryMs(v int64) {
	if o.firstQueryMs < 1 {
		o.firstQueryMs = v
	}
}
func (o *testOrder) GetFirstQueryMs() int64 { return o.firstQueryMs }

type testStrategyContext struct {
	now    time.Time
	client template.IClient
}

func (c *testStrategyContext) MainClient() template.IClient { return c.client }

func (c *testStrategyContext) AllClients() map[string]template.IClient { return nil }

func (c *testStrategyContext) GetClient(name string) template.IClient { return nil }

func (c *testStrategyContext) Now() time.Time { return c.now }

func (c *testStrategyContext) NowMs() int64 { return c.now.UnixMilli() }

func (c *testStrategyContext) NewOrder(params template.OrderParam) requests.Order {
	order := &testOrder{}
	order.SetCID(params.CID)
	order.SetPrice(params.Price)
	order.SetQuantity(params.Qty)
	return order
}

func (c *testStrategyContext) CallSignal(executeTime time.Time, tag string, payload interface{}) {}

func (c *testStrategyContext) CallFunc(executeTime time.Time, method func() error) {}

func (c *testStrategyContext) CallFuncNow(method func() error) {}

func (c *testStrategyContext) ReturnBBOToPool(bbo *utils.BBO) {}

func (c *testStrategyContext) ReturnTradeToPool(trade *utils.Trade) {}

func (c *testStrategyContext) ReturnDepthToPool(depth *utils.Depth) {}

func (c *testStrategyContext) ReturnOrderMessageToPool(msg *utils.OrderMessage) {}

func (c *testStrategyContext) ScheduleFunc(fn template.SchduledFunc, interval time.Duration, shift time.Duration) {
}

func newTestStrategy(t *testing.T) *Strategy {
	t.Helper()

	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Lead = "lead"
	cfg.Lag = "lag"
	cfg.Trigger.Lead = 0.5
	cfg.Trigger.Close = 0.25
	cfg.Trigger.DriftLimit = 10
	cfg.Trigger.DriftPeriod = jsontype.Duration(time.Minute)
	cfg.BBORecord.Window = jsontype.Duration(time.Minute)
	cfg.BBORecord.StatsWindow = jsontype.Duration(time.Minute)

	strat := cfg.New(nil)
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0)})
	return strat
}

func newTestStrategyWithClient(t *testing.T, client template.IClient) *Strategy {
	t.Helper()

	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Lead = "lead"
	cfg.Lag = "lag"
	cfg.Trigger.Lead = 0.01
	cfg.Trigger.Close = 0.005
	cfg.Trigger.LagPart = 0
	cfg.Trigger.DriftLimit = 0.02
	cfg.Trigger.DriftPeriod = jsontype.Duration(time.Minute)
	cfg.BBORecord.Window = jsontype.Duration(time.Minute)
	cfg.BBORecord.StatsWindow = jsontype.Duration(time.Minute)
	cfg.Execute.TrailingStop = 1.0

	strat := cfg.New(nil)
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0), client: client})
	return strat
}

func newTestStrategyWithExecution(t *testing.T, client template.IClient, trailingStop, maxEntrySpread float64) *Strategy {
	t.Helper()

	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Lead = "lead"
	cfg.Lag = "lag"
	cfg.Trigger.Lead = 0.01
	cfg.Trigger.Close = 0.005
	cfg.Trigger.LagPart = 0
	cfg.Trigger.DriftLimit = 0.02
	cfg.Trigger.DriftPeriod = jsontype.Duration(time.Minute)
	cfg.BBORecord.Window = jsontype.Duration(time.Minute)
	cfg.BBORecord.StatsWindow = jsontype.Duration(time.Minute)
	cfg.Execute.TrailingStop = trailingStop
	cfg.Execute.MaxEntrySpread = maxEntrySpread

	logger := logrus.New()
	logger.SetOutput(io.Discard)

	strat := cfg.New(logger.WithField("test", t.Name()))
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0), client: client})
	strat.SetRecorder(&recorder.EmptyRecorder{})
	return strat
}

func newAlignmentTestStrategy(t *testing.T, client template.IClient) (*Strategy, *testStrategyContext) {
	t.Helper()

	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Lead = "lead"
	cfg.Lag = "lag"
	cfg.Trigger.Lead = 0.01
	cfg.Trigger.Close = 0
	cfg.Trigger.LagPart = 0
	cfg.Trigger.DriftLimit = 10
	cfg.BBORecord.Window = jsontype.Duration(time.Minute)
	cfg.BBORecord.StatsWindow = jsontype.Duration(time.Second)
	cfg.Execute.TrailingStop = 1.0
	cfg.Execute.MaxEntrySpread = 0.05

	logger := logrus.New()
	logger.SetOutput(io.Discard)

	ctx := &testStrategyContext{now: time.Unix(1_700_000_000, 0), client: client}
	strat := cfg.New(logger.WithField("test", t.Name()))
	strat.SetContext(ctx)
	strat.SetRecorder(&recorder.EmptyRecorder{})
	return strat, ctx
}

func newAlignmentTestStrategyWithTuning(
	t *testing.T,
	client template.IClient,
	driftMinSamples int,
	statsWindow time.Duration,
) (*Strategy, *testStrategyContext) {
	t.Helper()

	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Lead = "lead"
	cfg.Lag = "lag"
	cfg.Trigger.Lead = 0.01
	cfg.Trigger.Close = 0
	cfg.Trigger.LagPart = 0
	cfg.Trigger.DriftLimit = 10
	cfg.Trigger.DriftMinSamples = driftMinSamples
	cfg.BBORecord.Window = jsontype.Duration(time.Minute)
	cfg.BBORecord.StatsWindow = jsontype.Duration(statsWindow)
	cfg.Execute.TrailingStop = 1.0
	cfg.Execute.MaxEntrySpread = 0.05

	logger := logrus.New()
	logger.SetOutput(io.Discard)

	ctx := &testStrategyContext{now: time.Unix(1_700_000_000, 0), client: client}
	strat := cfg.New(logger.WithField("test", t.Name()))
	strat.SetContext(ctx)
	strat.SetRecorder(&recorder.EmptyRecorder{})
	return strat, ctx
}

func newTestBBOAt(t *testing.T, exchangeName string, ask, bid float64, serverTime int64) *utils.BBO {
	t.Helper()

	symbol := atom_symbol.MockSymbolViaBaseQuote(1, exchangeName+"-symbol", exchangeName, "spot", "BTC", "USDT", marginconstant.SpotTokenUnit)
	return utils.NewBBO(
		ask, 1,
		bid, 1,
		serverTime,
		serverTime,
		utils.BBOMeta{Symbol: symbol},
		nil,
	)
}

func seedLeadRecorderAt(strat *Strategy, ask, bid float64, serverTime int64) {
	symbol := atom_symbol.MockSymbolViaBaseQuote(1, "lead-symbol", "lead", "spot", "BTC", "USDT", marginconstant.SpotTokenUnit)
	strat.leadContext.recorder.OnBBO(serverTime, ask, bid)
	// Keep the origin valid enough for the drift path without triggering any open orders.
	strat.leadContext.origin = *utils.NewBBO(ask, 1, bid, 1, serverTime, serverTime, utils.BBOMeta{Symbol: symbol}, nil)
}

func seedLagRecorderAt(t *testing.T, strat *Strategy, ask, bid float64, serverTime int64) {
	t.Helper()

	strat.lagContext.recorder.OnBBO(serverTime, ask, bid)
	strat.lagContext.bbo = *newTestBBOAt(t, "lag", ask, bid, serverTime)
}

func seedEntryScenario(t *testing.T, strat *Strategy, leadAsk, leadBid, lagAsk, lagBid float64) (*utils.BBO, *utils.BBO) {
	t.Helper()

	lead := newTestBBOAt(t, "lead", leadAsk, leadBid, testServerTime+1)
	lag := newTestBBOAt(t, "lag", lagAsk, lagBid, testServerTime+1)
	seedLeadRecorderAt(strat, 101, 100, testServerTime)
	seedLagRecorderAt(t, strat, lagAsk, lagBid, testServerTime)
	strat.lagContext.bbo = *lag
	return lead, lag
}

func seedShortEntryScenario(t *testing.T, strat *Strategy, leadAsk, leadBid, lagAsk, lagBid float64) (*utils.BBO, *utils.BBO) {
	t.Helper()

	lead := newTestBBOAt(t, "lead", leadAsk, leadBid, testServerTime+1)
	lag := newTestBBOAt(t, "lag", lagAsk, lagBid, testServerTime+1)
	seedLeadRecorderAt(strat, 121, 120, testServerTime)
	seedLagRecorderAt(t, strat, lagAsk, lagBid, testServerTime)
	strat.lagContext.bbo = *lag
	return lead, lag
}

func newHoldCache(position, trailing float64) *ExecuteCache {
	return &ExecuteCache{
		stage:    StageHold,
		position: decimal.NewFromFloat(position),
		trailing: trailing,
	}
}

func primeLongEntrySignals(strat *Strategy, now time.Time) {
	strat.threshold.UpEntry = 0.01
	strat.threshold.UpExit = 0
	strat.threshold.LeadNoise = 0
	strat.threshold.LagNoise = 0
	strat.lagContext.fee = 0
	strat.leadContext.recorder.OnBBO(testServerTime, 101, 100)
	strat.lagContext.recorder.OnBBO(testServerTime, 102, 100)
	strat.lagContext.spread.OnData(now, 2)
}

func feedAlignmentSamples(t *testing.T, strat *Strategy, ctx *testStrategyContext, pairs int) {
	t.Helper()

	base := ctx.now
	for i := 0; i < pairs; i++ {
		delta := float64(i) * 0.0001
		ctx.now = base.Add(time.Duration(i) * 100 * time.Millisecond)
		if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102+delta, 100+delta, testServerTime+int64(i*2+1))); err != nil {
			t.Fatalf("lag sample %d returned error: %v", i, err)
		}
		ctx.now = base.Add(time.Duration(i)*100*time.Millisecond + 50*time.Millisecond)
		if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 101+delta, 100+delta, testServerTime+int64(i*2+2))); err != nil {
			t.Fatalf("lead sample %d returned error: %v", i, err)
		}
	}
}

func TestAlignmentWarmupOnlyUpdatesRawLeadBeforeReady(t *testing.T) {
	strat := newTestStrategy(t)
	seedLeadRecorderAt(strat, 101, 100, testServerTime)

	lead := newTestBBOAt(t, "lead", 111, 110, testServerTime+1)
	if err := strat.OnRawBBO(lead); err != nil {
		t.Fatalf("OnRawBBO returned error: %v", err)
	}

	if got, want := strat.leadContext.origin.BestAskPrc, 111.0; got != want {
		t.Fatalf("raw lead ask should update during warm-up: got %v want %v", got, want)
	}
	if got, want := strat.leadContext.origin.BestBidPrc, 110.0; got != want {
		t.Fatalf("raw lead bid should update during warm-up: got %v want %v", got, want)
	}
	if got := strat.leadContext.drifted.BestAskPrc; got != 0 {
		t.Fatalf("drifted lead should stay untouched before alignment, got ask %v", got)
	}
	if got := strat.leadContext.drifted.BestBidPrc; got != 0 {
		t.Fatalf("drifted lead should stay untouched before alignment, got bid %v", got)
	}

	if got, _ := strat.leadContext.recorder.Bid.GetMin(); got.Price != 100.0 {
		t.Fatalf("lead recorder was polluted during warm-up: got %v want %v", got.Price, 100.0)
	}
	if got, _ := strat.leadContext.recorder.Ask.GetMax(); got.Price != 101.0 {
		t.Fatalf("lead recorder was polluted during warm-up: got %v want %v", got.Price, 101.0)
	}
}

func TestAlignmentLagFirstBlocksOpenBeforeReady(t *testing.T) {
	client := &testClient{}
	strat, ctx := newAlignmentTestStrategy(t, client)
	primeLongEntrySignals(strat, ctx.now)

	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+1)); err != nil {
		t.Fatalf("lag bootstrap tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(200 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+2)); err != nil {
		t.Fatalf("lead aligning tick returned error: %v", err)
	}

	if got := client.sendOrderCount; got != 0 {
		t.Fatalf("alignment should block lag-first startup opens before ready, got %d orders", got)
	}
}

func TestAlignmentLeadFirstBlocksOpenBeforeReady(t *testing.T) {
	client := &testClient{}
	strat, ctx := newAlignmentTestStrategy(t, client)
	primeLongEntrySignals(strat, ctx.now)

	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 101, 100, testServerTime+1)); err != nil {
		t.Fatalf("lead bootstrap tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(100 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+2)); err != nil {
		t.Fatalf("lag aligning tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(200 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+3)); err != nil {
		t.Fatalf("lead aligning tick returned error: %v", err)
	}

	if got := client.sendOrderCount; got != 0 {
		t.Fatalf("alignment should block lead-first startup opens before ready, got %d orders", got)
	}
}

func TestAlignmentBlocksMoveQueueAndThresholdRollUntilReady(t *testing.T) {
	strat, ctx := newAlignmentTestStrategy(t, nil)
	strat.threshold.UpEntry = 0.25
	strat.threshold.UpExit = 0.1
	strat.threshold.DownEntry = -0.25
	strat.threshold.DownExit = -0.1
	strat.leadContext.recorder.OnBBO(testServerTime, 101, 100)
	strat.leadContext.move.Push(0.4, -0.4)
	strat.leadContext.move.Push(0.5, -0.5)
	strat.leadContext.move.RollAt = ctx.now.Add(-time.Second)

	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+1)); err != nil {
		t.Fatalf("lag bootstrap tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(200 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+2)); err != nil {
		t.Fatalf("lead aligning tick returned error: %v", err)
	}

	if got := strat.leadContext.move.Size(); got != 2 {
		t.Fatalf("move queue should stay frozen before alignment, got size %d", got)
	}
	if got := strat.threshold.UpEntry; got != 0.25 {
		t.Fatalf("up threshold rolled before alignment: got %v want %v", got, 0.25)
	}
	if got := strat.threshold.DownEntry; got != -0.25 {
		t.Fatalf("down threshold rolled before alignment: got %v want %v", got, -0.25)
	}
}

func TestAlignmentBlocksSignalCloseUntilReady(t *testing.T) {
	client := &testClient{}
	strat, ctx := newAlignmentTestStrategy(t, client)
	strat.threshold.UpExit = 0.2
	strat.caches["hold"] = newHoldCache(1, 100)

	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+1)); err != nil {
		t.Fatalf("lead bootstrap tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(100 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+2)); err != nil {
		t.Fatalf("lag aligning tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(200 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+3)); err != nil {
		t.Fatalf("lead aligning tick returned error: %v", err)
	}

	if got := client.sendOrderCount; got != 0 {
		t.Fatalf("signal close should stay blocked before alignment, got %d orders", got)
	}
}

func TestAlignmentReadyRestoresTradingOnNextLeadTick(t *testing.T) {
	client := &testClient{}
	strat, ctx := newAlignmentTestStrategy(t, client)
	feedAlignmentSamples(t, strat, ctx, 20)

	ctx.now = ctx.now.Add(200 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+99)); err != nil {
		t.Fatalf("alignment completion lag tick returned error: %v", err)
	}
	client.sendOrderCount = 0

	ctx.now = ctx.now.Add(100 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+100)); err != nil {
		t.Fatalf("post-alignment lead tick returned error: %v", err)
	}

	if got := client.sendOrderCount; got != 1 {
		t.Fatalf("next lead tick after alignment should resume trading, got %d orders", got)
	}
}

func TestSamePriceRawEventsStillAdvanceAlignmentPhase(t *testing.T) {
	strat, ctx := newAlignmentTestStrategyWithTuning(t, nil, 3, time.Second)

	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+1)); err != nil {
		t.Fatalf("lead bootstrap tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(100 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+2)); err != nil {
		t.Fatalf("lag first paired tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(1200 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+3)); err != nil {
		t.Fatalf("lead same-price paired tick returned error: %v", err)
	}
	if got, want := strat.alignment.driftSamples, 2; got != want {
		t.Fatalf("same-price lead tick should still update drift samples: got %d want %d", got, want)
	}
	if got := strat.alignment.phase; got != AlignmentAligning {
		t.Fatalf("strategy should stay aligning until enough paired samples arrive, got %v", got)
	}

	ctx.now = ctx.now.Add(100 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+4)); err != nil {
		t.Fatalf("lag same-price activation tick returned error: %v", err)
	}

	if got, want := strat.alignment.driftSamples, 3; got != want {
		t.Fatalf("same-price lag tick should still update drift samples: got %d want %d", got, want)
	}
	if got := strat.alignment.phase; got != AlignmentActive {
		t.Fatalf("same-price raw events should allow alignment to reach active, got %v", got)
	}
}

func TestAlignmentActivationOnLeadTickResumesTradingImmediately(t *testing.T) {
	client := &testClient{}
	strat, ctx := newAlignmentTestStrategyWithTuning(t, client, 1, time.Second)
	primeLongEntrySignals(strat, ctx.now)

	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 101, 100, testServerTime+1)); err != nil {
		t.Fatalf("lead bootstrap tick returned error: %v", err)
	}

	ctx.now = ctx.now.Add(100 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+2)); err != nil {
		t.Fatalf("lag aligning tick returned error: %v", err)
	}
	if got := strat.alignment.phase; got != AlignmentAligning {
		t.Fatalf("strategy should still be aligning before warmup elapses, got %v", got)
	}

	ctx.now = ctx.now.Add(1200 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+3)); err != nil {
		t.Fatalf("lead activation tick returned error: %v", err)
	}

	if got := strat.alignment.phase; got != AlignmentActive {
		t.Fatalf("strategy should enter active on the lead tick, got %v", got)
	}
	if got := client.sendOrderCount; got != 1 {
		t.Fatalf("activation lead tick should resume trading immediately, got %d orders", got)
	}
}

func TestAlignmentWarmupWithSamePriceRawFeedResumesOnNextLeadTick(t *testing.T) {
	client := &testClient{}
	strat, ctx := newAlignmentTestStrategyWithTuning(t, client, 3, time.Second)
	strat.config.Trigger.DriftWarmup = jsontype.Duration(30 * time.Second)
	primeLongEntrySignals(strat, ctx.now)

	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 101, 100, testServerTime+1)); err != nil {
		t.Fatalf("lead bootstrap tick returned error: %v", err)
	}
	ctx.now = ctx.now.Add(100 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+2)); err != nil {
		t.Fatalf("lag first paired tick returned error: %v", err)
	}
	ctx.now = ctx.now.Add(15 * time.Second)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+3)); err != nil {
		t.Fatalf("lead move during warmup returned error: %v", err)
	}
	if got := strat.alignment.phase; got != AlignmentAligning {
		t.Fatalf("strategy should remain aligning before 30s warmup elapses, got %v", got)
	}
	if ready := strat.alignmentReady(ctx.now); ready {
		t.Fatalf("alignment should not be ready before the 30s warmup elapses")
	}
	ctx.now = ctx.now.Add(16 * time.Second)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lag", 102, 100, testServerTime+4)); err != nil {
		t.Fatalf("lag same-price activation tick returned error: %v", err)
	}
	if got := strat.alignment.phase; got != AlignmentActive {
		t.Fatalf("alignment should become active after 30s warmup, got %v", got)
	}
	if ready := strat.alignmentReady(ctx.now); !ready {
		t.Fatalf("alignmentReady should be true once warmup and samples are satisfied")
	}
	if got := client.sendOrderCount; got != 0 {
		t.Fatalf("lag activation tick should not send orders, got %d", got)
	}

	ctx.now = ctx.now.Add(100 * time.Millisecond)
	if err := strat.OnRawBBO(newTestBBOAt(t, "lead", 111, 110, testServerTime+5)); err != nil {
		t.Fatalf("post-activation same-price lead tick returned error: %v", err)
	}
	if got := client.sendOrderCount; got != 1 {
		t.Fatalf("first lead tick after activation should restore trading even on same-price raw feed, got %d orders", got)
	}
}

func TestDriftWarmupScalesLeadAfterLagMeanExists(t *testing.T) {
	strat := newTestStrategy(t)
	seedLeadRecorderAt(strat, 101, 100, testServerTime)

	lag := newTestBBOAt(t, "lag", 121.1, 120.1, testServerTime+1)
	if err := strat.OnRawBBO(lag); err != nil {
		t.Fatalf("OnRawBBO returned error: %v", err)
	}

	nextLead := newTestBBOAt(t, "lead", 111, 110, testServerTime+2)
	if err := strat.OnLeadBBO(nextLead); err != nil {
		t.Fatalf("OnLeadBBO returned error: %v", err)
	}

	if got, want := strat.lagContext.drift.GetMean(), 1.2; got != want {
		t.Fatalf("unexpected drift mean: got %v want %v", got, want)
	}
	if got, want := strat.leadContext.drifted.BestAskPrc, 133.2; got != want {
		t.Fatalf("lead ask not drift-adjusted: got %v want %v", got, want)
	}
	if got, want := strat.leadContext.drifted.BestBidPrc, 132.0; got != want {
		t.Fatalf("lead bid not drift-adjusted: got %v want %v", got, want)
	}
}

func TestActiveLeadBBOStillUpdatesLeadSideButDriftLimitBlocksOpen(t *testing.T) {
	client := &testClient{}
	strat := newTestStrategyWithClient(t, client)
	seedLeadRecorderAt(strat, 101, 100, testServerTime)

	lag := newTestBBOAt(t, "lag", 121.1, 120.1, testServerTime+1)
	strat.lagContext.bbo = *lag
	strat.UpdateDrift(time.Unix(testServerTime/1000, 0), &strat.leadContext.origin, lag)

	lead := newTestBBOAt(t, "lead", 200, 199, testServerTime+2)
	if err := strat.OnLeadBBO(lead); err != nil {
		t.Fatalf("OnLeadBBO returned error: %v", err)
	}

	if got, want := strat.leadContext.drifted.BestAskPrc, 240.0; got != want {
		t.Fatalf("lead ask update skipped by drift_limit: got %v want %v", got, want)
	}
	if got, want := strat.leadContext.drifted.BestBidPrc, 238.8; math.Abs(got-want) > 1e-9 {
		t.Fatalf("lead bid update skipped by drift_limit: got %v want %v", got, want)
	}
	if got := client.sendOrderCount; got != 0 {
		t.Fatalf("drift_limit should block new opens only, send count=%d", got)
	}
}

func TestMaxEntrySpreadFallbackAndIsolationFromStoploss(t *testing.T) {
	stopBBO := newTestBBOAt(t, "lag", 98.6, 98.5, testServerTime+2)

	fallbackClient := &testClient{}
	fallback := newTestStrategyWithExecution(t, fallbackClient, 0.01, -1)
	lead, _ := seedEntryScenario(t, fallback, 111, 110, 102, 100)

	opened, err := fallback.OpenLong(lead)
	if err != nil {
		t.Fatalf("OpenLong returned error: %v", err)
	}
	if opened {
		t.Fatalf("OpenLong should fall back to trailing_stop when max_entry_spread is unset")
	}
	if got := fallbackClient.sendOrderCount; got != 0 {
		t.Fatalf("entry should stay blocked in fallback case, send count=%d", got)
	}

	triggered, err := fallback.ExecuteStoplossLong("hold", newHoldCache(1, 100), stopBBO)
	if err != nil {
		t.Fatalf("ExecuteStoplossLong returned error: %v", err)
	}
	if !triggered {
		t.Fatalf("stoploss should still use trailing_stop in fallback case")
	}

	wideClient := &testClient{}
	wide := newTestStrategyWithExecution(t, wideClient, 0.01, 0.03)
	seedEntryScenario(t, wide, 111, 110, 102, 100)

	opened, err = wide.OpenLong(lead)
	if err != nil {
		t.Fatalf("OpenLong returned error: %v", err)
	}
	if !opened {
		t.Fatalf("OpenLong should use max_entry_spread when it is configured")
	}
	if got := wideClient.sendOrderCount; got != 1 {
		t.Fatalf("entry should be allowed in wide-spread case, send count=%d", got)
	}

	triggered, err = wide.ExecuteStoplossLong("hold", newHoldCache(1, 100), stopBBO)
	if err != nil {
		t.Fatalf("ExecuteStoplossLong returned error: %v", err)
	}
	if !triggered {
		t.Fatalf("stoploss should be unchanged when only max_entry_spread changes")
	}
}

func TestTrailingStopOnlyChangesStoplossLong(t *testing.T) {
	stopBBO := newTestBBOAt(t, "lag", 98.6, 98.5, testServerTime+2)

	tightClient := &testClient{}
	tight := newTestStrategyWithExecution(t, tightClient, 0.01, 0.03)
	lead, _ := seedEntryScenario(t, tight, 111, 110, 102, 100)

	opened, err := tight.OpenLong(lead)
	if err != nil {
		t.Fatalf("OpenLong returned error: %v", err)
	}
	if !opened {
		t.Fatalf("OpenLong should not depend on trailing_stop once max_entry_spread is wide enough")
	}

	triggered, err := tight.ExecuteStoplossLong("hold", newHoldCache(1, 100), stopBBO)
	if err != nil {
		t.Fatalf("ExecuteStoplossLong returned error: %v", err)
	}
	if !triggered {
		t.Fatalf("tight trailing_stop should trigger stoploss")
	}

	looseClient := &testClient{}
	loose := newTestStrategyWithExecution(t, looseClient, 0.05, 0.03)
	seedEntryScenario(t, loose, 111, 110, 102, 100)

	opened, err = loose.OpenLong(lead)
	if err != nil {
		t.Fatalf("OpenLong returned error: %v", err)
	}
	if !opened {
		t.Fatalf("OpenLong should stay unchanged when only trailing_stop changes")
	}

	triggered, err = loose.ExecuteStoplossLong("hold", newHoldCache(1, 100), stopBBO)
	if err != nil {
		t.Fatalf("ExecuteStoplossLong returned error: %v", err)
	}
	if triggered {
		t.Fatalf("loose trailing_stop should not trigger stoploss for the same move")
	}
}

func TestMaxEntrySpreadFallbackAndIsolationFromStoplossShort(t *testing.T) {
	stopBBO := newTestBBOAt(t, "lag", 101.5, 101.4, testServerTime+2)

	fallbackClient := &testClient{}
	fallback := newTestStrategyWithExecution(t, fallbackClient, 0.01, -1)
	lead, _ := seedShortEntryScenario(t, fallback, 111, 110, 117, 115.5)

	opened, err := fallback.OpenShort(lead)
	if err != nil {
		t.Fatalf("OpenShort returned error: %v", err)
	}
	if opened {
		t.Fatalf("OpenShort should fall back to trailing_stop when max_entry_spread is unset")
	}
	if got := fallbackClient.sendOrderCount; got != 0 {
		t.Fatalf("entry should stay blocked in fallback case, send count=%d", got)
	}

	triggered, err := fallback.ExecuteStoplossShort("hold", newHoldCache(-1, 100), stopBBO)
	if err != nil {
		t.Fatalf("ExecuteStoplossShort returned error: %v", err)
	}
	if !triggered {
		t.Fatalf("stoploss should still use trailing_stop in fallback case")
	}

	wideClient := &testClient{}
	wide := newTestStrategyWithExecution(t, wideClient, 0.01, 0.03)
	seedShortEntryScenario(t, wide, 111, 110, 117, 115.5)

	opened, err = wide.OpenShort(lead)
	if err != nil {
		t.Fatalf("OpenShort returned error: %v", err)
	}
	if !opened {
		t.Fatalf("OpenShort should use max_entry_spread when it is configured")
	}
	if got := wideClient.sendOrderCount; got != 1 {
		t.Fatalf("entry should be allowed in wide-spread case, send count=%d", got)
	}

	triggered, err = wide.ExecuteStoplossShort("hold", newHoldCache(-1, 100), stopBBO)
	if err != nil {
		t.Fatalf("ExecuteStoplossShort returned error: %v", err)
	}
	if !triggered {
		t.Fatalf("stoploss should be unchanged when only max_entry_spread changes")
	}
}

func TestTrailingStopOnlyChangesStoplossShort(t *testing.T) {
	stopBBO := newTestBBOAt(t, "lag", 101.5, 101.4, testServerTime+2)

	tightClient := &testClient{}
	tight := newTestStrategyWithExecution(t, tightClient, 0.01, 0.03)
	lead, _ := seedShortEntryScenario(t, tight, 111, 110, 117, 115.5)

	opened, err := tight.OpenShort(lead)
	if err != nil {
		t.Fatalf("OpenShort returned error: %v", err)
	}
	if !opened {
		t.Fatalf("OpenShort should not depend on trailing_stop once max_entry_spread is wide enough")
	}

	triggered, err := tight.ExecuteStoplossShort("hold", newHoldCache(-1, 100), stopBBO)
	if err != nil {
		t.Fatalf("ExecuteStoplossShort returned error: %v", err)
	}
	if !triggered {
		t.Fatalf("tight trailing_stop should trigger stoploss")
	}

	looseClient := &testClient{}
	loose := newTestStrategyWithExecution(t, looseClient, 0.05, 0.03)
	seedShortEntryScenario(t, loose, 111, 110, 117, 115.5)

	opened, err = loose.OpenShort(lead)
	if err != nil {
		t.Fatalf("OpenShort returned error: %v", err)
	}
	if !opened {
		t.Fatalf("OpenShort should stay unchanged when only trailing_stop changes")
	}

	triggered, err = loose.ExecuteStoplossShort("hold", newHoldCache(-1, 100), stopBBO)
	if err != nil {
		t.Fatalf("ExecuteStoplossShort returned error: %v", err)
	}
	if triggered {
		t.Fatalf("loose trailing_stop should not trigger stoploss for the same move")
	}
}

func TestUnifiedEntryCostDoesNotDoubleCountEmbeddedPriceFriction(t *testing.T) {
	client := &testClient{}
	strat := newTestStrategyWithExecution(t, client, 0.01, 0.05)
	strat.threshold.UpEntry = 0.0001
	strat.threshold.UpExit = 0
	strat.threshold.DownEntry = -0.0001
	strat.threshold.DownExit = 0
	strat.threshold.LeadNoise = 0
	strat.threshold.LagNoise = 0
	strat.lagContext.fee = 0

	seedLeadRecorderAt(strat, 103, 102, testServerTime)
	seedLagRecorderAt(t, strat, 102, 101, testServerTime)
	strat.lagContext.spread.OnData(time.Unix(testServerTime/1000, 0), 0.001)

	lead := newTestBBOAt(t, "lead", 104, 103, testServerTime+1)
	lag := newTestBBOAt(t, "lag", 102, 101, testServerTime+1)
	entryCost := strat.BuildEntryCostBreakdown(lag, lag.GetAskPrc())
	targetSpace := (lead.BestBidPrc-lead.BestBidPrc*strat.threshold.UpExit-strat.LagSpreadBuffer(lag))/lag.GetAskPrc() - 1
	if targetSpace >= entryCost.EmbeddedPriceFriction() {
		t.Fatalf("test setup must embed price friction in targetSpace: targetSpace=%v embedded=%v", targetSpace, entryCost.EmbeddedPriceFriction())
	}
	if entryCost.RequiredEdge() != 0 {
		t.Fatalf("required edge should exclude embedded price friction in this scenario: %v", entryCost.RequiredEdge())
	}

	opened, err := strat.OpenLong(lead)
	if err != nil {
		t.Fatalf("OpenLong returned error: %v", err)
	}
	if !opened {
		t.Fatalf("OpenLong should pass when embedded price friction is already accounted for in targetSpace")
	}
	if got := client.sendOrderCount; got != 1 {
		t.Fatalf("expected exactly one entry order, got %d", got)
	}
}
