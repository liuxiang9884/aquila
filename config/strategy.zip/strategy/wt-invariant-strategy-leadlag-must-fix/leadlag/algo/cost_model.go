package algo

import (
	"fmt"

	"git.hashingbot.com/aurthes/xex_mm_go/utils"
)

// EntryCostBreakdown captures the entry-side cost budget on the same percentage
// basis as the strategy's target space calculations.
type EntryCostBreakdown struct {
	Fee             float64
	Spread          float64
	LagSpreadBuffer float64
	LeadNoise       float64
	LagNoise        float64
}

func (b EntryCostBreakdown) RequiredEdge() float64 {
	return b.Fee + b.LeadNoise + b.LagNoise
}

func (b EntryCostBreakdown) EmbeddedPriceFriction() float64 {
	return b.Spread + b.LagSpreadBuffer
}

func (b EntryCostBreakdown) RequiredEdgeWithTargetProfit(targetProfitRate float64) float64 {
	return b.RequiredEdge() + targetProfitRate
}

func (b EntryCostBreakdown) String() string {
	return fmt.Sprintf(
		"fee=%.6f spread=%.6f lag_spread_buffer=%.6f lead_noise=%.6f lag_noise=%.6f embedded=%.6f required=%.6f",
		b.Fee,
		b.Spread,
		b.LagSpreadBuffer,
		b.LeadNoise,
		b.LagNoise,
		b.EmbeddedPriceFriction(),
		b.RequiredEdge(),
	)
}

func (s *Strategy) BuildEntryCostBreakdown(lagBBO *utils.BBO, triggerPrice float64) EntryCostBreakdown {
	lagSpreadBuffer := 0.0
	if triggerPrice > 0 {
		lagSpreadBuffer = s.LagSpreadBuffer(lagBBO) / triggerPrice
	}
	return EntryCostBreakdown{
		Fee:             s.lagContext.fee * 2,
		Spread:          spreadPct(lagBBO),
		LagSpreadBuffer: lagSpreadBuffer,
		LeadNoise:       s.threshold.LeadNoise,
		LagNoise:        s.threshold.LagNoise,
	}
}
