package algo

import (
	"math"
	"testing"
	"time"
)

func TestStreamRecorderInitResetsSquaredTotal(t *testing.T) {
	var r StreamRecorder

	start := time.Unix(1_700_000_000, 0)
	r.Init(time.Minute, 8)
	r.OnData(start, 10)
	r.OnData(start.Add(time.Second), 20)

	r.Init(time.Minute, 8)
	r.OnData(start.Add(2*time.Second), 100)

	if got := r.GetMean(); got != 100 {
		t.Fatalf("mean after re-init = %v, want 100", got)
	}
	if got := r.GetStd(); math.Abs(got) > 1e-12 {
		t.Fatalf("std after re-init = %v, want 0", got)
	}
}
