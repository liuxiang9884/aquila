package algo

import (
	"fmt"

	"git.hashingbot.com/aurthes/xex_mm_go/requests"
	"github.com/shopspring/decimal"
)

type ExecuteStage uint

const (
	StageIdle ExecuteStage = iota
	StageOpen
	StageHold
	StageClose

	StageEnd
)

var stageTexts = []string{
	"idle", "open", "hold", "close",
}

func (s ExecuteStage) String() string {
	if s < StageEnd {
		return stageTexts[s]
	} else {
		return fmt.Sprintf("unknown<%d>", s)
	}
}

type ExecuteCache struct {
	stage    ExecuteStage
	order    requests.Order
	position decimal.Decimal

	trailing float64

	groupTag string
	grouping []requests.Order
}
