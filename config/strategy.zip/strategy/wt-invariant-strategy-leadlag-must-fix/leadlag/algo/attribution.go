package algo

import (
	"fmt"

	"git.hashingbot.com/aurthes/xex_mm_go/requests"
	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

const (
	AttributionSchemaVersion = "leadlag_attribution.v1"
	DefaultStrategyVariant   = "fixed"

	AttributionEventTrigger        = "trigger"
	AttributionEventFilter         = "filter"
	AttributionEventOrderCreate    = "order_create"
	AttributionEventOrderLifecycle = "order_lifecycle"
	AttributionEventCloseDecision  = "close_decision"

	AttributionReasonTrigger       = "trigger"
	AttributionReasonFiltered      = "filtered"
	AttributionReasonNoTrigger     = "no-trigger"
	AttributionReasonCloseDecision = "close-decision"
	AttributionReasonNotApplicable = "not-applicable"

	AttributionFilterNoFilter = "no-filter"

	AttributionLifecycleNotApplicable          = "not-applicable"
	AttributionLifecycleOrderCreate            = "order-create"
	AttributionLifecyclePartialFill            = "partial-fill"
	AttributionLifecycleFullFill               = "full-fill"
	AttributionLifecycleZeroFillCanceled       = "zero-fill-canceled"
	AttributionLifecycleZeroFillExpired        = "zero-fill-expired"
	AttributionLifecycleCancelOrExpireWithFill = "cancel-or-expire-with-fill"
	AttributionLifecycleRejected               = "rejected"
	AttributionLifecyclePending                = "pending"
	AttributionLifecycleNew                    = "new"
	AttributionLifecycleUnknown                = "unknown"

	AttributionOutputModeBounded = "bounded"
	AttributionOutputModeFull    = "full"
	AttributionOutputModeOff     = "off"

	AttributionOutputFilterModeChanges = "changes"
	AttributionOutputFilterModeSampled = "sampled"
	AttributionOutputFilterModeFull    = "full"
	AttributionOutputFilterModeOff     = "off"

	AttributionOutputNoTriggerModeSampled = "sampled"
	AttributionOutputNoTriggerModeFull    = "full"
	AttributionOutputNoTriggerModeOff     = "off"
)

type AnalysisConfig struct {
	AttributionLog    bool                    `json:"attribution_log" default:"false"`
	Variant           string                  `json:"variant"`
	AttributionOutput AttributionOutputConfig `json:"attribution_output"`
}

type AttributionOutputConfig struct {
	Mode                      string   `json:"mode"`
	AlwaysEvents              []string `json:"always_events"`
	FilterMode                string   `json:"filter_mode"`
	NoTriggerMode             string   `json:"no_trigger_mode"`
	SampleIntervalMs          int64    `json:"sample_interval_ms"`
	ReasonChangeMinIntervalMs int64    `json:"reason_change_min_interval_ms"`
}

type attributionEmissionState struct {
	LastSignature string
	LastEmittedMs int64
}

func (c *AnalysisConfig) SetDefault() {
	if c.AttributionOutput.Mode == "" {
		c.AttributionOutput.Mode = AttributionOutputModeBounded
	}
	if len(c.AttributionOutput.AlwaysEvents) == 0 {
		c.AttributionOutput.AlwaysEvents = []string{
			AttributionEventTrigger,
			AttributionEventOrderCreate,
			AttributionEventOrderLifecycle,
			AttributionEventCloseDecision,
		}
	}
	if c.AttributionOutput.FilterMode == "" {
		c.AttributionOutput.FilterMode = AttributionOutputFilterModeChanges
	}
	if c.AttributionOutput.NoTriggerMode == "" {
		c.AttributionOutput.NoTriggerMode = AttributionOutputNoTriggerModeSampled
	}
	if c.AttributionOutput.SampleIntervalMs <= 0 {
		c.AttributionOutput.SampleIntervalMs = 60_000
	}
	if c.AttributionOutput.ReasonChangeMinIntervalMs <= 0 {
		c.AttributionOutput.ReasonChangeMinIntervalMs = 10_000
	}
}

type AttributionInput struct {
	Event                string
	Position             string
	CID                  string
	GroupID              string
	Side                 int
	Qty                  float64
	Price                float64
	SignalValue          float64
	Threshold            float64
	Cost                 float64
	Liquidity            float64
	DecisionReason       string
	OrderLifecycleReason string
	FilterName           string
	FilterReason         string
	StatusCode           int
	FilledQty            float64
}

func (s *Strategy) attributionEnabled() bool {
	return s != nil && s.config.Analysis.AttributionLog && s.recorder != nil
}

func (s *Strategy) shouldRecordAttribution(input AttributionInput) bool {
	if !s.attributionEnabled() {
		return false
	}
	policy := s.config.Analysis.AttributionOutput
	switch policy.Mode {
	case AttributionOutputModeOff:
		return false
	case AttributionOutputModeFull:
		return true
	}
	for _, event := range policy.AlwaysEvents {
		if input.Event == event {
			return true
		}
	}
	if input.Event != AttributionEventFilter {
		return true
	}
	reason := input.FilterReason
	if reason == "" || reason == AttributionReasonNotApplicable {
		reason = input.DecisionReason
	}
	if reason == AttributionReasonNoTrigger || input.DecisionReason == AttributionReasonNoTrigger {
		return s.shouldEmitSampledAttribution(input, policy.NoTriggerMode, policy.SampleIntervalMs)
	}
	return s.shouldEmitReasonChangeAttribution(input, policy.FilterMode, policy.ReasonChangeMinIntervalMs)
}

func (s *Strategy) shouldEmitSampledAttribution(input AttributionInput, mode string, intervalMs int64) bool {
	switch mode {
	case AttributionOutputNoTriggerModeOff:
		return false
	case AttributionOutputNoTriggerModeFull:
		return true
	}
	if s.attributionEmission == nil {
		s.attributionEmission = map[string]attributionEmissionState{}
	}
	key := s.attributionStateKey("sample", input)
	nowMs := s.Context.Now().UnixMilli()
	state := s.attributionEmission[key]
	if state.LastEmittedMs == 0 || nowMs-state.LastEmittedMs >= intervalMs {
		state.LastEmittedMs = nowMs
		s.attributionEmission[key] = state
		return true
	}
	return false
}

func (s *Strategy) shouldEmitReasonChangeAttribution(input AttributionInput, mode string, minIntervalMs int64) bool {
	switch mode {
	case AttributionOutputFilterModeOff:
		return false
	case AttributionOutputFilterModeFull:
		return true
	case AttributionOutputFilterModeSampled:
		return s.shouldEmitSampledAttribution(input, AttributionOutputNoTriggerModeSampled, s.config.Analysis.AttributionOutput.SampleIntervalMs)
	}
	if s.attributionEmission == nil {
		s.attributionEmission = map[string]attributionEmissionState{}
	}
	key := s.attributionStateKey("change", input)
	signature := fmt.Sprintf("%s|%s|%s|%s", input.DecisionReason, input.FilterName, input.FilterReason, input.Position)
	nowMs := s.Context.Now().UnixMilli()
	state := s.attributionEmission[key]
	if state.LastSignature != signature || state.LastEmittedMs == 0 || nowMs-state.LastEmittedMs >= minIntervalMs {
		state.LastSignature = signature
		state.LastEmittedMs = nowMs
		s.attributionEmission[key] = state
		return true
	}
	return false
}

func (s *Strategy) attributionStateKey(kind string, input AttributionInput) string {
	return fmt.Sprintf("%s|%s|%s|%d|%s", kind, input.Event, input.FilterName, input.Side, input.Position)
}

func (s *Strategy) RecordAttribution(input AttributionInput) {
	variant := s.config.Analysis.Variant
	if variant == "" {
		variant = DefaultStrategyVariant
	}
	if input.DecisionReason == "" {
		input.DecisionReason = AttributionReasonNotApplicable
	}
	if input.OrderLifecycleReason == "" {
		input.OrderLifecycleReason = AttributionLifecycleNotApplicable
	}
	if input.FilterName == "" {
		input.FilterName = AttributionFilterNoFilter
	}
	if input.FilterReason == "" {
		input.FilterReason = AttributionReasonNotApplicable
	}
	if !s.shouldRecordAttribution(input) {
		return
	}
	now := s.Context.Now()
	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type":           "attribution",
			"schema_version": AttributionSchemaVersion,
			"event":          input.Event,
			"variant":        variant,
		},
		Field: map[string]interface{}{
			"schema_version":         AttributionSchemaVersion,
			"strategy_variant":       variant,
			"event":                  input.Event,
			"symbol":                 s.config.Symbol,
			"lead":                   s.config.Lead,
			"lag":                    s.config.Lag,
			"timestamp_ms":           now.UnixMilli(),
			"date_hour":              now.Format("2006010215"),
			"cid":                    input.CID,
			"group_id":               input.GroupID,
			"side":                   input.Side,
			"qty":                    input.Qty,
			"price":                  input.Price,
			"signal_value":           input.SignalValue,
			"threshold":              input.Threshold,
			"cost":                   input.Cost,
			"liquidity":              input.Liquidity,
			"decision_reason":        input.DecisionReason,
			"order_lifecycle_reason": input.OrderLifecycleReason,
			"filter_name":            input.FilterName,
			"filter_reason":          input.FilterReason,
			"status_code":            input.StatusCode,
			"filled_qty":             input.FilledQty,
			"position":               input.Position,
		},
		Extra: map[string]interface{}{
			"time": now,
		},
	})
}

func ClassifyOrderLifecycle(status int, filledQty float64, orderQty float64) string {
	switch status {
	case 10:
		return AttributionLifecycleNew
	case 20:
		if filledQty > 0 {
			return AttributionLifecyclePartialFill
		}
		return AttributionLifecyclePending
	case 30:
		return AttributionLifecyclePending
	case 40:
		return AttributionLifecycleFullFill
	case 41:
		if filledQty > 0 {
			return AttributionLifecycleCancelOrExpireWithFill
		}
		return AttributionLifecycleZeroFillCanceled
	case 42:
		return AttributionLifecycleRejected
	case 45:
		if filledQty > 0 {
			return AttributionLifecycleCancelOrExpireWithFill
		}
		return AttributionLifecycleZeroFillExpired
	default:
		return AttributionLifecycleUnknown
	}
}

func (s *Strategy) RecordFilterAttribution(reason string, signalValue float64, threshold float64, cost float64, filterName string) {
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventFilter,
		SignalValue:          signalValue,
		Threshold:            threshold,
		Cost:                 cost,
		DecisionReason:       reason,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           filterName,
		FilterReason:         reason,
	})
}

func (s *Strategy) RecordOrderCreateAttribution(cache *ExecuteCache, param *template.OrderParam, position string, signalValue float64, threshold float64, cost float64, liquidity float64) {
	if param == nil || cache == nil {
		return
	}
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventOrderCreate,
		Position:             position,
		CID:                  param.CID,
		GroupID:              cache.groupTag,
		Side:                 param.Side,
		Qty:                  param.Qty,
		Price:                param.Price,
		SignalValue:          signalValue,
		Threshold:            threshold,
		Cost:                 cost,
		Liquidity:            liquidity,
		DecisionReason:       AttributionReasonTrigger,
		OrderLifecycleReason: AttributionLifecycleOrderCreate,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
	})
}

func (s *Strategy) RecordOrderLifecycleAttribution(cache *ExecuteCache, order requests.Order, msg *utils.OrderMessage) {
	if cache == nil || order == nil || msg == nil {
		return
	}
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventOrderLifecycle,
		CID:                  msg.ClientID,
		GroupID:              cache.groupTag,
		Side:                 msg.Side,
		Qty:                  msg.Qty,
		Price:                msg.Price,
		SignalValue:          0,
		Threshold:            0,
		Cost:                 0,
		DecisionReason:       AttributionReasonNotApplicable,
		OrderLifecycleReason: ClassifyOrderLifecycle(msg.Status, msg.FilledQty, msg.Qty),
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
		StatusCode:           msg.Status,
		FilledQty:            msg.FilledQty,
		Position:             cache.stage.String(),
	})
}
