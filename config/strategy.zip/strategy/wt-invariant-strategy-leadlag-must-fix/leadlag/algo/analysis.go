package algo

import (
	"math"
	"time"

	"github.com/gonum/stat"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/queue"
)

type LeadLagRecorder struct {
}

func (r *LeadLagRecorder) OnLag(price float64) {

}

func (r *LeadLagRecorder) OnLead(price float64) {

}

func floatLessThan(a, b float64) bool {
	return a < b
}

func floatGreaterThan(a, b float64) bool {
	return a > b
}

type PricePoint struct {
	Time  int64
	Price float64
}

func PriceLessThan(a, b PricePoint) bool {
	return a.Price < b.Price
}

func PriceGreaterThan(a, b PricePoint) bool {
	return a.Price > b.Price
}

type BBOVolRecorder struct {
	Ask    *queue.MonotonicQueue[PricePoint]
	Bid    *queue.MonotonicQueue[PricePoint]
	Times  *queue.Queue[int64]
	Window int64
}

func NewBBOVolRecorder(size int, window int64) *BBOVolRecorder {
	vr := &BBOVolRecorder{
		Ask:    queue.NewMonotonicQueue(size, PriceLessThan, PriceGreaterThan),
		Bid:    queue.NewMonotonicQueue(size, PriceLessThan, PriceGreaterThan),
		Times:  queue.NewQueue[int64](size),
		Window: window,
	}
	return vr
}

func (r *BBOVolRecorder) Init(size int, window int64) {
	r.Ask = queue.NewMonotonicQueue(size, PriceLessThan, PriceGreaterThan)
	r.Bid = queue.NewMonotonicQueue(size, PriceLessThan, PriceGreaterThan)
	r.Times = queue.NewQueue[int64](size)
	r.Window = int64(window)
}

func (r *BBOVolRecorder) OnBBO(milliTs int64, ask float64, bid float64) {
	r.Times.Put(milliTs)
	r.Ask.Put(PricePoint{Time: milliTs, Price: ask})
	r.Bid.Put(PricePoint{Time: milliTs, Price: bid})
	for {
		tailTs, _ := r.Times.Tail()
		// fmt.Printf("time<milliTs=%d, headTs=%d, window=%d>\n", milliTs, headTs, r.Window)
		if milliTs-tailTs > r.Window {
			r.Times.Pop()
			r.Ask.Pop()
			r.Bid.Pop()
		} else {
			break
		}
	}
}

type StreamRecorder struct {
	period  time.Duration
	count   int64
	total   float64
	sqTotal float64

	data queue.Queue[float64]
	time queue.Queue[time.Time]

	mean float64
	std  float64
}

func (r *StreamRecorder) Init(period time.Duration, size int) {
	r.period = period
	r.count = 0
	r.total = 0
	r.sqTotal = 0

	r.data.Init(size)
	r.time.Init(size)

	r.mean = 0
}

func (r *StreamRecorder) OnData(now time.Time, data float64) {
	r.count++
	r.total += data
	r.sqTotal += (data * data)
	r.data.Put(data)
	r.time.Put(now)
	for tailTs, ok := r.time.Tail(); ok; tailTs, ok = r.time.Tail() {
		if now.Sub(tailTs) > r.period {
			r.time.Pop()
			popped, _ := r.data.Pop()
			r.count--
			r.total -= popped
			r.sqTotal -= (popped * popped)
		} else {
			break
		}
	}
	r.mean = (r.total / float64(r.count))
	// r.std = math.Sqrt(r.sqTotal/float64(r.count) - r.mean*r.mean)
}

func (r *StreamRecorder) GetMean() float64 {
	return r.mean
}

func (r *StreamRecorder) GetStd() float64 {
	dx := r.sqTotal / float64(r.count)
	ex2 := r.mean * r.mean
	if dx > ex2 {
		return math.Sqrt(dx - ex2)
	} else {
		return 0
	}
}

type BatchRecorder struct {
	Window time.Duration
	Data   []float64
	RollAt time.Time
}

func (r *BatchRecorder) Init(window time.Duration, size int) {
	r.Window = window
	r.Data = make([]float64, 0, size)
}

func (r *BatchRecorder) OnData(data float64) {
	r.Data = append(r.Data, data)
}

func (r *BatchRecorder) ShouldRoll(t time.Time) bool {
	return t.After(r.RollAt)
}

func (r *BatchRecorder) Roll(t time.Time) {
	r.RollAt = t.Truncate(r.Window).Add(r.Window)
	r.Data = r.Data[:0]
}

func (r *BatchRecorder) GetStd() float64 {
	return stat.StdDev(r.Data, nil)
}

type StreamStdEmaRecorder struct {
	items StreamRecorder
	ema   StreamRecorder
}

func (s *StreamStdEmaRecorder) Init(window time.Duration, period time.Duration, size int) {
	s.items.Init(window, size)
	s.ema.Init(period, size)
}

func (s *StreamStdEmaRecorder) OnData(t time.Time, data float64) {
	s.items.OnData(t, data)
	std := s.items.GetStd()
	mean := s.items.GetMean()
	if !math.IsNaN(std) && mean != 0 {
		s.ema.OnData(t, s.items.GetStd()/mean)
	}
}

func (s *StreamStdEmaRecorder) GetStdEma() float64 {
	return s.ema.GetMean()
}
