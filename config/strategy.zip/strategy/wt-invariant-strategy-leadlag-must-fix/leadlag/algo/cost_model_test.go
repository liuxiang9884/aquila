package algo

import (
	"math"
	"testing"
	"time"
)

func TestEntryCostBreakdownSumsIndependentComponents(t *testing.T) {
	model := EntryCostBreakdown{
		Fee:             0.02,
		Spread:          0.03,
		LagSpreadBuffer: 0.04,
		LeadNoise:       0.05,
		LagNoise:        0.06,
	}

	if got, want := model.RequiredEdge(), 0.13; math.Abs(got-want) > 1e-12 {
		t.Fatalf("required edge mismatch: got %v want %v", got, want)
	}
	if got, want := model.EmbeddedPriceFriction(), 0.07; math.Abs(got-want) > 1e-12 {
		t.Fatalf("embedded price friction mismatch: got %v want %v", got, want)
	}

	if got, want := model.RequiredEdgeWithTargetProfit(0.07), 0.20; math.Abs(got-want) > 1e-12 {
		t.Fatalf("required edge with target profit mismatch: got %v want %v", got, want)
	}
}

func TestEntryCostBreakdownLagNoiseIsMonotonic(t *testing.T) {
	base := EntryCostBreakdown{
		Fee:             0.02,
		Spread:          0.01,
		LagSpreadBuffer: 0.03,
		LeadNoise:       0.04,
		LagNoise:        0,
	}
	noisy := base
	noisy.LagNoise = 0.05

	if got, want := noisy.RequiredEdge(), base.RequiredEdge()+0.05; math.Abs(got-want) > 1e-12 {
		t.Fatalf("lag noise should increase required edge by its amount: got %v want %v", got, want)
	}
	if noisy.RequiredEdge() <= base.RequiredEdge() {
		t.Fatalf("lag noise did not increase required edge: base=%v noisy=%v", base.RequiredEdge(), noisy.RequiredEdge())
	}
}

func TestEntryCostBreakdownWiderSpreadOnlyChangesEmbeddedFriction(t *testing.T) {
	narrow := EntryCostBreakdown{
		Fee:             0.02,
		Spread:          0.01,
		LagSpreadBuffer: 0.03,
		LeadNoise:       0.04,
		LagNoise:        0.05,
	}
	wide := narrow
	wide.Spread = 0.08

	if wide.RequiredEdge() != narrow.RequiredEdge() {
		t.Fatalf("required edge should stay unchanged when spread is already embedded in targetSpace: narrow=%v wide=%v", narrow.RequiredEdge(), wide.RequiredEdge())
	}
	if wide.EmbeddedPriceFriction() <= narrow.EmbeddedPriceFriction() {
		t.Fatalf("wider spread should raise embedded price friction: narrow=%v wide=%v", narrow.EmbeddedPriceFriction(), wide.EmbeddedPriceFriction())
	}
}

func TestStrategyBuildEntryCostBreakdownUsesSharedInputs(t *testing.T) {
	strat := newTestStrategyWithExecution(t, &testClient{}, 0.01, 0.03)
	strat.threshold.LeadNoise = 0.04
	strat.threshold.LagNoise = 0.05
	strat.lagContext.fee = 0.015

	lag := newTestBBOAt(t, "lag", 102.5, 100.5, testServerTime+1)
	triggerPrice := lag.GetAskPrc()
	got := strat.BuildEntryCostBreakdown(lag, triggerPrice)

	if got.Fee != 0.03 {
		t.Fatalf("round-trip fee mismatch: got %v want %v", got.Fee, 0.03)
	}
	if got.Spread <= 0 {
		t.Fatalf("spread component should be positive, got %v", got.Spread)
	}
	if got.LagSpreadBuffer < 0 {
		t.Fatalf("lag spread buffer should be non-negative, got %v", got.LagSpreadBuffer)
	}
	if got.LeadNoise != 0.04 {
		t.Fatalf("lead noise mismatch: got %v want %v", got.LeadNoise, 0.04)
	}
	if got.LagNoise != 0.05 {
		t.Fatalf("lag noise mismatch: got %v want %v", got.LagNoise, 0.05)
	}

	expected := 0.03 + 0.04 + 0.05
	if math.Abs(got.RequiredEdge()-expected) > 1e-12 {
		t.Fatalf("required edge mismatch: got %v want %v", got.RequiredEdge(), expected)
	}
	if got.EmbeddedPriceFriction() <= 0 {
		t.Fatalf("embedded price friction should stay available for diagnostics, got %v", got.EmbeddedPriceFriction())
	}
}

func TestStrategyLagTakerFeeFallsBackToExchangeTable(t *testing.T) {
	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Lead = "lead"
	cfg.Lag = "gateio"

	strat := cfg.New(nil)
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0)})

	if got, want := strat.lagContext.fee, takerFees["gateio"]; got != want {
		t.Fatalf("lag taker fee fallback mismatch: got %v want %v", got, want)
	}
	if got, want := strat.ProfitBuffer(), takerFees["gateio"]*2; got != want {
		t.Fatalf("profit buffer fallback fee mismatch: got %v want %v", got, want)
	}
}

func TestStrategyLagTakerFeeConfigOverridesExchangeFallback(t *testing.T) {
	fee := 2.1e-4
	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Lead = "lead"
	cfg.Lag = "gateio"
	cfg.Cost.LagTakerFee = &fee

	strat := cfg.New(nil)
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0)})

	if got := strat.lagContext.fee; got != fee {
		t.Fatalf("lag taker fee override mismatch: got %v want %v", got, fee)
	}

	strat.threshold.LeadNoise = 0.0003
	strat.threshold.LagNoise = 0.0004
	got := strat.BuildEntryCostBreakdown(newTestBBOAt(t, "lag", 100.1, 99.9, testServerTime), 100.1)
	if want := fee * 2; got.Fee != want {
		t.Fatalf("entry cost fee mismatch: got %v want %v", got.Fee, want)
	}
	if want := fee*2 + 0.0003 + 0.0004; math.Abs(got.RequiredEdge()-want) > 1e-12 {
		t.Fatalf("required edge mismatch: got %v want %v", got.RequiredEdge(), want)
	}
}
