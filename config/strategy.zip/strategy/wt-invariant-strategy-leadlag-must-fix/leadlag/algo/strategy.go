package algo

import (
	"math"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/atom_symbol"
	"git.hashingbot.com/aurthes/xex_mm_go/requests"
	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/shopspring/decimal"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/defaults"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/idgen"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/jsontype"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

var takerFees = map[string]float64{
	"gateio": 1.6 * 1e-4,
	"bybit":  1.5 * 1e-4,
}

type BBORecord struct {
	StatsWindow jsontype.Duration `json:"stats_window" default:"5s"`
	Window      jsontype.Duration `json:"window" default:"5s"`
	Size        int               `json:"size" default:"100"`
}

type TriggerConfig struct {
	Lead  float64 `json:"lead"`
	Open  float64 `json:"open"`
	Close float64 `json:"close"`

	LagPart  float64 `json:"lag_part" default:"0.5"` // require [lag move space]:(lead move - lag move) / (lead move) > LagPart
	LeadPart float64 `json:"lead_part" default:"1"`  // require: lead / price diff > LeadPart

	Quantile struct {
		Move float64 `json:"move" default:"0.99"`
	} `json:"quantile"`

	TargetProfitRate float64 `json:"target_profit_rate" default:"0"`

	DriftLimit      float64           `json:"drift_limit" default:"0.02"`
	DriftPeriod     jsontype.Duration `json:"drift_period" default:"1h"`
	DriftMinSamples int               `json:"drift_min_samples" default:"20"`
	DriftWarmup     jsontype.Duration `json:"drift_warmup"`
}

type ExecutionConfig struct {
	OpenNotional   decimal.Decimal `json:"open" default:"1000"`
	TrailingStop   float64         `json:"trailing_stop" default:"0.001"`
	MaxEntrySpread float64         `json:"max_entry_spread" default:"-1"` // <0 keeps backward-compatible fallback to trailing_stop
	Parallel       int             `json:"parallel" default:"1"`
}

func (c ExecutionConfig) EntrySpreadLimit() float64 {
	if c.MaxEntrySpread < 0 {
		return c.TrailingStop
	}
	return c.MaxEntrySpread
}

type CostConfig struct {
	LagTakerFee *float64 `json:"lag_taker_fee"`
}

type AlignmentPhase uint8

const (
	AlignmentBootstrap AlignmentPhase = iota
	AlignmentAligning
	AlignmentActive
)

type StrategyConfig struct {
	Symbol string `json:"symbol"`
	Lead   string `json:"lead"`
	Lag    string `json:"lag"`

	Trigger   TriggerConfig   `json:"trigger"`
	Execute   ExecutionConfig `json:"execute"`
	Cost      CostConfig      `json:"cost"`
	Analysis  AnalysisConfig  `json:"analysis"`
	BBORecord BBORecord       `json:"bbo_record"`
}

func (c *StrategyConfig) SetDefault() {
	defaults.MustSet(c)
	if c.Analysis.Variant == "" {
		c.Analysis.Variant = DefaultStrategyVariant
	}
	c.Analysis.SetDefault()
}

func (c *StrategyConfig) New(log *logrus.Entry) *Strategy {
	return &Strategy{
		bboCounts: map[string]int64{},

		config:   *c,
		log:      log,
		recorder: (*recorder.EmptyRecorder)(nil),
	}
}

func (c *StrategyConfig) LagTakerFee() float64 {
	if c.Cost.LagTakerFee != nil {
		return *c.Cost.LagTakerFee
	}
	return takerFees[c.Lag]
}

type PrivateVar struct {
	UpLeadCount    int
	UpLadCount     int
	UpSpaceCount   int
	DownLeadCount  int
	DownLadCount   int
	DownSpaceCount int
	MaxParallel    int

	ActiveLeadTicks       int
	ActiveLagTicks        int
	ThresholdRolls        int
	OpenChecks            int
	ParallelBlocked       int
	DriftBlocked          int
	LongPriceDiffBlocked  int
	LongThresholdBlocked  int
	ShortPriceDiffBlocked int
	ShortThresholdBlocked int

	LastUpEntry      float64
	LastDownEntry    float64
	LastDrift        float64
	LastUpQuantile   float64
	LastDownQuantile float64
	LastExit         float64
	LastProfitBuffer float64
	MaxExit          float64
	MaxUpQuantile    float64
	MinDownQuantile  float64
	MaxLeadMove      float64
	MaxAskDiff       float64
	MinLeadMove      float64
	MinBidDiff       float64
}

type Strategy struct {
	template.BaseSingleClientStrategy

	clientID    idgen.IDGenerator
	leadContext struct {
		origin      utils.BBO
		prevOrigin  utils.BBO
		drifted     utils.BBO
		recorder    BBOVolRecorder
		recordPoint int64

		volema StreamStdEmaRecorder

		move MoveQueue
	}
	lagContext struct {
		bbo        utils.BBO
		prevBBO    utils.BBO
		recorder   BBOVolRecorder
		drift      StreamRecorder
		driftReady bool
		stdema     StreamRecorder
		spread     StreamRecorder

		volema StreamStdEmaRecorder

		depth *utils.Depth

		fee float64
	}

	threshold struct {
		UpEntry float64
		UpExit  float64

		DownEntry float64
		DownExit  float64

		LeadNoise float64
		LagNoise  float64

		DriftStdEma StreamRecorder
	}
	alignment struct {
		phase              AlignmentPhase
		driftSamples       int
		firstPairedDriftTs time.Time
		resumeLeadTick     bool
		loggedActive       bool
	}

	cache               ExecuteCache
	caches              map[string]*ExecuteCache
	cacheOrderMap       map[string]string
	attributionEmission map[string]attributionEmissionState

	bboCounts map[string]int64

	pr PrivateVar

	config StrategyConfig

	log *logrus.Entry
	// recorder *logrus.Entry

	recorder recorder.IRecorder
}

func (s *Strategy) newExecuteCache() *ExecuteCache {
	return &ExecuteCache{
		stage:    StageIdle,
		grouping: make([]requests.Order, 0, 2),
	}
}

func (s *Strategy) registerCacheOrder(cacheKey string, cache *ExecuteCache, order requests.Order) {
	cache.order = order
	s.cacheOrderMap[order.GetCID()] = cacheKey
}

func (s *Strategy) SetContext(ctx template.IStrategyContext) {
	s.BaseSingleClientStrategy.SetContext(ctx)
	s.leadContext.recorder.Init(100, s.config.BBORecord.Window.Duration().Milliseconds())
	s.lagContext.recorder.Init(100, s.config.BBORecord.Window.Duration().Milliseconds())
	s.lagContext.drift.Init(s.config.Trigger.DriftPeriod.Duration(), 100)
	s.clientID = idgen.NewInt64Generator(8)
	s.caches = map[string]*ExecuteCache{}
	s.cacheOrderMap = map[string]string{}
	s.attributionEmission = map[string]attributionEmissionState{}
	s.leadContext.move.Init(s.Context.Now(), s.config.BBORecord.StatsWindow.Duration())
	s.leadContext.volema.Init(
		s.config.BBORecord.Window.Duration(),
		s.config.BBORecord.StatsWindow.Duration(),
		100,
	)
	s.lagContext.volema.Init(
		s.config.BBORecord.Window.Duration(),
		s.config.BBORecord.StatsWindow.Duration(),
		100,
	)
	s.lagContext.spread.Init(s.config.BBORecord.StatsWindow.Duration(), 100)
	s.threshold.UpEntry = s.config.Trigger.Lead
	s.threshold.UpExit = s.config.Trigger.Close
	s.threshold.DownEntry = -s.config.Trigger.Lead
	s.threshold.DownExit = -s.config.Trigger.Close
	s.threshold.DriftStdEma.Init(s.config.BBORecord.StatsWindow.Duration(), 100)
	s.lagContext.fee = s.config.LagTakerFee()
	s.alignment.phase = AlignmentBootstrap
	s.pr.MinLeadMove = math.MaxFloat64
	s.pr.MinBidDiff = math.MaxFloat64
	s.pr.MinDownQuantile = math.MaxFloat64
}

func (s *Strategy) SetRecorder(recorder recorder.IRecorder) {
	s.recorder = recorder
}

func (s *Strategy) Brief() {
	// s.log.Infof("[Brief] BBO Counts: %+v", s.bboCounts)
	s.log.Infof("[Brief] PRIVATE: %+v", s.pr)
	s.log.Infof("[Config] %+v", s.config)
}

func (s *Strategy) OnBBO(bbo *utils.BBO) error {

	s.Context.ReturnBBOToPool(bbo)
	return nil
}

func (s *Strategy) OnRawBBO(bbo *utils.BBO) error {
	defer s.Context.ReturnBBOToPool(bbo)
	s.bboCounts[bbo.GetSymbol().GetName()]++
	exchange := bbo.GetSymbol().GetExchangeName()
	prevLead := s.leadContext.origin
	prevLag := s.lagContext.bbo
	priceChanged, tracked := s.updateRawMarketState(bbo, exchange)
	if !tracked {
		return nil
	}
	now := s.Context.Now()
	if s.leadContext.origin.ValidBBO && s.lagContext.bbo.ValidBBO {
		s.UpdateDrift(now, &s.leadContext.origin, &s.lagContext.bbo)
	}

	prevPhase := s.alignment.phase
	switch s.updateAlignmentPhase(now) {
	case AlignmentBootstrap, AlignmentAligning:
		// Alignment-first: before Active we only keep raw market state and drift stats.
		// If position restore is added later, add a restricted recovery path here instead
		// of reusing the full active handlers.
		return nil
	case AlignmentActive:
		if prevPhase != AlignmentActive {
			leadSeed := s.leadContext.origin
			lagSeed := s.lagContext.bbo
			if exchange == s.config.Lead && priceChanged && prevLead.ValidBBO {
				leadSeed = prevLead
			}
			if exchange != s.config.Lead && s.leadContext.prevOrigin.ValidBBO {
				leadSeed = s.leadContext.prevOrigin
			}
			if exchange == s.config.Lag && priceChanged && prevLag.ValidBBO {
				lagSeed = prevLag
			}
			s.alignment.resumeLeadTick = exchange != s.config.Lead
			s.enterActivePhase(now, leadSeed, lagSeed)
			s.logAlignmentTransition(now)
		}
	}
	allowResumeLead := exchange == s.config.Lead && s.alignment.resumeLeadTick
	if !priceChanged && prevPhase == AlignmentActive && !allowResumeLead {
		return nil
	}
	if allowResumeLead {
		s.alignment.resumeLeadTick = false
	}

	switch exchange {
	case s.config.Lead:
		s.pr.ActiveLeadTicks++
		return s.OnLeadBBO(bbo)
	case s.config.Lag:
		s.pr.ActiveLagTicks++
		return s.OnLagBBO(bbo)
	default:
		return nil
	}
}

func (s *Strategy) ProfitBuffer() float64 {
	return EntryCostBreakdown{
		Fee:       s.lagContext.fee * 2,
		LeadNoise: s.threshold.LeadNoise,
		LagNoise:  s.threshold.LagNoise,
	}.RequiredEdge()
}

func (s *Strategy) UpdateDrift(t time.Time, leadBBO, lagBBO *utils.BBO) {
	// drift :=
	lead := (leadBBO.BestAskPrc + leadBBO.BestBidPrc)
	lag := (lagBBO.BestAskPrc + lagBBO.BestBidPrc)
	drift := lag / lead
	if s.alignment.driftSamples == 0 {
		s.alignment.firstPairedDriftTs = t
	}
	s.alignment.driftSamples++
	s.lagContext.drift.OnData(t, drift)
	s.lagContext.driftReady = true
	s.threshold.DriftStdEma.OnData(t, s.lagContext.drift.GetStd())
}

func (s *Strategy) updateRawMarketState(bbo *utils.BBO, exchange string) (bool, bool) {
	switch exchange {
	case s.config.Lead:
		if bbo.BestAskPrc == s.leadContext.origin.BestAskPrc && bbo.BestBidPrc == s.leadContext.origin.BestBidPrc {
			return false, true
		}
		s.leadContext.prevOrigin = s.leadContext.origin
		s.leadContext.origin = *bbo
		return true, true
	case s.config.Lag:
		if bbo.BestAskPrc == s.lagContext.bbo.BestAskPrc && bbo.BestBidPrc == s.lagContext.bbo.BestBidPrc {
			return false, true
		}
		s.lagContext.prevBBO = s.lagContext.bbo
		s.lagContext.bbo = *bbo
		return true, true
	default:
		return false, false
	}
}

func (s *Strategy) logAlignmentTransition(now time.Time) {
	if s.log == nil || s.alignment.loggedActive {
		return
	}
	s.alignment.loggedActive = true
	s.log.WithFields(logrus.Fields{
		"phase":            "active",
		"drift_samples":    s.alignment.driftSamples,
		"drift_ready":      s.lagContext.driftReady,
		"first_paired_ts":  s.alignment.firstPairedDriftTs,
		"warmup":           s.alignmentWarmup(),
		"resume_lead_tick": s.alignment.resumeLeadTick,
		"now":              now,
	}).Info("alignment phase transition")
}

func (s *Strategy) alignmentWarmup() time.Duration {
	if warmup := s.config.Trigger.DriftWarmup.Duration(); warmup > 0 {
		return warmup
	}
	return s.config.BBORecord.StatsWindow.Duration()
}

func (s *Strategy) alignmentReady(now time.Time) bool {
	if !s.leadContext.origin.ValidBBO || !s.lagContext.bbo.ValidBBO {
		return false
	}
	if s.alignment.driftSamples < s.config.Trigger.DriftMinSamples {
		return false
	}
	if s.alignment.firstPairedDriftTs.IsZero() {
		return false
	}
	return !now.Before(s.alignment.firstPairedDriftTs.Add(s.alignmentWarmup()))
}

func (s *Strategy) updateAlignmentPhase(now time.Time) AlignmentPhase {
	switch {
	case !s.leadContext.origin.ValidBBO || !s.lagContext.bbo.ValidBBO:
		s.alignment.phase = AlignmentBootstrap
	case s.alignmentReady(now):
		s.alignment.phase = AlignmentActive
	default:
		s.alignment.phase = AlignmentAligning
	}
	return s.alignment.phase
}

func (s *Strategy) enterActivePhase(now time.Time, leadSeed, lagSeed utils.BBO) {
	window := s.config.BBORecord.Window.Duration()
	statsWindow := s.config.BBORecord.StatsWindow.Duration()

	s.leadContext.recorder.Init(100, window.Milliseconds())
	s.lagContext.recorder.Init(100, window.Milliseconds())
	s.leadContext.volema.Init(window, statsWindow, 100)
	s.lagContext.volema.Init(window, statsWindow, 100)
	s.lagContext.spread.Init(statsWindow, 100)
	s.leadContext.move.Init(now, statsWindow)

	scaledLead := leadSeed
	if s.lagContext.driftReady {
		drift := s.lagContext.drift.GetMean()
		scaledLead.BestAskPrc = scaledLead.BestAskPrc * drift
		scaledLead.BestBidPrc = scaledLead.BestBidPrc * drift
	}
	s.leadContext.drifted = scaledLead
	s.leadContext.recorder.OnBBO(scaledLead.ServerTime, scaledLead.BestAskPrc, scaledLead.BestBidPrc)
	s.leadContext.volema.OnData(now, (scaledLead.BestAskPrc+scaledLead.BestBidPrc)/2)
	s.lagContext.recorder.OnBBO(lagSeed.ServerTime, lagSeed.BestAskPrc, lagSeed.BestBidPrc)
	s.lagContext.spread.OnData(now, lagSeed.BestAskPrc-lagSeed.BestBidPrc)
	s.lagContext.volema.OnData(now, (lagSeed.BestAskPrc+lagSeed.BestBidPrc)/2)
}

func (s *Strategy) UpdateMoveThreshold(t time.Time, bbo *utils.BBO) {
	if s.leadContext.move.ShouldRoll(t) {
		s.pr.ThresholdRolls++
		s.threshold.LeadNoise = s.leadContext.volema.GetStdEma()
		s.threshold.LagNoise = s.lagContext.volema.GetStdEma()
		s.leadContext.move.Sort()
		up, down := s.leadContext.move.Qunatile(s.config.Trigger.Quantile.Move)
		exit := s.threshold.DriftStdEma.GetMean()

		profitBuffer := s.ProfitBuffer()
		s.pr.LastUpQuantile = up
		s.pr.LastDownQuantile = down
		s.pr.LastExit = exit
		s.pr.LastProfitBuffer = profitBuffer
		if exit > s.pr.MaxExit {
			s.pr.MaxExit = exit
		}
		if up > s.pr.MaxUpQuantile {
			s.pr.MaxUpQuantile = up
		}
		if down < s.pr.MinDownQuantile {
			s.pr.MinDownQuantile = down
		}

		if up-exit > profitBuffer {
			s.threshold.UpEntry = up
			s.threshold.UpExit = exit

		} else {
			s.threshold.UpEntry = exit + profitBuffer
			s.threshold.UpExit = exit

		}
		if -down-exit > profitBuffer {
			s.threshold.DownEntry = down
			s.threshold.DownExit = -exit
		} else {
			s.threshold.DownEntry = -exit - profitBuffer
			s.threshold.DownExit = -exit
		}
		s.pr.LastUpEntry = s.threshold.UpEntry
		s.pr.LastDownEntry = s.threshold.DownEntry
		if s.log != nil && (math.Abs(exit) > 1 || math.Abs(s.threshold.UpEntry) > 1 || math.Abs(s.threshold.DownEntry) > 1) {
			s.log.WithFields(logrus.Fields{
				"up_quantile":   up,
				"down_quantile": down,
				"exit":          exit,
				"profit_buffer": profitBuffer,
				"up_entry":      s.threshold.UpEntry,
				"down_entry":    s.threshold.DownEntry,
				"lead_noise":    s.threshold.LeadNoise,
				"lag_noise":     s.threshold.LagNoise,
				"drift_mean":    s.lagContext.drift.GetMean(),
				"drift_std":     s.lagContext.drift.GetStd(),
				"drift_samples": s.alignment.driftSamples,
				"move_samples":  s.leadContext.move.Size(),
				"active_lead":   s.pr.ActiveLeadTicks,
				"active_lag":    s.pr.ActiveLagTicks,
			}).Info("threshold anomaly")
		}
		// s.NowEntry().
		// 	WithFields(logrus.Fields{
		// 		// "size": s.leadContext.move.Size(),
		// 		"up entry":   fmt.Sprintf("%.2f%%", up*100),
		// 		"up exit":    fmt.Sprintf("%.2f%%", exit*100),
		// 		"down entry": fmt.Sprintf("%.2f%%", down*100),
		// 		"down exit":  fmt.Sprintf("%.2f%%", -exit*100),
		// 		// "lead noise":    fmt.Sprintf("%.2f%%", s.threshold.LeadNoise*100),
		// 		// "lag noise":     fmt.Sprintf("%.2f%%", s.threshold.LagNoise*100),
		// 		// "profit buffer": fmt.Sprintf("%.2f%%", profitBuffer*100),
		// 	}).Info()
		s.leadContext.move.Roll(t)
	}
	bidMin, _ := s.leadContext.recorder.Bid.GetMin()
	askMax, _ := s.leadContext.recorder.Ask.GetMax()

	s.leadContext.move.Push(bbo.BestBidPrc/bidMin.Price-1, bbo.BestAskPrc/askMax.Price-1)
}

func (s *Strategy) OnLeadBBO(bbo *utils.BBO) error {
	s.leadContext.origin = *bbo

	drift := 1.0
	if s.lagContext.driftReady {
		drift = s.lagContext.drift.GetMean()
		bbo.BestAskPrc = bbo.BestAskPrc * drift
		bbo.BestBidPrc = bbo.BestBidPrc * drift
	}
	s.leadContext.drifted = *bbo
	s.leadContext.recorder.OnBBO(
		bbo.ServerTime,
		bbo.BestAskPrc,
		bbo.BestBidPrc,
	)
	s.leadContext.volema.OnData(s.Context.Now(), (bbo.BestAskPrc+bbo.BestBidPrc)/2)
	s.UpdateMoveThreshold(s.Context.Now(), bbo)

	// Close first for all existing caches, then try to open a new position.
	for key, cache := range s.caches {
		switch cache.stage {
		case StageHold:
			if cache.position.IsPositive() {
				err := s.CloseLong(key, cache, bbo, &s.lagContext.bbo)
				if err != nil {
					return err
				}
			} else if cache.position.IsNegative() {
				err := s.CloseShort(key, cache, bbo, &s.lagContext.bbo)
				if err != nil {
					return err
				}
			}
		}
	}
	if len(s.caches) >= s.config.Execute.Parallel {
		s.pr.ParallelBlocked++
		s.RecordFilterAttribution(AttributionReasonFiltered, 0, 0, 0, "parallel-limit")
		return nil
	}
	if s.lagContext.driftReady && math.Abs(drift-1) > s.config.Trigger.DriftLimit {
		s.pr.DriftBlocked++
		s.RecordFilterAttribution(AttributionReasonFiltered, drift-1, s.config.Trigger.DriftLimit, 0, "drift-limit")
		return nil
	}
	s.pr.OpenChecks++
	s.pr.LastDrift = drift
	ok, err := s.OpenLong(bbo)
	if err != nil {
		return err
	}
	if ok {
		return nil
	}
	_, err = s.OpenShort(bbo)
	return err
}

func (s *Strategy) OnLagBBO(bbo *utils.BBO) error {

	s.lagContext.recorder.OnBBO(
		bbo.ServerTime,
		bbo.BestAskPrc,
		bbo.BestBidPrc,
	)
	s.lagContext.spread.OnData(s.Context.Now(), bbo.BestAskPrc-bbo.BestBidPrc)
	s.lagContext.volema.OnData(s.Context.Now(), (bbo.BestAskPrc+bbo.BestBidPrc)/2)
	s.lagContext.bbo = *bbo

	// Close first for all existing caches on lag updates (stoploss/trailing/signal close).
	for key, cache := range s.caches {
		switch cache.stage {
		case StageHold:
			if cache.position.IsPositive() {
				s.TrackLogTrailingLong(cache, bbo)
				ok, err := s.ExecuteStoplossLong(key, cache, bbo)
				if err != nil {
					return err
				}
				if ok {
					continue
				}
				err = s.CloseLong(key, cache, &s.leadContext.drifted, bbo)
				if err != nil {
					return err
				}
			} else if cache.position.IsNegative() {
				s.TrackLogTrailingShort(cache, bbo)
				ok, err := s.ExecuteStoplossShort(key, cache, bbo)
				if err != nil {
					return err
				}
				if ok {
					continue
				}
				err = s.CloseShort(key, cache, &s.leadContext.drifted, bbo)
				if err != nil {
					return err
				}
			}
		}
	}
	return nil
}

func (s *Strategy) EstimateLagSpread() float64 {
	return s.lagContext.bbo.BestAskPrc - s.lagContext.bbo.BestBidPrc
}

func (s *Strategy) LagSpreadBuffer(bbo *utils.BBO) float64 {
	current := bbo.BestAskPrc - bbo.BestBidPrc
	histroy := s.lagContext.spread.GetMean()
	return math.Max(current-histroy, 0)
}

func spreadPct(bbo *utils.BBO) float64 {
	return (bbo.BestAskPrc - bbo.BestBidPrc) / (bbo.BestAskPrc + bbo.BestBidPrc) * 2
}

func (s *Strategy) OpenLong(bbo *utils.BBO) (bool, error) {
	// input param bbo is lead bbo
	leadBase, _ := s.leadContext.recorder.Bid.GetMin()
	minAsk, _ := s.leadContext.recorder.Ask.GetMin()

	leadMove := bbo.BestBidPrc/leadBase.Price - 1
	askDiff := bbo.BestAskPrc/minAsk.Price - 1
	if leadMove > s.pr.MaxLeadMove {
		s.pr.MaxLeadMove = leadMove
	}
	if askDiff > s.pr.MaxAskDiff {
		s.pr.MaxAskDiff = askDiff
	}
	trigPrice := s.lagContext.bbo.GetAskPrc()
	prcDiff := bbo.BestBidPrc/trigPrice - 1
	if prcDiff <= 0 {
		s.pr.LongPriceDiffBlocked++
		s.RecordFilterAttribution(AttributionReasonNoTrigger, prcDiff, 0, 0, "long-price-diff")
		return false, nil
	}

	if (leadMove >= s.threshold.UpEntry) && (askDiff >= s.threshold.UpEntry) {
		s.pr.UpLeadCount++
		if !s.lagContext.bbo.ValidBBO {
			return false, nil
		}

		lagBase, _ := s.lagContext.recorder.Bid.GetMin()
		basePrice := math.Min(leadBase.Price, lagBase.Price)
		lagMove := s.lagContext.bbo.GetBidPrc()/basePrice - 1

		moveSpace := leadMove - lagMove

		if moveSpace/leadMove > s.config.Trigger.LagPart {
			s.pr.UpLadCount++
			targetPrice := bbo.BestBidPrc - bbo.BestBidPrc*s.threshold.UpExit - s.LagSpreadBuffer(&s.lagContext.bbo)
			targetSpace := targetPrice/trigPrice - 1
			entryCost := s.BuildEntryCostBreakdown(&s.lagContext.bbo, trigPrice)
			requiredEdge := entryCost.RequiredEdgeWithTargetProfit(s.config.Trigger.TargetProfitRate)
			if targetSpace < requiredEdge {
				s.RecordFilterAttribution(AttributionReasonFiltered, targetSpace, requiredEdge, requiredEdge, "entry-cost")
				return false, nil
			}
			if spreadPct(&s.lagContext.bbo) > s.config.Execute.EntrySpreadLimit() {
				s.RecordFilterAttribution(AttributionReasonFiltered, spreadPct(&s.lagContext.bbo), s.config.Execute.EntrySpreadLimit(), requiredEdge, "entry-spread")
				return false, nil
			}
			s.pr.UpSpaceCount++
			entry := s.NowEntry().WithField("Method", "OpenLong")
			entry.Infof("Move=<Lead=%f%%, Lag=%f%%, Predict=%f%%>", leadMove*100, lagMove*100, targetSpace*100)
			entry.Infof("EntryCost<%s, target_profit_rate=%.6f>", entryCost.String(), s.config.Trigger.TargetProfitRate)
			param := template.OrderParam{
				Symbol:      s.lagContext.bbo.GetSymbol(),
				CID:         s.clientID.Next(),
				Side:        utils.Side.Long,
				Price:       trigPrice,
				OrderType:   template.OrderTypeLimit,
				TimeInForce: template.IOC,
			}
			cacheKey := param.CID
			cache := s.newExecuteCache()
			s.caches[cacheKey] = cache
			s.UpdateGroupTag(cache, entry, cacheKey)
			param.Qty = s.CalOpenQty(s.lagContext.bbo.GetSymbol(), param.Price)
			s.LogBBO(entry, "LeadBBO", bbo)
			s.LogBBO(entry, "LagBBO_", &s.lagContext.bbo)
			entry.Infof("Order Param %+v", &param)
			s.RecordTrigger(
				cache,
				s.Context.Now(),
				&s.leadContext.origin, &s.lagContext.bbo,
				TriggerParam{
					by:           "signal",
					Entry:        s.threshold.UpEntry,
					Exit:         s.threshold.UpExit,
					leadDiff:     leadMove,
					lagDiff:      lagMove,
					drift:        s.lagContext.drift.GetMean(),
					base:         leadBase,
					positionSide: "open",
					targetSpace:  targetSpace,
				},
				&param,
			)
			order := s.Context.NewOrder(param)
			s.registerCacheOrder(cacheKey, cache, order)
			err := s.Client.SendOrder(order)
			if err != nil {
				delete(s.cacheOrderMap, param.CID)
				delete(s.caches, cacheKey)
				return false, err
			}
			s.RecordOrderCreateAttribution(cache, &param, "open", leadMove, s.threshold.UpEntry, requiredEdge, s.EstimateOrderLiquidity(&s.lagContext.bbo, &param))
			s.SetStage(cache, StageOpen, entry)
			return true, nil
		}
	}
	s.pr.LongThresholdBlocked++
	s.RecordFilterAttribution(AttributionReasonNoTrigger, leadMove, s.threshold.UpEntry, 0, "long-threshold")
	return false, nil
}

func (s *Strategy) OpenShort(bbo *utils.BBO) (bool, error) {
	leadBase, _ := s.leadContext.recorder.Ask.GetMax()
	leadMove := bbo.BestAskPrc/leadBase.Price - 1
	if leadMove < s.pr.MinLeadMove {
		s.pr.MinLeadMove = leadMove
	}
	trigPrice := s.lagContext.bbo.GetBidPrc()
	prcDiff := bbo.BestAskPrc/trigPrice - 1
	if prcDiff >= 0 {
		s.pr.ShortPriceDiffBlocked++
		s.RecordFilterAttribution(AttributionReasonNoTrigger, prcDiff, 0, 0, "short-price-diff")
		return false, nil
	}

	maxBid, _ := s.leadContext.recorder.Bid.GetMax()
	bidDiff := bbo.BestBidPrc/maxBid.Price - 1
	if bidDiff < s.pr.MinBidDiff {
		s.pr.MinBidDiff = bidDiff
	}
	if (leadMove <= s.threshold.DownEntry) && (bidDiff <= s.threshold.DownEntry) {
		s.pr.DownLeadCount++
		if !s.lagContext.bbo.ValidBBO {
			return false, nil
		}
		lagBase, _ := s.lagContext.recorder.Ask.GetMax()
		basePrice := math.Max(leadBase.Price, lagBase.Price)
		lagMove := s.lagContext.bbo.GetAskPrc()/basePrice - 1

		moveSpace := leadMove - lagMove

		if moveSpace/leadMove >= s.config.Trigger.LagPart {

			targetPrice := bbo.BestAskPrc - leadBase.Price*s.threshold.DownExit + s.LagSpreadBuffer(&s.lagContext.bbo)
			s.pr.DownLadCount++
			trigPrice := s.lagContext.bbo.GetBidPrc()
			targetSpace := targetPrice/trigPrice - 1
			entryCost := s.BuildEntryCostBreakdown(&s.lagContext.bbo, trigPrice)
			requiredEdge := entryCost.RequiredEdgeWithTargetProfit(s.config.Trigger.TargetProfitRate)
			if -targetSpace < requiredEdge {
				s.RecordFilterAttribution(AttributionReasonFiltered, -targetSpace, requiredEdge, requiredEdge, "entry-cost")
				return false, nil
			}
			if spreadPct(&s.lagContext.bbo) > s.config.Execute.EntrySpreadLimit() {
				s.RecordFilterAttribution(AttributionReasonFiltered, spreadPct(&s.lagContext.bbo), s.config.Execute.EntrySpreadLimit(), requiredEdge, "entry-spread")
				return false, nil
			}

			s.pr.DownSpaceCount++

			entry := s.NowEntry().WithField("Method", "OpenShort")

			entry.Infof("Diff=<Lead=%f%%, Lag=%f%%, LagBid=%f%%>", leadMove*100, lagMove*100, targetSpace*100)
			entry.Infof("Down<Lead=%f%%, Lag=%f%%, LagBid=%f%%>", leadMove*100, lagMove*100, targetSpace*100)
			entry.Infof("EntryCost<%s, target_profit_rate=%.6f>", entryCost.String(), s.config.Trigger.TargetProfitRate)
			param := template.OrderParam{
				Symbol:      s.lagContext.bbo.GetSymbol(),
				CID:         s.clientID.Next(),
				Side:        utils.Side.Short,
				Price:       s.lagContext.bbo.GetBidPrc(),
				OrderType:   template.OrderTypeLimit,
				TimeInForce: template.IOC,
			}
			cacheKey := param.CID
			cache := s.newExecuteCache()
			s.caches[cacheKey] = cache
			s.UpdateGroupTag(cache, entry, cacheKey)
			param.Qty = s.CalOpenQty(s.lagContext.bbo.GetSymbol(), param.Price)
			s.LogBBO(entry, "LeadBBO", bbo)
			s.LogBBO(entry, "LagBBO_", &s.lagContext.bbo)
			entry.Infof("Order Param %+v", &param)
			s.RecordTrigger(
				cache,
				s.Context.Now(),
				&s.leadContext.origin, &s.lagContext.bbo,
				TriggerParam{
					by:           "signal",
					Entry:        s.threshold.DownEntry,
					Exit:         s.threshold.DownExit,
					leadDiff:     leadMove,
					lagDiff:      lagMove,
					drift:        s.lagContext.drift.GetMean(),
					base:         leadBase,
					positionSide: "open",
					targetSpace:  targetSpace,
				},
				&param,
			)
			order := s.Context.NewOrder(param)
			s.registerCacheOrder(cacheKey, cache, order)
			err := s.Client.SendOrder(order)
			if err != nil {
				delete(s.cacheOrderMap, param.CID)
				delete(s.caches, cacheKey)
				return false, err
			}
			s.RecordOrderCreateAttribution(cache, &param, "open", leadMove, s.threshold.DownEntry, requiredEdge, s.EstimateOrderLiquidity(&s.lagContext.bbo, &param))
			s.SetStage(cache, StageOpen, entry)

			return true, nil
		}
	}
	s.pr.ShortThresholdBlocked++
	s.RecordFilterAttribution(AttributionReasonNoTrigger, leadMove, s.threshold.DownEntry, 0, "short-threshold")
	return false, nil
}

func (s *Strategy) UpdateGroupTag(cache *ExecuteCache, entry *logrus.Entry, group string) {
	entry.Infof("Update Group: %s -> %s", cache.groupTag, group)
	cache.groupTag = group
}

func (s *Strategy) SetTrackTrailing(cache *ExecuteCache, price float64) {
	cache.trailing = price
}

func (s *Strategy) TrackLogTrailingLong(cache *ExecuteCache, bbo *utils.BBO) {
	if bbo.BestBidPrc > cache.trailing {
		cache.trailing = bbo.BestBidPrc
	}

}

func (s *Strategy) ExecuteStoplossLong(cacheKey string, cache *ExecuteCache, bbo *utils.BBO) (bool, error) {
	if cache.order != nil {
		return false, nil
	}

	fallback := bbo.BestBidPrc/cache.trailing - 1

	if fallback > -s.config.Execute.TrailingStop {
		return false, nil
	}

	entry := s.NowEntry().WithField("Method", "ExecuteStoplossLong")
	entry.Infof("TrailingStop<fallback=%f%%, highest=%f>", fallback, cache.trailing)
	s.LogBBO(entry, "LagSL", bbo)

	params := template.OrderParam{
		Symbol:      s.lagContext.bbo.GetSymbol(),
		CID:         s.clientID.Next(),
		Side:        utils.Side.Short,
		Qty:         cache.position.InexactFloat64(),
		Price:       bbo.GetBidPrc() * 0.995,
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	}
	entry.Infof("StoplossOrderParam<%+v>", params)
	s.RecordTrigger(
		cache,
		s.Context.Now(),
		&s.leadContext.origin, bbo,
		TriggerParam{
			by:           "sl",
			drift:        s.lagContext.drift.GetMean(),
			base:         PricePoint{Price: cache.trailing, Time: s.Context.Now().UnixMilli()},
			positionSide: "close",
		},
		&params,
	)
	order := s.Context.NewOrder(params)
	s.registerCacheOrder(cacheKey, cache, order)
	err := s.Client.SendOrder(order)
	if err != nil {
		delete(s.cacheOrderMap, params.CID)
		return false, err
	}
	s.RecordOrderCreateAttribution(cache, &params, "close", fallback, -s.config.Execute.TrailingStop, 0, s.EstimateOrderLiquidity(bbo, &params))
	s.SetStage(cache, StageClose, entry)
	return true, nil
}

func (s *Strategy) ExecuteStoplossShort(cacheKey string, cache *ExecuteCache, bbo *utils.BBO) (bool, error) {
	if cache.order != nil {
		return false, nil
	}

	fallback := -(bbo.BestAskPrc/cache.trailing - 1)

	if fallback > -s.config.Execute.TrailingStop {
		return false, nil
	}

	entry := s.NowEntry().WithField("Method", "ExecuteStoplossShort")
	entry.Infof("TrailingStop<fallback=%f%%, lowest=%f>", fallback, cache.trailing)
	s.LogBBO(entry, "LagSL", bbo)

	params := template.OrderParam{
		Symbol:      s.lagContext.bbo.GetSymbol(),
		CID:         s.clientID.Next(),
		Side:        utils.Side.Long,
		Qty:         cache.position.Abs().InexactFloat64(),
		Price:       bbo.BestAskPrc * 1.005,
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	}
	entry.Infof("StoplossOrderParam<%+v>", params)
	s.RecordTrigger(
		cache,
		s.Context.Now(),
		&s.leadContext.origin, bbo,
		TriggerParam{
			by:           "sl",
			drift:        s.lagContext.drift.GetMean(),
			base:         PricePoint{Price: cache.trailing, Time: s.Context.Now().UnixMilli()},
			positionSide: "close",
		},
		&params,
	)
	order := s.Context.NewOrder(params)
	s.registerCacheOrder(cacheKey, cache, order)
	err := s.Client.SendOrder(order)
	if err != nil {
		delete(s.cacheOrderMap, params.CID)
		return false, err
	}
	s.RecordOrderCreateAttribution(cache, &params, "close", fallback, -s.config.Execute.TrailingStop, 0, s.EstimateOrderLiquidity(bbo, &params))
	s.SetStage(cache, StageClose, entry)
	return true, nil
}

func (s *Strategy) TrackLogTrailingShort(cache *ExecuteCache, bbo *utils.BBO) {
	if bbo.BestAskPrc < cache.trailing {
		cache.trailing = bbo.BestAskPrc
	}

}

func (s *Strategy) CloseLong(cacheKey string, cache *ExecuteCache, leadBBO, lagBBO *utils.BBO) error {
	if cache.order != nil {
		return nil
	}

	lagDiff := leadBBO.BestBidPrc/lagBBO.BestBidPrc - 1
	if lagDiff < s.threshold.UpExit {
		// trigger close long
		entry := s.NowEntry().WithField("Method", "CloseLong")
		entry.Infof("Diff=<Lag=%f%%>", lagDiff*100)
		param := template.OrderParam{
			Symbol:      s.lagContext.bbo.GetSymbol(),
			CID:         s.clientID.Next(),
			Side:        utils.Side.Short,
			Qty:         cache.position.InexactFloat64(),
			Price:       lagBBO.GetBidPrc(),
			OrderType:   template.OrderTypeLimit,
			TimeInForce: template.IOC,
		}
		s.LogBBO(entry, "LeadBBO", leadBBO)
		s.LogBBO(entry, "LagBBO_", lagBBO)
		entry.Infof("CloseLong OrderParam<%+v>", &param)
		s.RecordTrigger(
			cache,
			s.Context.Now(),
			&s.leadContext.origin, lagBBO,
			TriggerParam{
				by:           "signal",
				lagDiff:      lagDiff,
				drift:        s.lagContext.drift.GetMean(),
				base:         PricePoint{Price: lagBBO.BestBidPrc, Time: s.Context.Now().UnixMilli()},
				positionSide: "close",
			},
			&param,
		)
		order := s.Context.NewOrder(param)
		s.registerCacheOrder(cacheKey, cache, order)
		err := s.Client.SendOrder(order)
		if err != nil {
			delete(s.cacheOrderMap, param.CID)
			return err
		}
		s.RecordOrderCreateAttribution(cache, &param, "close", lagDiff, s.threshold.UpExit, 0, s.EstimateOrderLiquidity(lagBBO, &param))
		s.SetStage(cache, StageClose, entry)

	}
	return nil
}

func (s *Strategy) CloseShort(cacheKey string, cache *ExecuteCache, leadBBO, lagBBO *utils.BBO) error {
	if cache.order != nil {
		return nil
	}

	lagDiff := leadBBO.BestAskPrc/lagBBO.BestAskPrc - 1
	if lagDiff > s.threshold.DownExit {
		// trigger close short
		entry := s.NowEntry().WithField("Method", "CloseShort")
		entry.Infof("Diff=<Lag=%f%%>", lagDiff*100)
		param := template.OrderParam{
			Symbol:      s.lagContext.bbo.GetSymbol(),
			CID:         s.clientID.Next(),
			Side:        utils.Side.Long,
			Qty:         cache.position.Abs().InexactFloat64(),
			Price:       lagBBO.GetAskPrc(),
			OrderType:   template.OrderTypeLimit,
			TimeInForce: template.IOC,
		}
		s.LogBBO(entry, "LeadBBO", leadBBO)
		s.LogBBO(entry, "LagBBO_", lagBBO)
		entry.Infof("CloseShort OrderParam<%+v>", &param)
		s.RecordTrigger(
			cache,
			s.Context.Now(),
			&s.leadContext.origin, lagBBO,
			TriggerParam{
				by:           "signal",
				lagDiff:      lagDiff,
				drift:        s.lagContext.drift.GetMean(),
				base:         PricePoint{Price: lagBBO.BestAskPrc, Time: s.Context.Now().UnixMilli()},
				positionSide: "close",
			},
			&param,
		)
		order := s.Context.NewOrder(param)
		s.registerCacheOrder(cacheKey, cache, order)
		err := s.Client.SendOrder(order)
		if err != nil {
			delete(s.cacheOrderMap, param.CID)
			return err
		}
		s.RecordOrderCreateAttribution(cache, &param, "close", lagDiff, s.threshold.DownExit, 0, s.EstimateOrderLiquidity(lagBBO, &param))
		s.SetStage(cache, StageClose, entry)
	}
	return nil
}

type TriggerParam struct {
	by           string
	drift        float64
	Entry        float64
	Exit         float64
	base         PricePoint
	positionSide string
	leadDiff     float64
	lagDiff      float64
	targetSpace  float64

	depthQty float64
}

func (s *Strategy) RecordTrigger(
	cache *ExecuteCache,
	ts time.Time, leadBBO *utils.BBO, lagBBO *utils.BBO,
	trigger TriggerParam,
	order *template.OrderParam,
) {
	attributionLiquidity := s.EstimateOrderLiquidity(lagBBO, order)
	rr := recorder.RawRecord{
		Tag: map[string]string{
			"type": "trigger",
			"by":   trigger.by,
			"lag":  lagBBO.GetSymbol().GetName(),
			"lead": leadBBO.GetSymbol().GetName(),
		},
		Extra: map[string]interface{}{
			"time": ts,
		},
		Field: map[string]interface{}{
			"group":      cache.groupTag,
			"entry":      trigger.Entry,
			"exit":       trigger.Exit,
			"drift":      trigger.drift,
			"lead_ask":   leadBBO.BestAskPrc,
			"lead_bid":   leadBBO.BestBidPrc,
			"lag_ask":    lagBBO.BestAskPrc,
			"lag_bid":    lagBBO.BestBidPrc,
			"position":   trigger.positionSide,
			"base_price": trigger.base.Price,
			"base_time":  time.UnixMilli(trigger.base.Time).Format("2006-01-02 15:04:05.999"),
			"cid":        order.CID,
			"side":       order.Side,
			"type":       order.OrderType,
			"price":      order.Price,
			"qty":        order.Qty,
		},
	}
	if s.lagContext.depth != nil {
		rr.Field["liq_ts"] = time.UnixMilli(s.lagContext.depth.ServerTS).Format("2006-01-02 15:04:05.999")
		if order.Side == utils.Side.Long {
			ask := s.lagContext.depth.GetBestAsk()
			if ask != nil && ask.Prc <= order.Price {
				rr.Field["liquidity"] = ask.Qty * ask.Prc
			} else {
				rr.Field["liquidity"] = 0
			}

		} else {
			bid := s.lagContext.depth.GetBestBid()
			if bid != nil && bid.Prc >= order.Price {
				rr.Field["liquidity"] = bid.Qty * bid.Prc
			} else {
				rr.Field["liquidity"] = 0
			}
		}
	} else {
		rr.Field["liq_ts"] = time.UnixMilli(lagBBO.ServerTime).Format("2006-01-02 15:04:05.999")
		if order.Side == utils.Side.Long {
			rr.Field["liquidity"] = lagBBO.BestAskPrc * lagBBO.BestAskQty
		} else {
			rr.Field["liquidity"] = lagBBO.BestBidPrc * lagBBO.BestBidQty
		}
	}
	switch trigger.by {
	case "signal":
		rr.Field["lead_diff"] = trigger.leadDiff
		rr.Field["lag_diff"] = trigger.lagDiff
		rr.Field["target_space"] = trigger.targetSpace
	}
	s.recorder.Record(&rr)
	event := AttributionEventTrigger
	reason := AttributionReasonTrigger
	signalValue := trigger.leadDiff
	threshold := trigger.Entry
	if trigger.positionSide == "close" {
		event = AttributionEventCloseDecision
		reason = AttributionReasonCloseDecision
		signalValue = trigger.lagDiff
		threshold = trigger.Exit
	}
	s.RecordAttribution(AttributionInput{
		Event:                event,
		Position:             trigger.positionSide,
		CID:                  order.CID,
		GroupID:              cache.groupTag,
		Side:                 order.Side,
		Qty:                  order.Qty,
		Price:                order.Price,
		SignalValue:          signalValue,
		Threshold:            threshold,
		Cost:                 s.ProfitBuffer() + s.config.Trigger.TargetProfitRate,
		Liquidity:            attributionLiquidity,
		DecisionReason:       reason,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
	})
}

func (s *Strategy) EstimateOrderLiquidity(lagBBO *utils.BBO, order *template.OrderParam) float64 {
	if lagBBO == nil || order == nil {
		return 0
	}
	if s.lagContext.depth != nil {
		if order.Side == utils.Side.Long {
			ask := s.lagContext.depth.GetBestAsk()
			if ask != nil && ask.Prc <= order.Price {
				return ask.Qty * ask.Prc
			}
			return 0
		}
		bid := s.lagContext.depth.GetBestBid()
		if bid != nil && bid.Prc >= order.Price {
			return bid.Qty * bid.Prc
		}
		return 0
	}
	if order.Side == utils.Side.Long {
		return lagBBO.BestAskPrc * lagBBO.BestAskQty
	}
	return lagBBO.BestBidPrc * lagBBO.BestBidQty
}

func (s *Strategy) SetStage(cache *ExecuteCache, stage ExecuteStage, entry *logrus.Entry) {
	if entry == nil {
		cache.stage = stage
	} else {
		prev := cache.stage
		cache.stage = stage
		entry.Infof("UpdateStage[%s -> %s]<position=%s>", prev, stage, cache.position)
	}
}

func (s *Strategy) LogBBO(entry *logrus.Entry, name string, bbo *utils.BBO) {
	spread := (bbo.BestAskPrc - bbo.BestBidPrc) / (bbo.BestAskPrc + bbo.BestBidPrc) * 2
	entry.Infof("%s<spread=%f%%, Ask=<%f: %f>, Bid=<%f: %f>>", name, spread*100, bbo.GetAskPrc(), bbo.GetAskQty(), bbo.GetBidPrc(), bbo.GetBidQty())
}

func (s *Strategy) NowEntry() *logrus.Entry {
	return s.log.WithTime(s.Context.Now())
}

func (s *Strategy) CalOpenQty(symbol *atom_symbol.Symbol, price float64) float64 {
	qty := s.config.Execute.OpenNotional.Div(decimal.NewFromFloat(price))
	// s.log.WithField("cv", symbol.GetContractValue()).Infof("symbol config")
	// return symbol.FormatQty(qty.InexactFloat64())
	return s.FormatQty(symbol, qty.InexactFloat64())
}

func (s *Strategy) FormatQty(symbol *atom_symbol.Symbol, rawQuantity float64) float64 {
	cv := symbol.GetContractValue()
	return math.Round(rawQuantity/symbol.RawSymbol.QuantityTick/symbol.GetContractValue()) * symbol.RawSymbol.QuantityTick * cv
}

func (s *Strategy) OnDepth(depth *utils.Depth) error {
	if depth.GetSymbol().GetExchangeName() == s.config.Lag {
		s.Context.ReturnDepthToPool(s.lagContext.depth)
		s.lagContext.depth = depth
	} else {
		s.Context.ReturnDepthToPool(depth)
	}

	return nil
}

func (s *Strategy) OnTrade(trade *utils.Trade) error {
	s.Context.ReturnTradeToPool(trade)
	return nil
}

func (s *Strategy) OnAggTrade(trade *utils.Trade) error {
	s.Context.ReturnTradeToPool(trade)
	// s.log.Infof("OnAggTrade %+v", trade)
	return nil
}

func (s *Strategy) OnOrder(msg *utils.OrderMessage) error {
	defer s.Context.ReturnOrderMessageToPool(msg)
	entry := s.NowEntry().WithField("Method", "OnOrder")
	entry.Debugf("OnOrderMsg<%+v>", msg)

	cacheKey, ok := s.cacheOrderMap[msg.ClientID]
	if !ok {
		entry.Warningf("Order not found")
		return nil
	}
	cache := s.caches[cacheKey]
	if cache == nil || cache.order == nil {
		entry.Warningf("Order cache not found")
		return nil
	}
	if msg.OrderID == cache.order.GetOID() {
	} else if msg.ClientID == cache.order.GetCID() {
		cache.order.SetOID(msg.OrderID)
	} else {
		entry.Warningf("Order mismatch")
	}

	order := cache.order
	order.SetFilledQuantity(msg.FilledQty)
	order.SetStatus(msg.Status)
	entry.Infof("OrderInstance[%s]<%s>", msg.OrderID, order)
	s.RecordOrderLifecycleAttribution(cache, order, msg)
	if cache.order.Finished() {
		cache.grouping = append(cache.grouping, cache.order)
		s.recorder.Record(&recorder.RawRecord{
			Tag: map[string]string{
				"type":   "order",
				"symbol": order.GetSymbol().GetName(),
			},
			Field: map[string]interface{}{
				"group":     cache.groupTag,
				"server_ms": msg.ServerTime,
				"local_us":  msg.LocalTime,
				"oid":       msg.OrderID,
				"cid":       msg.ClientID,
				"side":      msg.Side,
				"staus":     msg.Status,
				"price":     msg.Price,
				"avg":       msg.AvgFillPrc,
				"qty":       msg.Qty,
				"filled":    msg.FilledQty,
			},
			Extra: map[string]interface{}{
				"time": s.Context.Now(),
			},
		})
		filled := s.GetOrderFilled(order)

		if order.GetSide() == utils.Side.Long {
			cache.position = cache.position.Add(filled)
		} else {
			cache.position = cache.position.Sub(filled)
		}

		if cache.position.Equal(decimal.Zero) {
			s.SetStage(cache, StageIdle, entry)
			delete(s.caches, cacheKey)
		} else {
			if cache.stage == StageOpen {
				if msg.AvgFillPrc > 0 {
					s.SetTrackTrailing(cache, msg.AvgFillPrc)
				}
			}
			s.SetStage(cache, StageHold, entry)
		}
		cache.order = nil
		delete(s.cacheOrderMap, msg.ClientID)
	}

	return nil
}

func (s *Strategy) InitGrouping(cache *ExecuteCache) {
	cache.grouping = make([]requests.Order, 0, 2)
}

func (s *Strategy) LogStage(cache *ExecuteCache, entry *logrus.Entry) {
	entry.Infof("Stage[%s]<Hold=%s>", cache.stage, cache.position)
}

func (s *Strategy) GetOrderFilled(order requests.Order) decimal.Decimal {
	symbol := order.GetSymbol()
	tick := decimal.NewFromFloat(symbol.GetQuantityTick() * symbol.GetContractValue())
	qty := decimal.NewFromFloat(order.GetFilledQuantity())
	return qty.Div(tick).Round(0).Mul(tick)
}
