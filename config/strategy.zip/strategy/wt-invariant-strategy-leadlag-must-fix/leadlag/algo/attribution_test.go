package algo

import (
	"testing"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

type captureRecorder struct {
	records []recorder.IRecord
}

func (r *captureRecorder) Record(record recorder.IRecord) {
	r.records = append(r.records, record)
}

func TestAttributionLogDefaultsOff(t *testing.T) {
	cfg := StrategyConfig{}
	cfg.SetDefault()

	strat := cfg.New(nil)
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0)})
	rec := &captureRecorder{}
	strat.SetRecorder(rec)

	strat.RecordAttribution(AttributionInput{
		Event:          AttributionEventTrigger,
		DecisionReason: AttributionReasonTrigger,
	})

	if len(rec.records) != 0 {
		t.Fatalf("default attribution logging should be disabled, got %d records", len(rec.records))
	}
}

func TestAttributionRecordUsesComparableSchema(t *testing.T) {
	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Symbol = "eth_usdt"
	cfg.Lead = "binance"
	cfg.Lag = "gateio"
	cfg.Analysis.AttributionLog = true

	strat := cfg.New(nil)
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0)})
	rec := &captureRecorder{}
	strat.SetRecorder(rec)

	strat.RecordAttribution(AttributionInput{
		Event:                AttributionEventTrigger,
		Position:             "open",
		CID:                  "cid-1",
		GroupID:              "group-1",
		Side:                 utils.Side.Long,
		Qty:                  2,
		Price:                101.5,
		SignalValue:          0.012,
		Threshold:            0.01,
		Cost:                 0.003,
		Liquidity:            5000,
		DecisionReason:       AttributionReasonTrigger,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
	})

	if len(rec.records) != 1 {
		t.Fatalf("got %d records, want 1", len(rec.records))
	}
	fields := rec.records[0].Fields()
	assertField(t, fields, "schema_version", AttributionSchemaVersion)
	assertField(t, fields, "strategy_variant", DefaultStrategyVariant)
	assertField(t, fields, "symbol", "eth_usdt")
	assertField(t, fields, "lead", "binance")
	assertField(t, fields, "lag", "gateio")
	assertField(t, fields, "cid", "cid-1")
	assertField(t, fields, "group_id", "group-1")
	assertField(t, fields, "side", utils.Side.Long)
	assertField(t, fields, "qty", float64(2))
	assertField(t, fields, "price", 101.5)
	assertField(t, fields, "signal_value", 0.012)
	assertField(t, fields, "threshold", 0.01)
	assertField(t, fields, "cost", 0.003)
	assertField(t, fields, "liquidity", float64(5000))
	assertField(t, fields, "decision_reason", AttributionReasonTrigger)
	assertField(t, fields, "order_lifecycle_reason", AttributionLifecycleNotApplicable)
	assertField(t, fields, "filter_name", AttributionFilterNoFilter)
	assertField(t, fields, "filter_reason", AttributionReasonNotApplicable)
	if fields["timestamp_ms"] == nil || fields["date_hour"] == nil {
		t.Fatalf("expected timestamp_ms and date_hour fields, got %+v", fields)
	}
	if rec.records[0].Tags()["type"] != "attribution" {
		t.Fatalf("unexpected tag type: %+v", rec.records[0].Tags())
	}
}

func TestAttributionLifecycleReasonClassifiesExecutionOutcomes(t *testing.T) {
	tests := []struct {
		name   string
		status int
		filled float64
		qty    float64
		want   string
	}{
		{name: "partial fill", status: 20, filled: 1, qty: 3, want: AttributionLifecyclePartialFill},
		{name: "full fill", status: 40, filled: 3, qty: 3, want: AttributionLifecycleFullFill},
		{name: "zero canceled", status: 41, filled: 0, qty: 3, want: AttributionLifecycleZeroFillCanceled},
		{name: "canceled with fill", status: 41, filled: 1, qty: 3, want: AttributionLifecycleCancelOrExpireWithFill},
		{name: "zero expired", status: 45, filled: 0, qty: 3, want: AttributionLifecycleZeroFillExpired},
		{name: "expired with fill", status: 45, filled: 1, qty: 3, want: AttributionLifecycleCancelOrExpireWithFill},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := ClassifyOrderLifecycle(tt.status, tt.filled, tt.qty); got != tt.want {
				t.Fatalf("ClassifyOrderLifecycle()=%q want %q", got, tt.want)
			}
		})
	}
}

func TestAttributionOutputSuppressesRepeatedNoTriggerWithinSampleWindow(t *testing.T) {
	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Analysis.AttributionLog = true
	cfg.Analysis.AttributionOutput.SampleIntervalMs = 60_000

	ctx := &testStrategyContext{now: time.Unix(1_700_000_000, 0)}
	strat := cfg.New(nil)
	strat.SetContext(ctx)
	rec := &captureRecorder{}
	strat.SetRecorder(rec)

	for i := 0; i < 10; i++ {
		strat.RecordFilterAttribution(AttributionReasonNoTrigger, 0.001, 0.002, 0.0001, AttributionFilterNoFilter)
	}
	if len(rec.records) != 1 {
		t.Fatalf("repeated no-trigger rows within sample window=%d want 1", len(rec.records))
	}

	ctx.now = ctx.now.Add(61 * time.Second)
	strat.RecordFilterAttribution(AttributionReasonNoTrigger, 0.001, 0.002, 0.0001, AttributionFilterNoFilter)
	if len(rec.records) != 2 {
		t.Fatalf("no-trigger row after sample window=%d want 2", len(rec.records))
	}
}

func TestAttributionOutputRecordsFilterReasonChanges(t *testing.T) {
	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Analysis.AttributionLog = true
	cfg.Analysis.AttributionOutput.ReasonChangeMinIntervalMs = 60_000

	strat := cfg.New(nil)
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0)})
	rec := &captureRecorder{}
	strat.SetRecorder(rec)

	strat.RecordFilterAttribution("inventory-limit", 0.001, 0.002, 0.0001, "inventory")
	strat.RecordFilterAttribution("inventory-limit", 0.001, 0.002, 0.0001, "inventory")
	strat.RecordFilterAttribution("spread-limit", 0.001, 0.002, 0.0001, "spread")

	if len(rec.records) != 2 {
		t.Fatalf("filter reason changes should be retained, got %d records", len(rec.records))
	}
	assertField(t, rec.records[0].Fields(), "filter_reason", "inventory-limit")
	assertField(t, rec.records[1].Fields(), "filter_reason", "spread-limit")
}

func TestAttributionOutputAlwaysKeepsOrderLifecycle(t *testing.T) {
	cfg := StrategyConfig{}
	cfg.SetDefault()
	cfg.Analysis.AttributionLog = true

	strat := cfg.New(nil)
	strat.SetContext(&testStrategyContext{now: time.Unix(1_700_000_000, 0)})
	rec := &captureRecorder{}
	strat.SetRecorder(rec)

	strat.RecordAttribution(AttributionInput{
		Event:                AttributionEventOrderLifecycle,
		DecisionReason:       AttributionReasonNotApplicable,
		OrderLifecycleReason: AttributionLifecycleZeroFillExpired,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
	})
	strat.RecordAttribution(AttributionInput{
		Event:                AttributionEventOrderLifecycle,
		DecisionReason:       AttributionReasonNotApplicable,
		OrderLifecycleReason: AttributionLifecycleZeroFillExpired,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
	})

	if len(rec.records) != 2 {
		t.Fatalf("order lifecycle attribution must not be sampled away, got %d", len(rec.records))
	}
}

func assertField(t *testing.T, fields map[string]interface{}, key string, want interface{}) {
	t.Helper()
	if got := fields[key]; got != want {
		t.Fatalf("field %s=%#v want %#v in %+v", key, got, want, fields)
	}
}
