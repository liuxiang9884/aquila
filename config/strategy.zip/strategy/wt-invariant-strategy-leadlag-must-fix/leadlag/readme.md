
# Lead-Lag strategy (invariant-strategy/leadlag)

This folder contains the lead-lag strategy backtest tools.

## Code structure (quick overview)

Most of the runnable tooling lives under [leadlag/backtest](leadlag/backtest):

- [Go backtest entrypoint](leadlag/backtest/main.go)
	- Runs the simulation/backtest given a strategy config and a backtest config.
	- Produces logs (via `LOG_DIR` and `LOG_FILE` environment variables) which are later analyzed.

- [Python optimizer](leadlag/backtest/optimize.py)
	- Sweeps different latency parameter combinations.
	- For each combination:
		1) runs the Go backtest
		2) runs [leadlag/backtest/order.py](leadlag/backtest/order.py) to compute metrics
		3) writes JSON + CSV summaries under an output directory.

- Analysis / helpers
	- [leadlag/backtest/order.py](leadlag/backtest/order.py): parse backtest log and output performance summary
	- [leadlag/backtest/analysis.py](leadlag/backtest/analysis.py): analysis helpers
	- [leadlag/backtest/trace.py](leadlag/backtest/trace.py): trace/debug helpers
	- [leadlag/backtest/QUOTING_LOGIC.md](leadlag/backtest/QUOTING_LOGIC.md): quoting logic notes

## Strategy core algorithm (`leadlag/algo`)

The core strategy logic lives in [leadlag/algo](leadlag/algo). This is where the lead-lag signal is computed and translated into trading decisions (open/close conditions, sizing, and state transitions). The backtest entrypoint wires market data + execution simulation to this algorithm.

Key files:

- [leadlag/algo/strategy.go](leadlag/algo/strategy.go): main strategy loop/state and decision making
- [leadlag/algo/move.go](leadlag/algo/move.go): price move / lead-lag signal modeling
- [leadlag/algo/execute_cache.go](leadlag/algo/execute_cache.go): caching/execution bookkeeping for faster runs
- [leadlag/algo/analysis.go](leadlag/algo/analysis.go): metrics/statistics helpers used by the algorithm

## Config files (strategy / backtest / optimization)

This strategy uses JSON config files.

In this repo, config files are often kept local-only (not synced to git). For that reason, this README does not rely on any `leadlag/config/...` paths; pass whatever local JSON paths you use via CLI flags.

### Strategy config

Minimal example (template):

```json
{
	"trigger": {
		"lead": 0.0025,
		"open": 0.0020,
		"close": 0.0005,
		"lag_part": 0.5,
		"drift_period": "1m"
	},
	"execute": {
		"open": "100",
		"trailing_stop": 0.001
	},
	"bbo_record": {
		"window": "1s",
		"stats_window": "30s",
		"size": 100
	}
}
```

For a runnable backtest you usually also set these top-level fields:

- `symbol`: e.g. `river_usdt`
- `lead`: e.g. `binance`
- `lag`: e.g. `bybit`

### Backtest config

Key parts:

- `group.hourly.root`: points to the hourly data root directory (often `raw_data_hourly`)
- `group.hourly.range`: start/end “hour folder” range, e.g. `2026010800` to `2026010809`
- `global`: simulation/global parameters (tick interval, depth mode, etc.)
- `latencies`: per-exchange latency settings (this is what the optimizer overwrites)

Minimal example:

```json
{
	"group": {
		"hourly": {
			"data": {},
			"root": "/path/to/raw_data_hourly",
			"range": ["2026010800", "2026010809"],
			"Memory": "128M"
		}
	},
	"global": {
		"tick_ms": 10,
		"sizes": [1],
		"depth_mode": "tick",
		"raw_bbo": true,
		"market_reduce_split": 0.5
	},
	"latencies": {
		"binance": {
			"req": {"type": "fixed", "fixed": 30, "real": false},
			"resp": {"type": "fixed", "fixed": 30, "real": false},
			"public": {"type": "fixed", "fixed": 35, "real": false}
		},
		"bybit": {
			"req": {"type": "fixed", "fixed": 2, "real": false},
			"resp": {"type": "fixed", "fixed": 1, "real": false},
			"public": {"type": "fixed", "fixed": 2, "real": false}
		}
	}
}
```

### Optimization config (latency search space)

This file defines the search space as two lists:

- `lead_latencies`: list of partial latency objects to test on the lead exchange
- `lag_latencies`: list of partial latency objects to test on the lag exchange

The optimizer takes the Cartesian product of `lead_latencies × lag_latencies`.

Example:

```json
{
	"description": "Latency optimization search space",
	"lead_latencies": [
		{"public": 30},
		{"public": 33},
		{"public": 35}
	],
	"lag_latencies": [
		{"req": 2, "resp": 1, "public": 2}
	]
}
```

## Run a backtest

Entrypoint: [leadlag/backtest/main.go](leadlag/backtest/main.go)

From the repo root (`invariant-strategy`):

```bash
cd invariant-strategy

# optional: where the backtest writes its log
export LOG_DIR=./logs
export LOG_FILE=leadlag_backtest.log

go run leadlag/backtest/main.go -s <strategy_config.json> -b <backtest_config.json>
```

Output:

- Backtest log file: `./logs/leadlag_backtest.log` (or your chosen `LOG_DIR`/`LOG_FILE`)

## Run optimization (latency sweep)

Entrypoint: [leadlag/backtest/optimize.py](leadlag/backtest/optimize.py)

`optimize.py` repeatedly runs the Go backtest and then calls `order.py` to produce metrics.

From the repo root (`invariant-strategy`):

```bash
cd invariant-strategy

# Single optimization
python3 leadlag/backtest/optimize.py \
	-s <strategy_config.json> \
	-b <backtest_config.json> \
	-o <optimization_config.json>
```

Common options:

- `--output-dir <dir>`: where to store optimization results (default: `results/optimization`)
- `-q/--quiet`: suppress Go backtest stdout (backtest stderr is still captured on failure)

Batch mode (multiple symbols/pairs from a group file):

```bash
cd invariant-strategy

python3 leadlag/backtest/optimize.py \
	-g <group_file.json> \
	-s <strategy_template.json> \
	-b <backtest_template.json> \
	-o <optimization_config.json> \
	--processes 4
```

## Generate group file for batch optimization (`searcher.py`)

The batch optimizer expects a “group file” JSON (the `-g/--group` argument). This file is usually produced by [scripts/searcher.py](scripts/searcher.py), which scans your hourly data folders and finds symbols that exist on multiple exchanges over a time range.

What it does:

- Scans `<root>/<YYYYMMDDHH>/` folders for files named like `<exchange>.<symbol>_<YYYYMMDDHH>.h5`
- Finds symbols that have data on at least 2 exchanges for the same hour
- Outputs a JSON with `results` mapping symbols to exchange pairs and date ranges (this is what `optimize.py` consumes)

Common usage:

```bash
cd invariant-strategy

# Generate a group file for binance vs bybit over an hour range
python3 scripts/searcher.py \
	-d 2026010800,2026010809 \
	-e binance,bybit \
	-r /path/to/raw_data_hourly \
	-j \
	-o group_file.json
```

Useful flags:

- `-d/--dates`: single hour (`YYYYMMDDHH`) or range (`start,end`)
- `-e/--exchanges`: comma-separated exchanges to consider
- `-r/--root`: root directory containing hour folders (defaults to `$REMOTE_DATA_DIR` or `.`)
- `--regex`: optional regex to filter filenames (e.g. only `*_swap_*.h5`)
- `-c/--copy`: optionally copy matched files to a local dir and rewrite paths in output

Then run batch optimization using the generated group file:

```bash
cd invariant-strategy

python3 leadlag/backtest/optimize.py \
	-g group_file.json \
	-s <strategy_template.json> \
	-b <backtest_template.json> \
	-o <optimization_config.json> \
	--processes 4
```

## Copy hourly data locally (`copier.sh`)

If your hourly `.h5` data lives on an external/remote mount, you can copy a subset of hours and symbols into a local directory (so backtests run on local disk).

Script: [scripts/copier.sh](scripts/copier.sh)

What it does:

- Reads a single hour (`YYYYMMDDHH`) or an hour range (`start,end`)
- Copies files matching one or more glob patterns (comma-separated)
- Writes into `<output_base>/<YYYYMMDDHH>/...` (it will prompt you to confirm the output directory before copying)

Example:

```bash
cd invariant-strategy

# Will prompt for output base directory (default: current directory)
bash scripts/copier.sh 2026010800,2026010809 "bybit.eth_usdt*,binance.*"
```

Environment variables:

- `REMOTE_DATA_DIR`: source root (default in script: `/Volumes/hf_data/raw_data_hourly`)
- `OUTPUT_DIR`: output base directory (if set, skips the output-dir prompt; still asks for y/yes confirmation)

Merge summaries:

```bash
cd invariant-strategy

python3 leadlag/backtest/optimize.py merge \
	--results-dir results/optimization \
	--output merged_summary.csv
```

