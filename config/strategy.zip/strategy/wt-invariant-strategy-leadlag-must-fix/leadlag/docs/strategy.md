# Lead-Lag Strategy: Architecture, Config & Behaviour

## Architecture

- **Alignment phase**: `Bootstrap → Aligning → Active` before any trade-slot state machine is allowed to react
- **State machine**: `Idle → Open → Hold → Close → Idle` per trade slot (`ExecuteCache`)
- **Parallelism**: up to `execute.parallel` slots open simultaneously, each independent
- **Drift correction**: lead prices scaled by rolling `lag_mid / lead_mid` only after alignment reaches `Active`
- **Adaptive thresholds**: entry/exit levels recomputed every `bbo_record.stats_window` from live move distribution and drift std once alignment is active; `trigger.lead` / `trigger.close` are seeds only
- **All orders**: IOC limit on the lag exchange; trailing stoploss uses aggressive IOC limit (`±0.5%` beyond BBO)

---

## Config Fields

### `StrategyConfig` (top-level)

| Field | Type | Description |
|---|---|---|
| `symbol` | string | Trading pair (e.g. `eth_usdt`) |
| `lead` | string | Lead exchange name (e.g. `binance`) |
| `lag` | string | Lag exchange name (e.g. `bybit`) |
| `trigger` | TriggerConfig | Signal detection thresholds |
| `execute` | ExecutionConfig | Order sizing & risk params |
| `bbo_record` | BBORecord | Market data observation windows |

---

### `BBORecord` — init-time only

All fields are consumed once in `SetContext` to size internal recorders. Changing them has no effect after startup.

| Field | Default | Used to initialize |
|---|---|---|
| `window` | `5s` | `BBOVolRecorder` window for both lead and lag — the rolling lookback for min/max bid/ask prices. Also the inner std window of `volema` (volatility normaliser). |
| `stats_window` | `5s` | `MoveQueue` roll period (how often the move distribution is flushed and quantiles computed). Also the EMA period of `volema`, the lag spread tracker window, and the drift std EMA window. |
| `size` | `100` | Buffer capacity for all internal queues. |

---

### `TriggerConfig`

| Field | Default | Lifecycle | Description |
|---|---|---|---|
| `lead` | — | **Init seed only** | Seeds `threshold.UpEntry = lead` and `threshold.DownEntry = -lead`. Overridden after the first `stats_window` roll by the adaptive quantile calculation. Only active during the very first window. |
| `open` | — | **Unused** | Defined in struct but never referenced in any logic. |
| `close` | — | **Init seed only** | Seeds `threshold.UpExit = close` and `threshold.DownExit = -close`. Overridden each roll by the drift std EMA. Only active during the very first window. |
| `lag_part` | `0.5` | **Runtime** | Checked on every entry attempt: `(lead_move - lag_move) / lead_move > lag_part`. Ensures lead is still ahead of lag at the moment of entry. |
| `lead_part` | `1.0` | **Unused** | Defined in struct but never referenced in entry/exit logic. |
| `quantile.move` | `0.99` | **Runtime (per roll)** | Percentile applied to the move distribution at each `stats_window` boundary to compute the adaptive entry threshold. |
| `target_profit_rate` | `0` | **Runtime** | Minimum additional profit headroom required above the unified entry cost model. It stays separate from the base cost budget and is added after the cost model is built. |
| `drift_limit` | `0.02` | **Runtime** | Checked on lead BBO ticks only after alignment is `Active`. If `abs(drift - 1) > drift_limit` (basis > 2%), only new entries are blocked. Recorder updates, threshold rolls, and existing-position handling continue normally. |
| `drift_period` | `1h` | **Init only** | Sets the rolling window of the `lagContext.drift` StreamRecorder — the long-term tracker of `lag_mid / lead_mid`. Determines how slowly the drift mean responds to basis changes. |
| `drift_min_samples` | `20` | **Runtime gate** | Minimum number of paired drift samples required before the strategy is allowed to leave the alignment phase and start comparing lead-vs-lag signals. |
| `drift_warmup` | `stats_window` when unset | **Runtime gate** | Minimum paired elapsed time required before activation. If omitted, the strategy uses `bbo_record.stats_window` as the warm-up duration. |

---

### `ExecutionConfig`

| Field | Default | Lifecycle | Description |
|---|---|---|---|
| `open` | `1000` | **Runtime** | Notional size per trade. Used in `CalOpenQty` on every order. |
| `trailing_stop` | `0.001` | **Runtime** | Stoploss trigger only — closes position when price retraces `trailing_stop` from the peak/trough. |
| `max_entry_spread` | `-1` | **Runtime** | Entry spread cap only — entry is skipped if current lag spread exceeds this value. Negative values keep backward compatibility and fall back to `trailing_stop`. |
| `parallel` | `1` | **Runtime** | Max concurrent open positions. Checked on every lead BBO tick before any new entry. |

> Backward compatibility: older configs that do not set `max_entry_spread` use `trailing_stop` as the entry spread cap.

---

## Entry Cost Model

The open decision now uses a single helper to build the required entry edge. The helper keeps the remaining explicit costs on the same percentage basis as the strategy's `target_space` calculation.

`target_space` already absorbs the current spread and `LagSpreadBuffer` because it is measured against the lag ask and subtracts the lag-side price buffer before division. Those two items are therefore tracked as diagnostics, not counted again in `required_edge`.

`required_edge = round-trip lag taker fee + lead noise + lag noise`

Where:
- **Round-trip lag taker fee**: `lag taker fee × 2`
- **Lead noise**: the lead side volatility EMA
- **Lag noise**: the lag side volatility EMA

`Spread` and `LagSpreadBuffer` stay in the breakdown for logging and diagnostics, but they are already counted once inside `target_space`.

`target_profit_rate` is added after this base cost budget. It remains a separate "extra profit request" and does not get merged into the base cost terms.

The strategy logs the breakdown as `EntryCost<...>` when an order is submitted.

---

## Strategy Behaviour

### Data Flow

`OnRawBBO` is now alignment-first:
- It always updates the raw lead / raw lag snapshot first.
- Once both sides are valid, it updates the drift recorder on every non-duplicate paired tick.
- It dispatches into trading logic only after the alignment phase reaches `Active`.

Ticks with unchanged bid/ask are skipped.

### Drift Correction

On every lead or lag BBO change after both raw sides exist, `UpdateDrift` records `lag_mid / lead_mid` into `lagContext.drift` (a `StreamRecorder` with a `drift_period` window). The rolling mean of this ratio is the **drift factor**.

Before any move comparison or entry check, lead prices are scaled by drift:
```
drifted_lead_bid = lead_bid × drift_mean
drifted_lead_ask = lead_ask × drift_mean
```

This normalises persistent basis between exchanges (e.g. funding-driven perp premium).

### Alignment Phases

The strategy keeps alignment and trading as separate layers:

- **Bootstrap**: at least one side of the raw BBO pair is still missing.
- **Aligning**: both raw BBOs exist and drift statistics are accumulating, but activation gates are not satisfied yet.
- **Active**: drift alignment is considered stable enough; move/threshold/open/close logic is enabled.

`alignmentReady` is defined as:

1. Raw lead BBO is valid.
2. Raw lag BBO is valid.
3. `driftSampleCount >= drift_min_samples`.
4. `now - firstPairedDriftTs >= drift_warmup` (or `stats_window` when `drift_warmup` is unset).

Before `Active`, the strategy is intentionally restricted to:

- updating raw lead / raw lag latest state
- updating drift statistics
- keeping the latest lag BBO / depth snapshot

Before `Active`, the strategy does **not**:

- push into `MoveQueue`
- roll thresholds
- call `OpenLong` / `OpenShort`
- call `CloseLong` / `CloseShort`

When the phase first flips to `Active`, the trading-side recorders are re-seeded from the latest aligned/raw snapshots and the activation tick itself does not trade. Trading resumes from the next qualifying lead tick. This keeps future position-recovery work open without letting pre-alignment samples leak into signal logic.

### Adaptive Thresholds (reset every `stats_window`)

On each lead BBO tick after alignment is `Active`, `UpdateMoveThreshold` checks if the `MoveQueue` window has elapsed. When it has:

1. Capture `LeadNoise` = `volema.GetStdEma()` (normalised price volatility EMA)
2. Compute `profitBuffer = lag_taker_fee × 2 + LeadNoise + LagNoise`
3. Extract `up` (99th pct) and `down` (1st pct) from the move distribution
4. Set `exit = DriftStdEma.GetMean()` (rolling mean of drift standard deviation)
5. Update thresholds:
   - If `up - exit > profitBuffer`: `UpEntry = up`, `UpExit = exit`
   - Otherwise: `UpEntry = exit + profitBuffer`, `UpExit = exit`
   - Symmetric for downside

Then the queue is flushed and a new window begins. The `trigger.lead` / `trigger.close` seeds are replaced permanently after the first roll.

This rolling buffer represents the explicit, non-embedded costs only. Current spread and `LagSpreadBuffer` are already embedded in the later `target_space` calculation, so they do not appear here again.

### Entry Conditions

All must hold at the moment of the lead BBO tick:

**Long entry (`OpenLong`)**:
1. Lead bid moved up `≥ UpEntry` from the window min, AND lead ask moved up `≥ UpEntry`
2. Lead bid is above lag ask (positive price diff)
3. `(lead_move - lag_move) / lead_move > lag_part` — lag hasn't caught up
4. `target_space > required_edge + target_profit_rate` — sufficient profit headroom after the unified cost model; current spread and `LagSpreadBuffer` are already embedded in `target_space`
5. Lag spread < `max_entry_spread` (falls back to `trailing_stop` when unset) — lag not too wide at entry
6. `|drift - 1| ≤ drift_limit` — basis within bounds
7. `len(active_positions) < parallel`

**Short entry (`OpenShort`)**: symmetric on the downside using ask/bid roles swapped.

Order type: **IOC limit** at lag ask (long) or lag bid (short).

### Position Management (StageHold)

**On lag BBO tick:**
1. Update trailing reference price (track highest bid for long, lowest ask for short).
2. **Trailing stoploss**: if price retraces `trailing_stop` from the peak, send an aggressive IOC limit close (`bid × 0.995` for long, `ask × 1.005` for short) and move to `StageClose`.
3. **Signal close**: if the lead-lag spread has collapsed below the exit threshold, send IOC close.

**On lead BBO tick:**
- Signal close is also evaluated using drift-adjusted lead prices vs current lag BBO.
- Close is attempted before any new entry attempt.

A pending order (`cache.order != nil`) blocks further close signals for that position until it resolves.

### State Machine

```
Idle ──(entry signal)──► Open ──(order fill)──► Hold ──(exit signal / trailing stop)──► Close ──► Idle
```

Each trade lives in an `ExecuteCache` keyed by order CID. Multiple caches coexist up to `parallel`.

### Taker Fees (hardcoded)

| Exchange | Taker Fee |
|---|---|
| `gateio` | 0.016% |
| `bybit` | 0.015% |

Binance is not in the table — when used as lag exchange its fee defaults to 0, which inflates estimated profit buffer.
