# Debugging & Diagnostics

## Backtest Log

The backtest writes JSON-formatted logs via `JsonLog` in `backtest/main.go`.

**Environment variables:**
- `LOG_DIR` — output directory (default: `.`)
- `LOG_FILE` — filename (default: `backtest.log`)
- `ENVFILE` — path to `.env` for additional config (default: `.env`)

Each line is a JSON object with fields: `ts`, `level`, `msg`, `order`, `trigger`, etc.

## Parsing Logs

Extract metrics from a log file directly:
```bash
conda run -n base python3 leadlag/backtest/order.py <backtest.log> --output metrics.json
```

## Visual Trade Trace

Plot trade sequences:
```bash
conda run -n base python3 leadlag/backtest/trace.py <backtest.log> --output trace.html
```

## Verbose Logging

Set `log.Level = logrus.DebugLevel` in `backtest/main.go` to emit detailed per-tick logs.

## Performance Profiling

A `cpu.prof` may be generated during backtest (check `backtest/main.go` for pprof setup):
```bash
go tool pprof cpu.prof
```
