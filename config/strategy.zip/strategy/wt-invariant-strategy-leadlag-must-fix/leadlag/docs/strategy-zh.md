# 策略配置说明

## 架构概览

- **对齐阶段**：交易逻辑外层新增 `Bootstrap → Aligning → Active` 三阶段。
- **交易状态机**：每个 `ExecuteCache` 仍然遵循 `Idle → Open → Hold → Close → Idle`。
- **长期漂移修正**：只有在对齐阶段进入 `Active` 后，才允许用 `lag_mid / lead_mid` 的滚动均值去缩放 lead 价格。
- **自适应阈值**：只有在 `Active` 阶段，`MoveQueue` / 阈值滚动 / recorder 噪声统计才会推进；`trigger.lead` / `trigger.close` 仍然只是初始种子。
- **所有订单**：继续使用 lag 侧 IOC 限价单；trailing stoploss 继续走更激进的 IOC 价格。

## 顶层配置 `StrategyConfig`

| 字段 | 类型 | 说明 |
|---|---|---|
| `symbol` | string | 交易对，如 `eth_usdt` |
| `lead` | string | 领先交易所名称，如 `binance` |
| `lag` | string | 滞后交易所名称，如 `bybit` |
| `trigger` | TriggerConfig | 信号检测参数 |
| `execute` | ExecutionConfig | 下单与风控参数 |
| `bbo_record` | BBORecord | 市场数据观测窗口 |

---

## `BBORecord` — 仅初始化时生效

所有字段在 `SetContext` 中一次性消费，用于初始化内部记录器，运行中不可更改。

| 字段 | 默认值 | 作用 |
|---|---|---|
| `window` | `5s` | 领先/滞后两侧 `BBOVolRecorder` 的滚动窗口，决定计算移动幅度时参考的最值（min/max bid/ask）回溯范围；同时作为波动率归一化器 `volema` 的内层标准差窗口。 |
| `stats_window` | `5s` | `MoveQueue` 的滚动周期（每隔多久清空移动分布并重新计算分位数）；同时用于 `volema` 的 EMA 周期、滞后价差追踪窗口、漂移标准差 EMA 窗口。 |
| `size` | `100` | 所有内部队列的容量上限。 |

---

## `TriggerConfig` — 信号触发参数

| 字段 | 默认值 | 生命周期 | 说明 |
|---|---|---|---|
| `lead` | — | **仅初始化种子** | 初始化 `threshold.UpEntry = lead`、`threshold.DownEntry = -lead`。第一个 `stats_window` 结束后即被自适应分位数覆盖，仅在最初一个窗口内有效。 |
| `open` | — | **未使用** | 结构体中定义，但代码中从未引用。 |
| `close` | — | **仅初始化种子** | 初始化 `threshold.UpExit = close`、`threshold.DownExit = -close`。每次滚动后被漂移标准差 EMA 覆盖，仅在最初一个窗口内有效。 |
| `lag_part` | `0.5` | **运行时** | 每次尝试开仓时检查：`(lead_move - lag_move) / lead_move > lag_part`，确保领先交易所在开仓时仍领先于滞后交易所。 |
| `lead_part` | `1.0` | **未使用** | 结构体中定义，但未在开仓/平仓逻辑中引用。 |
| `quantile.move` | `0.99` | **运行时（每次滚动）** | 每个 `stats_window` 结束时，从移动分布中提取该分位数作为自适应开仓阈值。 |
| `target_profit_rate` | `0` | **运行时** | 开仓前额外要求的利润空间。它不会并入基础成本项，而是在统一成本模型算出后再单独加上。 |
| `drift_limit` | `0.02` | **运行时** | 只在对齐阶段进入 `Active` 之后的领先 BBO tick 上检查。若 `|drift均值 - 1| > drift_limit`（基差超过 2%），只阻止新开仓；recorder、阈值滚动和已有持仓处理继续进行。 |
| `drift_period` | `1h` | **仅初始化** | 设置 `lagContext.drift`（`StreamRecorder`）的滚动窗口——追踪 `lag_mid / lead_mid` 比值的长期均值。窗口越长，漂移均值越平滑、对基差变化越迟钝。与 `drift_limit` 共同作用：前者决定均值如何计算，后者决定容忍上限。 |
| `drift_min_samples` | `20` | **运行时门控** | 至少积累这么多条 paired drift 样本之后，策略才允许离开对齐阶段并开始做 lead-lag 信号比较。 |
| `drift_warmup` | 未设置时回退到 `stats_window` | **运行时门控** | 至少经过这么长的 paired 对齐时间之后，策略才允许进入 `Active`。若未配置，则默认使用 `bbo_record.stats_window`。 |

> **`drift_period` 与 `drift_limit` 的关系**：两者作用于同一个值。`drift_period` 控制漂移均值的平滑程度，`drift_limit` 是对该均值的门控阈值。

---

## `ExecutionConfig` — 执行参数

| 字段 | 默认值 | 生命周期 | 说明 |
|---|---|---|---|
| `open` | `1000` | **运行时** | 每笔交易的名义金额，每次下单时通过 `CalOpenQty` 转换为数量。 |
| `trailing_stop` | `0.001` | **运行时** | 仅用于止损触发——价格从最高/最低点回撤超过该比例时平仓。 |
| `max_entry_spread` | `-1` | **运行时** | 仅用于开仓价差上限——若滞后交易所当前价差超过该值则放弃开仓。负值表示兼容旧配置，开仓过滤回退到 `trailing_stop`。 |
| `parallel` | `1` | **运行时** | 最大同时持仓数量，每个领先 BBO tick 开仓前检查。 |

> 向后兼容：旧配置如果未显式提供 `max_entry_spread`，运行时会用 `trailing_stop` 作为开仓价差上限。

---

## 开仓成本模型

开仓判断现在由统一 helper 计算所需门槛。helper 只保留 `target_space` 没有自动吸收的那部分成本，所有 explicit 成本项都放在同一比例单位上。

`target_space` 已经通过 `lag ask` 作为分母，并在 `targetPrice` 里减掉了 `LagSpreadBuffer`，因此“当前 spread”和 `LagSpreadBuffer` 这两项已经在 `target_space` 里记过一次，不会再进入 `required_edge`。

`required_edge = lag 双边手续费 + lead noise + lag noise`

其中：
- **lag 双边手续费**：`lag taker fee × 2`
- **lead noise**：领先侧波动率 EMA
- **lag noise**：滞后侧波动率 EMA

`Spread` 和 `LagSpreadBuffer` 会继续保留在 breakdown 里做日志和诊断，但它们已经只在 `target_space` 中出现一次。

`target_profit_rate` 仍然是单独的“额外利润要求”，只在基础成本预算算完后再加上，不会和基础成本项混在一起。

策略在提交订单时会记录 `EntryCost<...>` 分项日志。

---

## 对齐优先语义

`OnRawBBO` 现在先做“原始状态 + 对齐状态”更新，再决定是否进入交易逻辑：

1. 先更新 raw lead / raw lag 最新 BBO。
2. 当两边 raw BBO 都有效后，每个非重复 tick 都更新一次 drift 统计。
3. 只有对齐阶段到达 `Active`，才会继续进入 `OnLeadBBO` / `OnLagBBO`。

### 三个阶段

- **Bootstrap**：lead / lag 原始 BBO 还没收齐。
- **Aligning**：两边原始 BBO 已到齐，但 drift 统计还没满足激活门槛。
- **Active**：对齐完成，可以开始做 lead-lag 比较与交易决策。

### `alignmentReady` 判定条件

1. raw lead BBO 有效。
2. raw lag BBO 有效。
3. `driftSampleCount >= drift_min_samples`。
4. `now - firstPairedDriftTs >= drift_warmup`；若 `drift_warmup` 未配置，则使用 `stats_window`。

### 未对齐阶段允许与禁止的事情

`alignmentReady == false` 时允许：

- 更新 raw lead / raw lag 最新状态
- 更新 drift 统计
- 更新最新的 lag BBO / depth 持有状态

`alignmentReady == false` 时禁止：

- `MoveQueue.Push`
- 阈值滚动
- `OpenLong` / `OpenShort`
- `CloseLong` / `CloseShort`

首次进入 `Active` 时，策略会用最新的已对齐/raw 快照重新播种交易侧 recorder，并且“激活当下这笔 tick”本身不做交易；真正恢复交易逻辑从下一笔符合条件的 lead tick 开始。这样既防止未对齐样本污染，也给未来的持仓恢复逻辑留出清晰扩展点。

---

## 自适应阈值更新逻辑（每 `stats_window` 滚动一次）

每次在 `Active` 阶段的 lead tick 上，当 `MoveQueue` 到期时重新计算开仓/平仓阈值：

1. 取 `LeadNoise = volema.GetStdEma()`（归一化波动率 EMA）
2. 计算 `profitBuffer = 滞后手续费 × 2 + LeadNoise + LagNoise`
3. 从移动分布中提取 `up`（第99百分位）和 `down`（第1百分位）
4. 取 `exit = DriftStdEma.GetMean()`（漂移标准差的滚动均值）
5. 更新阈值：
   - 若 `up - exit > profitBuffer`：`UpEntry = up`，`UpExit = exit`
   - 否则：`UpEntry = exit + profitBuffer`，`UpExit = exit`
   - 下行方向对称处理

`trigger.lead` / `trigger.close` 仅作为第一个窗口的种子，之后永久被覆盖。

这个滚动 buffer 只代表未被 `targetSpace` 吸收的显式成本。当前 spread 和 `LagSpreadBuffer` 已经在后面的 `targetSpace` 计算中记账一次，因此不会在这里再重复出现。

---

## 手续费（硬编码）

| 交易所 | Taker 手续费 |
|---|---|
| `gateio` | 0.016% |
| `bybit` | 0.015% |

> Binance 不在表中，作为滞后交易所时手续费默认为 0，会导致 `profitBuffer` 估算偏低。
