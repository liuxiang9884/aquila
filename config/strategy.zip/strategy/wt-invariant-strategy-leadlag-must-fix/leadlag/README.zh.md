# Lead-Lag 策略（invariant-strategy/leadlag）

本目录包含 Lead-Lag 策略的回测与优化工具。

## 代码结构（快速概览）

大部分可直接运行的工具都在 [leadlag/backtest](leadlag/backtest)：

- [Go 回测入口](leadlag/backtest/main.go)
	- 根据策略配置与回测配置运行模拟回测。
	- 通过环境变量 `LOG_DIR` 与 `LOG_FILE` 生成日志，后续用于分析。

- [Python 优化器](leadlag/backtest/optimize.py)
	- 扫描不同的延迟参数组合（latency sweep）。
	- 每个组合会：
		1) 运行 Go 回测
		2) 运行 [leadlag/backtest/order.py](leadlag/backtest/order.py) 计算指标
		3) 将结果输出为 JSON + CSV（写入到输出目录）

- 分析 / 辅助工具
	- [leadlag/backtest/order.py](leadlag/backtest/order.py)：解析回测日志并输出性能汇总
	- [leadlag/backtest/analysis.py](leadlag/backtest/analysis.py)：分析辅助
	- [leadlag/backtest/trace.py](leadlag/backtest/trace.py)：调试/追踪辅助
	- [leadlag/backtest/QUOTING_LOGIC.md](leadlag/backtest/QUOTING_LOGIC.md)：报价逻辑说明

## 策略核心算法（`leadlag/algo`）

策略的核心逻辑在 [leadlag/algo](leadlag/algo)。这里负责计算 lead-lag 信号，并将其转换为交易决策（开/平条件、仓位/下单量、状态机流转等）。回测入口会把行情数据与撮合/执行模拟“接”到这套算法上。

关键文件：

- [leadlag/algo/strategy.go](leadlag/algo/strategy.go)：策略主循环/状态与决策逻辑
- [leadlag/algo/move.go](leadlag/algo/move.go)：价格变动与 lead-lag 信号建模
- [leadlag/algo/execute_cache.go](leadlag/algo/execute_cache.go)：执行/缓存相关，加速运行
- [leadlag/algo/analysis.go](leadlag/algo/analysis.go)：算法使用的统计/指标辅助

## 配置文件（strategy / backtest / optimization）

本策略使用 JSON 配置文件。

在这个仓库中，配置文件通常是本地维护（不一定会同步到 git）。因此本文档不会依赖任何 `leadlag/config/...` 的固定路径；请在命令行参数中传入你本地的 JSON 文件路径。

### Strategy 配置（策略参数）

最小示例（模板）：

```json
{
	"trigger": {
		"lead": 0.0025,
		"open": 0.0020,
		"close": 0.0005,
		"lag_part": 0.5,
		"drift_period": "1m"
	},
	"execute": {
		"open": "100",
		"trailing_stop": 0.001
	},
	"bbo_record": {
		"window": "1s",
		"stats_window": "30s",
		"size": 100
	}
}
```

为了能直接跑回测，通常还需要补充这些顶层字段：

- `symbol`：例如 `river_usdt`
- `lead`：例如 `binance`
- `lag`：例如 `bybit`

### Backtest 配置（回测运行参数）

关键字段：

- `group.hourly.root`：小时数据根目录（通常是 `raw_data_hourly`）
- `group.hourly.range`：小时目录范围，例如 `2026010800` 到 `2026010809`
- `global`：全局仿真参数（tick 间隔、盘口模式等）
- `latencies`：按交易所配置延迟（优化器会覆盖/替换这里的值）

最小示例：

```json
{
	"group": {
		"hourly": {
			"data": {},
			"root": "/path/to/raw_data_hourly",
			"range": ["2026010800", "2026010809"],
			"Memory": "128M"
		}
	},
	"global": {
		"tick_ms": 10,
		"sizes": [1],
		"depth_mode": "tick",
		"raw_bbo": true,
		"market_reduce_split": 0.5
	},
	"latencies": {
		"binance": {
			"req": {"type": "fixed", "fixed": 30, "real": false},
			"resp": {"type": "fixed", "fixed": 30, "real": false},
			"public": {"type": "fixed", "fixed": 35, "real": false}
		},
		"bybit": {
			"req": {"type": "fixed", "fixed": 2, "real": false},
			"resp": {"type": "fixed", "fixed": 1, "real": false},
			"public": {"type": "fixed", "fixed": 2, "real": false}
		}
	}
}
```

### Optimization 配置（延迟搜索空间）

该文件通过两个列表定义搜索空间：

- `lead_latencies`：lead 交易所要测试的延迟配置列表（可只写部分字段）
- `lag_latencies`：lag 交易所要测试的延迟配置列表（可只写部分字段）

优化器会对 `lead_latencies × lag_latencies` 做笛卡尔积组合测试。

示例：

```json
{
	"description": "Latency optimization search space",
	"lead_latencies": [
		{"public": 30},
		{"public": 33},
		{"public": 35}
	],
	"lag_latencies": [
		{"req": 2, "resp": 1, "public": 2}
	]
}
```

## 运行回测

入口：[leadlag/backtest/main.go](leadlag/backtest/main.go)

在仓库根目录（`invariant-strategy`）执行：

```bash
cd invariant-strategy

# 可选：回测日志输出位置
export LOG_DIR=./logs
export LOG_FILE=leadlag_backtest.log

go run leadlag/backtest/main.go -s <strategy_config.json> -b <backtest_config.json>
```

输出：

- 回测日志：`./logs/leadlag_backtest.log`（或你设置的 `LOG_DIR`/`LOG_FILE`）

## 运行优化（延迟扫描）

入口：[leadlag/backtest/optimize.py](leadlag/backtest/optimize.py)

`optimize.py` 会循环运行 Go 回测，并调用 `order.py` 产出指标。

在仓库根目录（`invariant-strategy`）执行：

```bash
cd invariant-strategy

# 单次优化
python3 leadlag/backtest/optimize.py \
	-s <strategy_config.json> \
	-b <backtest_config.json> \
	-o <optimization_config.json>
```

常用参数：

- `--output-dir <dir>`：优化结果输出目录（默认：`results/optimization`）
- `-q/--quiet`：减少 Go 回测 stdout 输出（失败时仍会捕获并输出 stderr）

批量模式（从 group file 中读取多个标的/交易所组合）：

```bash
cd invariant-strategy

python3 leadlag/backtest/optimize.py \
	-g <group_file.json> \
	-s <strategy_template.json> \
	-b <backtest_template.json> \
	-o <optimization_config.json> \
	--processes 4
```

## 生成批量优化用的 group file（`searcher.py`）

批量优化需要一个 “group file” JSON（即 `optimize.py` 的 `-g/--group` 参数）。这个文件通常由脚本 [scripts/searcher.py](scripts/searcher.py) 生成：它会扫描你的小时数据目录，找出在多个交易所同时存在数据的 symbol，并输出给优化器使用。

脚本行为：

- 扫描 `<root>/<YYYYMMDDHH>/` 目录
- 文件名形如：`<exchange>.<symbol>_<YYYYMMDDHH>.h5`
- 找到同一小时里，至少 2 个交易所都存在的 symbol
- 输出 JSON：`results` 中包含 symbol -> 交易所组合 -> 时间范围（`optimize.py` 会读取这一结构）

常用示例：

```bash
cd invariant-strategy

# 生成 binance vs bybit 的 group file（时间范围：2026010800~2026010809）
python3 scripts/searcher.py \
	-d 2026010800,2026010809 \
	-e binance,bybit \
	-r /path/to/raw_data_hourly \
	-j \
	-o group_file.json
```

常用参数：

- `-d/--dates`：单个小时（`YYYYMMDDHH`）或范围（`start,end`）
- `-e/--exchanges`：要参与匹配的交易所列表（逗号分隔）
- `-r/--root`：小时目录根路径（默认 `$REMOTE_DATA_DIR` 或当前目录）
- `--regex`：可选，按正则过滤文件名（例如只匹配 `*_swap_*.h5`）
- `-c/--copy`：可选，将匹配到的文件复制到本地目录，并在输出 JSON 中改写为复制后的路径

然后用生成的 group file 跑批量优化：

```bash
cd invariant-strategy

python3 leadlag/backtest/optimize.py \
	-g group_file.json \
	-s <strategy_template.json> \
	-b <backtest_template.json> \
	-o <optimization_config.json> \
	--processes 4
```

## 将小时数据拷贝到本地（`copier.sh`）

如果你的小时 `.h5` 数据在外接盘/远程挂载上，可以先把一小段时间和特定 symbol 拷贝到本地目录里（这样回测读取本地磁盘会更稳定/更快）。

脚本：[scripts/copier.sh](scripts/copier.sh)

脚本功能：

- 支持输入单个小时（`YYYYMMDDHH`）或范围（`start,end`）
- 支持一个或多个 glob pattern（逗号分隔）
- 输出到 `<output_base>/<YYYYMMDDHH>/...`（执行前会提示你输入/确认输出目录）

示例：

```bash
cd invariant-strategy

# 会提示输入 output base（默认当前目录）
bash scripts/copier.sh 2026010800,2026010809 "bybit.eth_usdt*,binance.*"
```

环境变量：

- `REMOTE_DATA_DIR`：源数据根目录（脚本默认：`/Volumes/hf_data/raw_data_hourly`）
- `OUTPUT_DIR`：输出根目录（如果设置则跳过“输入 output base”的提示；但仍需要 y/yes 确认）

合并多个优化结果的汇总表：

```bash
cd invariant-strategy

python3 leadlag/backtest/optimize.py merge \
	--results-dir results/optimization \
	--output merged_summary.csv
```
