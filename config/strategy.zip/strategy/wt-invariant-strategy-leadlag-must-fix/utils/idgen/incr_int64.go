package idgen

import (
	"fmt"
	"sync/atomic"
)

type Int64Generator struct {
	id        atomic.Int64
	formatter string
}

func NewInt64Generator(size uint) *Int64Generator {
	ig := &Int64Generator{}
	ig.id.Store(0)
	if size < 8 {
		ig.formatter = "%d"
	} else {
		ig.formatter = "%0" + fmt.Sprintf("%dd", size)
	}
	return ig
}

func (g *Int64Generator) Next() string {
	return fmt.Sprintf(g.formatter, g.id.Add(1))
}

func (g *Int64Generator) NextInt64() int64 {
	return g.id.Add(1)
}
