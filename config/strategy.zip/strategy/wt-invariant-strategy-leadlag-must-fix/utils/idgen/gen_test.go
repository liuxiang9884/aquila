package idgen

import (
	"fmt"
	"testing"
)

func TestFormatting(t *testing.T) {
	t.Logf("%%0" + fmt.Sprintf("%dd", 5))
	t.Logf(`%06d`, 3)
}

func TestGenerator(t *testing.T) {
	gen := NewInt64Generator(5)
	for i := 0; i < 10; i++ {
		t.Logf("%s", gen.Next())

	}

	gen = NewInt64Generator(8)
	for i := 0; i < 10; i++ {
		t.Logf("%s", gen.Next())

	}
}
