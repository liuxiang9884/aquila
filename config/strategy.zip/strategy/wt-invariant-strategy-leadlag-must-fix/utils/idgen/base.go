package idgen

type IDGenerator interface {
	Next() string
}
