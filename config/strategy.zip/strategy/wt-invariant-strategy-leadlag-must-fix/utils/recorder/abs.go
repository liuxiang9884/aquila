package recorder

import "fmt"

type IRecorder interface {
	Record(record IRecord)
}

type IRecord interface {
	Tags() map[string]string
	Fields() map[string]interface{}
	Extras() map[string]interface{}
	String() string
}

type RawRecord struct {
	Tag   map[string]string
	Field map[string]interface{}
	Extra map[string]interface{}
}

func (r *RawRecord) String() string {
	return fmt.Sprintf("RawRecord<tags=%+v, fields=%+v>", r.Tag, r.Field)
}

func (r *RawRecord) Tags() map[string]string {
	return r.Tag
}

func (r *RawRecord) Extras() map[string]interface{} {
	return r.Extra
}

func (r *RawRecord) Fields() map[string]interface{} {
	return r.Field
}

type EmptyRecorder struct {
}

func (e *EmptyRecorder) Record(record IRecord) {

}
