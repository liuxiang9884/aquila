package recorder

import (
	"fmt"
	"time"

	"github.com/sirupsen/logrus"
)

type LogRecorder struct {
	Log   *logrus.Entry
	Level logrus.Level
}

func (r *LogRecorder) Record(record IRecord) {
	tags := record.Tags()
	fields := record.Fields()
	for k, v := range tags {
		fields[k] = v
	}
	level := r.Level
	log := r.Log
	for k, v := range record.Extras() {
		switch k {
		case "time":
			if t, ok := v.(time.Time); ok {
				log = log.WithTime(t)
			}
		case "error":
			if err, ok := v.(error); ok {
				log = log.WithError(err)
			}
		case "log_level":
			if l, ok := v.(logrus.Level); ok {
				level = l
			} else {
				panic(fmt.Errorf("invalid level %v", l))
			}
		}
	}

	log.WithFields(fields).Log(level)
}
