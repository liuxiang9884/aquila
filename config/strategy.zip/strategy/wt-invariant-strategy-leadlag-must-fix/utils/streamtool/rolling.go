package streamtool

import (
	"math"
	"sort"

	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/queue"
)

// RollingRecorder maintains statistics over a fixed-count window.
type RollingRecorder struct {
	size    int
	count   int64
	total   float64
	sqTotal float64

	data queue.Queue[float64]
}

func (r *RollingRecorder) Init(size int) {
	r.size = size
	r.count = 0
	r.total = 0
	r.sqTotal = 0

	r.data.Init(size)
}

func (r *RollingRecorder) OnData(data float64) {
	if r.data.Full() {
		popped, ok := r.data.Pop()
		if ok {
			r.count--
			r.total -= popped
			r.sqTotal -= (popped * popped)
		}
	}

	r.count++
	r.total += data
	r.sqTotal += (data * data)
	r.data.Put(data)
}

func (r *RollingRecorder) GetMean() float64 {
	if r.count == 0 {
		return 0
	}
	return r.total / float64(r.count)
}

func (r *RollingRecorder) GetStd() float64 {
	if r.count == 0 {
		return 0
	}
	mean := r.GetMean()
	dx := r.sqTotal / float64(r.count)
	ex2 := mean * mean
	if dx > ex2 {
		return math.Sqrt(dx - ex2)
	}
	return 0
}

func (r *RollingRecorder) GetCount() int64 {
	return r.count
}

func (r *RollingRecorder) IsFull() bool {
	return r.data.Full()
}

func (r *RollingRecorder) GetData() []float64 {
	return r.data.ToSlice()
}

func (r *RollingRecorder) Median() float64 {
	if r.data.Empty() {
		return 0
	}
	data := r.data.ToSlice()
	sort.Float64s(data)
	return data[len(data)/2]
}

func (r *RollingRecorder) MAD() (float64, float64) {
	if r.data.Empty() {
		return 0, 0
	}
	data := r.data.ToSlice()
	sort.Float64s(data)
	median := data[len(data)/2]

	for i, v := range data {
		data[i] = math.Abs(v - median)
	}
	sort.Float64s(data)
	return median, data[len(data)/2]
}
