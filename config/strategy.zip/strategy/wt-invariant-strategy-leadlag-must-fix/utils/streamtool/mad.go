package streamtool

// MADEstimatorConfig holds parameters for the MAD-based robust estimator.
type MADEstimatorConfig struct {
	N int     `json:"n" default:"100"` // Raw sample window size (Stage 1)
	M int     `json:"m" default:"20"`  // Modified/adjusted window size (Stage 2)
	K float64 `json:"k" default:"3"`   // MAD multiplier for winsorization bounds
}

func (c *MADEstimatorConfig) SetDefault() {
	if c.N <= 0 {
		c.N = 100
	}
	if c.M <= 0 {
		c.M = 20
	}
	if c.K <= 0 {
		c.K = 3
	}
}

// MADEstimator implements a robust, adaptive estimator using
// MAD-based winsorization and EMA smoothing.
type MADEstimator struct {
	config MADEstimatorConfig

	// Stage 1: raw sample window
	raw RollingRecorder

	// Stage 2: modified/adjusted window
	adjusted RollingRecorder
}

func NewMADEstimator(config MADEstimatorConfig) *MADEstimator {
	config.SetDefault()
	e := &MADEstimator{
		config: config,
	}
	e.raw.Init(config.N)
	e.adjusted.Init(config.M)
	return e
}

// winsorize clamps value to [median - k*MAD, median + k*MAD].
func (e *MADEstimator) winsorize(value float64) float64 {
	median, mad := e.raw.MAD()
	lower := median - e.config.K*mad
	upper := median + e.config.K*mad
	if value < lower {
		return lower
	}
	if value > upper {
		return upper
	}
	return value
}

func (e *MADEstimator) AddRaw(value float64) {
	e.raw.OnData(value)
}

func (e *MADEstimator) Init(value float64) {
	for i := 0; i < e.config.M; i++ {
		e.adjusted.OnData(value)
	}
}

// OnSample processes a new raw observation through the full pipeline.
func (e *MADEstimator) OnSample(value float64) {
	e.raw.OnData(value)
	modified := e.winsorize(value)
	e.adjusted.OnData(modified)
}

// Get returns the current smoothed estimate.
func (e *MADEstimator) Get() float64 {
	return e.adjusted.GetMean()
}

// GetMedian returns the current raw window median.
func (e *MADEstimator) GetMedian() float64 {
	return e.raw.Median()
}

// GetMAD returns the current MAD of the raw window.
func (e *MADEstimator) GetMAD() float64 {
	_, mad := e.raw.MAD()
	return mad
}
