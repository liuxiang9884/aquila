package queue

func Float64LessThan(a, b float64) bool    { return a < b }
func Float64GreaterThan(a, b float64) bool { return a > b }

type MonotonicQueue[T comparable] struct {
	Queue       Queue[T]
	Max         Queue[T]
	Min         Queue[T]
	LessThan    func(a, b T) bool // true if a < b
	GreaterThan func(a, b T) bool // true if a > b
}

func NewMonotonicQueue[T comparable](size int, lessThan, greaterthan func(a, b T) bool) *MonotonicQueue[T] {
	q := &MonotonicQueue[T]{}
	q.Init(size, lessThan, greaterthan)
	return q
}

// Init initializes the monotonic queue with given size and comparison functions
func (mq *MonotonicQueue[T]) Init(size int, lessThan, greaterThan func(a, b T) bool) {
	mq.Queue.Init(size)
	mq.Max.Init(size)
	mq.Min.Init(size)
	mq.LessThan = lessThan
	mq.GreaterThan = greaterThan
}

// Put adds a value to the queue - O(1) amortized
func (mq *MonotonicQueue[T]) Put(value T) {
	// Add to main queue
	mq.Queue.Put(value)

	// Maintain max queue (decreasing order)
	// Remove all elements smaller than current from back
	for !mq.Max.Empty() {
		back, _ := mq.Max.Head()
		if mq.LessThan(back, value) {
			mq.Max.PopTail()
		} else {
			break
		}
	}
	mq.Max.Put(value)

	// Maintain min queue (increasing order)
	// Remove all elements larger than current from back
	for !mq.Min.Empty() {
		back, _ := mq.Min.Head()
		if mq.GreaterThan(back, value) {
			mq.Min.PopTail()
		} else {
			break
		}
	}
	mq.Min.Put(value)
}

// Pop removes and returns the front element - O(1)
func (mq *MonotonicQueue[T]) Pop() (value T, ok bool) {
	value, ok = mq.Queue.Pop()
	if !ok {
		return
	}

	// Check if popped value is at front of max queue
	// We need to check if value == front using the comparison functions
	// Two values are equal if neither is less than nor greater than the other
	if !mq.Max.Empty() {
		front, _ := mq.Max.Tail()
		// value == front means: !(value < front) AND !(front < value)
		if front == value {
			mq.Max.Pop() // Ignore return value to avoid modifying our named return `ok`
		}
	}

	// Check if popped value is at front of min queue
	if !mq.Min.Empty() {
		front, _ := mq.Min.Tail()
		// value == front means: !(value < front) AND !(front < value)
		if front == value {
			mq.Min.Pop() // Ignore return value to avoid modifying our named return `ok`
		}
	}

	return
}

// GetMax returns the maximum value in the current queue - O(1)
func (mq *MonotonicQueue[T]) GetMax() (value T, ok bool) {
	return mq.Max.Tail()
}

// GetMin returns the minimum value in the current queue - O(1)
func (mq *MonotonicQueue[T]) GetMin() (value T, ok bool) {
	return mq.Min.Tail()
}

// Size returns the number of elements in the queue
func (mq *MonotonicQueue[T]) Size() int {
	return mq.Queue.Size()
}

// Empty returns true if the queue is empty
func (mq *MonotonicQueue[T]) Empty() bool {
	return mq.Queue.Empty()
}
