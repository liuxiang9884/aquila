package queue

type Queue[T any] struct {
	data []T

	size int
	head int
	tail int
}

func NewQueue[T any](size int) *Queue[T] {
	q := &Queue[T]{}
	q.Init(size)
	return q
}

func (q *Queue[T]) Init(size int) {
	q.data = make([]T, size)
	q.size = 0
	q.head = 0
	q.tail = 0
}

func (q *Queue[T]) Extend(size int) {
	data := make([]T, size)
	if q.head > q.tail {
		copy(data, q.data[q.tail:q.head])
		q.data = data
		q.tail = 0
		q.head = q.size
	} else {
		copy(data, q.data[q.tail:q.size])
		copy(data[q.size-q.tail:], q.data[:q.head])
		q.data = data
		q.tail = 0
		q.head = q.size
	}
}

func (q *Queue[T]) Size() int {
	return q.size
}

func (q *Queue[T]) Empty() bool {
	return q.size == 0
}

func (q *Queue[T]) Full() bool {
	return q.size == len(q.data)
}

func (q *Queue[T]) Put(value T) {
	if q.Full() {
		q.Extend(q.size * 2)
	}
	q.data[q.head] = value
	q.head = (q.head + 1) % len(q.data)
	q.size++
}

func (q *Queue[T]) Pop() (value T, ok bool) {
	if q.Empty() {
		ok = false
		return
	}
	value = q.data[q.tail]
	q.tail = (q.tail + 1) % len(q.data)
	q.size--
	return value, true
}

func (q *Queue[T]) Tail() (value T, ok bool) {
	if q.Empty() {
		ok = false
		return
	}
	value = q.data[q.tail]
	return value, true
}

func (q *Queue[T]) Head() (value T, ok bool) {
	if q.Empty() {
		ok = false
		return
	}
	backIdx := (q.head - 1 + len(q.data)) % len(q.data)
	value = q.data[backIdx]
	return value, true
}

func (q *Queue[T]) PopTail() (value T, ok bool) {
	if q.Empty() {
		ok = false
		return
	}
	q.head = (q.head - 1 + len(q.data)) % len(q.data)
	value = q.data[q.head]
	q.size--
	return value, true
}

func (q *Queue[T]) ToSlice() []T {
	if q.Empty() {
		return nil
	}
	result := make([]T, q.size)
	if q.tail < q.head {
		copy(result, q.data[q.tail:q.head])
	} else {
		n := copy(result, q.data[q.tail:])
		copy(result[n:], q.data[:q.head])
	}
	return result
}
