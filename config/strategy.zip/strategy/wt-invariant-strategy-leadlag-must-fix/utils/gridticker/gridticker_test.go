package gridticker

import (
	"testing"
	"time"
)

func TestGridTicker(t *testing.T) {
	// Test 1: Period=100ms, Shift=0 → ticks at aligned grid points
	// Ticks should be exactly 100ms apart
	gt := New(100*time.Millisecond, 0)
	defer gt.Stop()

	tick1 := <-gt.C
	tick2 := <-gt.C
	tick3 := <-gt.C

	// Verify ticks are exactly 100ms apart
	tolerance := 10 * time.Millisecond
	interval1 := tick2.Sub(tick1)
	interval2 := tick3.Sub(tick2)

	if interval1 < 100*time.Millisecond-tolerance || interval1 > 100*time.Millisecond+tolerance {
		t.Errorf("interval between tick1 and tick2: %v, want ~100ms", interval1)
	}
	if interval2 < 100*time.Millisecond-tolerance || interval2 > 100*time.Millisecond+tolerance {
		t.Errorf("interval between tick2 and tick3: %v, want ~100ms", interval2)
	}
}

func TestGridTickerWithShift(t *testing.T) {
	// Test 2: Period=100ms, Shift=25ms → ticks at 25, 125, 225, 325ms, ...
	gt := New(100*time.Millisecond, 25*time.Millisecond)
	defer gt.Stop()

	start := time.Now()
	tick1 := <-gt.C
	elapsed1 := tick1.Sub(start)

	tick2 := <-gt.C
	elapsed2 := tick2.Sub(start)

	tolerance := 50 * time.Millisecond

	if elapsed1 < 25*time.Millisecond-tolerance || elapsed1 > 25*time.Millisecond+tolerance {
		t.Errorf("tick1 elapsed %v, want ~25ms", elapsed1)
	}
	if elapsed2 < 125*time.Millisecond-tolerance || elapsed2 > 125*time.Millisecond+tolerance {
		t.Errorf("tick2 elapsed %v, want ~125ms", elapsed2)
	}
}

func TestGridTickerNextTickTime(t *testing.T) {
	tests := []struct {
		name     string
		period   time.Duration
		shift    time.Duration
		now      time.Time
		expected time.Duration // expected duration from now to next tick
	}{
		{
			name:     "period=1s, shift=0, now=0.5s",
			period:   1 * time.Second,
			shift:    0,
			now:      time.Unix(0, 500*1e6),  // 0.5 seconds
			expected: 500 * time.Millisecond, // should be 1.0s
		},
		{
			name:     "period=1s, shift=0.3s, now=1.5s",
			period:   1 * time.Second,
			shift:    300 * time.Millisecond,
			now:      time.Unix(0, 1500*1e6), // 1.5 seconds
			expected: 800 * time.Millisecond, // should be 2.3s
		},
		{
			name:     "period=1s, shift=0, now=1.0s (on boundary)",
			period:   1 * time.Second,
			shift:    0,
			now:      time.Unix(0, 1000*1e6), // exactly on boundary
			expected: 1 * time.Second,        // next is 1 period away
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gt := New(tt.period, tt.shift)
			nextTick := gt.nextTickTime(tt.now)
			actual := nextTick.Sub(tt.now)

			if actual != tt.expected {
				t.Errorf("got %v, want %v", actual, tt.expected)
			}

			gt.Stop()
		})
	}
}

func TestGridTickerStop(t *testing.T) {
	gt := New(100*time.Millisecond, 0)
	gt.Stop()

	// Channel should close eventually
	select {
	case _, ok := <-gt.C:
		if ok {
			t.Error("channel should be closed")
		}
	case <-time.After(1 * time.Second):
		t.Error("timeout waiting for channel to close")
	}
}

func TestGridTickerRun(t *testing.T) {
	// Create a ticker that fires at 0:00, 1:00, 2:00, etc.
	shift := time.Second / 10
	gt := New(1*time.Second, shift)
	defer gt.Stop()

	for i := 0; i < 5; i++ {
		tick := <-gt.C
		now := time.Now()
		t.Logf("now: %s, tick: %s, diff: %s", now, tick, now.Sub(tick))
		t.Logf("shifted: %s", tick.Add(-shift))
	}
}
