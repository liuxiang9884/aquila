package gridticker

import (
	"time"
)

// GridTicker provides a time.Ticker-like object that generates tick events
// at aligned times. It ticks when (current_time - shift) mod period = 0.
type GridTicker struct {
	Period time.Duration
	Shift  time.Duration
	C      chan time.Time
	stop   chan struct{}
}

// New creates a new GridTicker with the specified period and shift.
// Period is the interval between ticks. Shift offsets the alignment.
// Ticks are generated at times where (current_time - shift) mod period = 0.
//
// Example: Period=1h, Shift=0 → ticks at 0:00, 1:00, 2:00, ...
// Example: Period=1h, Shift=30m → ticks at 0:30, 1:30, 2:30, ...
func New(period, shift time.Duration) *GridTicker {
	gt := &GridTicker{
		Period: period,
		Shift:  shift,
		C:      make(chan time.Time, 1),
		stop:   make(chan struct{}),
	}
	go gt.run()
	return gt
}

// Stop stops the ticker and closes the channel.
func (gt *GridTicker) Stop() {
	close(gt.stop)
}

// NextTickTime calculates the next aligned tick time from the given time.
// This can be used to schedule events to align with grid boundaries without running the ticker.
func (gt *GridTicker) NextTickTime(now time.Time) time.Time {
	return gt.nextTickTime(now)
}

func (gt *GridTicker) run() {
	defer close(gt.C)

	// Create timer once and reuse by calling Reset()
	timer := time.NewTimer(0)
	timer.Stop() // Drain initial timer

	for {
		now := time.Now()
		nextTick := gt.nextTickTime(now)
		waitDuration := nextTick.Sub(now)
		timer.Reset(waitDuration)

		select {
		case <-gt.stop:
			timer.Stop()
			return
		case <-timer.C:
			select {
			case gt.C <- nextTick:
			case <-gt.stop:
				timer.Stop()
				return
			}
		}
	}
}

func (gt *GridTicker) nextTickTime(now time.Time) time.Time {
	// Align to period boundary and apply shift
	return AlignedTickTime(now, gt.Period, gt.Shift)
}

func AlignedTickTime(now time.Time, period, shift time.Duration) time.Time {
	result := now.Add(-shift).Truncate(period).Add(period).Add(shift)
	return result
}
