package algo

import (
	"fmt"
	"math"
	"strings"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/shopspring/decimal"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/streamtool"
)

// IDynamicValue provides a dynamic value getter.
type IDynamicValue[T any] interface {
	Get() T
}

// FixedFloat64 returns a constant value.
type FixedFloat64 float64

func (f FixedFloat64) Get() float64 { return float64(f) }

// EmaFloat64 returns the rolling mean.
type EmaFloat64 struct {
	recorder *streamtool.RollingRecorder
}

func (r *EmaFloat64) Get() float64 { return r.recorder.GetMean() }

// VolPredictor predicts slippage/drift from current volatility.
type VolPredictor struct {
	vol    func() float64
	factor float64
}

func (d *VolPredictor) Get() float64 { return d.vol() * d.factor }

// V2ActionFill records a single fill event.
type V2ActionFill struct {
	ClientId string
	IsMaker  bool
	IsFix    bool
	Price    float64
	Side     int
	Qty      decimal.Decimal
}

// V2ActionGroup tracks all orders and signals in one active state operation.
type V2ActionGroup struct {
	GroupId           string
	ExecState         V2ExecutionState
	StartTime         time.Time
	TriggerRatio      float64
	KeepRangeLower    float64
	KeepRangeUpper    float64
	TakerTriggerPrice float64
	TakerSlippage     float64
	TakerDrift        float64
	Entry             float64
	Exit              float64

	MakerVol     float64
	TakerVol     float64
	MakerVolMax  float64
	TakerVolMax  float64
	PredictSlp   float64
	PredictDrift float64

	Fills           []V2ActionFill
	Status          string
	CheckRangeCount int
	OrderCount      int
}

func (g *V2ActionGroup) AddOrderCount() { g.OrderCount++ }

// slippageState holds slippage tracking state.
type slippageState struct {
	recorder streamtool.RollingRecorder
	// mad        *streamtool.MADEstimator
	value      IDynamicValue[float64]
	lastUpdate time.Time
}

// driftState holds drift tracking state.
type driftState struct {
	recorder streamtool.RollingRecorder
	// mad        *streamtool.MADEstimator
	value      IDynamicValue[float64]
	lastUpdate time.Time
}

// --- Order execution methods ---

// GetExecuteSlippage returns the effective slippage for hedge orders.
func (s *Strategy) GetExecuteSlippage() float64 {
	return math.Max(s.config.Execute.Slippage, s.slippage.value.Get()*s.config.Execute.Multiplier)
}

// addOrderCount safely increments the order count.
func (s *Strategy) addOrderCount() {
	if s.actionGroup != nil {
		s.actionGroup.AddOrderCount()
	}
}

// startActionGroup starts a new action group.
func (s *Strategy) startActionGroup(groupId string, execState V2ExecutionState) {
	s.actionGroup = &V2ActionGroup{
		GroupId:           groupId,
		ExecState:         execState,
		StartTime:         s.Context.Now(),
		Fills:             make([]V2ActionFill, 0),
		TakerTriggerPrice: s.state.TakerTriggerPrice,
		KeepRangeLower:    s.state.KeepRangeLower,
		KeepRangeUpper:    s.state.KeepRangeUpper,
		MakerVol:          s.tracker.MakerRecorder.GetLastVol(),
		TakerVol:          s.tracker.TakerRecorder.GetLastVol(),
		MakerVolMax:       s.tracker.MakerRecorder.GetVolMax(),
		TakerVolMax:       s.tracker.TakerRecorder.GetVolMax(),
		PredictSlp:        s.slippagePredictor.Get(),
		PredictDrift:      s.driftPredictor.Get(),
	}
	switch execState {
	case V2ExecOpenLong, V2ExecCloseShort:
		makerBuffer := s.getMakerBuffer()
		qUp := s.tracker.GetQUp()
		noCancelRange := s.tracker.TakerRecorder.GetVolEma()
		totalCost := s.TotalCost()
		entryLong := qUp + 2*makerBuffer - 2*noCancelRange - totalCost - s.config.Signal.ProfitTarget
		s.actionGroup.Entry = entryLong
		s.actionGroup.Exit = qUp

		s.forceStoreIndicators(s.Context.Now(), s.makerDepth, s.takerDepth, logrus.DebugLevel)
	case V2ExecOpenShort, V2ExecCloseLong:
		makerBuffer := s.getMakerBuffer()
		qDown := s.tracker.GetQDown()
		noCancelRange := s.tracker.TakerRecorder.GetVolEma()
		totalCost := s.TotalCost()
		entryShort := qDown - 2*makerBuffer + 2*noCancelRange + totalCost + s.config.Signal.ProfitTarget
		s.actionGroup.Entry = entryShort
		s.actionGroup.Exit = qDown
		s.forceStoreIndicators(s.Context.Now(), s.makerDepth, s.takerDepth, logrus.DebugLevel)
	}
	s.NowEntry().Debugf("[ActionGroup] started: groupId=%s, exec=%s", groupId, execState)
}

// recordActionFill records a fill event in the current action group.
func (s *Strategy) recordActionFill(clientId string, isMaker bool, isFix bool, side int, price float64, qty decimal.Decimal) {
	if s.actionGroup == nil {
		return
	}
	fill := V2ActionFill{
		ClientId: clientId,
		IsMaker:  isMaker,
		IsFix:    isFix,
		Side:     side,
		Price:    price,
		Qty:      qty,
	}
	s.actionGroup.Fills = append(s.actionGroup.Fills, fill)
	s.NowEntry().Debugf("[ActionGroup] fill: groupId=%s, clientId=%s, isMaker=%v, isFix=%v, side=%d, price=%f, qty=%s",
		s.actionGroup.GroupId, clientId, isMaker, isFix, side, price, qty)
}

// endActionGroup ends the current action group and records summary.
func (s *Strategy) endActionGroup() {
	if s.actionGroup == nil {
		return
	}
	if len(s.actionGroup.Fills) == 0 {
		if s.actionGroup.Status == "" {
			s.actionGroup.Status = "rejected"
		}
		s.recorder.Record(&recorder.RawRecord{
			Tag: map[string]string{
				"type":  "action_summary",
				"exec":  s.actionGroup.ExecState.String(),
				"state": s.actionGroup.Status,
			},
			Field: map[string]interface{}{
				"group_id":         s.actionGroup.GroupId,
				"trigger_ratio":    s.actionGroup.TriggerRatio,
				"keep_range_low":   s.actionGroup.KeepRangeLower,
				"keep_range_up":    s.actionGroup.KeepRangeUpper,
				"duration_ms":      s.Context.Now().Sub(s.actionGroup.StartTime).Milliseconds(),
				"fill_count":       0,
				"keep_range_check": s.actionGroup.CheckRangeCount,
				"maker_vol":        s.actionGroup.MakerVol,
				"taker_vol":        s.actionGroup.TakerVol,
				"maker_vol_max":    s.actionGroup.MakerVolMax,
				"taker_vol_max":    s.actionGroup.TakerVolMax,
				"predict_slp":      s.actionGroup.PredictSlp,
				"predict_drift":    s.actionGroup.PredictDrift,
				"entry":            s.actionGroup.Entry,
				"exit":             s.actionGroup.Exit,
				"start":            s.actionGroup.StartTime.Format("2006-01-02 15:04:05.999"),
			},
			Extra: map[string]interface{}{
				"time":      s.Context.Now(),
				"log_level": logrus.InfoLevel,
			},
		})
		s.actionGroup = nil
		return
	}

	var makerFillQty, takerFillQty, fixFillQty decimal.Decimal
	var makerFillValue, takerFillValue, fixFillValue float64
	var makerId, takerId, fixId string
	var makerAvgPrice, takerAvgPrice, fixAvgPrice float64

	clientIds := make([]string, len(s.actionGroup.Fills))
	for i, fill := range s.actionGroup.Fills {
		clientIds[i] = fill.ClientId
		qty := fill.Qty.Mul(decimal.NewFromInt(int64(fill.Side)))
		value := fill.Price * qty.InexactFloat64()
		if fill.IsFix {
			fixId = fill.ClientId
			fixFillQty = fixFillQty.Add(qty)
			fixFillValue += value
			continue
		}
		if fill.IsMaker {
			makerId = fill.ClientId
			makerFillQty = makerFillQty.Add(qty)
			makerFillValue += value
		} else {
			takerId = fill.ClientId
			takerFillQty = takerFillQty.Add(qty)
			takerFillValue += value
		}
	}

	if !makerFillQty.IsZero() {
		makerAvgPrice = math.Abs(makerFillValue / makerFillQty.InexactFloat64())
	}
	if !takerFillQty.IsZero() {
		takerAvgPrice = math.Abs(takerFillValue / takerFillQty.InexactFloat64())
	}
	if !fixFillQty.IsZero() {
		fixAvgPrice = math.Abs(fixFillValue / fixFillQty.InexactFloat64())
	}

	duration := s.Context.Now().Sub(s.actionGroup.StartTime)

	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type":  "action_summary",
			"exec":  s.actionGroup.ExecState.String(),
			"state": "filled",
		},
		Field: map[string]interface{}{
			"group_id":         s.actionGroup.GroupId,
			"trigger_ratio":    s.actionGroup.TriggerRatio,
			"keep_range_low":   s.actionGroup.KeepRangeLower,
			"keep_range_up":    s.actionGroup.KeepRangeUpper,
			"maker_cid":        makerId,
			"maker_fill_qty":   makerFillQty.InexactFloat64(),
			"maker_avg_price":  makerAvgPrice,
			"taker_cid":        takerId,
			"taker_fill_qty":   takerFillQty.InexactFloat64(),
			"taker_avg_price":  takerAvgPrice,
			"fix_cid":          fixId,
			"fix_fill_qty":     fixFillQty.InexactFloat64(),
			"fix_avg_price":    fixAvgPrice,
			"duration_ms":      duration.Milliseconds(),
			"fill_count":       len(s.actionGroup.Fills),
			"taker_slp":        s.actionGroup.TakerSlippage,
			"taker_drift":      s.actionGroup.TakerDrift,
			"keep_range_check": s.actionGroup.CheckRangeCount,
			"maker_vol":        s.actionGroup.MakerVol,
			"taker_vol":        s.actionGroup.TakerVol,
			"maker_vol_max":    s.actionGroup.MakerVolMax,
			"taker_vol_max":    s.actionGroup.TakerVolMax,
			"predict_slp":      s.actionGroup.PredictSlp,
			"predict_drift":    s.actionGroup.PredictDrift,
			"entry":            s.actionGroup.Entry,
			"exit":             s.actionGroup.Exit,
			"ids":              strings.Join(clientIds, ","),
			"start":            s.actionGroup.StartTime.Format("2006-01-02 15:04:05.999"),
		},
		Extra: map[string]interface{}{
			"time":      s.Context.Now(),
			"log_level": logrus.InfoLevel,
		},
	})

	s.actionGroup = nil
}

// longAskRatio places a maker SELL order (for openLong / closeShort).
func (s *Strategy) longAskRatio(price float64, qty decimal.Decimal, basePrice float64) error {
	cid := s.clientID.Next()

	noCancelRange := s.tracker.TakerRecorder.GetVolEma()
	s.state.KeepRangeLower = basePrice * (1 - noCancelRange)
	s.state.KeepRangeUpper = basePrice * (1 + noCancelRange)
	s.state.TakerTriggerPrice = basePrice
	s.startActionGroup(cid, s.state.Exec)

	// Round price down for sell orders and adjust quantity to tick size
	roundedPrice := CalFloorPrice(s.makerSymbol.GetPriceTick(), price)
	roundedQty := AdjustRebalanceDecimal(qty, s.makerSymbol.GetQuantityTick()*s.makerSymbol.GetContractValue())

	order := s.Context.NewOrder(template.OrderParam{
		Symbol:      s.makerSymbol,
		CID:         cid,
		Side:        utils.Side.Short,
		Price:       roundedPrice,
		Qty:         roundedQty.InexactFloat64(),
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.GTX,
	})

	s.activeMakerOrder = order
	s.activeMakerCID = cid
	s.addOrderCount()

	if err := s.makerClient.SendOrder(order); err != nil {
		s.activeMakerOrder = nil
		s.activeMakerCID = ""
		s.endActionGroup()
		return fmt.Errorf("longAskRatio maker order failed: %w", err)
	}

	s.NowEntry().Infof("[longAskRatio] placed maker SELL order: cid=%s, price=%f, qty=%s, keepRange=[%f, %f]",
		cid, roundedPrice, roundedQty, s.state.KeepRangeLower, s.state.KeepRangeUpper)

	return nil
}

// shortBidRatio places a maker BUY order (for openShort / closeLong).
func (s *Strategy) shortBidRatio(price float64, qty decimal.Decimal, basePrice float64) error {
	cid := s.clientID.Next()

	noCancelRange := s.tracker.TakerRecorder.GetVolEma()
	s.state.KeepRangeLower = basePrice * (1 - noCancelRange)
	s.state.KeepRangeUpper = basePrice * (1 + noCancelRange)
	s.state.TakerTriggerPrice = basePrice
	s.startActionGroup(cid, s.state.Exec)

	// Round price up for buy orders and adjust quantity to tick size
	roundedPrice := CalCeilPrice(s.makerSymbol.GetPriceTick(), price)
	roundedQty := AdjustRebalanceDecimal(qty, s.makerSymbol.GetQuantityTick()*s.makerSymbol.GetContractValue())

	order := s.Context.NewOrder(template.OrderParam{
		Symbol:      s.makerSymbol,
		CID:         cid,
		Side:        utils.Side.Long,
		Price:       roundedPrice,
		Qty:         roundedQty.InexactFloat64(),
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.GTX,
	})

	s.activeMakerOrder = order
	s.activeMakerCID = cid
	s.addOrderCount()

	if err := s.makerClient.SendOrder(order); err != nil {
		s.activeMakerOrder = nil
		s.activeMakerCID = ""
		s.endActionGroup()
		return fmt.Errorf("shortBidRatio maker order failed: %w", err)
	}

	s.NowEntry().Infof("[shortBidRatio] placed maker BUY order: cid=%s, price=%f, qty=%s, keepRange=[%f, %f]",
		cid, roundedPrice, roundedQty, s.state.KeepRangeLower, s.state.KeepRangeUpper)

	return nil
}

// hedgeBuy places a taker BUY order (IOC) with slippage.
func (s *Strategy) hedgeBuy(qty decimal.Decimal, price float64) error {
	hedgePrice := price * (1 + s.GetExecuteSlippage())
	cid := s.clientID.Next()

	// Round price up for buy orders and adjust quantity to tick size
	roundedPrice := CalTakerPrice(s.takerSymbol.GetPriceTick(), hedgePrice, true)
	roundedQty := AdjustRebalanceDecimal(qty, s.takerSymbol.GetQuantityTick()*s.takerSymbol.GetContractValue())

	order := s.Context.NewOrder(template.OrderParam{
		Symbol:      s.takerSymbol,
		CID:         cid,
		Side:        utils.Side.Long,
		Price:       roundedPrice,
		Qty:         roundedQty.InexactFloat64(),
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	})

	s.activeTakerOrder = order
	s.activeTakerCID = cid
	s.state.TakerBasePrice = price
	s.addOrderCount()

	if err := s.takerClient.SendOrder(order); err != nil {
		s.activeTakerOrder = nil
		s.activeTakerCID = ""
		s.state.TakerBasePrice = 0
		return fmt.Errorf("hedgeBuy taker order failed: %w", err)
	}

	s.NowEntry().Infof("[hedgeBuy] placed taker BUY order: cid=%s, price=%f, qty=%s", cid, roundedPrice, roundedQty)
	return nil
}

// hedgeSell places a taker SELL order (IOC) with slippage.
func (s *Strategy) hedgeSell(qty decimal.Decimal, price float64) error {
	hedgePrice := price * (1 - s.GetExecuteSlippage())
	cid := s.clientID.Next()

	// Round price down for sell orders and adjust quantity to tick size
	roundedPrice := CalTakerPrice(s.takerSymbol.GetPriceTick(), hedgePrice, false)
	roundedQty := AdjustRebalanceDecimal(qty, s.takerSymbol.GetQuantityTick()*s.takerSymbol.GetContractValue())

	order := s.Context.NewOrder(template.OrderParam{
		Symbol:      s.takerSymbol,
		CID:         cid,
		Side:        utils.Side.Short,
		Price:       roundedPrice,
		Qty:         roundedQty.InexactFloat64(),
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	})

	s.activeTakerOrder = order
	s.activeTakerCID = cid
	s.state.TakerBasePrice = price
	s.addOrderCount()

	if err := s.takerClient.SendOrder(order); err != nil {
		s.activeTakerOrder = nil
		s.activeTakerCID = ""
		s.state.TakerBasePrice = 0
		return fmt.Errorf("hedgeSell taker order failed: %w", err)
	}

	s.NowEntry().Infof("[hedgeSell] placed taker SELL order: cid=%s, price=%f, qty=%s", cid, roundedPrice, roundedQty)
	return nil
}

// fixExposure reduces exposure to zero.
func (s *Strategy) fixExposure(makerDepth, takerDepth *utils.Depth) error {
	exposure := s.takerPosition.Add(s.makerPosition)

	if exposure.IsZero() {
		s.transitionToStableState("fixExposure")
		return nil
	}

	tolerance := decimal.NewFromFloat(s.config.Position.ExposureTolerance)
	midPrice := ((*takerDepth.Bids)[0].Prc + (*takerDepth.Asks)[0].Prc) / 2
	exposureNotional := exposure.Abs().Mul(decimal.NewFromFloat(midPrice))
	entry := s.NowEntry()
	entry.Infof("[fixExposure] exposure=%s, notional=%s, taker=%s, maker=%s",
		exposure, exposureNotional, s.takerPosition, s.makerPosition)

	if exposureNotional.LessThanOrEqual(tolerance) {
		entry.Infof("[fixExposure] notional=%s <= tolerance=%s, ignoring", exposureNotional, tolerance)
		s.transitionToStableState("fixExposure")
		return nil
	}

	if exposure.IsPositive() {
		// Long exposure — sell
		if s.takerPosition.IsPositive() {
			qty := decimal.Min(s.takerPosition, exposure)
			price := (*takerDepth.Bids)[0].Prc
			s.setExecState("fixExposure", V2ExecFixExposure)
			if err := s.hedgeSell(qty, price); err != nil {
				entry.Errorf("[fixExposure] hedge sell err: %s", err)
			}
		}
		if s.makerPosition.IsPositive() {
			qty := decimal.Min(s.makerPosition, exposure)
			price := (*makerDepth.Bids)[0].Prc * (1 - s.GetExecuteSlippage())
			s.setExecState("fixExposure", V2ExecFixExposure)

			// Round price down for sell orders and adjust quantity to tick size
			roundedPrice := CalTakerPrice(s.makerSymbol.GetPriceTick(), price, false)
			roundedQty := AdjustRebalanceDecimal(qty, s.makerSymbol.GetQuantityTick()*s.makerSymbol.GetContractValue())

			cid := s.clientID.Next()
			order := s.Context.NewOrder(template.OrderParam{
				Symbol:      s.makerSymbol,
				CID:         cid,
				Side:        utils.Side.Short,
				Price:       roundedPrice,
				Qty:         roundedQty.InexactFloat64(),
				OrderType:   template.OrderTypeLimit,
				TimeInForce: template.IOC,
			})
			s.activeMakerOrder = order
			s.activeMakerCID = cid
			s.addOrderCount()
			if err := s.makerClient.SendOrder(order); err != nil {
				s.activeMakerOrder = nil
				s.activeMakerCID = ""
				return fmt.Errorf("fixExposure maker sell failed: %w", err)
			}
		}
	} else {
		// Short exposure — buy
		exposureAbs := exposure.Abs()
		if s.takerPosition.IsNegative() {
			qty := decimal.Min(s.takerPosition.Abs(), exposureAbs)
			price := (*takerDepth.Asks)[0].Prc
			s.setExecState("fixExposure", V2ExecFixExposure)
			if err := s.hedgeBuy(qty, price); err != nil {
				entry.Errorf("[fixExposure] hedge buy err: %s", err)
			}
		}
		if s.makerPosition.IsNegative() {
			qty := decimal.Min(s.makerPosition.Abs(), exposureAbs)
			price := (*makerDepth.Asks)[0].Prc * (1 + s.GetExecuteSlippage())
			s.setExecState("fixExposure", V2ExecFixExposure)

			// Round price up for buy orders and adjust quantity to tick size
			roundedPrice := CalTakerPrice(s.makerSymbol.GetPriceTick(), price, true)
			roundedQty := AdjustRebalanceDecimal(qty, s.makerSymbol.GetQuantityTick()*s.makerSymbol.GetContractValue())

			cid := s.clientID.Next()
			order := s.Context.NewOrder(template.OrderParam{
				Symbol:      s.makerSymbol,
				CID:         cid,
				Side:        utils.Side.Long,
				Price:       roundedPrice,
				Qty:         roundedQty.InexactFloat64(),
				OrderType:   template.OrderTypeLimit,
				TimeInForce: template.IOC,
			})
			s.activeMakerOrder = order
			s.activeMakerCID = cid
			s.addOrderCount()
			if err := s.makerClient.SendOrder(order); err != nil {
				s.activeMakerOrder = nil
				s.activeMakerCID = ""
				return fmt.Errorf("fixExposure maker buy failed: %w", err)
			}
		}
	}

	return nil
}

// openLong opens a long spread position (maker sell + taker buy).
func (s *Strategy) openLong(makerDepth, takerDepth *utils.Depth) (bool, error) {
	makerBuffer := s.getExecuteMakerBuffer()
	makerAsk := (*makerDepth.Asks)[0].Prc
	price := makerAsk * (1 + makerBuffer)
	takerAsk := (*takerDepth.Asks)[0].Prc

	qty := s.calcOpenQty(makerDepth, takerDepth, true, price, takerAsk)
	if qty.IsZero() {
		return false, nil
	}

	s.setExecState("openLong", V2ExecOpenLong)
	if err := s.longAskRatio(price, qty, takerAsk); err != nil {
		s.setExecState("openLong", V2ExecInactive)
		return false, err
	}
	s.actionGroup.TriggerRatio = takerAsk/makerAsk - 1

	s.NowEntry().Infof("[openLong] started: price=%f, qty=%s, makerBuffer=%f", price, qty, makerBuffer)
	return true, nil
}

// closeLong closes a long spread position (maker buy + taker sell).
func (s *Strategy) closeLong(makerDepth, takerDepth *utils.Depth) (bool, error) {
	makerBuffer := s.getMakerBuffer()
	makerBid := (*makerDepth.Bids)[0].Prc
	price := makerBid * (1 - makerBuffer)
	takerBid := (*takerDepth.Bids)[0].Prc

	qty := s.calcCloseQty(makerDepth, takerDepth, price, takerBid)
	if qty.IsZero() {
		return false, nil
	}

	s.setExecState("closeLong", V2ExecCloseLong)
	if err := s.shortBidRatio(price, qty, takerBid); err != nil {
		s.setExecState("closeLong", V2ExecInactive)
		return false, err
	}
	s.actionGroup.TriggerRatio = takerBid/makerBid - 1

	s.NowEntry().Infof("[closeLong] started: price=%f, qty=%s, makerBuffer=%f", price, qty, makerBuffer)
	return true, nil
}

// openShort opens a short spread position (maker buy + taker sell).
func (s *Strategy) openShort(makerDepth, takerDepth *utils.Depth) (bool, error) {
	makerBuffer := s.getMakerBuffer()
	makerBid := (*makerDepth.Bids)[0].Prc
	price := makerBid * (1 - makerBuffer)
	takerBid := (*takerDepth.Bids)[0].Prc

	qty := s.calcOpenQty(makerDepth, takerDepth, false, price, takerBid)
	if qty.IsZero() {
		return false, nil
	}

	s.setExecState("openShort", V2ExecOpenShort)
	if err := s.shortBidRatio(price, qty, takerBid); err != nil {
		s.setExecState("openShort", V2ExecInactive)
		return false, err
	}
	s.actionGroup.TriggerRatio = takerBid/makerBid - 1

	s.NowEntry().Infof("[openShort] started: price=%f, qty=%s, makerBuffer=%f", price, qty, makerBuffer)
	return true, nil
}

// closeShort closes a short spread position (maker sell + taker buy).
func (s *Strategy) closeShort(makerDepth, takerDepth *utils.Depth) (bool, error) {
	makerBuffer := s.getExecuteMakerBuffer()
	makerAsk := (*makerDepth.Asks)[0].Prc
	price := makerAsk * (1 + makerBuffer)
	takerAsk := (*takerDepth.Asks)[0].Prc

	qty := s.calcCloseQty(makerDepth, takerDepth, price, takerAsk)
	if qty.IsZero() {
		return false, nil
	}

	s.setExecState("closeShort", V2ExecCloseShort)
	if err := s.longAskRatio(price, qty, takerAsk); err != nil {
		s.setExecState("closeShort", V2ExecInactive)
		return false, err
	}
	s.actionGroup.TriggerRatio = takerAsk/makerAsk - 1

	s.NowEntry().Infof("[closeShort] started: price=%f, qty=%s, makerBuffer=%f", price, qty, makerBuffer)
	return true, nil
}
