package algo

import (
	"fmt"

	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/shopspring/decimal"
)

// IAccountContext provides position/notional info for qty calculation.
type IAccountContext interface {
	GetPositionNotional() decimal.Decimal
	GetGlobalNotional() decimal.Decimal
	GetPosition() decimal.Decimal
	GetAvailable() decimal.Decimal
}

// IQtyRule calculates order quantities based on account state and depth.
type IQtyRule interface {
	OpenQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64, isBuy bool) decimal.Decimal
	CloseQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64) decimal.Decimal
	CleanQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64) decimal.Decimal
	String() string
}

// QtyRule is the JSON-configurable qty rule.
type QtyRule struct {
	Type string `json:"type"` // "fixed" or "dynamic"

	// fixed rule
	Fixed decimal.Decimal `json:"fixed,omitempty"`

	// dynamic rule
	PosLimit   decimal.Decimal `json:"pos,omitempty"`
	OpenLimit  decimal.Decimal `json:"open,omitempty"`
	CloseLimit decimal.Decimal `json:"close,omitempty"`
	Impact     float64         `json:"impact,omitempty"`
	CleanLimit decimal.Decimal `json:"clean,omitempty"`
}

func (r *QtyRule) ToRule() IQtyRule {
	switch r.Type {
	case "dynamic":
		if r.Impact <= 0 {
			r.Impact = 1
		}
		return &DynamicRule{
			HoldingLimit: r.PosLimit,
			OpenLimit:    r.OpenLimit,
			CloseLimit:   r.CloseLimit,
			Impact:       r.Impact,
			CleanLimit:   r.CleanLimit,
		}
	default: // "fixed" or ""
		return &FixedQtyRule{Qty: r.Fixed}
	}
}

// FixedQtyRule uses a fixed quantity per trade.
type FixedQtyRule struct {
	Qty decimal.Decimal
}

func (r *FixedQtyRule) String() string {
	return fmt.Sprintf("FixedRule<%s>", r.Qty.String())
}

func (r *FixedQtyRule) OpenQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64, isBuy bool) decimal.Decimal {
	return r.Qty
}

func (r *FixedQtyRule) CloseQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64) decimal.Decimal {
	p := ctx.GetPosition().Abs()
	if p.IsZero() {
		return decimal.Zero
	}
	if p.LessThan(r.Qty) {
		return p
	}
	return r.Qty
}

func (r *FixedQtyRule) CleanQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64) decimal.Decimal {
	return r.CloseQty(ctx, depth, priceLimit)
}

// DynamicRule calculates qty from depth levels with notional limits.
type DynamicRule struct {
	HoldingLimit decimal.Decimal
	OpenLimit    decimal.Decimal
	CloseLimit   decimal.Decimal
	Impact       float64
	CleanLimit   decimal.Decimal
}

func (r *DynamicRule) String() string {
	return fmt.Sprintf(
		"DynamicRule<hold=%s, open=%s, close=%s, impact=%f, clean=%s>",
		r.HoldingLimit, r.OpenLimit, r.CloseLimit, r.Impact, r.CleanLimit,
	)
}

func (r *DynamicRule) OpenQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64, isBuy bool) decimal.Decimal {
	notionalLimit := r.HoldingLimit.Sub(ctx.GetPositionNotional().Abs())
	availableLimit := ctx.GetAvailable()
	notionalLimit = decimal.Min(notionalLimit, availableLimit, r.OpenLimit)

	var qty float64
	if isBuy {
		qty = searchAskLevels(*depth.Asks, notionalLimit.InexactFloat64(), priceLimit, r.Impact)
	} else {
		qty = searchBidLevels(*depth.Bids, notionalLimit.InexactFloat64(), priceLimit, r.Impact)
	}
	return decimal.NewFromFloat(qty)
}

func (r *DynamicRule) CloseQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64) decimal.Decimal {
	pos := ctx.GetPosition()
	if pos.IsZero() {
		return decimal.Zero
	}
	var qty float64
	if pos.IsPositive() { // sell
		qty = tryBidLevels(*depth.Bids, pos.InexactFloat64(), r.CloseLimit.InexactFloat64(), priceLimit, r.Impact)
	} else { // buy
		qty = tryAskLevels(*depth.Asks, pos.Abs().InexactFloat64(), r.CloseLimit.InexactFloat64(), priceLimit, r.Impact)
	}
	return decimal.NewFromFloat(qty)
}

func (r *DynamicRule) CleanQty(ctx IAccountContext, depth *utils.Depth, priceLimit float64) decimal.Decimal {
	pos := ctx.GetPosition()
	var qty float64
	if pos.IsPositive() {
		qty = tryBidLevels(*depth.Bids, pos.InexactFloat64(), r.CleanLimit.InexactFloat64(), priceLimit, r.Impact)
	} else {
		qty = tryAskLevels(*depth.Asks, pos.Abs().InexactFloat64(), r.CleanLimit.InexactFloat64(), priceLimit, r.Impact)
	}
	return decimal.NewFromFloat(qty)
}

// --- Depth level search utilities ---

func tryAskLevels(levels []*utils.Level, target, notionalLimit, priceLimit, pct float64) float64 {
	totalNotional := 0.0
	qty := 0.0
	for _, lvl := range levels {
		if lvl.Prc > priceLimit {
			break
		}
		levelQty := lvl.Qty * pct
		levelNotional := levelQty * lvl.Prc
		if totalNotional+levelNotional > notionalLimit {
			levelNotional = notionalLimit - totalNotional
			qty += levelNotional / lvl.Prc
			break
		}
		totalNotional += levelNotional
		qty += levelQty
		if qty >= target {
			return target
		}
	}
	if qty >= target {
		return target
	}
	return qty
}

func tryBidLevels(levels []*utils.Level, target, notionalLimit, priceLimit, pct float64) float64 {
	totalNotional := 0.0
	qty := 0.0
	for _, lvl := range levels {
		if lvl.Prc < priceLimit {
			break
		}
		levelQty := lvl.Qty * pct
		levelNotional := levelQty * lvl.Prc
		if totalNotional+levelNotional > notionalLimit {
			levelNotional = notionalLimit - totalNotional
			qty += levelNotional / lvl.Prc
			break
		}
		totalNotional += levelNotional
		qty += levelQty
		if qty >= target {
			return target
		}
	}
	if qty >= target {
		return target
	}
	return qty
}

func searchAskLevels(levels []*utils.Level, notionalLimit, priceLimit, pct float64) float64 {
	levelNotional := 0.0
	index := 0
	for i, lvl := range levels {
		index = i + 1
		if lvl.Prc > priceLimit {
			break
		}
		levelNotional += lvl.Qty * lvl.Prc * pct
		if levelNotional > notionalLimit {
			levelNotional = notionalLimit
			break
		}
	}
	return searchLevels(levels[:index], notionalLimit)
}

func searchBidLevels(levels []*utils.Level, notionalLimit, priceLimit, pct float64) float64 {
	levelNotional := 0.0
	index := 0
	for i, lvl := range levels {
		index = i + 1
		if lvl.Prc < priceLimit {
			break
		}
		levelNotional += lvl.Qty * lvl.Prc * pct
		if levelNotional > notionalLimit {
			levelNotional = notionalLimit
			break
		}
	}
	return searchLevels(levels[:index], levelNotional)
}

func searchLevels(levels []*utils.Level, notionalLimit float64) (qty float64) {
	notional := 0.0
	for _, lvl := range levels {
		amount := lvl.Qty * lvl.Prc
		notional += amount
		if notional < notionalLimit {
			qty += lvl.Qty
		} else {
			notional -= amount
			qty += lvl.Qty * (notionalLimit - notional) / amount
			break
		}
	}
	return
}

// backtestAccountContext adapts backtest position tracking to IAccountContext.
type backtestAccountContext struct {
	position decimal.Decimal
	midPrice float64
}

func (c *backtestAccountContext) GetPosition() decimal.Decimal {
	return c.position
}

func (c *backtestAccountContext) GetPositionNotional() decimal.Decimal {
	return c.position.Abs().Mul(decimal.NewFromFloat(c.midPrice))
}

func (c *backtestAccountContext) GetGlobalNotional() decimal.Decimal {
	return c.GetPositionNotional()
}

func (c *backtestAccountContext) GetAvailable() decimal.Decimal {
	// In backtest, assume unlimited available margin
	return decimal.NewFromInt(1_000_000_000)
}
