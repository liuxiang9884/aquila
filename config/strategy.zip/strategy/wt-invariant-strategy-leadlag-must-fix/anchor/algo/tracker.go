package algo

import (
	"fmt"
	"math"
	"sort"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/jsontype"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/queue"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/streamtool"
	"gonum.org/v1/gonum/stat"
)

// VolParams configures the rolling volatility measurement for a single side (maker or taker).
type VolParams struct {
	Window    jsontype.Duration `json:"window" default:"1s"`
	Ema       jsontype.Duration `json:"ema" default:"30s"`
	MaxPeriod jsontype.Duration `json:"max_period" default:"10s"`
	MaxEma    jsontype.Duration `json:"max_ema" default:"30s"`
}

// QuantileParams configures the rolling quantile estimation used to derive entry thresholds.
type QuantileParams struct {
	Period struct {
		Window jsontype.Duration `json:"window" default:"60s"`
		Smooth int               `json:"smooth" default:"10"`
	} `json:"period"`
	Init struct {
		Up   float64 `json:"up" default:"0.001"`
		Down float64 `json:"down" default:"-0.001"`
	} `json:"init"`
	Threshold struct {
		Up   float64 `json:"up" default:"0.95"`
		Down float64 `json:"down" default:"0.05"`
	} `json:"threshold"`
	Source string `json:"source"`
}

// V2TrackerConfig groups the volatility and quantile parameters.
type V2TrackerConfig struct {
	Taker    VolParams      `json:"taker"`
	Maker    VolParams      `json:"maker"`
	Quantile QuantileParams `json:"quantile"`
}

// sideRecorder tracks price volatility for one side (ask or bid).
type sideRecorder struct {
	name       string
	priceQueue *queue.MonotonicQueue[float64]
	timeQueue  *queue.Queue[time.Time]
	volRecord  *streamtool.RollingRecorder

	volMaxQueue  *queue.MonotonicQueue[float64]
	volMaxCap    int
	volMaxRecord *streamtool.RollingRecorder
	lastVol      float64
	curMax       float64
}

func (s *sideRecorder) init(config VolParams) {
	less := queue.Float64LessThan
	greater := queue.Float64GreaterThan
	s.priceQueue = queue.NewMonotonicQueue(10000, less, greater)
	s.timeQueue = queue.NewQueue[time.Time](10000)

	volSize := int(config.Ema / config.Window)
	if volSize < 10 {
		volSize = 10
	}
	s.volRecord = &streamtool.RollingRecorder{}
	s.volRecord.Init(volSize)

	maxCap := int(config.MaxPeriod / config.Window)
	if maxCap < 1 {
		maxCap = 1
	}
	s.volMaxCap = maxCap
	s.volMaxQueue = queue.NewMonotonicQueue(maxCap+1, less, greater)

	volMaxSize := int(config.MaxEma / config.Window)
	if volMaxSize < 10 {
		volMaxSize = 10
	}
	s.volMaxRecord = &streamtool.RollingRecorder{}
	s.volMaxRecord.Init(volMaxSize)
}

func (s *sideRecorder) computeSnapshot(now time.Time) {
	maxP, ok1 := s.priceQueue.GetMax()
	minP, ok2 := s.priceQueue.GetMin()
	if ok1 && ok2 && minP > 0 {
		rawVol := (maxP - minP) / (maxP + minP) * 2
		s.volRecord.OnData(rawVol)
		s.lastVol = rawVol

		if s.volMaxQueue.Size() >= s.volMaxCap {
			s.volMaxQueue.Pop()
		}
		s.volMaxQueue.Put(rawVol)

		if curMax, ok := s.volMaxQueue.GetMax(); ok {
			s.volMaxRecord.OnData(curMax)
			s.curMax = curMax
		}
	}
}

func (s *sideRecorder) onPrice(price float64, now time.Time) {
	// for !s.timeQueue.Empty() {
	// 	earliestTime, ok := s.timeQueue.Tail()
	// 	if !ok {
	// 		break
	// 	}
	// 	if now.Sub(earliestTime) > window {
	// 		s.priceQueue.Pop()
	// 		s.timeQueue.Pop()
	// 	} else {
	// 		break
	// 	}
	// }

	s.priceQueue.Put(price)
	s.timeQueue.Put(now)

	// Update live curMax on every tick (between scheduled snapshots)
	maxP, ok1 := s.priceQueue.GetMax()
	minP, ok2 := s.priceQueue.GetMin()
	if ok1 && ok2 && minP > 0 {
		rawVol := (maxP - minP) / (maxP + minP) * 2
		if rawVol > s.curMax {
			s.curMax = rawVol
		}
	}
}

func (s *sideRecorder) getVolEma() float64  { return s.volRecord.GetMean() }
func (s *sideRecorder) getVolMax() float64  { return s.curMax }
func (s *sideRecorder) getLastVol() float64 { return s.lastVol }
func (s *sideRecorder) isReady() bool       { return s.volRecord.GetCount() > 0 && s.getVolEma() > 0 }

func (s *sideRecorder) rollCache(startPoint time.Time) {
	for ts, ok := s.timeQueue.Tail(); ok; ts, ok = s.timeQueue.Tail() {
		if ts.Before(startPoint) {
			s.priceQueue.Pop()
			s.timeQueue.Pop()
		} else {
			break
		}
	}
}

// DepthRecorder wraps two sideRecorders (ask + bid) for one exchange side.
type DepthRecorder struct {
	Tag       string
	Config    VolParams
	CacheTime int64
	ask       sideRecorder
	bid       sideRecorder
}

func (r *DepthRecorder) Init(tag string, config VolParams) {
	r.Tag = tag
	r.Config = config
	r.ask.init(config)
	r.ask.name = fmt.Sprintf("%s.ask", tag)
	r.bid.init(config)
	r.bid.name = fmt.Sprintf("%s.bid", tag)
}

func (r *DepthRecorder) IsReady() bool {
	return r.ask.isReady() && r.bid.isReady()
}

func (r *DepthRecorder) ComputeWindowSnapshot(now time.Time) {
	r.ask.computeSnapshot(now)
	r.bid.computeSnapshot(now)
}

func (r *DepthRecorder) RollCache(now time.Time) {
	startPoint := now.Add(-r.Config.Window.Duration())
	r.ask.rollCache(startPoint)
	r.bid.rollCache(startPoint)
}

func (r *DepthRecorder) OnDepth(depth *utils.Depth) {
	if depth == nil || depth.ServerTS <= r.CacheTime {
		return
	}
	if depth.Asks == nil || len(*depth.Asks) == 0 || depth.Bids == nil || len(*depth.Bids) == 0 {
		return
	}

	r.CacheTime = depth.ServerTS

	askPrice := (*depth.Asks)[0].Prc
	bidPrice := (*depth.Bids)[0].Prc
	now := time.UnixMicro(depth.RespTS)
	// window := time.Duration(r.Config.Window)

	r.ask.onPrice(askPrice, now)
	r.bid.onPrice(bidPrice, now)
}

func (r *DepthRecorder) GetVolMax() float64  { return max(r.ask.getVolMax(), r.bid.getVolMax()) }
func (r *DepthRecorder) GetVolEma() float64  { return max(r.ask.getVolEma(), r.bid.getVolEma()) }
func (r *DepthRecorder) GetLastVol() float64 { return max(r.ask.getLastVol(), r.bid.getLastVol()) }

// GetAskMetrics returns ask-side detailed volatility metrics.
func (r *DepthRecorder) GetAskMetrics() (maxPrice, minPrice float64, startTime, endTime time.Time, vol, volEma float64, timeSize, volMaxSize int) {
	maxPrice, _ = r.ask.priceQueue.GetMax()
	minPrice, _ = r.ask.priceQueue.GetMin()
	startTime, _ = r.ask.timeQueue.Tail()
	endTime, _ = r.ask.timeQueue.Head()
	vol = r.ask.getLastVol()
	volEma = r.ask.getVolEma()
	timeSize = r.ask.timeQueue.Size()
	volMaxSize = r.ask.volMaxQueue.Size()
	return
}

// GetBidMetrics returns bid-side detailed volatility metrics.
func (r *DepthRecorder) GetBidMetrics() (maxPrice, minPrice float64, startTime, endTime time.Time, vol, volEma float64, timeSize, volMaxSize int) {
	maxPrice, _ = r.bid.priceQueue.GetMax()
	minPrice, _ = r.bid.priceQueue.GetMin()
	startTime, _ = r.bid.timeQueue.Tail()
	endTime, _ = r.bid.timeQueue.Head()
	vol = r.bid.getLastVol()
	volEma = r.bid.getVolEma()
	timeSize = r.bid.timeQueue.Size()
	volMaxSize = r.bid.volMaxQueue.Size()
	return
}

// IQuantileTracker defines the interface for quantile value tracking.
type IQuantileTracker interface {
	OnDepth(makerDepth, takerDepth *utils.Depth) bool
	SetQValue(qUp, qDown float64)
	GetQValue() (qUp, qDown float64)
}

// StaticQuantileTracker is a simple setter/getter for quantile values (indicator mode).
type StaticQuantileTracker struct {
	qUp   float64
	qDown float64
}

func (t *StaticQuantileTracker) OnDepth(makerDepth, takerDepth *utils.Depth) bool { return true }
func (t *StaticQuantileTracker) SetQValue(qUp, qDown float64)                     { t.qUp = qUp; t.qDown = qDown }
func (t *StaticQuantileTracker) GetQValue() (float64, float64)                    { return t.qUp, t.qDown }

// RollingQuantileTracker calculates quantiles from rolling ratio history.
type RollingQuantileTracker struct {
	log             *logrus.Entry
	config          QuantileParams
	ratioAskHistory *streamtool.BatchRecorder
	ratioBidHistory *streamtool.BatchRecorder
	qUpHistory      *queue.Queue[float64]
	qDownHistory    *queue.Queue[float64]
	qUp             float64
	qDown           float64
}

func (t *RollingQuantileTracker) Init(log *logrus.Entry, config QuantileParams) {
	t.log = log
	t.config = config
	t.qUp = config.Init.Up
	t.qDown = config.Init.Down

	sampleRateSec := 1
	var ratioSize int
	if sampleRateSec > 0 {
		ratioSize = int(time.Duration(config.Period.Window).Seconds()) / sampleRateSec
	}
	if ratioSize < 100 {
		ratioSize = 100
	}

	t.ratioAskHistory = &streamtool.BatchRecorder{}
	t.ratioAskHistory.Init(time.Duration(config.Period.Window), ratioSize)

	t.ratioBidHistory = &streamtool.BatchRecorder{}
	t.ratioBidHistory.Init(time.Duration(config.Period.Window), ratioSize)

	smoothSize := config.Period.Smooth
	if smoothSize < 1 {
		smoothSize = 10
	}

	t.qUpHistory = queue.NewQueue[float64](smoothSize)
	t.qDownHistory = queue.NewQueue[float64](smoothSize)
}

func (t *RollingQuantileTracker) OnDepth(makerDepth, takerDepth *utils.Depth) bool {
	qtUpdate := false
	ts := time.UnixMilli(takerDepth.ServerTS)

	if t.ratioAskHistory.ShouldRoll(ts) {
		if len(t.ratioAskHistory.Data) > 0 {
			sort.Float64s(t.ratioAskHistory.Data)
			qDownRaw := stat.Quantile(t.config.Threshold.Down, stat.Empirical, t.ratioAskHistory.Data, nil)

			if t.qDownHistory.Full() {
				t.qDownHistory.Pop()
			}
			t.qDownHistory.Put(qDownRaw)

			qDownData := t.qDownHistory.ToSlice()
			if len(qDownData) > 0 {
				t.qDown = getMedian(qDownData)
			} else {
				t.qDown = qDownRaw
			}
			qtUpdate = true
		}
		t.ratioAskHistory.Roll(ts)
	}
	if t.ratioBidHistory.ShouldRoll(ts) {
		if len(t.ratioBidHistory.Data) > 0 {
			sort.Float64s(t.ratioBidHistory.Data)
			qUpRaw := stat.Quantile(t.config.Threshold.Up, stat.Empirical, t.ratioBidHistory.Data, nil)

			if t.qUpHistory.Full() {
				t.qUpHistory.Pop()
			}
			t.qUpHistory.Put(qUpRaw)

			qUpData := t.qUpHistory.ToSlice()
			if len(qUpData) > 0 {
				t.qUp = getMedian(qUpData)
			} else {
				t.qUp = qUpRaw
			}
			qtUpdate = true
		}
		t.ratioBidHistory.Roll(ts)
	}

	if makerDepth.Asks != nil && len(*makerDepth.Asks) > 0 && takerDepth.Asks != nil && len(*takerDepth.Asks) > 0 {
		ratioAsk := (*takerDepth.Asks)[0].Prc/(*makerDepth.Asks)[0].Prc - 1
		t.ratioAskHistory.OnData(ratioAsk)
	}

	if makerDepth.Bids != nil && len(*makerDepth.Bids) > 0 && takerDepth.Bids != nil && len(*takerDepth.Bids) > 0 {
		ratioBid := (*takerDepth.Bids)[0].Prc/(*makerDepth.Bids)[0].Prc - 1
		t.ratioBidHistory.OnData(ratioBid)
	}

	return qtUpdate
}

func getMedian(data []float64) float64 {
	sort.Float64s(data)
	return data[len(data)/2]
}

func (t *RollingQuantileTracker) SetQValue(qUp, qDown float64)  { t.qUp = qUp; t.qDown = qDown }
func (t *RollingQuantileTracker) GetQValue() (float64, float64) { return t.qUp, t.qDown }

// V2DataTracker owns maker/taker recorders and quantile tracking.
type V2DataTracker struct {
	log    *logrus.Entry
	config V2TrackerConfig

	MakerRecorder DepthRecorder
	TakerRecorder DepthRecorder

	quantileTracker IQuantileTracker
	lastLogTs       time.Time
}

func (t *V2DataTracker) Init(log *logrus.Entry, config V2TrackerConfig) {
	t.log = log
	t.config = config
	t.MakerRecorder.Init("maker", config.Maker)
	t.TakerRecorder.Init("taker", config.Taker)

	if config.Quantile.Source == "indicator" {
		static := &StaticQuantileTracker{}
		static.SetQValue(config.Quantile.Init.Up, config.Quantile.Init.Down)
		t.quantileTracker = static
		t.log.Info("V2DataTracker: using StaticQuantileTracker (indicator mode)")
	} else {
		rolling := &RollingQuantileTracker{}
		rolling.Init(log, config.Quantile)
		t.quantileTracker = rolling
		t.log.Info("V2DataTracker: using RollingQuantileTracker (realtime mode)")
	}
}

func (t *V2DataTracker) OnDepth(makerDepth, takerDepth *utils.Depth) (bool, error) {
	t.MakerRecorder.OnDepth(makerDepth)
	t.TakerRecorder.OnDepth(takerDepth)
	qtUpdate := t.quantileTracker.OnDepth(makerDepth, takerDepth)
	return qtUpdate, nil
}

func (t *V2DataTracker) GetQUp() float64 {
	qUp, _ := t.quantileTracker.GetQValue()
	return qUp
}

func (t *V2DataTracker) GetQDown() float64 {
	_, qDown := t.quantileTracker.GetQValue()
	return qDown
}

func (t *V2DataTracker) SetQValue(qUp, qDown float64) {
	t.quantileTracker.SetQValue(qUp, qDown)
}

func (t *V2DataTracker) GetVolMax() float64 {
	return math.Max(t.MakerRecorder.GetVolMax(), t.TakerRecorder.GetVolMax())
}
