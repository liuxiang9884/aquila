package algo

import (
	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

// SignalResult holds the evaluated signals.
type SignalResult struct {
	LongSignal       bool
	ShortSignal      bool
	CloseLongSignal  bool
	CloseShortSignal bool
}

// evaluateSignals evaluates entry/exit signals based on current market conditions.
func (s *Strategy) evaluateSignals(makerDepth, takerDepth *utils.Depth) SignalResult {
	result := SignalResult{}

	makerAsk := (*makerDepth.Asks)[0].Prc
	makerBid := (*makerDepth.Bids)[0].Prc
	takerAsk := (*takerDepth.Asks)[0].Prc
	takerBid := (*takerDepth.Bids)[0].Prc

	qUp := s.tracker.GetQUp()
	qDown := s.tracker.GetQDown()
	makerBuffer := s.getMakerBuffer()
	noCancelRange := s.tracker.TakerRecorder.GetVolEma()

	totalCost := s.TotalCost()
	profitTarget := s.config.Signal.ProfitTarget

	askRatio := takerAsk/makerAsk - 1
	bidRatio := takerBid/makerBid - 1

	longProfitSpace := qUp - askRatio + 2*makerBuffer - 2*noCancelRange
	result.LongSignal = longProfitSpace-totalCost > profitTarget

	shortProfitSpace := bidRatio - qDown + 2*makerBuffer - 2*noCancelRange
	result.ShortSignal = shortProfitSpace-totalCost > profitTarget

	result.CloseLongSignal = bidRatio > qUp
	result.CloseShortSignal = askRatio < qDown

	return result
}

// getMakerBuffer returns the volatility-scaled maker order buffer.
func (s *Strategy) getMakerBuffer() float64 {
	return s.tracker.MakerRecorder.GetVolEma()
}

func (s *Strategy) getExecuteMakerBuffer() float64 {
	return s.tracker.MakerRecorder.GetVolMax() * s.config.Signal.BufferFactor
}

// TotalCost returns the round-trip cost: makerFee*2 + takerFee*2 + 2*slippage + 2*drift.
func (s *Strategy) TotalCost() float64 {
	return s.config.MakerFee*2 + s.config.TakerFee*2 + 2*s.slippage.value.Get() + 2*s.drift.value.Get()
}

// TriggerSignal records signal metrics for post-analysis.
func (s *Strategy) TriggerSignal(makerDepth, takerDepth *utils.Depth) {
	if makerDepth.Asks == nil || len(*makerDepth.Asks) == 0 || makerDepth.Bids == nil || len(*makerDepth.Bids) == 0 {
		return
	}
	if takerDepth.Asks == nil || len(*takerDepth.Asks) == 0 || takerDepth.Bids == nil || len(*takerDepth.Bids) == 0 {
		return
	}

	makerAsk := (*makerDepth.Asks)[0].Prc
	makerBid := (*makerDepth.Bids)[0].Prc
	takerAsk := (*takerDepth.Asks)[0].Prc
	takerBid := (*takerDepth.Bids)[0].Prc

	makerBuffer := s.getMakerBuffer()
	noCancelRange := s.tracker.TakerRecorder.GetVolEma()
	totalCost := s.TotalCost()
	profitTarget := s.config.Signal.ProfitTarget

	now := s.Context.Now()

	// Long spread signal
	ratioAsk := takerAsk/makerAsk - 1
	longProfitSpace := s.tracker.GetQUp() - ratioAsk + 2*makerBuffer - 2*noCancelRange
	if longProfitSpace-totalCost > profitTarget {
		s.recorder.Record(&recorder.RawRecord{
			Tag: map[string]string{
				"type": "signal",
				"side": "long",
			},
			Field: map[string]interface{}{
				"order_price":     makerAsk * (1 + makerBuffer),
				"profit_space":    longProfitSpace,
				"total_cost":      totalCost,
				"net_profit":      longProfitSpace - totalCost,
				"ratio_ask":       ratioAsk,
				"q_up":            s.tracker.GetQUp(),
				"entry_long":      s.tracker.GetQUp() + 2*makerBuffer - 2*noCancelRange - totalCost - s.config.Signal.ProfitTarget,
				"maker_buffer":    makerBuffer,
				"no_cancel_range": noCancelRange,
			},
			Extra: map[string]interface{}{
				"time":      now,
				"log_level": logrus.TraceLevel,
			},
		})
	}

	// Short spread signal
	ratioBid := takerBid/makerBid - 1
	shortProfitSpace := ratioBid - s.tracker.GetQDown() + 2*makerBuffer - 2*noCancelRange
	if shortProfitSpace-totalCost > profitTarget {
		s.recorder.Record(&recorder.RawRecord{
			Tag: map[string]string{
				"type": "signal",
				"side": "short",
			},
			Field: map[string]interface{}{
				"order_price":     makerBid * (1 - makerBuffer),
				"profit_space":    shortProfitSpace,
				"total_cost":      totalCost,
				"net_profit":      shortProfitSpace - totalCost,
				"ratio_bid":       ratioBid,
				"q_down":          s.tracker.GetQDown(),
				"entry_short":     s.tracker.GetQDown() - 2*makerBuffer + 2*noCancelRange + totalCost + s.config.Signal.ProfitTarget,
				"maker_buffer":    makerBuffer,
				"no_cancel_range": noCancelRange,
			},
			Extra: map[string]interface{}{
				"time":      now,
				"log_level": logrus.TraceLevel,
			},
		})
	}
}
