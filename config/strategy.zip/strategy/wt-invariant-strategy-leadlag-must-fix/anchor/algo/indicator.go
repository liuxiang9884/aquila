package algo

import (
	"encoding/csv"
	"fmt"
	"io"
	"os"
	"strconv"
)

// IndicatorData holds a single row of external indicator values.
type IndicatorData struct {
	Long  float64
	Short float64
}

// IndicatorReader reads a per-percentile indicator CSV file for pinnaquant's AddCustomData.
// CSV format: timestamp_ms, long, short
type IndicatorReader struct {
	file   *os.File
	reader *csv.Reader
}

// NewIndicatorReader creates a reader for the given CSV file.
// The file should be one of the per-percentile files (e.g. q95.csv)
// with columns: timestamp_ms, long, short.
func NewIndicatorReader(path string) (*IndicatorReader, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("failed to open indicator file: %w", err)
	}

	r := csv.NewReader(f)

	// Skip header
	if _, err := r.Read(); err != nil {
		f.Close()
		return nil, fmt.Errorf("failed to read indicator header: %w", err)
	}

	return &IndicatorReader{
		file:   f,
		reader: r,
	}, nil
}

// Next implements pinnaquant's CustomReader[IndicatorData] interface.
func (r *IndicatorReader) Next() (timeMs int64, payload *IndicatorData, ok bool) {
	record, err := r.reader.Read()
	if err != nil {
		if err == io.EOF {
			r.file.Close()
		}
		return 0, nil, false
	}

	timeMs, err = strconv.ParseInt(record[0], 10, 64)
	if err != nil {
		panic(err)
		// return 0, nil, false
	}

	longVal, err := strconv.ParseFloat(record[1], 64)
	if err != nil {
		panic(err)
		// return 0, nil, false
	}

	shortVal, err := strconv.ParseFloat(record[2], 64)
	if err != nil {
		panic(err)
		// return 0, nil, false
	}

	return timeMs, &IndicatorData{Long: longVal, Short: shortVal}, true
}

// OnIndicator is the custom data handler for external indicator values.
// It updates the quantile tracker with the received values.
func (s *Strategy) OnIndicator(timeMs int64, data *IndicatorData) error {
	s.log.Infof("[OnIndicator] ts=%d, long=%f, short=%f", timeMs, data.Long, data.Short)
	s.tracker.SetQValue(data.Short, -data.Long)
	return nil
}
