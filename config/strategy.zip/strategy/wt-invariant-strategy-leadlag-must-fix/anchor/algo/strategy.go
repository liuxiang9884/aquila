package algo

import (
	"encoding/json"
	"fmt"
	"math"
	"strings"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/atom_symbol"
	"git.hashingbot.com/aurthes/xex_mm_go/requests"
	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/shopspring/decimal"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/defaults"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/idgen"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/jsontype"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/streamtool"
)

// ValueType selects the dynamic value implementation for slippage/drift.
type ValueType string

const (
	ValueTypeFixed   ValueType = "fixed"
	ValueTypeEma     ValueType = "ema"
	ValueTypePredict ValueType = "predict"
)

// V2SlippageConfig configures taker slippage tracking.
type V2SlippageConfig struct {
	Init    float64                       `json:"init" default:"0.0005"`
	Rolling int                           `json:"rolling" default:"20"`
	Type    ValueType                     `json:"type" default:"fixed"`
	MAD     streamtool.MADEstimatorConfig `json:"mad"`
}

// V2DriftConfig configures taker drift tracking.
type V2DriftConfig struct {
	Init    float64                       `json:"init" default:"0"`
	Rolling int                           `json:"rolling" default:"20"`
	Type    ValueType                     `json:"type" default:"fixed"`
	MAD     streamtool.MADEstimatorConfig `json:"mad"`
}

// V2SignalConfig controls the signal-emission gate.
type V2SignalConfig struct {
	Inactive     jsontype.Duration `json:"inactive" default:"300s"`
	Slippage     V2SlippageConfig  `json:"slippage"`
	Drift        V2DriftConfig     `json:"drift"`
	MakerLatency jsontype.Duration `json:"maker_latency" default:"10ms"`
	BufferFactor float64           `json:"buffer_factor" default:"0"`
	TakerLatency jsontype.Duration `json:"taker_latency" default:"500ms"`
	ProfitTarget float64           `json:"profit_target" default:"0"`
}

// V2PositionConfig configures position management.
type V2PositionConfig struct {
	ExposureTolerance float64 `json:"exposure_tolerance" default:"10"`
}

// V2ExecuteConfig configures execution parameters.
type V2ExecuteConfig struct {
	Slippage   float64 `json:"slippage" default:"0.001"`
	Multiplier float64 `json:"multiplier" default:"0"`
}

// ExchangeSymbol holds a parsed "exchange.symbol" pair.
// JSON marshals as a string in "exchange.symbol" format.
type ExchangeSymbol struct {
	Exchange string
	Symbol   string
}

func (e ExchangeSymbol) String() string {
	return e.Exchange + "." + e.Symbol
}

func (e ExchangeSymbol) MarshalJSON() ([]byte, error) {
	return []byte(`"` + e.String() + `"`), nil
}

func (e *ExchangeSymbol) UnmarshalJSON(data []byte) error {
	var s string
	if err := json.Unmarshal(data, &s); err != nil {
		return err
	}
	parts := strings.SplitN(s, ".", 2)
	if len(parts) == 2 {
		e.Exchange = parts[0]
		e.Symbol = parts[1]
	} else {
		return fmt.Errorf("invalid ex symbol '%s'", data)
	}
	return nil
}

// ParseExchangeSymbol parses "exchange.symbol" format (e.g. "gateio.eth_usdt").
func ParseExchangeSymbol(s string) ExchangeSymbol {
	parts := strings.SplitN(s, ".", 2)
	if len(parts) == 2 {
		return ExchangeSymbol{Exchange: parts[0], Symbol: parts[1]}
	}
	return ExchangeSymbol{Exchange: s}
}

// V2Config is the top-level configuration for the anchor backtest strategy.
type V2Config struct {
	Maker ExchangeSymbol `json:"maker"` // "exchange.symbol" e.g. "gateio.eth_usdt"
	Taker ExchangeSymbol `json:"taker"` // "exchange.symbol" e.g. "paradex.eth_usdc"

	// Fee rates (backtest-specific, production derives from exchange)
	MakerFee float64 `json:"maker_fee" default:"0"`
	TakerFee float64 `json:"taker_fee" default:"0"`

	QtyRule QtyRule `json:"qty_rule"`

	Tracker  V2TrackerConfig  `json:"tracker"`
	Signal   V2SignalConfig   `json:"signal"`
	Execute  V2ExecuteConfig  `json:"execute"`
	Position V2PositionConfig `json:"position"`
	Store    struct {
		Period jsontype.Duration `json:"period" default:"1s"`
	} `json:"store"`
}

func (c *V2Config) SetDefault() {
	defaults.MustSet(c)
}

func (c *V2Config) New(log *logrus.Entry) *Strategy {
	return &Strategy{
		config:   *c,
		log:      log,
		recorder: (*recorder.EmptyRecorder)(nil),
	}
}

// V2PositionState represents the stable state derived from positions.
type V2PositionState int

const (
	V2StateIdle V2PositionState = iota
	V2StateHoldLong
	V2StateHoldShort
	V2StateEnd
)

var positionStates = [V2StateEnd]string{"Idle", "HoldLong", "HoldShort"}

func (s V2PositionState) String() string {
	if s < V2StateEnd {
		return positionStates[s]
	}
	return fmt.Sprintf("UnknownPositionState<%d>", s)
}

// V2ExecutionState represents the current execution state.
type V2ExecutionState uint

const (
	V2ExecInactive V2ExecutionState = iota
	V2ExecOpenLong
	V2ExecCloseLong
	V2ExecOpenShort
	V2ExecCloseShort
	V2ExecFixExposure
	V2ExecEnd
)

var executeStates = [V2ExecEnd]string{"Inactive", "OpenLong", "CloseLong", "OpenShort", "CloseShort", "FixExposure"}

func (s V2ExecutionState) String() string {
	if s < V2ExecEnd {
		return executeStates[s]
	}
	return fmt.Sprintf("UnknownExecuteState<%d>", s)
}

// V2StateManager holds all state management fields.
type V2StateManager struct {
	Position          V2PositionState
	Exec              V2ExecutionState
	KeepRangeLower    float64
	KeepRangeUpper    float64
	TakerTriggerPrice float64
	TakerBasePrice    float64
}

// Strategy is the backtest version of AdaptiveV2.
type Strategy struct {
	template.BaseSingleClientStrategy

	config   V2Config
	log      *logrus.Entry
	recorder recorder.IRecorder
	clientID idgen.IDGenerator

	tracker V2DataTracker
	state   V2StateManager
	qtyRule IQtyRule

	actionGroup *V2ActionGroup

	slippage          slippageState
	drift             driftState
	driftPredictor    *VolPredictor
	slippagePredictor *VolPredictor

	// Cached depths (backtest sends one exchange at a time)
	makerDepth *utils.Depth
	takerDepth *utils.Depth

	// Exchange-specific clients and symbols
	makerClient template.IClient
	takerClient template.IClient
	makerSymbol *atom_symbol.Symbol
	takerSymbol *atom_symbol.Symbol

	// Position tracking (backtest-side)
	makerPosition decimal.Decimal
	takerPosition decimal.Decimal

	// Active order tracking
	activeMakerOrder requests.Order
	activeTakerOrder requests.Order
	activeMakerCID   string
	activeTakerCID   string

	// Indicator store cache
	storeCache struct {
		takerCount int64
		makerCount int64
	}
}

func (s *Strategy) SetRecorder(r recorder.IRecorder) {
	s.recorder = r
}

// SetContext initializes the strategy when the backtest framework starts.
func (s *Strategy) SetContext(ctx template.IStrategyContext) {
	s.BaseSingleClientStrategy.SetContext(ctx)

	s.clientID = idgen.NewInt64Generator(8)

	// Resolve exchange clients
	s.makerClient = s.Context.GetClient(s.config.Maker.Exchange)
	s.takerClient = s.Context.GetClient(s.config.Taker.Exchange)

	// Initialize qty rule
	s.qtyRule = s.config.QtyRule.ToRule()

	// Initialize tracker
	s.tracker.Init(s.log, s.config.Tracker)

	// Schedule volatility window snapshots and indicator snapshots
	s.Context.ScheduleFunc(s.scheduledStoreIndicators, s.storePeriod(), time.Millisecond*5)
	s.Context.ScheduleFunc(s.ComputeMakerWindow, s.config.Tracker.Maker.Window.Duration(), 0)
	s.Context.ScheduleFunc(s.ComputeTakerWindow, s.config.Tracker.Taker.Window.Duration(), 0)

	// Precompute prediction factors
	volTakerPeriod := s.config.Tracker.Taker.Window.Duration().Seconds()
	if volTakerPeriod > 0 {
		makerLatency := s.config.Signal.MakerLatency.Duration().Seconds()
		s.driftPredictor = &VolPredictor{
			factor: math.Sqrt(makerLatency / volTakerPeriod),
			// vol:    s.tracker.TakerRecorder.GetVolMax,
			vol: s.tracker.GetVolMax,
		}

		takerLatency := s.config.Signal.TakerLatency.Duration().Seconds()
		s.slippagePredictor = &VolPredictor{
			factor: math.Sqrt(takerLatency / volTakerPeriod),
			// vol:    s.tracker.TakerRecorder.GetVolMax,
			vol: s.tracker.GetVolMax,
		}
	}

	// Initialize slippage/drift
	s.initSlippage()

	// State
	s.state.Position = V2StateIdle
	s.state.Exec = V2ExecInactive

	entry := s.NowEntry()
	entry.Infof("[AnchorV2] qtyRule: %s", s.qtyRule)
	entry.Infof("[AnchorV2] config: %+v", s.config)
	entry.Infof("[AnchorV2] initial state: exec=%s, position=%s", s.state.Exec, s.state.Position)
}

func (s *Strategy) initSlippage() {
	slippageSize := s.config.Signal.Slippage.Rolling
	if slippageSize <= 0 {
		slippageSize = 20
	}
	s.slippage.recorder.Init(slippageSize)
	for i := 0; i < slippageSize; i++ {
		s.slippage.recorder.OnData(s.config.Signal.Slippage.Init)
	}
	// s.slippage.mad = streamtool.NewMADEstimator(s.config.Signal.Slippage.MAD)
	// s.slippage.mad.Init(s.config.Signal.Slippage.Init)
	switch s.config.Signal.Slippage.Type {
	case ValueTypeEma:
		s.slippage.value = &EmaFloat64{&s.slippage.recorder}
	case ValueTypePredict:
		s.slippage.value = s.slippagePredictor
	default:
		s.slippage.value = FixedFloat64(s.config.Signal.Slippage.Init)
	}

	driftSize := s.config.Signal.Drift.Rolling
	if driftSize <= 0 {
		driftSize = 20
	}
	s.drift.recorder.Init(driftSize)
	for i := 0; i < driftSize; i++ {
		s.drift.recorder.OnData(s.config.Signal.Drift.Init)
	}
	// s.drift.mad = streamtool.NewMADEstimator(s.config.Signal.Drift.MAD)
	// s.drift.mad.Init(s.config.Signal.Drift.Init)
	switch s.config.Signal.Drift.Type {
	case ValueTypeEma:
		s.drift.value = &EmaFloat64{&s.drift.recorder}
	case ValueTypePredict:
		s.drift.value = s.driftPredictor
	default:
		s.drift.value = FixedFloat64(s.config.Signal.Drift.Init)
	}
}

// --- Pinnaquant hooks ---

// OnDepth receives depth updates per exchange, caches them, and runs the main loop
// when both sides are available.
func (s *Strategy) OnDepth(depth *utils.Depth) error {
	exchangeName := depth.GetSymbol().GetExchangeName()

	switch exchangeName {
	case s.config.Maker.Exchange:
		if s.makerSymbol == nil {
			s.makerSymbol = depth.GetSymbol()
		}
		if s.makerDepth != nil {
			s.Context.ReturnDepthToPool(s.makerDepth)
		}
		s.makerDepth = depth
	case s.config.Taker.Exchange:
		if s.takerSymbol == nil {
			s.takerSymbol = depth.GetSymbol()
		}
		if s.takerDepth != nil {
			s.Context.ReturnDepthToPool(s.takerDepth)
		}
		s.takerDepth = depth
	default:
		s.Context.ReturnDepthToPool(depth)
		return nil
	}

	// Run main loop when both depths available
	if s.makerDepth != nil && s.takerDepth != nil {
		return s.onDualDepth(s.makerDepth, s.takerDepth)
	}
	return nil
}

// OnTrade returns trade to pool (not used).
func (s *Strategy) OnTrade(trade *utils.Trade) error {
	s.Context.ReturnTradeToPool(trade)
	return nil
}

// OnRawBBO returns BBO to pool (we use OnDepth instead).
func (s *Strategy) OnRawBBO(bbo *utils.BBO) error {
	s.Context.ReturnBBOToPool(bbo)
	return nil
}

func depthValid(d *utils.Depth) bool {
	return d != nil && d.Asks != nil && d.Bids != nil && len(*d.Asks) > 0 && len(*d.Bids) > 0
}

// onDualDepth is the main loop, called when both maker and taker depths are available.
func (s *Strategy) onDualDepth(makerDepth, takerDepth *utils.Depth) error {
	if !depthValid(makerDepth) || !depthValid(takerDepth) {
		return nil
	}

	// Track depth update counts
	if makerDepth.ServerTS > s.tracker.MakerRecorder.CacheTime {
		s.storeCache.makerCount++
	}
	if takerDepth.ServerTS > s.tracker.TakerRecorder.CacheTime {
		s.storeCache.takerCount++
	}

	// Update tracker
	_, err := s.tracker.OnDepth(makerDepth, takerDepth)
	if err != nil {
		return err
	}

	// State machine dispatch
	switch s.state.Exec {
	case V2ExecInactive:
		s.handleInactiveState(makerDepth, takerDepth)
	case V2ExecFixExposure:
		if s.activeMakerOrder == nil && s.activeTakerOrder == nil {
			if err := s.fixExposure(makerDepth, takerDepth); err != nil {
				s.NowEntry().Errorf("fix exposure failed: %s", err)
			}
		}
	default:
		s.checkKeepRange(takerDepth)
	}

	// Debug log: level-1 depth and signal values
	// s.DebugLogMetric(makerDepth, takerDepth)

	return nil
}

func (s *Strategy) DebugLogMetric(makerDepth, takerDepth *utils.Depth) {
	mAsk := (*makerDepth.Asks)[0].Prc
	mBid := (*makerDepth.Bids)[0].Prc
	tAsk := (*takerDepth.Asks)[0].Prc
	tBid := (*takerDepth.Bids)[0].Prc
	rAsk := tAsk/mAsk - 1
	rBid := tBid/mBid - 1
	qUp := s.tracker.GetQUp()
	qDown := s.tracker.GetQDown()
	buf := s.getMakerBuffer()
	ncr := s.tracker.TakerRecorder.GetVolEma()
	cost := s.TotalCost()
	longPS := qUp - rAsk + 2*buf - 2*ncr
	shortPS := rBid - qDown + 2*buf - 2*ncr
	entryLong := qUp + 2*buf - 2*ncr - cost - s.config.Signal.ProfitTarget
	entryShort := qDown - 2*buf + 2*ncr + cost + s.config.Signal.ProfitTarget
	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type": "instance",
		},
		Field: map[string]interface{}{
			"mAsk": mAsk, "mBid": mBid, "tAsk": tAsk, "tBid": tBid,
			"rAsk": rAsk, "rBid": rBid, "qUp": qUp, "qDown": qDown,
			"buf": buf, "ncr": ncr, "cost": cost,
			"longPS": longPS, "shortPS": shortPS,
			"entryLong": entryLong, "entryShort": entryShort,
			"mTs": makerDepth.ServerTS, "tTs": takerDepth.ServerTS,
			"mRespTs": makerDepth.RespTS, "tRespTs": takerDepth.RespTS,
			"mSeq": makerDepth.MetaData.DepthSeqId, "tSeq": takerDepth.MetaData.DepthSeqId,
		},
		Extra: map[string]interface{}{
			"time":      s.Context.Now(),
			"log_level": logrus.DebugLevel,
		},
	})
}

func (s *Strategy) forceStoreIndicators(now time.Time, makerDepth, takerDepth *utils.Depth, level logrus.Level) {
	ratioAsk := (*takerDepth.Asks)[0].Prc/(*makerDepth.Asks)[0].Prc - 1
	ratioBid := (*takerDepth.Bids)[0].Prc/(*makerDepth.Bids)[0].Prc - 1

	makerBuffer := s.getMakerBuffer()
	noCancelRange := s.tracker.TakerRecorder.GetVolEma()
	totalCost := s.TotalCost()
	qUp := s.tracker.GetQUp()
	qDown := s.tracker.GetQDown()
	entryLong := qUp + 2*makerBuffer - 2*noCancelRange - totalCost - s.config.Signal.ProfitTarget
	entryShort := qDown - 2*makerBuffer + 2*noCancelRange + totalCost + s.config.Signal.ProfitTarget

	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type": "indicator",
		},
		Field: map[string]interface{}{
			"ratio_ask":       ratioAsk,
			"ratio_bid":       ratioBid,
			"q_up":            qUp,
			"q_down":          qDown,
			"entry_long":      entryLong,
			"entry_short":     entryShort,
			"total_cost":      totalCost,
			"taker_c":         s.storeCache.takerCount,
			"maker_c":         s.storeCache.makerCount,
			"exec_state":      int(s.state.Exec),
			"position_state":  int(s.state.Position),
			"maker_buffer":    makerBuffer,
			"no_cancel_range": noCancelRange,
			"drift_predict":   s.driftPredictor.Get(),
			"slp_predict":     s.slippagePredictor.Get(),
			"taker_slp":       s.slippage.recorder.GetMean(),
			"taker_drift":     s.drift.recorder.GetMean(),
		},
		Extra: map[string]interface{}{
			"time":      now,
			"log_level": level,
		},
	})
	s.storeDepth(now, makerDepth, makerBuffer, s.tracker.MakerRecorder.GetVolMax(), s.tracker.MakerRecorder.GetLastVol(), level)
	s.storeDepth(now, takerDepth, noCancelRange, s.tracker.TakerRecorder.GetVolMax(), s.tracker.TakerRecorder.GetLastVol(), level)

}

// storePeriod returns the effective store period (>0).
func (s *Strategy) storePeriod() time.Duration {
	d := s.config.Store.Period.Duration()
	if d <= 0 {
		d = time.Second
	}
	return d
}

func (s *Strategy) scheduledStoreIndicators(now time.Time) error {
	if s.makerDepth != nil && s.takerDepth != nil &&
		depthValid(s.makerDepth) && depthValid(s.takerDepth) {
		s.forceStoreIndicators(now, s.makerDepth, s.takerDepth, logrus.InfoLevel)
		s.storeCache.takerCount = 0
		s.storeCache.makerCount = 0
	}
	return nil
}

// storeDepth records a depth snapshot via the recorder.
func (s *Strategy) storeDepth(now time.Time, depth *utils.Depth, vol float64, volMax float64, rawVol float64, level logrus.Level) {
	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type":   "depth",
			"symbol": depth.GetSymbol().GetName(),
		},
		Field: map[string]interface{}{
			"askPrc1": (*depth.Asks)[0].Prc,
			"bidPrc1": (*depth.Bids)[0].Prc,
			"vol":     vol,
			"vol_max": volMax,
			"vol_raw": rawVol,
		},
		Extra: map[string]interface{}{
			"time":      now,
			"log_level": level,
		},
	})
}

// handleInactiveState handles signal evaluation and dispatch when no active operation.
func (s *Strategy) handleInactiveState(makerDepth, takerDepth *utils.Depth) {

	signals := s.evaluateSignals(makerDepth, takerDepth)

	midPrice := ((*takerDepth.Asks)[0].Prc + (*takerDepth.Bids)[0].Prc) / 2
	entry := s.NowEntry()
	switch s.state.Position {
	case V2StateIdle:
		if signals.LongSignal {
			if _, err := s.openLong(makerDepth, takerDepth); err != nil {
				entry.Errorf("[OnDepth] openLong failed: %v", err)
			}
		} else if signals.ShortSignal {
			if _, err := s.openShort(makerDepth, takerDepth); err != nil {
				entry.Errorf("[OnDepth] openShort failed: %v", err)
			}
		}

	case V2StateHoldLong:
		if signals.CloseLongSignal {
			if _, err := s.closeLong(makerDepth, takerDepth); err != nil {
				entry.Errorf("[OnDepth] closeLong failed: %v", err)
			}
		} else if signals.LongSignal {
			takerNotional := s.takerPosition.Mul(decimal.NewFromFloat(midPrice))
			if takerNotional.LessThan(s.config.QtyRule.PosLimit) {
				if _, err := s.openLong(makerDepth, takerDepth); err != nil {
					entry.Errorf("[OnDepth] openLong (add) failed: %v", err)
				}
			}
		}

	case V2StateHoldShort:
		if signals.CloseShortSignal {
			if _, err := s.closeShort(makerDepth, takerDepth); err != nil {
				entry.Errorf("[OnDepth] closeShort failed: %v", err)
			}
		} else if signals.ShortSignal {
			takerNotional := s.takerPosition.Neg().Mul(decimal.NewFromFloat(midPrice))
			if takerNotional.LessThan(s.config.QtyRule.PosLimit) {
				if _, err := s.openShort(makerDepth, takerDepth); err != nil {
					entry.Errorf("[OnDepth] openShort (add) failed: %v", err)
				}
			}
		}
	}

	if signals.LongSignal || signals.ShortSignal {
		s.TriggerSignal(makerDepth, takerDepth)
	}
}

// OnOrder handles order fill callbacks from the backtest engine.
func (s *Strategy) OnOrder(msg *utils.OrderMessage) error {
	defer s.Context.ReturnOrderMessageToPool(msg)

	// Determine if this is a maker or taker order (match by exchange pair + CID)
	var isMaker, isTaker bool

	var symbol *atom_symbol.Symbol
	switch msg.Ex {
	case s.config.Maker.Exchange:
		if s.activeMakerOrder != nil && msg.ClientID == s.activeMakerOrder.GetCID() {
			isMaker = true
			UpdateOrder(s.activeMakerOrder, msg)
			symbol = s.makerSymbol
		}

	case s.config.Taker.Exchange:
		if s.activeTakerOrder != nil && msg.ClientID == s.activeTakerOrder.GetCID() {
			isTaker = true
			UpdateOrder(s.activeTakerOrder, msg)
			symbol = s.takerSymbol
		}

	}

	if !isMaker && !isTaker {
		return nil
	}

	if !utils.FinishedStatus[msg.Status] {
		return nil
	}

	filledQty := ToRoundDecimal(symbol, msg.FilledQty)
	fillPrice := msg.AvgFillPrc

	// Update position
	positionDelta := filledQty
	if msg.Side == utils.Side.Short {
		positionDelta = positionDelta.Neg()
	}

	if isMaker {
		s.makerPosition = s.makerPosition.Add(positionDelta)
		s.onMakerFill(msg, filledQty, fillPrice)
	} else {
		s.takerPosition = s.takerPosition.Add(positionDelta)
		s.onTakerFill(msg, filledQty, fillPrice)
	}

	// Record order
	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type": "order",
		},
		Field: map[string]interface{}{
			"cid":       msg.ClientID,
			"oid":       msg.OrderID,
			"side":      msg.Side,
			"price":     msg.Price,
			"avg_price": msg.AvgFillPrc,
			"filled":    msg.FilledQty,
			"is_maker":  isMaker,
			"exchange":  msg.Ex,
		},
		Extra: map[string]interface{}{
			"time":      s.Context.Now(),
			"log_level": logrus.InfoLevel,
		},
	})

	return nil
}

// onMakerFill handles maker order fill.
func (s *Strategy) onMakerFill(msg *utils.OrderMessage, filledQty decimal.Decimal, fillPrice float64) {
	entry := s.NowEntry()
	entry.Infof("[OnMakerOrder] cid=%s, filled=%s, price=%f, exec=%s",
		msg.ClientID, filledQty, fillPrice, s.state.Exec)

	if !filledQty.IsZero() {
		s.recordActionFill(msg.ClientID, true, s.state.Exec == V2ExecFixExposure, msg.Side, fillPrice, filledQty)
	}

	s.activeMakerOrder = nil
	s.activeMakerCID = ""

	switch s.state.Exec {
	case V2ExecOpenLong, V2ExecCloseShort:
		if !filledQty.IsZero() && s.takerDepth != nil {
			takerAsk := (*s.takerDepth.Asks)[0].Prc
			if err := s.hedgeBuy(filledQty, takerAsk); err != nil {
				entry.Errorf("[OnMakerOrder] hedgeBuy failed: %v", err)
			}
		} else {
			s.checkPositionState("OnMakerOrder")
		}

	case V2ExecOpenShort, V2ExecCloseLong:
		if !filledQty.IsZero() && s.takerDepth != nil {
			takerBid := (*s.takerDepth.Bids)[0].Prc
			if err := s.hedgeSell(filledQty, takerBid); err != nil {
				entry.Errorf("[OnMakerOrder] hedgeSell failed: %v", err)
			}
		} else {
			s.checkPositionState("OnMakerOrder")
		}

	case V2ExecFixExposure:
		if s.checkPositionState("OnMakerOrder") {
			if s.makerDepth != nil && s.takerDepth != nil {
				if err := s.fixExposure(s.makerDepth, s.takerDepth); err != nil {
					entry.Errorf("[OnMakerOrder] fixExposure failed: %v", err)
				}
			}
		}
	}
}

// onTakerFill handles taker order fill.
func (s *Strategy) onTakerFill(msg *utils.OrderMessage, filledQty decimal.Decimal, fillPrice float64) {
	entry := s.NowEntry()
	entry.Infof("[OnTakerOrder] cid=%s, filled=%s, price=%f, exec=%s",
		msg.ClientID, filledQty, fillPrice, s.state.Exec)

	if !filledQty.IsZero() {
		s.recordActionFill(msg.ClientID, false, s.state.Exec == V2ExecFixExposure, msg.Side, fillPrice, filledQty)

		// Record slippage
		if s.state.TakerBasePrice != 0 {
			var slippage float64
			if msg.Side == utils.Side.Long {
				slippage = fillPrice/s.state.TakerBasePrice - 1
			} else {
				slippage = 1 - fillPrice/s.state.TakerBasePrice
			}
			if slippage > 0 {
				s.slippage.recorder.OnData(slippage)
			}
			s.slippage.lastUpdate = s.Context.Now()

			if s.actionGroup != nil {
				s.actionGroup.TakerSlippage = slippage

				// Record drift
				if s.actionGroup.TakerTriggerPrice != 0 {
					side := 1.0
					if msg.Side == utils.Side.Short {
						side = -1.0
					}
					drift := (s.state.TakerBasePrice/s.actionGroup.TakerTriggerPrice - 1) * side
					s.actionGroup.TakerDrift = drift
					s.drift.recorder.OnData(drift)
					s.drift.lastUpdate = s.Context.Now()
				}
			}
		}
	}

	s.activeTakerOrder = nil
	s.activeTakerCID = ""
	s.state.TakerBasePrice = 0

	if s.checkPositionState("OnTakerOrder") {
		if s.makerDepth != nil && s.takerDepth != nil {
			if err := s.fixExposure(s.makerDepth, s.takerDepth); err != nil {
				entry.Errorf("[OnTakerOrder] fixExposure failed: %v", err)
			}
		}
	}
}

func (s *Strategy) derivePositionState() V2PositionState {
	if s.takerPosition.IsZero() {
		return V2StateIdle
	}
	if s.takerPosition.IsPositive() {
		return V2StateHoldLong
	}
	return V2StateHoldShort
}

func (s *Strategy) checkPositionState(tag string) bool {
	if s.activeMakerOrder != nil || s.activeTakerOrder != nil {
		return false
	}
	exposure := s.takerPosition.Add(s.makerPosition)
	if !exposure.IsZero() {
		s.setExecState(tag, V2ExecFixExposure)
		return true
	}
	s.transitionToStableState(tag)
	return false
}

func (s *Strategy) transitionToStableState(tag string) {
	s.endActionGroup()
	s.setPositionState(tag, s.derivePositionState())
	s.setExecState(tag, V2ExecInactive)
}

func (s *Strategy) setPositionState(tag string, newState V2PositionState) {
	if s.state.Position != newState {
		s.NowEntry().Infof("[State][%s] Position: %s -> %s", tag, s.state.Position, newState)
		s.state.Position = newState
	}
}

func (s *Strategy) setExecState(tag string, newState V2ExecutionState) {
	if s.state.Exec != newState {
		s.NowEntry().Infof("[State][%s] Exec: %s -> %s", tag, s.state.Exec, newState)
		s.state.Exec = newState
	}
}

// checkKeepRange cancels the active maker order if taker price moves out of range.
func (s *Strategy) checkKeepRange(takerDepth *utils.Depth) bool {
	if s.actionGroup != nil {
		s.actionGroup.CheckRangeCount++
	}
	if s.activeMakerOrder == nil {
		return false
	}

	entry := s.NowEntry()
	switch s.state.Exec {
	case V2ExecOpenLong, V2ExecCloseShort:
		takerAsk := (*takerDepth.Asks)[0].Prc
		if takerAsk < s.state.KeepRangeLower || takerAsk > s.state.KeepRangeUpper {
			if s.actionGroup != nil {
				s.actionGroup.Status = "canceled"
			}
			oid := s.activeMakerOrder.GetOID()
			if oid == "" {
				entry.Warnf("maker order oid is empty")
				return false
			}
			entry.Infof("Cancel(%s) triggered by price=%f, range=[%f, %f]", oid, takerAsk, s.state.KeepRangeLower, s.state.KeepRangeUpper)
			err := s.makerClient.Cancel(s.makerSymbol, oid)
			if err != nil {
				panic(fmt.Errorf("send cancel, err: %s", err))
			}
			return true
		}

	case V2ExecOpenShort, V2ExecCloseLong:
		takerBid := (*takerDepth.Bids)[0].Prc
		if takerBid < s.state.KeepRangeLower || takerBid > s.state.KeepRangeUpper {
			if s.actionGroup != nil {
				s.actionGroup.Status = "canceled"
			}
			oid := s.activeMakerOrder.GetOID()
			if oid == "" {
				entry.Warnf("maker order oid is empty")
				return false
			}
			entry.Infof("Cancel(%s) triggered by price=%f, range=[%f, %f]", oid, takerBid, s.state.KeepRangeLower, s.state.KeepRangeUpper)
			err := s.makerClient.Cancel(s.makerSymbol, oid)
			if err != nil {
				panic(fmt.Errorf("send cancel, err: %s", err))
			}
			return true
		}
	}

	return false
}

// --- Quantity helpers ---

func (s *Strategy) calcOpenQty(makerDepth, takerDepth *utils.Depth, makerLong bool, makerPrice, takerLimit float64) decimal.Decimal {
	midPrice := ((*takerDepth.Asks)[0].Prc + (*takerDepth.Bids)[0].Prc) / 2
	ctx := &backtestAccountContext{position: s.takerPosition, midPrice: midPrice}

	var qty decimal.Decimal
	if makerLong { // maker sells → taker buys to hedge
		qty = s.qtyRule.OpenQty(ctx, takerDepth, takerLimit, true)
	} else { // maker buys → taker sells to hedge
		qty = s.qtyRule.OpenQty(ctx, takerDepth, takerLimit, false)
	}
	qty = s.roundQty(qty)
	return qty
}

func (s *Strategy) calcCloseQty(makerDepth, takerDepth *utils.Depth, makerPrice, takerLimit float64) decimal.Decimal {
	midPrice := ((*takerDepth.Asks)[0].Prc + (*takerDepth.Bids)[0].Prc) / 2
	ctx := &backtestAccountContext{position: s.takerPosition, midPrice: midPrice}

	qty := s.qtyRule.CloseQty(ctx, takerDepth, takerLimit)
	qty = s.roundQty(qty)
	return qty
}

func (s *Strategy) roundQty(qty decimal.Decimal) decimal.Decimal {
	if s.makerSymbol != nil {
		tick := decimal.NewFromFloat(s.makerSymbol.GetQuantityTick() * s.makerSymbol.GetContractValue())
		if tick.IsPositive() {
			qty = qty.Div(tick).Floor().Mul(tick)
		}
	}
	return qty
}

// Brief prints end-of-backtest summary and closes any open positions with market orders.
func (s *Strategy) Brief() {
	entry := s.NowEntry()
	entry.Infof("[V2 State] exec=%s, position=%s", s.state.Exec, s.state.Position)
	entry.Infof("[V2 Quantiles] qUp=%f, qDown=%f", s.tracker.GetQUp(), s.tracker.GetQDown())
	entry.Infof("[V2 Volatility] makerBuffer=%f, noCancelRange=%f", s.getMakerBuffer(), s.tracker.TakerRecorder.GetVolEma())
	entry.Infof("[V2 Position] taker=%s, maker=%s", s.takerPosition, s.makerPosition)
	entry.Infof("[V2 Slippage] mean=%f", s.slippage.recorder.GetMean())
	entry.Infof("[V2 Drift] mean=%f", s.drift.recorder.GetMean())
	s.forceStoreIndicators(s.Context.Now(), s.makerDepth, s.takerDepth, logrus.InfoLevel)
}

func UpdateOrder(o requests.Order, raw *utils.OrderMessage) bool {
	if o.GetOID() == "" && raw.OrderID != "" {
		o.SetOID(raw.OrderID)
	}
	qty := raw.FilledQty * o.GetSymbol().GetContractValue()
	o.SetFilledQuantity(qty)
	o.SetFilledNotional(qty * raw.AvgFillPrc)
	o.SetStatus(raw.Status)
	if utils.IsFinishedStatus(raw.Status) {
		o.SetFinishTs(raw.ServerTime)
	}
	return true
}

// NowEntry returns a logger entry with current strategy context time.
func (s *Strategy) NowEntry() *logrus.Entry {
	return s.log.WithTime(s.Context.Now())
}

func (s *Strategy) LogVolatilityMetrics(now time.Time, dr *DepthRecorder, by string) {
	// Get ask-side metrics
	aMax, aMin, aStart, aEnd, aVol, _, aTimeSize, aVolMaxSize := dr.GetAskMetrics()
	// Get bid-side metrics
	bMax, bMin, bStart, bEnd, bVol, _, bTimeSize, bVolMaxSize := dr.GetBidMetrics()

	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type": "vol",
		},
		Field: map[string]interface{}{
			"by":        by,
			"role":      dr.Tag,
			"ema":       dr.GetVolEma(),
			"aEmaSize":  dr.ask.volRecord.GetCount(),
			"bEmaSize":  dr.bid.volRecord.GetCount(),
			"last":      dr.GetLastVol(),
			"max":       dr.GetVolMax(),
			"aVol":      aVol,
			"bVol":      bVol,
			"aMax":      aMax,
			"aMin":      aMin,
			"bMax":      bMax,
			"bMin":      bMin,
			"aStart":    aStart.UnixMilli(),
			"aEnd":      aEnd.UnixMilli(),
			"bStart":    bStart.UnixMilli(),
			"bEnd":      bEnd.UnixMilli(),
			"aSize":     aTimeSize,
			"aMaxSize":  aVolMaxSize,
			"bSize":     bTimeSize,
			"bMaxSize":  bVolMaxSize,
			"eventTime": now.Unix(),
		},
		Extra: map[string]interface{}{
			"time":      now,
			"log_level": logrus.DebugLevel,
		},
	})
}

// scheduleMakerWindow registers the next grid-aligned maker window computation.
// func (s *Strategy) scheduleMakerWindow(now time.Time) {
// 	window := s.config.Tracker.Maker.Window.Duration()
// 	s.Context.CallFunc(gridticker.AlignedTickTime(now, window, 0), s.computeMakerWindow)
// }

// // computeMakerWindow computes and records a volatility snapshot for maker side.
// func (s *Strategy) computeMakerWindow() error {
// 	now := s.Context.Now()

// 	s.tracker.MakerRecorder.RollCache(now)
// 	s.tracker.MakerRecorder.ComputeWindowSnapshot(now)
// 	s.LogVolatilityMetrics(now, &s.tracker.MakerRecorder, "callfunc")

// 	// End loop if no new data for longer than EMA period
// 	if s.makerDepth != nil {
// 		emaPeriod := s.config.Tracker.Maker.Ema.Duration()
// 		if now.UnixMilli()-s.makerDepth.ServerTS > emaPeriod.Milliseconds() {
// 			return nil
// 		}
// 	}

// 	s.scheduleMakerWindow(now)
// 	return nil
// }

// scheduleTakerWindow registers the next grid-aligned taker window computation.
// func (s *Strategy) scheduleTakerWindow(now time.Time) {
// 	window := s.config.Tracker.Taker.Window.Duration()
// 	s.Context.CallFunc(gridticker.AlignedTickTime(now, window, 0), s.computeTakerWindow)
// }

// // computeTakerWindow computes and records a volatility snapshot for taker side.
// func (s *Strategy) computeTakerWindow() error {
// 	now := s.Context.Now()

// 	s.tracker.TakerRecorder.RollCache(now)
// 	s.tracker.TakerRecorder.ComputeWindowSnapshot(now)
// 	s.LogVolatilityMetrics(now, &s.tracker.TakerRecorder, "callfunc")

// 	// End loop if no new data for longer than EMA period
// 	if s.takerDepth != nil {
// 		emaPeriod := s.config.Tracker.Taker.Ema.Duration()
// 		if now.UnixMilli()-s.takerDepth.ServerTS > emaPeriod.Milliseconds() {
// 			return nil
// 		}
// 	}

// 	s.scheduleTakerWindow(now)
// 	return nil
// }

func (s *Strategy) ComputeTakerWindow(now time.Time) error {
	s.tracker.TakerRecorder.RollCache(now)
	s.tracker.TakerRecorder.ComputeWindowSnapshot(now)
	s.LogVolatilityMetrics(now, &s.tracker.TakerRecorder, "schedule")
	return nil
}

func (s *Strategy) ComputeMakerWindow(now time.Time) error {
	s.tracker.MakerRecorder.RollCache(now)
	s.tracker.MakerRecorder.ComputeWindowSnapshot(now)
	s.LogVolatilityMetrics(now, &s.tracker.MakerRecorder, "schedule")
	return nil
}
