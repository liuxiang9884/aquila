package algo

import (
	"math"

	"git.hashingbot.com/aurthes/xex_mm_go/atom_symbol"
	"github.com/shopspring/decimal"
)

// CalCeilPrice rounds a price up to the nearest price tick.
func CalCeilPrice(priceTick float64, price float64) float64 {
	if priceTick <= 0 {
		return price
	}
	return math.Ceil(price/priceTick) * priceTick
}

// CalFloorPrice rounds a price down to the nearest price tick.
func CalFloorPrice(priceTick float64, price float64) float64 {
	if priceTick <= 0 {
		return price
	}
	return math.Floor(price/priceTick) * priceTick
}

// CalTakerPrice rounds a price using ceil for buys (positive) and floor for sells (negative).
func CalTakerPrice(priceTick float64, price float64, isPositive bool) float64 {
	if isPositive {
		return CalCeilPrice(priceTick, price)
	}
	return CalFloorPrice(priceTick, price)
}

// AdjustRebalanceDecimal rounds quantity up for positive values and down for negative values.
func AdjustRebalanceDecimal(qty decimal.Decimal, qtyTick float64) decimal.Decimal {
	if qtyTick <= 0 {
		return qty
	}

	tick := decimal.NewFromFloat(qtyTick)
	if qty.IsPositive() {
		// Round up for positive quantities
		return qty.Div(tick).RoundCeil(0).Mul(tick)
	}
	// Round down (toward zero) for negative quantities
	return qty.Div(tick).RoundFloor(0).Mul(tick)
}

func ToRoundDecimal(symbol *atom_symbol.Symbol, qty float64) decimal.Decimal {
	return decimal.NewFromFloatWithExponent(qty, int32(math.Round(math.Log10(symbol.GetQuantityTick()*symbol.GetContractValue()))))
}
