# Anchor Strategy — Python Analysis Tools

Post-run analysis tools for anchor strategy backtest logs. The backtest produces newline-delimited JSON (via logrus), and these scripts parse, aggregate, and visualize the results.

## Prerequisites

```bash
pip install pandas matplotlib mplcursors numpy
```

## Log Format

The backtest emits several record types (field `type` in each JSON line):

| type | level | key fields | purpose |
|---|---|---|---|
| `indicator` | Debug | `ratio_ask`, `ratio_bid`, `q_up`, `q_down`, `entry_long`, `entry_short`, `exec_state`, `position_state`, `maker_buffer`, `no_cancel_range` | Per-tick market snapshot |
| `depth` | Debug | `symbol`, `askPrc1`, `bidPrc1`, `vol`, `vol_max` | Per-exchange depth snapshot |
| `signal` | Info | `side`, `profit_space`, `net_profit`, `ratio_ask`/`ratio_bid`, `q_up`/`q_down`, `total_cost` | Entry signal fired |
| `order` | Info | `cid`, `side`, `price`, `filled`, `is_maker` | Order fill |
| `action_summary` | Info | `group_id`, `state`, `exec`, `maker_avg_price`, `maker_fill_qty`, `taker_avg_price`, `taker_fill_qty`, `taker_slp`, `taker_drift`, `duration_ms` | Action group end |

All records include a `time` field (ISO 8601 timestamp from logrus).

### `action_summary` states

- `filled` — both maker and taker legs filled successfully
- `rejected` — maker order rejected (e.g., GTX self-trade)
- `canceled` — maker order canceled (e.g., keep-range breach)

### `exec` values

| value | maker side | taker side | direction |
|---|---|---|---|
| `OpenLong` | sell | buy | +1 |
| `CloseShort` | sell | buy | +1 |
| `OpenShort` | buy | sell | −1 |
| `CloseLong` | buy | sell | −1 |
| `FixExposure` | varies | varies | n/a |

---

## order.py — Trade Analyzer

Reads the log, extracts filled `action_summary` records, and computes per-trade PnL.

### PnL Calculation

```
pnl_gross = |maker_fill_qty| × (taker_avg_price − maker_avg_price) × direction
fee       = (|maker_fill_qty| × maker_avg_price + |taker_fill_qty| × taker_avg_price) × taker_fee_rate
pnl_net   = pnl_gross − fee
```

### Usage

```bash
# Human-readable summary
python order.py -l path/to/backtest.log

# Verbose: include per-trade table
python order.py -l backtest.log -v

# JSON output
python order.py -l backtest.log -j -o results.json

# Custom taker fee (default: 0.015%)
python order.py -l backtest.log --fee 0.00016
```

### CLI Options

| Flag | Description | Default |
|---|---|---|
| `-l`, `--logfile` | Path to log file | `$LOG_DIR/$LOG_FILE` or `./logs/backtest.log` |
| `-j`, `--json` | Output JSON format | off |
| `-o`, `--output` | Write output to file | stdout |
| `-v`, `--verbose` | Show per-trade details | off |
| `--fee` | Taker fee rate | `0.00015` (0.015%) |

### Output Fields (summary)

| Field | Description |
|---|---|
| `total_actions` | Total action groups (all states) |
| `filled` | Successfully filled trades |
| `rejected` / `canceled` | Failed action groups |
| `open_long` / `close_long` / `open_short` / `close_short` | Breakdown by exec type |
| `win_rate` | Fraction of trades with pnl_net > 0 |
| `pnl_gross_total` / `pnl_net_total` | Aggregate PnL |
| `pnl_net_mean` | Average PnL per trade |
| `profit_rate` | pnl_net_total / total_notional |
| `fee_total` | Total fees paid |
| `avg_holding_ms` | Average trade duration (ms) |
| `avg_taker_slp` / `avg_taker_drift` | Average taker slippage / drift |

---

## trace.py — Visualization

Three-panel matplotlib figure with interactive tooltips (mplcursors).

### Panels

**Panel 1 — Ratio + Quantile Thresholds**
- `ratio_ask`, `ratio_bid` lines (from `indicator` records)
- `q_up`, `q_down` quantile thresholds (dashed)
- `entry_long`, `entry_short` entry thresholds (dotted)
- Vertical lines at `signal` events (green = long, red = short)
- Scatter markers on filled trades at `trigger_ratio`, colored by PnL; hover for details

**Panel 2 — Volatility + State Machine**
- `maker_buffer`, `no_cancel_range` lines (left axis)
- `exec_state`, `position_state` step charts (right axis, labeled)

**Panel 3 — PnL Distribution**
- Histogram of per-trade `pnl_net` with bins aligned at zero
- Break-even and mean vertical lines
- Summary text box (trade count, win rate, total PnL, profit rate, avg holding/slippage/drift)

### Usage

```bash
# All three panels
python trace.py -l backtest.log

# Single panel
python trace.py -l backtest.log -p 1   # ratio panel
python trace.py -l backtest.log -p 2   # volatility/state panel
python trace.py -l backtest.log -p 3   # PnL histogram

# Custom fee
python trace.py -l backtest.log --fee 0.00016
```

### CLI Options

| Flag | Description | Default |
|---|---|---|
| `-l`, `--logfile` | Path to log file | `$LOG_DIR/$LOG_FILE` or `./logs/backtest.log` |
| `-p`, `--panel` | Show single panel (1, 2, or 3) | all panels |
| `--fee` | Taker fee rate | `0.00015` (0.015%) |

---

## config.py — Config Management

Creates and manages backtest run configs. All runs are stored under a base directory controlled by `ANCHOR_CONFIG` (read from env or `.env` in the current directory; prompted and saved on first use).

### Subcommands

#### `create` — Scaffold a new run

Generates three config files under `$ANCHOR_CONFIG/<name>/`:

| File | Description |
|---|---|
| `backtest.json` | Backtest settings (shared by indicator and strategy runs) |
| `indicator.json` | Indicator params (period, frequency, percentiles) |
| `strategy.json` | Strategy params (fees, tracker, signal, etc.) |

The `indicator.output` field is set to `$ANCHOR_CONFIG/<name>/indicator` so generated CSVs land alongside the configs. The run is registered in `$ANCHOR_CONFIG/index.json`.

```bash
python backtest/config.py create \
  --name eth-v1 \
  --maker gateio.eth_usdt \
  --taker paradex.eth_usdc \
  --start 2026022611 \
  --end   2026022623 \
  --period 4h
```

All flags are optional — missing values are prompted interactively.

| Flag | Description |
|---|---|
| `--name` | Run name; determines output directory |
| `--maker` | Maker exchange + symbol (e.g. `gateio.eth_usdt`) |
| `--taker` | Taker exchange + symbol (e.g. `paradex.eth_usdc`) |
| `--start` | Strategy start date `YYYYmmddHH` |
| `--end` | Strategy end date `YYYYmmddHH` |
| `--period` | Indicator lookback period (e.g. `4h`) |

#### `copy` — Clone a run with optional overrides

```bash
# exact clone
python backtest/config.py copy eth-v1 eth-v2

# clone with new date range
python backtest/config.py copy eth-v1 eth-v2 --start 2026030100 --end 2026030123
```

Accepts the same override flags as `create`. Any flag not provided keeps the value from the source run.

#### `list` — List runs

```bash
# print all run names
python backtest/config.py list

# show details for specific runs
python backtest/config.py list eth-v1 eth-v2
```

---

## Typical Workflow

```bash
cd anchor/

# 1. Create run configs
python backtest/config.py create \
  --name eth-v1 \
  --maker gateio.eth_usdt --taker paradex.eth_usdc \
  --start 2026022611 --end 2026022623 --period 4h

# 2. Generate indicator (start is auto-shifted back by period in Go)
go run backtest/main.go indicator \
  -c $ANCHOR_CONFIG/eth-v1/indicator.json \
  -b $ANCHOR_CONFIG/eth-v1/backtest.json

# 3. Run strategy backtest
go run backtest/main.go strategy \
  -s $ANCHOR_CONFIG/eth-v1/strategy.json \
  -b $ANCHOR_CONFIG/eth-v1/backtest.json \
  -i $ANCHOR_CONFIG/eth-v1/indicator/q95.csv

# 4. Analyze trades
python backtest/order.py -l logs/backtest.log

# 5. Visualize
python backtest/trace.py -l logs/backtest.log
```

## Architecture Note

`trace.py` imports `read_jsons` and `analyze` from `order.py` to avoid duplicating log parsing and PnL computation. Both scripts must be in the same directory (or `order.py` must be importable).
