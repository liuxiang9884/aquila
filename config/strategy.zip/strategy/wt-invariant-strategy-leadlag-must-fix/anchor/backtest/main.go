package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"
	"runtime/pprof"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/utils/godotenv"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/backtest"
	"gitlab.com/hashingbotrepo/backend/xexchange/utils/tableview"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/anchor/algo"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/anchor/indicator"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

var Logger = logrus.New()
var JsonLog = logrus.New()
var RecordeLevel = logrus.InfoLevel

func init() {
	godotenv.Load(getEnv("ENVFILE", ".env"))
	Logger.SetFormatter(&logrus.TextFormatter{
		TimestampFormat: "2006-01-02 15:04:05.000",
		FullTimestamp:   true,
	})
	logFileName := path.Join(
		getEnv("LOG_DIR", "."),
		getEnv("LOG_FILE", "backtest.log"),
	)
	jsonLogFile, err := os.OpenFile(logFileName, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0666)
	if err != nil {
		Logger.Fatalf("Failed to open json log file: %v", err)
	}
	JsonLog.SetOutput(io.MultiWriter(os.Stdout, jsonLogFile))
	JsonLog.SetFormatter(&logrus.JSONFormatter{
		TimestampFormat:   "2006-01-02 15:04:05.000",
		DisableHTMLEscape: true,
		FieldMap: logrus.FieldMap{
			logrus.FieldKeyTime:  "ts",
			logrus.FieldKeyLevel: "level",
			logrus.FieldKeyMsg:   "msg",
		},
	})
	if text, ok := os.LookupEnv("RECORD_LEVEL"); ok {
		lv, err := logrus.ParseLevel(text)
		if err == nil {
			RecordeLevel = lv
			JsonLog.SetLevel(RecordeLevel)
		}
	}
}

func getEnv(key, _default string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return _default
}

func loadStrategyConfig(filename string) (*algo.V2Config, error) {
	data, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("failed to read strategy config: %w", err)
	}

	config := new(algo.V2Config)
	err = json.Unmarshal(data, config)
	if err != nil {
		return nil, fmt.Errorf("failed to parse strategy config: %w", err)
	}

	return config, nil
}

func generateSetting(config *algo.V2Config, backtestTemplate string) (*backtest.Setting, error) {
	data, err := os.ReadFile(backtestTemplate)
	if err != nil {
		return nil, fmt.Errorf("failed to read backtest template: %w", err)
	}

	setting := new(backtest.Setting)
	err = json.Unmarshal(data, setting)
	if err != nil {
		return nil, fmt.Errorf("failed to parse backtest template: %w", err)
	}

	setting.Group.Hourly.Data = backtest.GroupFiles{
		config.Maker.Exchange: {
			"perp": {fmt.Sprintf("%s_swap", config.Maker.Symbol)},
		},
		config.Taker.Exchange: {
			"perp": {fmt.Sprintf("%s_swap", config.Taker.Symbol)},
		},
	}

	return setting, nil
}

func loadBacktestSetting(filename string) (*backtest.Setting, error) {
	data, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("failed to read backtest setting: %w", err)
	}
	setting := new(backtest.Setting)
	if err := json.Unmarshal(data, setting); err != nil {
		return nil, fmt.Errorf("failed to parse backtest setting: %w", err)
	}
	return setting, nil
}

func runStrategy(strategyFile, backtestFile, indicatorFile string) {
	config, err := loadStrategyConfig(strategyFile)
	if err != nil {
		Logger.Fatal(err)
	}

	config.SetDefault()
	ctx := context.TODO()
	stg := config.New(Logger.WithContext(ctx))
	stg.SetRecorder(&recorder.LogRecorder{
		Log:   JsonLog.WithContext(ctx),
		Level: RecordeLevel,
	})

	setting, err := generateSetting(config, backtestFile)
	if err != nil {
		Logger.Fatal(err)
	}

	widgets, err := setting.NewBackTest(stg)
	if err != nil {
		panic(err)
	}

	// Register external indicator data if provided
	if indicatorFile != "" {
		reader, err := algo.NewIndicatorReader(indicatorFile)
		if err != nil {
			Logger.Fatal(err)
		}
		backtest.AddCustomData(widgets.Custom, reader, stg.OnIndicator)
		Logger.Infof("Registered external indicator: %s", indicatorFile)
	}

	start := time.Now()
	widgets.Run()
	end := time.Now()
	stg.Brief()

	orders := widgets.AllHistoryOrders()
	orderCounts := len(orders[1])
	startIdx := orderCounts - 20
	if startIdx < 0 {
		startIdx = 0
	}

	for key, accountOrders := range orders {
		Logger.Infof("History<Account=%d, Total=%d>:\n%s", key, orderCounts, tableview.ArrayToTableText(
			accountOrders[startIdx:],
			"Ex", "HostType", "ExchangePair",
			"OrderID", "ClientID", "ServerTime", "Contract",
			"Side", "Price", "Qty", "AvgFillPrc", "FilledQty", "Status",
			"OrderType",
		))
	}

	Logger.Infof("Backtest done in %s", end.Sub(start))
}

func runIndicator(configFile, backtestFile string) {
	data, err := os.ReadFile(configFile)
	if err != nil {
		Logger.Fatalf("failed to read indicator config: %v", err)
	}
	config := new(indicator.IndicatorConfig)
	if err := json.Unmarshal(data, config); err != nil {
		Logger.Fatalf("failed to parse indicator config: %v", err)
	}
	config.SetDefault()

	setting, err := loadBacktestSetting(backtestFile)
	if err != nil {
		Logger.Fatal(err)
	}

	// Shift the backtest start back by the indicator period to provide warmup data.
	// The backtest config stores the strategy date range; only the indicator run needs the shift.
	originalStart := setting.Group.Hourly.Range[0]
	strategyStart, err := time.Parse("2006010215", originalStart)
	if err != nil {
		Logger.Fatalf("failed to parse backtest start date %q: %v", originalStart, err)
	}
	indicatorStart := strategyStart.Add(-config.Period.Duration())
	setting.Group.Hourly.Range[0] = indicatorStart.Format("2006010215")
	Logger.Infof("Indicator warmup: shifted start %s → %s (period=%s)",
		originalStart, setting.Group.Hourly.Range[0], config.Period)

	ctx := context.TODO()
	stg := config.New(Logger.WithContext(ctx))

	widgets, err := setting.NewBackTest(stg)
	if err != nil {
		panic(err)
	}

	start := time.Now()
	widgets.Run()
	end := time.Now()
	stg.Brief()

	Logger.Infof("Indicator backtest done in %s", end.Sub(start))
}

// anchorConfigDir returns the $ANCHOR_CONFIG base directory, or exits if unset.
func anchorConfigDir() string {
	dir := os.Getenv("ANCHOR_CONFIG")
	if dir == "" {
		fmt.Fprintln(os.Stderr, "Error: ANCHOR_CONFIG environment variable is not set")
		os.Exit(1)
	}
	return dir
}

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintf(os.Stderr, "Usage: %s <command> [<name>] [flags]\n\nCommands:\n  strategy    Run strategy backtest\n  indicator   Generate indicator CSV\n\nPositional argument:\n  <name>      Run name under $ANCHOR_CONFIG. Resolves config file paths automatically.\n              Individual flags (-s, -b, -c, -i) override name-derived paths.\n", os.Args[0])
		os.Exit(1)
	}

	cmd := os.Args[1]
	os.Args = append(os.Args[:1], os.Args[2:]...)

	switch cmd {
	case "strategy":
		strategyCmd := flag.NewFlagSet("strategy", flag.ExitOnError)
		strategyFile := strategyCmd.String("s", "", "Path to strategy config JSON file")
		backtestFile := strategyCmd.String("b", "", "Path to backtest setting JSON file")
		indicatorFile := strategyCmd.String("i", "", "Path to external indicator CSV file (e.g. indicator/q95.csv)")
		cpuProfile := strategyCmd.String("cpuprofile", "", "Write CPU profile to file")
		memProfile := strategyCmd.String("memprofile", "", "Write memory profile to file")
		strategyCmd.Usage = func() {
			fmt.Fprintf(os.Stderr, "Usage: %s strategy [<name>] [-s <strategy.json>] [-b <backtest.json>] [-i <indicator.csv>]\n\n", os.Args[0])
			fmt.Fprintf(os.Stderr, "  <name>  Run name under $ANCHOR_CONFIG.\n")
			fmt.Fprintf(os.Stderr, "          Automatically sets -s, -b, and -i (indicator/$ANCHOR_INDICATOR.csv, default q95).\n")
			fmt.Fprintf(os.Stderr, "          Individual flags override name-derived paths.\n\n")
			fmt.Fprintf(os.Stderr, "Flags:\n")
			strategyCmd.PrintDefaults()
		}
		strategyCmd.Parse(os.Args[1:])

		if name := strategyCmd.Arg(0); name != "" {
			base := filepath.Join(anchorConfigDir(), name)
			if *strategyFile == "" {
				*strategyFile = filepath.Join(base, "strategy.json")
			}
			if *backtestFile == "" {
				*backtestFile = filepath.Join(base, "backtest.json")
			}
			if *indicatorFile == "" {
				quantile := getEnv("ANCHOR_INDICATOR", "q95")
				*indicatorFile = filepath.Join(base, "indicator", quantile+".csv")
			}
		}

		if *strategyFile == "" || *backtestFile == "" {
			fmt.Fprintf(os.Stderr, "Usage: %s strategy [<name>] [-s <strategy.json>] [-b <backtest.json>] [-i <indicator.csv>]\n\n  <name>  Run name under $ANCHOR_CONFIG. Sets -s, -b, and -i (q95.csv) automatically.\n\nFlags:\n", os.Args[0])
			strategyCmd.PrintDefaults()
			os.Exit(1)
		}

		setupProfiling(*cpuProfile, *memProfile)
		runStrategy(*strategyFile, *backtestFile, *indicatorFile)

	case "indicator":
		indicatorCmd := flag.NewFlagSet("indicator", flag.ExitOnError)
		configFile := indicatorCmd.String("c", "", "Path to indicator config JSON file")
		backtestFile := indicatorCmd.String("b", "", "Path to backtest setting JSON file")
		cpuProfile := indicatorCmd.String("cpuprofile", "", "Write CPU profile to file")
		memProfile := indicatorCmd.String("memprofile", "", "Write memory profile to file")
		indicatorCmd.Usage = func() {
			fmt.Fprintf(os.Stderr, "Usage: %s indicator [<name>] [-c <indicator.json>] [-b <backtest.json>]\n\n", os.Args[0])
			fmt.Fprintf(os.Stderr, "  <name>  Run name under $ANCHOR_CONFIG.\n")
			fmt.Fprintf(os.Stderr, "          Automatically sets -c and -b.\n")
			fmt.Fprintf(os.Stderr, "          Start date is shifted back by indicator period for warmup.\n\n")
			fmt.Fprintf(os.Stderr, "Flags:\n")
			indicatorCmd.PrintDefaults()
		}
		indicatorCmd.Parse(os.Args[1:])

		if name := indicatorCmd.Arg(0); name != "" {
			base := filepath.Join(anchorConfigDir(), name)
			if *configFile == "" {
				*configFile = filepath.Join(base, "indicator.json")
			}
			if *backtestFile == "" {
				*backtestFile = filepath.Join(base, "backtest.json")
			}
		}

		if *configFile == "" || *backtestFile == "" {
			fmt.Fprintf(os.Stderr, "Usage: %s indicator [<name>] [-c <indicator.json>] [-b <backtest.json>]\n\n  <name>  Run name under $ANCHOR_CONFIG. Sets -c and -b automatically.\n          Start date is shifted back by indicator period for warmup.\n\nFlags:\n", os.Args[0])
			indicatorCmd.PrintDefaults()
			os.Exit(1)
		}

		setupProfiling(*cpuProfile, *memProfile)
		runIndicator(*configFile, *backtestFile)

	default:
		fmt.Fprintf(os.Stderr, "Unknown command: %s\n\nCommands:\n  strategy    Run strategy backtest\n  indicator   Generate indicator CSV\n", cmd)
		os.Exit(1)
	}
}

func setupProfiling(cpuProfile, memProfile string) {
	if cpuProfile != "" {
		f, err := os.Create(cpuProfile)
		if err != nil {
			Logger.Fatalf("Could not create CPU profile: %v", err)
		}
		if err := pprof.StartCPUProfile(f); err != nil {
			f.Close()
			Logger.Fatalf("Could not start CPU profile: %v", err)
		}
		defer pprof.StopCPUProfile()
		defer f.Close()
	}
	if memProfile != "" {
		defer func() {
			f, err := os.Create(memProfile)
			if err != nil {
				Logger.Fatalf("Could not create memory profile: %v", err)
			}
			defer f.Close()
			if err := pprof.WriteHeapProfile(f); err != nil {
				Logger.Fatalf("Could not write memory profile: %v", err)
			}
		}()
	}
}
