#!/usr/bin/env python3
"""
Slippage vol analysis: HistoryVol vs FutureVol (PredictVol) correlation and coverage.

Replicates the vector simulation from slippage_sim.ipynb across multiple hourly files.

Usage:
    python slippage_vol.py \\
        --taker paradex.eth_usdc_swap \\
        --maker gateio.eth_usdt_swap \\
        --start 2026022601 --end 2026022623

Output (per hour + aggregate):
    - PredictVol vs HistoryVol correlation
    - Coverage rate (all ticks)
    - Coverage rate (ticks where history_max_vol is rising)

Environment:
    DATA_DIR  Root directory containing hourly data folders (read from .env if not set).
"""
import argparse
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# .env loader (mirrors config.py)
# ---------------------------------------------------------------------------

DOTENV_PATH = Path(".env")


def load_dotenv() -> None:
    if not DOTENV_PATH.exists():
        return
    with open(DOTENV_PATH) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


def save_dotenv(key: str, value: str) -> None:
    lines = []
    if DOTENV_PATH.exists():
        with open(DOTENV_PATH) as f:
            lines = f.readlines()
    new_line = f"{key}={value}\n"
    for i, line in enumerate(lines):
        if line.strip().startswith(f"{key}="):
            lines[i] = new_line
            break
    else:
        lines.append(new_line)
    with open(DOTENV_PATH, "w") as f:
        f.writelines(lines)


def get_env(key: str, prompt: str) -> str:
    value = os.environ.get(key)
    if value:
        return value
    value = input(f"{prompt}: ").strip()
    if not value:
        print(f"Error: {key} is required.", file=sys.stderr)
        sys.exit(1)
    os.environ[key] = value
    save_dotenv(key, value)
    return value


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

DATE_FMT = "%Y%m%d%H"


def parse_date(s: str) -> datetime:
    return datetime.strptime(s, DATE_FMT)


def date_to_str(dt: datetime) -> str:
    return dt.strftime(DATE_FMT)


def hourly_range(start: str, end: str):
    """Yield date_hour strings from start to end inclusive, stepping 1 hour."""
    cur = parse_date(start)
    stop = parse_date(end)
    while cur <= stop:
        yield date_to_str(cur)
        cur += timedelta(hours=1)


def file_path(data_dir: str, source: str, date_hour: str) -> Path:
    """Resolve {data_dir}/{date_hour}/{source}_{date_hour}.h5"""
    return Path(data_dir) / date_hour / f"{source}_{date_hour}.h5"


def load_bbo(path: Path, tablename: str = "bbo") -> pd.DataFrame:
    df = pd.read_hdf(path, tablename)
    df.index = df["localtime"].apply(lambda x: datetime.fromtimestamp(x / 1000))
    df.index.name = "localtime"
    return df


# ---------------------------------------------------------------------------
# Vol helpers (verbatim from slippage_sim.ipynb)
# ---------------------------------------------------------------------------

def get_vol(data: pd.DataFrame, column: str, period: str = "1s") -> pd.Series:
    resampled = data[column].resample(period, closed="right", label="right")
    hi = resampled.max()
    lo = resampled.min()
    return ((hi - lo) / (hi + lo) * 2).rename(f"{column}_vol")


def get_joined_vol(data: pd.DataFrame, period: str = "1s") -> pd.DataFrame:
    ask_vol = get_vol(data, "ask_price", period)
    bid_vol = get_vol(data, "bid_price", period)
    joined_vol = pd.concat([ask_vol, bid_vol], axis=1).max(axis=1).rename("joined_vol")
    return pd.concat([ask_vol, bid_vol, joined_vol], axis=1)


def rolling_max_vol(vol: pd.DataFrame, period: str = "30s") -> pd.DataFrame:
    return vol.rolling(period).max()


def apply_hist_vol(
    prices: pd.Series, rolling_vol: pd.Series, vol_period: str = "1s"
) -> pd.Series:
    times = prices.index
    floored = times.floor(vol_period)
    vals = prices.to_numpy(dtype=float)

    roll_at_floor = rolling_vol.reindex(floored, method="ffill").to_numpy(dtype=float)

    unclosed = np.empty(len(vals))
    cur_floor = floored[0]
    cur_max = vals[0]
    cur_min = vals[0]

    for i in range(len(vals)):
        if floored[i] != cur_floor:
            cur_floor = floored[i]
            cur_max = vals[i]
            cur_min = vals[i]
        else:
            if vals[i] > cur_max:
                cur_max = vals[i]
            if vals[i] < cur_min:
                cur_min = vals[i]
        unclosed[i] = (cur_max - cur_min) / (cur_max + cur_min) * 2

    return pd.Series(
        np.fmax(roll_at_floor, unclosed), index=prices.index, name="hist_vol"
    )


def source_hist_vol(
    data: pd.DataFrame, vol_period: str = "1s", vol_max_period: str = "30s"
) -> pd.Series:
    jvol = get_joined_vol(data, period=vol_period)
    rolling = rolling_max_vol(jvol, period=vol_max_period)
    ask_hv = apply_hist_vol(data["ask_price"], rolling["joined_vol"], vol_period=vol_period)
    bid_hv = apply_hist_vol(data["bid_price"], rolling["joined_vol"], vol_period=vol_period)
    return pd.Series(
        np.fmax(ask_hv.to_numpy(), bid_hv.to_numpy()),
        index=data.index,
        name="hist_vol",
    )


def vector_hist_vol(taker_hv: pd.Series, maker_hv: pd.Series) -> pd.DataFrame:
    t_df = pd.DataFrame({"taker": taker_hv.to_numpy()}, index=taker_hv.index)
    m_df = pd.DataFrame({"maker": maker_hv.to_numpy()}, index=maker_hv.index)
    combined = pd.concat([t_df, m_df], axis=0).sort_index()
    combined["taker"] = combined["taker"].ffill()
    combined["maker"] = combined["maker"].ffill()
    combined["history_max_vol"] = combined[["taker", "maker"]].max(axis=1)
    return combined


def get_future_vol(
    data: pd.DataFrame, column: str, period: str = "500ms"
) -> pd.Series:
    offset = pd.Timedelta(period)
    times = data.index
    prices = data[column].to_numpy(dtype=float)
    n = len(prices)
    result = np.empty(n)
    j = 0
    for i in range(n):
        while j < n and times[j] < times[i] + offset:
            j += 1
        window = prices[i:j]
        hi = window.max()
        lo = window.min()
        result[i] = (hi - lo) / (hi + lo) * 2
    return pd.Series(result, index=data.index, name=f"{column}_future_vol")


def get_joined_future_vol(data: pd.DataFrame, period: str = "500ms") -> pd.Series:
    ask_fv = get_future_vol(data, "ask_price", period)
    bid_fv = get_future_vol(data, "bid_price", period)
    return pd.Series(
        np.fmax(ask_fv.to_numpy(), bid_fv.to_numpy()),
        index=data.index,
        name="future_vol",
    )


# ---------------------------------------------------------------------------
# Per-hour analysis
# ---------------------------------------------------------------------------

def analyse_hour(
    taker: pd.DataFrame,
    maker: pd.DataFrame,
    vol_period: str = "1s",
    vol_max_period: str = "30s",
    future_period: str = "600ms",
) -> pd.DataFrame:
    """
    Returns a DataFrame with columns ['history_max_vol', 'predict_vol', 'future_vol']
    aligned to taker ticks.

    predict_vol = history_max_vol × √(future_period / vol_period)
    """
    taker_hv = source_hist_vol(taker, vol_period=vol_period, vol_max_period=vol_max_period)
    maker_hv = source_hist_vol(maker, vol_period=vol_period, vol_max_period=vol_max_period)

    sim = vector_hist_vol(taker_hv, maker_hv)

    taker_fv = get_joined_future_vol(taker, period=future_period)

    sim_hmv = sim["history_max_vol"]
    sim_hmv_dedup = sim_hmv[~sim_hmv.index.duplicated(keep="last")]
    hist_on_taker = sim_hmv_dedup.asof(taker_fv.index)

    scale = np.sqrt(
        pd.Timedelta(future_period).total_seconds()
        / pd.Timedelta(vol_period).total_seconds()
    )

    hmv = hist_on_taker.to_numpy()
    return pd.DataFrame(
        {
            "history_max_vol": hmv,
            "predict_vol": hmv * scale,
            "future_vol": taker_fv.to_numpy(),
        },
        index=taker_fv.index,
    )


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def compute_metrics(comparison: pd.DataFrame) -> dict:
    hmv = comparison["history_max_vol"]
    pv  = comparison["predict_vol"]
    fv  = comparison["future_vol"]

    rising = pd.Series(
        np.diff(hmv.to_numpy(), prepend=hmv.iloc[0]) > 0,
        index=hmv.index,
    )

    covered_hist = hmv >= fv
    covered_pred = pv  >= fv

    def _rising_cov(covered):
        return covered[rising].mean() if rising.any() else float("nan")

    return {
        "ticks":                  len(comparison),
        "corr":                   hmv.corr(fv),
        "pred_corr":              pv.corr(fv),
        # history_max_vol coverage
        "coverage_all":           covered_hist.mean(),
        "covered_count":          int(covered_hist.sum()),
        "coverage_rising":        _rising_cov(covered_hist),
        # predict_vol coverage
        "pred_coverage_all":      covered_pred.mean(),
        "pred_covered_count":     int(covered_pred.sum()),
        "pred_coverage_rising":   _rising_cov(covered_pred),
        "rising_ticks":           int(rising.sum()),
    }


def _pct(v) -> str:
    return f"{v:.2%}" if not np.isnan(v) else "n/a"


def print_metrics(label: str, m: dict) -> None:
    n = m["ticks"]
    print(f"\n{'='*64}")
    print(f"  {label}  ({n:,} ticks)")
    print(f"{'='*64}")
    print(f"  {'':30s}  {'hist_vol':>10}  {'predict_vol':>11}")
    print(f"  {'-'*30}  {'-'*10}  {'-'*11}")
    print(f"  {'Correlation vs future_vol':30s}  {m['corr']:>10.4f}  {m['pred_corr']:>11.4f}")
    print(f"  {'Coverage (all ticks)':30s}  {_pct(m['coverage_all']):>10}  {_pct(m['pred_coverage_all']):>11}")
    print(f"  {'Coverage (rising vol ticks)':30s}  {_pct(m['coverage_rising']):>10}  {_pct(m['pred_coverage_rising']):>11}")
    print(f"\n  Rising hist_max_vol ticks: {m['rising_ticks']:,}  ({m['rising_ticks']/n:.2%} of all)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Analyse HistoryVol vs FutureVol correlation and coverage."
    )
    p.add_argument("--taker", required=True, help="Taker source, e.g. paradex.eth_usdc_swap")
    p.add_argument("--maker", required=True, help="Maker source, e.g. gateio.eth_usdt_swap")
    p.add_argument("--start", required=True, help="Start date-hour (YYYYMMDDHH), inclusive")
    p.add_argument("--end", required=True, help="End date-hour (YYYYMMDDHH), inclusive")
    p.add_argument("--data-dir", default=None, help="Root data directory (default: $DATA_DIR)")
    p.add_argument("--tablename", default="bbo", help="HDF5 table name (default: bbo)")
    p.add_argument("--vol-period", default="1s", help="Volatility bucket period (default: 1s)")
    p.add_argument("--vol-max-period", default="30s", help="Rolling max window (default: 30s)")
    p.add_argument("--future-period", default="600ms", help="Future vol window (default: 600ms)")
    return p


def main() -> None:
    load_dotenv()
    args = build_arg_parser().parse_args()

    data_dir = args.data_dir or get_env("DATA_DIR", "Enter root data directory")

    hours = list(hourly_range(args.start, args.end))
    print(f"Processing {len(hours)} hour(s): {args.start} → {args.end}")

    all_comparisons: List[pd.DataFrame] = []
    skipped = 0

    for date_hour in hours:
        taker_path = file_path(data_dir, args.taker, date_hour)
        maker_path = file_path(data_dir, args.maker, date_hour)

        if not taker_path.exists() or not maker_path.exists():
            missing = []
            if not taker_path.exists():
                missing.append(str(taker_path))
            if not maker_path.exists():
                missing.append(str(maker_path))
            print(f"  [{date_hour}] SKIP — missing: {', '.join(missing)}")
            skipped += 1
            continue

        print(f"  [{date_hour}] loading ...", end="", flush=True)
        try:
            taker = load_bbo(taker_path, args.tablename)
            maker = load_bbo(maker_path, args.tablename)
            print(f" taker={len(taker):,} maker={len(maker):,} rows", end="", flush=True)

            comparison = analyse_hour(
                taker,
                maker,
                vol_period=args.vol_period,
                vol_max_period=args.vol_max_period,
                future_period=args.future_period,
            )
            m = compute_metrics(comparison)
            print(
                f"  corr={m['corr']:.4f}"
                f"  hist_cov={m['coverage_all']:.2%}"
                f"  pred_cov={m['pred_coverage_all']:.2%}"
                f"  rising={_pct(m['coverage_rising'])}/{_pct(m['pred_coverage_rising'])}"
            )
            all_comparisons.append(comparison)
        except Exception as exc:
            print(f"  ERROR: {exc}")
            skipped += 1

    if not all_comparisons:
        print("\nNo data processed — nothing to aggregate.")
        return

    print(f"\nProcessed {len(all_comparisons)} hour(s), skipped {skipped}.")

    aggregate = pd.concat(all_comparisons, axis=0)
    m = compute_metrics(aggregate)
    print_metrics(
        f"AGGREGATE  {args.taker} / {args.maker}  [{args.start}–{args.end}]", m
    )


if __name__ == "__main__":
    main()
