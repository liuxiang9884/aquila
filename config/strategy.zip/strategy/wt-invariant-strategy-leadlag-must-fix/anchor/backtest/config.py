#!/usr/bin/env python3
"""
Anchor config management CLI.

Subcommands:
  create  Scaffold a new config set from templates
  copy    Clone an existing run with optional overrides
  list    List runs recorded in the index
"""
import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# .env helpers
# ---------------------------------------------------------------------------

DOTENV_PATH = Path(".env")


def load_dotenv() -> None:
    """Load key=value pairs from .env into os.environ (does not overwrite existing env vars)."""
    if not DOTENV_PATH.exists():
        return
    with open(DOTENV_PATH) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


def save_dotenv(key: str, value: str) -> None:
    """Persist a key=value pair to .env, replacing existing entry if present."""
    lines = []
    if DOTENV_PATH.exists():
        with open(DOTENV_PATH) as f:
            lines = f.readlines()

    new_line = f"{key}={value}\n"
    for i, line in enumerate(lines):
        if line.strip().startswith(f"{key}=") or line.strip().startswith(f"{key} ="):
            lines[i] = new_line
            break
    else:
        lines.append(new_line)

    with open(DOTENV_PATH, "w") as f:
        f.writelines(lines)
    print(f"  saved {key} to {DOTENV_PATH.resolve()}")


def get_env(key: str, prompt: str) -> str:
    """Return env var value; if missing, prompt user, then save to .env."""
    val = os.environ.get(key, "").strip()
    if not val:
        val = input(f"{key} is not set. {prompt}: ").strip()
        if not val:
            sys.exit(f"Error: {key} is required.")
        save_dotenv(key, val)
        os.environ[key] = val
    return val


# ---------------------------------------------------------------------------
# Env / paths
# ---------------------------------------------------------------------------

load_dotenv()


def get_base_dir() -> Path:
    return Path(get_env("ANCHOR_CONFIG", "Enter base config directory"))


def index_path(base: Path) -> Path:
    return base / "index.json"


def run_dir(base: Path, name: str) -> Path:
    return base / name


# ---------------------------------------------------------------------------
# Index helpers
# ---------------------------------------------------------------------------

def load_index(base: Path) -> dict:
    p = index_path(base)
    if not p.exists():
        return {}
    with open(p) as f:
        return json.load(f)


def save_index(base: Path, index: dict) -> None:
    p = index_path(base)
    with open(p, "w") as f:
        json.dump(index, f, indent=4)
        f.write("\n")
    print(f"  updated {p}")


def register(base: Path, name: str, maker: str, taker: str, start: str, end: str, period: str) -> None:
    index = load_index(base)
    index[name] = {
        "path": str(run_dir(base, name).resolve()),
        "maker": maker,
        "taker": taker,
        "start": start,
        "end": end,
        "period": period,
        "created_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
    }
    save_index(base, index)


# ---------------------------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------------------------

def load(path) -> dict:
    with open(path) as f:
        return json.load(f)


def save(path, data: dict) -> None:
    with open(path, "w") as f:
        json.dump(data, f, indent=4)
        f.write("\n")
    print(f"  wrote {path}")


# ---------------------------------------------------------------------------
# Symbol helpers
# ---------------------------------------------------------------------------

def parse_symbol(symbol: str) -> tuple:
    parts = symbol.split(".", 1)
    if len(parts) != 2:
        sys.exit(f"Invalid symbol '{symbol}'. Expected 'exchange.coin_quote' e.g. gateio.eth_usdt")
    return parts[0], parts[1]


def replace_base(symbol: str, new_base: str) -> str:
    """Replace the base currency in a symbol, e.g. gateio.eth_usdt -> gateio.btc_usdt."""
    exchange, coin_quote = parse_symbol(symbol)
    parts = coin_quote.split("_", 1)
    if len(parts) != 2:
        sys.exit(f"Invalid coin_quote '{coin_quote}' in symbol '{symbol}'. Expected 'coin_quote' e.g. eth_usdt")
    return f"{exchange}.{new_base}_{parts[1]}"


EXCHANGE_LATENCIES = {
    "gateio":  {"req": {"type": "fixed", "fixed": 2,   "real": False},
                "resp": {"type": "fixed", "fixed": 2,  "real": False},
                "public": {"type": "fixed", "fixed": 2, "real": True}},
    "bybit":   {"req": {"type": "fixed", "fixed": 20,  "real": False},
                "resp": {"type": "fixed", "fixed": 20, "real": False},
                "public": {"type": "fixed", "fixed": 30, "real": True}},
    "paradex": {"req": {"type": "fixed", "fixed": 500, "real": False},
                "resp": {"type": "fixed", "fixed": 100, "real": False},
                "public": {"type": "fixed", "fixed": 10, "real": True}},
}


def build_backtest_data(maker: str, taker: str) -> dict:
    data = {}
    for sym in (maker, taker):
        exchange, coin_quote = parse_symbol(sym)
        instrument = coin_quote if coin_quote.endswith("_swap") else coin_quote + "_swap"
        if exchange not in data:
            data[exchange] = {"perp": []}
        if instrument not in data[exchange]["perp"]:
            data[exchange]["perp"].append(instrument)
    return data


def build_latencies(maker: str, taker: str) -> dict:
    latencies = {}
    for sym in (maker, taker):
        exchange, _ = parse_symbol(sym)
        if exchange not in latencies and exchange in EXCHANGE_LATENCIES:
            latencies[exchange] = EXCHANGE_LATENCIES[exchange]
    return latencies


# ---------------------------------------------------------------------------
# Config builders
# ---------------------------------------------------------------------------

def get_data_dir() -> str:
    return get_env("DATA_DIR", "Enter root data directory")


def make_backtest_cfg(maker: str, taker: str, start: str, end: str) -> dict:
    return {
        "group": {
            "hourly": {
                "data": build_backtest_data(maker, taker),
                "root": get_data_dir(),
                "range": [start, end],
                "Memory": "128M",
            }
        },
        "global": {
            "tick_ms": 0,
            "incr_tick": True,
            "sizes": [5],
            "depth_mode": "tick",
            "raw_bbo": True,
            "market_reduce_split": 0.5,
        },
        "latency": {
            "req":    {"type": "fixed", "fixed": 0, "real": False},
            "resp":   {"type": "fixed", "fixed": 0, "real": False},
            "public": {"type": "fixed", "fixed": 0, "real": True},
        },
        "latencies": build_latencies(maker, taker),
    }


def make_indicator_cfg(maker: str, taker: str, period: str, indicator_output: str) -> dict:
    return {
        "maker": maker,
        "taker": taker,
        "period": period,
        "frequency": "10s",
        "roll": "5m",
        "percentiles": [0.9, 0.95, 0.99],
        "output": indicator_output,
    }


def make_strategy_cfg(maker: str, taker: str) -> dict:
    return {
        "maker": maker,
        "taker": taker,
        "maker_fee": 0,
        "taker_fee": 0,
        "qty_rule": {"type": "dynamic", "pos": 2000, "open": 100, "close": 105, "impact": 0.5, "clean": 500},
        "tracker": {
            "taker": {"window": "1s", "ema": "30s", "max_period": "30s", "max_ema": "60s"},
            "maker": {"window": "1s", "ema": "30s", "max_period": "30s", "max_ema": "60s"},
            "quantile": {
                "source": "indicator",
                "init": {"up": 0.0001, "down": -0.0001},
                "threshold": {"up": 0.95, "down": 0.05},
            },
        },
        "signal": {
            "profit_target": 0.0001,
            "slippage": {"init": 0.00015, "type": "fixed"},
            "drift": {"init": 0, "type": "fixed"},
            "maker_latency": "200ms",
            "taker_latency": "1s",
        },
        "execute": {"multiplier": 3, "slippage": 0.001},
        "position": {"exposure_tolerance": 10},
        "store": {"period": "1s"},
    }


# ---------------------------------------------------------------------------
# Interactive prompt helpers
# ---------------------------------------------------------------------------

def require(value, flag: str, prompt: str) -> str:
    if value:
        return value
    v = input(f"{prompt}: ").strip()
    if not v:
        sys.exit(f"Error: {flag} is required.")
    return v


# ---------------------------------------------------------------------------
# write_run: create files for a run given resolved params
# ---------------------------------------------------------------------------

def write_run(base: Path, name: str, maker: str, taker: str, start: str, end: str, period: str) -> None:
    out = run_dir(base, name)
    out.mkdir(parents=True, exist_ok=True)

    indicator_output = str((out / "indicator").resolve())

    save(out / "backtest.json",  make_backtest_cfg(maker, taker, start, end))
    save(out / "indicator.json", make_indicator_cfg(maker, taker, period, indicator_output))
    save(out / "strategy.json",  make_strategy_cfg(maker, taker))
    register(base, name, maker, taker, start, end, period)
    print(f"\nRun '{name}' created at {out.resolve()}")


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------

def cmd_create(args):
    base = get_base_dir()
    name   = require(args.name,   "--name",   "Run name")
    maker  = require(args.maker,  "--maker",  "Maker symbol (e.g. gateio.eth_usdt)")
    taker  = require(args.taker,  "--taker",  "Taker symbol (e.g. paradex.eth_usdc)")
    start  = require(args.start,  "--start",  "Strategy start date (YYYYmmddHH)")
    end    = require(args.end,    "--end",    "Strategy end date (YYYYmmddHH)")
    period = require(args.period, "--period", "Indicator period (e.g. 4h)")

    write_run(base, name, maker, taker, start, end, period)


def cmd_copy(args):
    base = get_base_dir()
    src, dst = args.src, args.dst

    index = load_index(base)
    if src not in index:
        sys.exit(f"Error: run '{src}' not found in index.")

    entry = index[src]
    maker  = args.maker  or entry["maker"]
    taker  = args.taker  or entry["taker"]
    start  = args.start  or entry["start"]
    end    = args.end    or entry["end"]
    period = args.period or entry["period"]

    if args.base:
        maker = replace_base(maker, args.base)
        taker = replace_base(taker, args.base)

    write_run(base, dst, maker, taker, start, end, period)


def cmd_list(args):
    base = get_base_dir()
    index = load_index(base)

    if not index:
        print("No runs found.")
        return

    if not args.names:
        for name in index:
            print(name)
    else:
        for name in args.names:
            if name not in index:
                print(f"{name}: not found")
                continue
            entry = index[name]
            print(f"\n[{name}]")
            for k, v in entry.items():
                print(f"  {k}: {v}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        prog="config.py",
        description="Anchor backtest config management",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # -- create --
    p_create = sub.add_parser("create", help="Scaffold a new config set from templates")
    p_create.add_argument("--name",   help="Run name")
    p_create.add_argument("--maker",  help="Maker symbol e.g. gateio.eth_usdt")
    p_create.add_argument("--taker",  help="Taker symbol e.g. paradex.eth_usdc")
    p_create.add_argument("--start",  help="Strategy start YYYYmmddHH")
    p_create.add_argument("--end",    help="Strategy end YYYYmmddHH")
    p_create.add_argument("--period", help="Indicator period e.g. 4h")

    # -- copy --
    p_copy = sub.add_parser("copy", help="Clone a run with optional overrides")
    p_copy.add_argument("src", help="Source run name")
    p_copy.add_argument("dst", help="Destination run name")
    p_copy.add_argument("--maker",  help="Override maker symbol")
    p_copy.add_argument("--taker",  help="Override taker symbol")
    p_copy.add_argument("--base",   help="Replace base currency in both maker and taker (e.g. btc)")
    p_copy.add_argument("--start",  help="Override strategy start YYYYmmddHH")
    p_copy.add_argument("--end",    help="Override strategy end YYYYmmddHH")
    p_copy.add_argument("--period", help="Override indicator period")

    # -- list --
    p_list = sub.add_parser("list", help="List runs in index")
    p_list.add_argument("names", nargs="*", help="Run names to show details for (omit to list all keys)")

    args = parser.parse_args()

    if args.cmd == "create":
        cmd_create(args)
    elif args.cmd == "copy":
        cmd_copy(args)
    elif args.cmd == "list":
        cmd_list(args)


if __name__ == "__main__":
    main()
