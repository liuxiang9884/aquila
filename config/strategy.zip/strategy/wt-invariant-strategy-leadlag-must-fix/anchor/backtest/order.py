#!/usr/bin/env python3
"""
Order analyzer for anchor strategy backtest results.

Reads newline-delimited JSON logs produced by the anchor strategy,
extracts action_summary records, and computes per-trade PnL and
aggregate statistics.

Usage:
    python order.py summary backtest.log
    python order.py summary backtest.log -j -o results.json
    python order.py summary backtest.log -v
    python order.py trades backtest.log
    python order.py trades backtest.log -o trades.csv
"""

import argparse
import json
import os
from collections import deque
from typing import Dict, List, Optional, Tuple

import pandas as pd


# Fee rate per exchange. Edit here to adjust costs.
EXCHANGE_FEE: Dict[str, float] = {
    "gateio":  0.0,
    "paradex": 0.0,
}

# Default log file location
DEFAULT_LOG_FILE = os.path.join(
    os.getenv("LOG_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")),
    os.getenv("LOG_FILE", "backtest.log"),
)


def read_jsons(logfile: str, groupby: str) -> Dict[str, pd.DataFrame]:
    """Read JSON-lines log and group into DataFrames by *groupby* field."""
    rows: Dict[str, List] = {}
    with open(logfile, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            doc = json.loads(line)
            key = doc.get(groupby, "")
            rows.setdefault(key, []).append(doc)

    dfs = {}
    for k, v in rows.items():
        df = pd.DataFrame(v)
        if "ts" in df.columns:
            df.index = pd.to_datetime(df["ts"])
        elif "time" in df.columns:
            df.index = pd.to_datetime(df["time"])
        dfs[k] = df
    return dfs


def build_order_index(orders_df: Optional[pd.DataFrame]) -> dict:
    """Build cid → last order record dict (last record per cid has final fill state)."""
    if orders_df is None or orders_df.empty or "cid" not in orders_df.columns:
        return {}
    # logs are chronological — later rows overwrite earlier ones for the same cid
    return {row["cid"]: row for _, row in orders_df.iterrows()}


EXEC_SIDE = {
    "OpenLong":   1,
    "CloseShort": 1,
    "OpenShort":  -1,
    "CloseLong":  -1,
}


def build_action_index(actions_df: Optional[pd.DataFrame]) -> dict:
    """Build group_id → action row dict from action_summary DataFrame."""
    if actions_df is None or actions_df.empty or "group_id" not in actions_df.columns:
        return {}
    return {row["group_id"]: row for _, row in actions_df.iterrows()}


def compute_trade(row: pd.Series, order_index: dict) -> dict:
    """
    Compute PnL for a single action_summary record from its orders.

    Collects all orders in ids, then for each order:
      - pnl contribution = -side * filled * avg_price
          side=-1 (sell) → positive (received funds)
          side=+1 (buy)  → negative (spent funds)
      - fee = filled * avg_price * EXCHANGE_FEE[exchange]

    Returns pnl_gross, fee, pnl_net, total notional, long_avg_price, short_avg_price.
    """
    pnl_gross = 0.0
    fee = 0.0
    notional = 0.0
    exposure = 0.0
    long_notional = 0.0
    long_qty = 0.0
    short_notional = 0.0
    short_qty = 0.0

    net_taker_qty = 0
    for cid in str(row.get("ids", "")).split(","):
        cid = cid.strip()
        if not cid:
            continue
        o = order_index.get(cid)
        if o is None:
            continue
        filled = float(o.get("filled", 0))
        price  = float(o.get("avg_price", 0))
        side   = float(o.get("side", 0))
        exch   = str(o.get("exchange", ""))
        order_notional = filled * price
        pnl_gross += -side * order_notional
        fee       += order_notional * EXCHANGE_FEE.get(exch, 0.0)
        notional  += order_notional
        exposure  += filled * side
        if side > 0:
            long_notional += order_notional
            long_qty      += filled
        elif side < 0:
            short_notional += order_notional
            short_qty      += filled
        if not o["is_maker"]:
            net_taker_qty +=  side * filled

    long_avg_price  = long_notional  / long_qty  if long_qty  > 0 else 0.0
    short_avg_price = short_notional / short_qty if short_qty > 0 else 0.0
    side = EXEC_SIDE.get(str(row.get("exec", "")), 0)
    if long_avg_price > 0 and short_avg_price > 0:
        if side > 0:
            avg_ratio = long_avg_price / short_avg_price - 1
        elif side < 0:
            avg_ratio = short_avg_price / long_avg_price - 1
        else:
            avg_ratio = 0.0
    else:
        avg_ratio = 0.0
    return {
        "notional":        notional,
        "pnl_gross":       pnl_gross,
        "fee":             fee,
        "pnl_net":         pnl_gross - fee,
        "exposure":        exposure,
        "long_qty":        long_qty,
        "short_qty":       short_qty,
        "net_qty":         net_taker_qty,
        "long_avg_price":  long_avg_price,
        "short_avg_price": short_avg_price,
        "side":            side,
        "avg_ratio":       avg_ratio,
    }


def compute_trades(summaries: pd.DataFrame, order_index: dict) -> pd.DataFrame:
    """Apply compute_trade to every filled action_summary row. Returns only the computed columns."""
    return summaries.apply(
        lambda row: compute_trade(row, order_index),
        axis=1,
        result_type="expand",
    )


def fifo_match_trades(trades: pd.DataFrame) -> Tuple[pd.DataFrame, float]:
    """
    FIFO-match open actions with close actions to form round-trip trades.

    OpenLong is matched with CloseLong; OpenShort is matched with CloseShort.
    When quantities differ, the overlapping quantity is split and paired.
    Unmatched open positions are excluded from the result.

    Returns (matched_df, unmatched_qty) where unmatched_qty is the total
    remaining open quantity after all close actions are processed.
    """
    CLOSE_TO_OPEN: Dict[str, str] = {"CloseLong": "OpenLong", "CloseShort": "OpenShort"}
    df = trades.sort_index()
    # Each queue entry: [remaining_qty, row_as_dict, timestamp]
    # net_qty carries direction: positive = taker bought (OpenLong/CloseShort),
    #                            negative = taker sold  (OpenShort/CloseLong)
    queues: Dict[str, deque] = {"OpenLong": deque(), "OpenShort": deque()}
    matched: List[dict] = []

    for ts, row in df.iterrows():
        exec_type = str(row.get("exec", ""))
        pos_qty = abs(float(row.get("net_qty", 0) or 0))
        if pos_qty <= 0:
            continue

        if exec_type in queues:
            queues[exec_type].append([pos_qty, dict(row), ts])
        elif exec_type in CLOSE_TO_OPEN:
            open_exec = CLOSE_TO_OPEN[exec_type]
            queue = queues[open_exec]
            remaining = pos_qty

            while remaining > 1e-9 and queue:
                entry = queue[0]
                open_remaining, open_row, open_ts = entry[0], entry[1], entry[2]
                open_total = abs(float(open_row["net_qty"]))
                match_qty = min(open_remaining, remaining)
                open_frac = match_qty / open_total
                close_frac = match_qty / pos_qty

                pnl_gross = open_frac * float(open_row["pnl_gross"]) + close_frac * float(row["pnl_gross"])
                pnl_net = open_frac * float(open_row["pnl_net"]) + close_frac * float(row["pnl_net"])
                notional = open_frac * float(open_row["notional"]) + close_frac * float(row["notional"])
                try:
                    duration_ms = (ts - open_ts).total_seconds() * 1000
                except Exception:
                    duration_ms = float("nan")

                matched.append({
                    "exec":            open_exec,
                    "open_id":         open_row.get("group_id"),
                    "close_id":        row.get("group_id"),
                    "qty":             match_qty,
                    "notional":        notional,
                    "pnl_gross":       pnl_gross,
                    "pnl_net":         pnl_net,
                    "duration_ms":     duration_ms,
                    "taker_slp":       row.get("taker_slp"),
                    "taker_drift":     row.get("taker_drift"),
                    "predict_slp":     row.get("predict_slp"),
                    "predict_drift":   row.get("predict_drift"),
                    "open_avg_ratio":  open_row.get("avg_ratio"),
                    "close_avg_ratio": row.get("avg_ratio"),
                    "open_time":       open_ts,
                    "close_time":      ts,
                })

                entry[0] -= match_qty
                remaining -= match_qty
                if entry[0] <= 1e-9:
                    queue.popleft()

    unmatched_qty = sum(entry[0] for q in queues.values() for entry in q)

    if not matched:
        return pd.DataFrame(), unmatched_qty

    result = pd.DataFrame(matched)
    result.index = pd.to_datetime(result["close_time"])
    return result, unmatched_qty


def cash_flow_for_match(match_row: dict, action_index: dict, order_index: dict) -> dict:
    """
    Recompute pnl_gross and fee for one matched trade from raw orders.

    For each leg (open_id, close_id):
      1. Look up the action_summary row by group_id.
      2. Walk its order ids and sum pnl_gross / fee from raw order fills.
      3. Scale the leg's contribution by (match_qty / abs(leg_net_qty))
         to handle partial matches.

    Returns {"pnl_gross": ..., "fee": ..., "pnl_net": ...}.
    """
    match_qty = float(match_row.get("qty", 0))
    total_pnl_gross = 0.0
    total_fee = 0.0

    for gid in (match_row.get("open_id"), match_row.get("close_id")):
        action = action_index.get(gid)
        if action is None:
            continue

        leg_pnl_gross = 0.0
        leg_fee = 0.0
        leg_net_qty = 0.0

        for cid in str(action.get("ids", "")).split(","):
            cid = cid.strip()
            if not cid:
                continue
            o = order_index.get(cid)
            if o is None:
                continue
            filled = float(o.get("filled", 0))
            price  = float(o.get("avg_price", 0))
            side   = float(o.get("side", 0))
            exch   = str(o.get("exchange", ""))
            notional = filled * price
            leg_pnl_gross += -side * notional
            leg_fee       += notional * EXCHANGE_FEE.get(exch, 0.0)
            if not o["is_maker"]:
                leg_net_qty += side * filled

        frac = match_qty / abs(leg_net_qty) if abs(leg_net_qty) > 1e-12 else 1.0
        total_pnl_gross += frac * leg_pnl_gross
        total_fee       += frac * leg_fee

    return {
        "pnl_gross": total_pnl_gross,
        "fee":       total_fee,
        "pnl_net":   total_pnl_gross - total_fee,
    }


def match_order_flows(
    matched: pd.DataFrame,
    action_index: dict,
    order_index: dict,
) -> pd.DataFrame:
    """
    Expand every matched trade into its constituent raw order fills.

    For each matched trade, both the open and close legs are walked
    order-by-order. Each order's contribution is scaled by
    (match_qty / abs(leg_net_qty)) to reflect partial matching.

    Returns a DataFrame with one row per raw order fill, columns:
      open_id, close_id, leg (open/close), cid, exchange,
      side, filled, avg_price, notional, pnl_gross, fee, frac
    """
    rows: List[dict] = []

    for _, match in matched.iterrows():
        open_id   = match.get("open_id")
        close_id  = match.get("close_id")
        match_qty = float(match.get("qty", 0))

        for leg, gid in (("open", open_id), ("close", close_id)):
            action = action_index.get(gid)
            if action is None:
                continue

            leg_net_qty = 0.0
            leg_orders: List[dict] = []

            for cid in str(action.get("ids", "")).split(","):
                cid = cid.strip()
                if not cid:
                    continue
                o = order_index.get(cid)
                if o is None:
                    continue
                filled   = float(o.get("filled", 0))
                price    = float(o.get("avg_price", 0))
                side     = float(o.get("side", 0))
                exch     = str(o.get("exchange", ""))
                notional = filled * price
                if not o["is_maker"]:
                    leg_net_qty += side * filled
                leg_orders.append({
                    "open_id":   open_id,
                    "close_id":  close_id,
                    "leg":       leg,
                    "cid":       cid,
                    "exchange":  exch,
                    "side":      side,
                    "filled":    filled,
                    "avg_price": price,
                    "notional":  notional,
                    "pnl_gross": -side * notional,
                    "fee":       notional * EXCHANGE_FEE.get(exch, 0.0),
                })

            frac = match_qty / abs(leg_net_qty) if abs(leg_net_qty) > 1e-12 else 1.0
            for r in leg_orders:
                r["frac"]      = frac
                r["pnl_gross"] *= frac
                r["fee"]       *= frac
                r["notional"]  *= frac
                r["filled"]    *= frac
            rows.extend(leg_orders)

    return pd.DataFrame(rows)


def verify_matches(
    matched: pd.DataFrame,
    dfs: Dict[str, pd.DataFrame],
    tol: float = 1e-8,
) -> pd.DataFrame:
    """
    Verify every matched trade's stored pnl_gross / pnl_net against
    raw-order cash flow recomputed via cash_flow_for_match.

    Returns a DataFrame of mismatches (empty if all correct).
    Each row has: open_id, close_id, field, stored, computed, diff.
    """
    action_index = build_action_index(dfs.get("action_summary"))
    order_index  = build_order_index(dfs.get("order"))

    mismatches: List[dict] = []
    for _, row in matched.iterrows():
        real = cash_flow_for_match(dict(row), action_index, order_index)
        for field in ("pnl_gross", "pnl_net"):
            stored   = float(row.get(field, float("nan")))
            computed = real[field]
            if abs(stored - computed) > tol:
                mismatches.append({
                    "open_id":  row.get("open_id"),
                    "close_id": row.get("close_id"),
                    "field":    field,
                    "stored":   stored,
                    "computed": computed,
                    "diff":     stored - computed,
                })

    return pd.DataFrame(mismatches)


def analyze(dfs: Dict[str, pd.DataFrame]) -> Tuple[Optional[pd.DataFrame], dict]:
    """Return (trades_df, summary_dict)."""
    if "action_summary" not in dfs:
        return None, {"error": "no action_summary records found"}

    actions = dfs["action_summary"]
    total_actions = len(actions)
    filled = actions[actions["fill_count"]>0].copy()
    rejected = len(actions[actions["state"] == "rejected"])
    canceled = len(actions[actions["state"] == "canceled"])
    if "maker_fill_qty" in actions.columns and "taker_fill_qty" in actions.columns:
        reverted = int(
            ((filled["maker_fill_qty"].fillna(0) != 0) & (filled["taker_fill_qty"].fillna(0) == 0)).sum()
        )
    else:
        reverted = None

    if filled.empty:
        return None, {
            "total_actions": total_actions,
            "filled": 0,
            "rejected": rejected,
            "canceled": canceled,
            "reverted": reverted,
            "unmatched_qty": 0.0,
        }

    order_index = build_order_index(dfs.get("order"))
    computed = compute_trades(filled, order_index)
    trades = filled.copy()
    trades[computed.columns] = computed

    matched, unmatched_qty = fifo_match_trades(trades)

    if matched.empty:
        return None, {
            "total_actions": total_actions,
            "filled": 0,
            "rejected": rejected,
            "canceled": canceled,
            "reverted": reverted,
            "unmatched_qty": unmatched_qty,
        }

    net_wins = (matched["pnl_net"] > 0).sum()
    gross_wins = (matched["pnl_gross"] > 0).sum()
    total = len(matched)
    total_notional = matched["notional"].sum()

    matched_long = len(matched[matched["exec"] == "OpenLong"])
    matched_short = len(matched[matched["exec"] == "OpenShort"])

    summary = {
        "total_actions": total_actions,
        "filled": total,
        "rejected": rejected,
        "canceled": canceled,
        "unmatched_qty": unmatched_qty,
        "reverted": reverted,
        "matched_long": matched_long,
        "matched_short": matched_short,
        "gross_win_rate": gross_wins / total if total else 0,
        "pnl_gross_total": matched["pnl_gross"].sum(),
        "pnl_gross_mean": matched["pnl_gross"].mean(),
        "net_win_rate": net_wins / total if total else 0,
        "pnl_net_total": matched["pnl_net"].sum(),
        "pnl_net_mean": matched["pnl_net"].mean(),
        "profit_rate": matched["pnl_net"].sum() / total_notional if total_notional else 0,
        "avg_holding_ms": matched["duration_ms"].mean(),
        "avg_taker_slp": matched["taker_slp"].mean() if "taker_slp" in matched.columns else None,
        "avg_taker_drift": matched["taker_drift"].mean() if "taker_drift" in matched.columns else None,
        "avg_predict_slp": matched["predict_slp"].mean() if "predict_slp" in matched.columns else None,
        "avg_predict_drift": matched["predict_drift"].mean() if "predict_drift" in matched.columns else None,
    }

    return matched, summary


def print_summary(summary: dict) -> None:
    print("\n" + "=" * 60)
    print("SUMMARY STATISTICS")
    print("=" * 60)
    for key, value in summary.items():
        display_key = " ".join(w.capitalize() for w in key.split("_"))
        if "rate" in key:
            print(f"  {display_key}: {value * 100:.2f}%")
        elif isinstance(value, float):
            print(f"  {display_key}: {value:.4f}")
        else:
            print(f"  {display_key}: {value}")


TRADES_COLS = [
    "open_id", "close_id", "exec", "qty",
    "pnl_gross", "pnl_net", "notional",
    "open_avg_ratio", "close_avg_ratio",
    "duration_ms", "open_time", "close_time",
    "taker_slp", "taker_drift", "predict_slp", "predict_drift",
]


def main():
    parser = argparse.ArgumentParser(description="Analyze anchor strategy backtest results")
    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")
    subparsers.required = True

    # --- summary ---
    p_sum = subparsers.add_parser("summary", help="Show aggregate PnL statistics")
    p_sum.add_argument("logfiles", nargs="*", default=[DEFAULT_LOG_FILE], help="Path(s) to log file(s)")
    p_sum.add_argument("-j", "--json", action="store_true", help="Output JSON")
    p_sum.add_argument("-o", "--output", help="Output file path")
    p_sum.add_argument("-v", "--verbose", action="store_true", help="Include per-trade list in output")

    # --- trades ---
    p_trades = subparsers.add_parser("trades", help="Show matched round-trip trades")
    p_trades.add_argument("logfile", nargs="?", default=DEFAULT_LOG_FILE, help="Path to log file")
    p_trades.add_argument("-o", "--output", help="Output file path (CSV)")
    p_trades.add_argument("-r", "--range", help="Show range, sample: '0:10'")

    args = parser.parse_args()
    print(f"Exchange fees: { {k: f'{v*100:.4f}%' for k, v in EXCHANGE_FEE.items()} }")

    if args.command == "summary":
        if len(args.logfiles) > 1:
            rows = []
            for logfile in args.logfiles:
                dfs = read_jsons(logfile, "type")
                _, summary = analyze(dfs)
                summary["logfile"] = os.path.basename(logfile)
                rows.append(summary)
            df = pd.DataFrame(rows).set_index("logfile")
            rate_cols = {c for c in df.columns if "rate" in c}
            df_display = df.copy()
            for col in df_display.columns:
                if col in rate_cols:
                    df_display[col] = df_display[col].map(lambda x: f"{x * 100:.2f}%" if isinstance(x, float) else x)
                elif df_display[col].dtype == float:
                    df_display[col] = df_display[col].map(lambda x: f"{x:.4f}" if isinstance(x, float) else x)
            print("\n" + "=" * 60)
            print("SUMMARY COMPARISON")
            print("=" * 60)
            print(df_display.T.to_string())
            return

        logfile = args.logfiles[0]
        print(f"Log file: {logfile}")
        dfs = read_jsons(logfile, "type")
        trades, summary = analyze(dfs)
        unmatched_qty = summary.get("unmatched_qty", 0.0)

        if args.json:
            output = {
                "metadata": {"log_file": logfile, "exchange_fees": EXCHANGE_FEE},
                "summary": summary,
            }
            if args.verbose and trades is not None:
                cols = [c for c in TRADES_COLS if c in trades.columns]
                output["trades"] = trades[cols].to_dict(orient="records")
            json_str = json.dumps(output, indent=2, default=str)
            if args.output:
                with open(args.output, "w") as f:
                    f.write(json_str)
                print(f"Results saved to {args.output}")
            else:
                print(json_str)
        else:
            print_summary(summary)
            if unmatched_qty > 1e-9:
                print(f"\n  WARNING: {unmatched_qty:.4f} qty unmatched (open positions excluded from PnL)")
            if args.verbose and trades is not None:
                print("\n" + "=" * 60)
                print("PER-TRADE DETAILS")
                print("=" * 60)
                cols = [c for c in TRADES_COLS if c in trades.columns]
                print(trades[cols].to_string())

    elif args.command == "trades":
        logfile = args.logfile
        print(f"Log file: {logfile}")
        dfs = read_jsons(logfile, "type")
        trades, _ = analyze(dfs)

        if trades is None or trades.empty:
            print("No matched trades found.")
            return

        cols = [c for c in TRADES_COLS if c in trades.columns]
        if args.range:
            start, end = map(int, args.range.split(":"))
            trades = trades.iloc[start:end]

        if args.output:
            trades[cols].to_csv(args.output)
            print(f"Results saved to {args.output}")
        else:
            print(trades[cols])


if __name__ == "__main__":
    main()
