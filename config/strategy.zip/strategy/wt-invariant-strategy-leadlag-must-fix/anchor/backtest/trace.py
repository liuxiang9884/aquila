#!/usr/bin/env python3
"""
Trace visualization for anchor strategy backtest results.

Plots three panels from the anchor strategy's newline-delimited JSON log:
  Panel 1: Raw depth prices (askPrc1 / bidPrc1)
  Panel 2: Ratio + quantile thresholds + signals + trade scatter
  Panel 3: Volatility / state machine

Usage:
    python trace.py -l backtest.log
    python trace.py -l backtest.log -p 1      # depth panel only
    python trace.py -l backtest.log -p 2      # ratio panel only
    python trace.py -l backtest.log -p 3      # volatility panel only
"""

import argparse
import os
from typing import Optional

import matplotlib.pyplot as plt
import mplcursors
import numpy as np
import pandas as pd

# Re-use log reader and trade analysis from order.py
from order import DEFAULT_LOG_FILE, read_jsons, analyze

# Execution state labels matching V2ExecutionState enum
EXEC_STATE_LABELS = {
    0: "Inactive",
    1: "OpenLong",
    2: "CloseLong",
    3: "OpenShort",
    4: "CloseShort",
    5: "FixExposure",
}

# Position state labels matching V2PositionState enum
POSITION_STATE_LABELS = {
    0: "Idle",
    1: "HoldLong",
    2: "HoldShort",
}


def plot_depth_price_panel(ax, depth: Optional[pd.DataFrame]):
    """Panel 1: Raw depth prices (askPrc1 / bidPrc1)."""
    if depth is None or depth.empty:
        ax.text(0.5, 0.5, "No depth data", transform=ax.transAxes, ha="center", va="center", fontsize=12)
        ax.set_title("Raw Depth Prices")
        return

    # Group by symbol if multiple symbols present
    symbols = depth['symbol'].unique() if 'symbol' in depth.columns else [None]

    for symbol in symbols:
        if symbol is None:
            subset = depth
            label_pfx = ""
        else:
            subset = depth[depth['symbol'] == symbol]
            label_pfx = f"{symbol}: "

        if subset.empty:
            continue

        t = subset.index
        if 'askPrc1' in subset.columns:
            ax.plot(t, subset['askPrc1'], label=f"{label_pfx}Ask", alpha=0.8, linewidth=1)
        if 'bidPrc1' in subset.columns:
            ax.plot(t, subset['bidPrc1'], label=f"{label_pfx}Bid", alpha=0.8, linewidth=1)

    ax.set_ylabel("Price")
    ax.set_title("Raw Depth Prices (Ask / Bid)")
    ax.legend(loc="best", fontsize=7)
    ax.grid(True, alpha=0.3)


def plot_ratio_panel(ax, indicator: pd.DataFrame, signals: Optional[pd.DataFrame],
                     trades: Optional[pd.DataFrame]):
    """Panel 2: Ratio + quantile thresholds + entry lines + signals + trades."""
    t = indicator.index
    # Ratio lines
    ax.plot(t, indicator["ratio_ask"], label="ratio_ask", color="blue", alpha=0.7, linewidth=0.8)
    ax.plot(t, indicator["ratio_bid"], label="ratio_bid", color="red", alpha=0.7, linewidth=0.8)

    # Quantile thresholds
    ax.plot(t, indicator["q_up"], label="q_up", color="darkgreen", linestyle="--", alpha=0.8, linewidth=0.8)
    ax.plot(t, indicator["q_down"], label="q_down", color="darkorange", linestyle="--", alpha=0.8, linewidth=0.8)

    # Entry thresholds (ratio must exceed these for a signal)
    ax.plot(t, indicator["entry_long"], label="entry_long", color="orange", linestyle=":", alpha=0.5, linewidth=0.8)
    ax.plot(t, indicator["entry_short"], label="entry_short", color="green", linestyle=":", alpha=0.5, linewidth=0.8)

    # Signal events
    # if signals is not None and not signals.empty:
    #     long_sig = signals[signals["side"] == "long"]
    #     short_sig = signals[signals["side"] == "short"]
    #     if not long_sig.empty:
    #         for ts in long_sig.index:
    #             ax.axvline(ts, color="green", alpha=0.15, linewidth=0.5)
    #     if not short_sig.empty:
    #         for ts in short_sig.index:
    #             ax.axvline(ts, color="red", alpha=0.15, linewidth=0.5)

    # Trade scatter with PnL annotation — one series per exec type
    EXEC_STYLE = {
        "OpenLong":   {"marker": "^", "color": "green",     "edge": "darkgreen",  "fc": "lightgreen"},
        "CloseShort": {"marker": "^", "color": "limegreen", "edge": "green",      "fc": "lightgreen"},
        "OpenShort":  {"marker": "v", "color": "red",       "edge": "darkred",    "fc": "lightcoral"},
        "CloseLong":  {"marker": "v", "color": "salmon",    "edge": "red",        "fc": "lightcoral"},
    }
    if trades is not None and not trades.empty:
        trades = trades.copy()
        if 'group_id' not in trades.columns and 'close_id' in trades.columns:
            trades['group_id'] = trades['close_id']

        # Plot all 4 exec types, each with two layers:
        #   triangles  → trigger_ratio  (expected fill when action was made)
        #   X crosses  → avg_ratio      (actual filled ratio)
        # Matched trades store exec as the open type (OpenLong/OpenShort).
        # Open leg  → open_time,  open_avg_ratio,  open_trigger_ratio
        # Close leg → close_time, close_avg_ratio, close_trigger_ratio
        _OPEN_TO_CLOSE = {'OpenLong': 'CloseLong', 'OpenShort': 'CloseShort'}
        _CLOSE_TO_OPEN = {v: k for k, v in _OPEN_TO_CLOSE.items()}

        for exec_name, style in EXEC_STYLE.items():
            if exec_name in _OPEN_TO_CLOSE:
                subset = trades[trades["exec"] == exec_name].copy()
                avg_col     = 'open_avg_ratio'
                trigger_col = 'open_trigger_ratio'
                times = pd.to_datetime(subset['open_time']) if 'open_time' in subset.columns else subset.index
            else:
                subset = trades[trades["exec"] == _CLOSE_TO_OPEN[exec_name]].copy()
                avg_col     = 'close_avg_ratio'
                trigger_col = 'close_trigger_ratio'
                times = subset.index  # index is close_time

            if subset.empty or avg_col not in subset.columns:
                continue

            avg_ratios = subset[avg_col]
            valid = avg_ratios.notna() & (avg_ratios != 0)
            if not valid.any():
                continue

            subset_v = subset[valid]
            times_v  = times[valid]

            # Layer 1: triangles at trigger_ratio
            if trigger_col in subset_v.columns:
                tr = subset_v[trigger_col]
                tr_valid = tr.notna() & (tr != 0)
                if tr_valid.any():
                    ax.scatter(times_v[tr_valid], tr[tr_valid],
                               marker=style["marker"], s=50, c=style["color"],
                               edgecolors=style["edge"], linewidths=1, zorder=5,
                               label=exec_name)

            # Layer 2: X crosses at avg_ratio (actual fill)
            sc = ax.scatter(times_v, avg_ratios[valid],
                            marker='x', s=60, c=style["color"],
                            linewidths=1.5, zorder=6,
                            label=f"{exec_name} (filled)")
            cursor = mplcursors.cursor(sc, hover=mplcursors.HoverMode.Transient)
            @cursor.connect("add")
            def _on_hover(sel, _df=subset_v, _fc=style["fc"], _ac=avg_col, _tc=trigger_col):
                row = _df.iloc[sel.index]
                hover_lines = [
                    f"Trade: {row.get('group_id', '')}",
                ]
                if _tc in row.index and pd.notna(row[_tc]) and row[_tc] != 0:
                    hover_lines.append(f"Trigger: {row[_tc]:.6f}")
                hover_lines += [
                    f"Filled:  {row[_ac]:.6f}",
                    f"PnL: {row['pnl_net']:.4f}",
                    f"Exec: {row['exec']}",
                ]
                dur = row.get('duration_ms')
                if dur is not None and not pd.isna(dur):
                    hover_lines.append(f"Dur: {dur:.0f}ms")
                sel.annotation.set_text("\n".join(hover_lines))
                sel.annotation.get_bbox_patch().set(fc=_fc, alpha=0.9)

    ax.set_ylabel("Ratio")
    ax.set_title("Ratio + Quantile Thresholds")
    ax.legend(loc="best", fontsize=7)
    ax.grid(True, alpha=0.3)


def plot_drift_slippage_panel(ax, trades: Optional[pd.DataFrame], summary: dict, depth: Optional[pd.DataFrame] = None, indicator: Optional[pd.DataFrame] = None):
    """Panel 3: Taker drift, slippage, entry-exit space, and volatility analysis."""
    if trades is None or trades.empty:
        ax.text(0.5, 0.5, "No trade data", transform=ax.transAxes, ha="center", va="center", fontsize=12)
        ax.set_title("Taker Drift & Slippage & Volatility")
        return

    trades = trades.copy()
    if 'group_id' not in trades.columns and 'close_id' in trades.columns:
        trades['group_id'] = trades['close_id']

    # Plot volatility from depth records (maker and taker)
    if depth is not None and not depth.empty:
        # Split depth by symbol (assuming symbol column exists)
        if 'symbol' in depth.columns:
            for symbol, subset in depth.groupby("symbol"):
                t = subset.index
                if 'vol' in subset.columns:
                    ax.plot(t, subset['vol'] * 100, label=f'{symbol}_vol (%)', alpha=0.4, linewidth=1)

    # Plot slp_predict and drift_predict from indicator records
    if indicator is not None and not indicator.empty:
        t = indicator.index
        if 'slp_predict' in indicator.columns:
            ax.plot(t, indicator['slp_predict'] * 100, label='slp_predict (%)', color='steelblue',
                    alpha=0.6, linewidth=1, linestyle='-.')
        if 'drift_predict' in indicator.columns:
            ax.plot(t, indicator['drift_predict'] * 100, label='drift_predict (%)', color='darkorange',
                    alpha=0.6, linewidth=1, linestyle='-.')

    # Calculate space (open_avg_ratio - close_avg_ratio) for trades with both fields
    if 'open_avg_ratio' in trades.columns and 'close_avg_ratio' in trades.columns:
        trades_with_space = trades[trades['open_avg_ratio'].notna() & trades['close_avg_ratio'].notna()].copy()
    else:
        trades_with_space = pd.DataFrame()
    if not trades_with_space.empty:
        trades_with_space['space'] = (trades_with_space['open_avg_ratio'] - trades_with_space['close_avg_ratio']).abs() * 100
        trades_with_space['start_dt'] = pd.to_datetime(trades_with_space['open_time'])
        ax.plot(trades_with_space['start_dt'], trades_with_space['space'],
                color='purple', alpha=0.5, linewidth=1.5, label='space (%)', marker='.')
        cursor_space = mplcursors.cursor(
            ax.scatter(trades_with_space['start_dt'], trades_with_space['space'],
                      marker='.', s=30, c='purple', alpha=0),
            hover=mplcursors.HoverMode.Transient
        )
        @cursor_space.connect("add")
        def _on_hover_space(sel, _df=trades_with_space):
            row = _df.iloc[sel.index]
            sel.annotation.set_text(
                "\n".join([
                    f"Open: {row['open_id']}",
                    f"Close: {row['close_id']}",
                    f"Entry ratio: {row['open_avg_ratio']:.6f}",
                    f"Exit ratio: {row['close_avg_ratio']:.6f}",
                    f"Space: {row['space']:.4f}%",
                    f"Exec: {row['exec']}",
                ])
            )
            sel.annotation.get_bbox_patch().set(fc="plum", alpha=0.9)

    # Plot slippage/drift/predict for both open and close legs.
    # Open-leg data is in open_taker_slp/open_taker_drift (plotted at open_time).
    # Close-leg data is in close_taker_slp/close_taker_drift (plotted at close_time = index).
    _LEG_CFG = [
        ('open_taker_slp',     'open_time',  'o', 50, 'steelblue',  'taker_slp (open)',     'lightblue', 'open_id'),
        ('close_taker_slp',    None,         'o', 50, 'royalblue',  'taker_slp (close)',    'lightblue', 'close_id'),
        ('open_taker_drift',   'open_time',  's', 50, 'darkorange', 'taker_drift (open)',   'wheat',     'open_id'),
        ('close_taker_drift',  None,         's', 50, 'saddlebrown','taker_drift (close)',  'wheat',     'close_id'),
        ('open_predict_slp',   'open_time',  'D', 30, 'steelblue',  'predict_slp (open)',   'lightblue', 'open_id'),
        ('close_predict_slp',  None,         'D', 30, 'royalblue',  'predict_slp (close)',  'lightblue', 'close_id'),
        ('open_predict_drift', 'open_time',  'D', 30, 'darkorange', 'predict_drift (open)', 'wheat',     'open_id'),
        ('close_predict_drift',None,         'D', 30, 'saddlebrown','predict_drift (close)','wheat',     'close_id'),
    ]
    for val_col, time_col, marker, sz, color, label, fc, id_col in _LEG_CFG:
        if val_col not in trades.columns:
            continue
        subset = trades[trades[val_col].notna() & (trades[val_col] != 0)].copy()
        if subset.empty:
            continue
        subset['_dt'] = pd.to_datetime(subset[time_col]) if time_col else subset.index
        sc = ax.scatter(subset['_dt'], subset[val_col] * 100,
                        marker=marker, s=sz, c=color, alpha=0.6, label=label)
        cursor = mplcursors.cursor(sc, hover=mplcursors.HoverMode.Transient)
        @cursor.connect("add")
        def _on_hover(sel, _df=subset, _vc=val_col, _ic=id_col, _fc=fc):
            row = _df.iloc[sel.index]
            sel.annotation.set_text("\n".join([
                f"ID: {row.get(_ic, '')}",
                f"{_vc}: {row[_vc] * 100:.4f}%",
                f"Exec: {row['exec']}",
                f"PnL: {row['pnl_net']:.4f}",
            ]))
            sel.annotation.get_bbox_patch().set(fc=_fc, alpha=0.9)

    # Add summary statistics box
    avg_space = (trades_with_space['space'].mean() / 100) if not trades_with_space.empty else 0
    lines = [
        f"Avg Space: {avg_space * 100:.4f}%",
        f"Avg Slippage: {summary.get('avg_taker_slp', 0) * 100:.4f}%",
        f"Avg Drift: {summary.get('avg_taker_drift', 0) * 100:.4f}%",
        f"Filled Trades: {summary.get('filled', 0)}",
    ]
    ax.text(0.02, 0.98, "\n".join(lines), transform=ax.transAxes,
            verticalalignment="top", fontsize=8, family="monospace",
            bbox=dict(boxstyle="round", facecolor="lightyellow", alpha=0.8))

    ax.axhline(y=0, color="black", linestyle="-", linewidth=0.5, alpha=0.5)
    ax.set_ylabel("Percentage (%)")
    ax.set_title("Taker Drift & Slippage & Space")
    ax.legend(loc="best", fontsize=7)
    ax.grid(True, alpha=0.3)


def main():
    parser = argparse.ArgumentParser(description="Trace visualization for anchor strategy backtest")
    parser.add_argument("logfile", nargs="?", default=DEFAULT_LOG_FILE, help="Path to log file")
    parser.add_argument("-p", "--panel", type=str, default=None,
                        help="Comma-separated panels to show (e.g., 1,2,3 or 1,3). Default: all panels")
    parser.add_argument("-n", "--name", type=str, default=None,
                        help="Figure window title")
    args = parser.parse_args()

    print(f"Loading: {args.logfile}")
    dfs = read_jsons(args.logfile, "type")

    depth = dfs.get("depth")
    indicator = dfs.get("indicator")
    signals = dfs.get("signal")
    trades, summary = analyze(dfs)

    # Enrich matched trades with per-leg fields from action_summary (keyed by group_id).
    # Matched DataFrame only stores close-leg slippage/drift; open-leg data must be joined.
    actions = dfs.get("action_summary")
    if trades is not None and actions is not None and 'group_id' in actions.columns:
        trades = trades.copy()
        for col in ('trigger_ratio', 'taker_slp', 'taker_drift', 'predict_slp', 'predict_drift'):
            if col not in actions.columns:
                continue
            col_map = actions.set_index('group_id')[col]
            trades[f'open_{col}'] = trades['open_id'].map(col_map)
            trades[f'close_{col}'] = trades['close_id'].map(col_map)

    # Parse comma-separated panel list
    if args.panel is None:
        panels = [1, 2, 3]
    else:
        panels = sorted(set(int(p.strip()) for p in args.panel.split(',') if p.strip()))
        # Validate panels
        panels = [p for p in panels if p in (1, 2, 3)]
    n = len(panels)

    # All panels share time axis
    fig, axes = plt.subplots(n, 1, figsize=(16, 5 * n), num=args.name)
    if n == 1:
        axes = [axes]
    # Link time-axis panels
    for a in axes[1:]:
        a.sharex(axes[0])

    for ax, p in zip(axes, panels):
        if p == 1:
            plot_depth_price_panel(ax, depth)
        elif p == 2:
            if indicator is not None:
                plot_ratio_panel(ax, indicator, signals, trades)
            else:
                ax.text(0.5, 0.5, "No indicator data", transform=ax.transAxes, ha="center")
        elif p == 3:
            plot_drift_slippage_panel(ax, trades, summary, depth, indicator)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
