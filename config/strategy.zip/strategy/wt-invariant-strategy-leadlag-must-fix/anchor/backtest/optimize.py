#!/usr/bin/env python3
"""
Anchor strategy parameter grid-search optimizer.

Subcommands:
  init    <run> [-o optimize.json]   Scaffold an example optimize config from a run's strategy.json
  single  <optimize.json> [options]  Run the full cartesian-product grid search for one task
  multi   <optimize.json> [options]  Run the grid search over multiple tasks
  summary <optimize.json> [options]  Display results of a completed optimization run (no re-run)

Usage:
  python optimize.py init eth-v1
  python optimize.py init eth-v1 -o my_search.json
  python optimize.py single optimize.json
  python optimize.py single optimize.json --jobs 4 --objective profit_rate
  python optimize.py single optimize.json --opt-result /path/to/results
  python optimize.py multi optimize.json
  python optimize.py multi optimize.json --jobs 4 --opt-result /path/to/results
  python optimize.py summary optimize.json
  python optimize.py summary optimize.json --top 20
  python optimize.py summary optimize.json --opt-result /path/to/results
"""

import argparse
import copy
import itertools
import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from functools import partial
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd


class _NumpyEncoder(json.JSONEncoder):
    """JSON encoder that converts numpy scalars to native Python types."""
    def default(self, obj):
        if hasattr(obj, "item"):
            return obj.item()
        return super().default(obj)

# Load .env before anything else so ANCHOR_CONFIG, ANCHOR_OPT_RESULT and siblings are available.
_DOTENV_PATH = Path(".env")


def _load_dotenv() -> None:
    if not _DOTENV_PATH.exists():
        return
    with open(_DOTENV_PATH) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


_load_dotenv()

# Ensure order.py (sibling) is importable in both main process and workers.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import order as order_mod  # noqa: E402

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

# invariant-strategy/ (repo root, where go.mod lives)
REPO_ROOT = Path(__file__).resolve().parents[2]

# Fields that identify the pair/exchange — skip in param space
NON_TUNABLE = {"maker", "taker", "type", "source"}

OBJECTIVES = {"pnl_net_total", "pnl_gross_total", "profit_rate", "net_win_rate", "gross_win_rate", "risk_adjusted"}

# ---------------------------------------------------------------------------
# Env helpers
# ---------------------------------------------------------------------------

def _get_anchor_config() -> Optional[Path]:
    val = os.environ.get("ANCHOR_CONFIG", "").strip()
    return Path(val) if val else None


def _get_anchor_opt_result() -> Optional[Path]:
    val = os.environ.get("ANCHOR_OPT_RESULT", "").strip()
    return Path(val) if val else None


def _resolve_run_paths(base: Path, run: str) -> Tuple[Path, Path, Path]:
    """Return (strategy_json, backtest_json, indicator_csv) for a named run."""
    run_dir = base / run
    strategy = run_dir / "strategy.json"
    backtest = run_dir / "backtest.json"
    quantile = os.environ.get("ANCHOR_INDICATOR", "q95")
    indicator = run_dir / "indicator" / f"{quantile}.csv"
    return strategy, backtest, indicator


# ---------------------------------------------------------------------------
# Param spec expansion
# ---------------------------------------------------------------------------

def _decimal_places(step: float) -> int:
    """Number of decimal places needed to represent step without noise."""
    s = f"{step:.15f}".rstrip("0")
    return len(s.split(".")[1]) if "." in s else 0


def expand_spec(desc: dict) -> list:
    """Expand a param Description to a flat list of candidate values.

    Description fields:
      key    : dot-path to the param
      type   : "values" (default) | "range"
      values : list of values — required when type is "values"
      range  : [start, end]    — required when type is "range"
      step   : step size       — required when type is "range"
    """
    typ = desc.get("type", "values")

    if typ == "values":
        return list(desc["values"])

    if typ == "range":
        lo, hi, step = desc["range"][0], desc["range"][1], desc["step"]
        if isinstance(lo, int) and isinstance(hi, int) and isinstance(step, int):
            return list(range(lo, hi + 1, step))
        # Float arange: round to avoid floating-point noise
        places = _decimal_places(float(step))
        vals = np.arange(float(lo), float(hi) + float(step) * 0.5, float(step))
        return [round(float(v), places) for v in vals]

    raise ValueError(f"Unknown param type {typ!r}, expected 'values', 'range', or 'comb'")


# ---------------------------------------------------------------------------
# Dot-path helpers
# ---------------------------------------------------------------------------

def apply_params(config: dict, flat: dict) -> dict:
    """Deep-copy config and apply flat {dot.path: value} overrides."""
    cfg = copy.deepcopy(config)
    for dotpath, value in flat.items():
        parts = dotpath.split(".")
        node = cfg
        for key in parts[:-1]:
            node = node[key]
        node[parts[-1]] = value
    return cfg


def _flatten_leaves(obj: dict, prefix: str = "") -> dict:
    """Recursively flatten nested dict to {dot.path: value}, skipping non-tunable keys."""
    result = {}
    for k, v in obj.items():
        if k in NON_TUNABLE:
            continue
        path = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            result.update(_flatten_leaves(v, path))
        else:
            result[path] = v
    return result


# ---------------------------------------------------------------------------
# Key parsing  (format: [bt:]<dot.path>)
# ---------------------------------------------------------------------------

def _key_display(raw: str) -> str:
    """Return the display name: dot-path only, stripping any bt: prefix."""
    return raw[3:] if raw.startswith("bt:") else raw


def _key_dotpath(raw: str) -> str:
    """Return the dot-path only, stripping any bt: prefix."""
    return raw[3:] if raw.startswith("bt:") else raw


def _key_is_bt(raw: str) -> bool:
    return raw.startswith("bt:")


def _prefix_bt(desc: dict) -> dict:
    """Return a copy of desc with bt: prepended to its key(s)."""
    if desc.get("type") == "comb":
        return {**desc, "keys": [f"bt:{k}" for k in desc["keys"]]}
    return {**desc, "key": f"bt:{desc['key']}"}


# ---------------------------------------------------------------------------
# Combinations
# ---------------------------------------------------------------------------

def build_combinations(params: List[dict]) -> Tuple[List[str], List[str], List[tuple]]:
    """Expand all param Descriptions and return (raw_keys, display_keys, combos).

    Each Description contributes one dimension to the cartesian product:
      - "values" / "range" : one key, each value is a 1-tuple slot
      - "comb"             : N keys, each row in values is an N-tuple slot

    Display name precedence:
      - single param : alias field > dot-path (bt: prefix stripped)
      - comb         : aliases[i]  > dot-path (bt: prefix stripped), per key
    """
    all_keys: List[str] = []
    display_keys: List[str] = []
    slot_lists: List[List[tuple]] = []

    for desc in params:
        if desc.get("type") == "comb":
            raw_keys = desc["keys"]
            aliases  = desc.get("aliases") or [None] * len(raw_keys)
            all_keys.extend(raw_keys)
            display_keys.extend(
                alias if alias else _key_display(k)
                for alias, k in zip(aliases, raw_keys)
            )
            slot_lists.append([tuple(row) for row in desc["values"]])
        else:
            raw_key = desc["key"]
            all_keys.append(raw_key)
            display_keys.append(desc.get("alias") or _key_display(raw_key))
            slot_lists.append([(v,) for v in expand_spec(desc)])

    combos = [
        tuple(v for slot in combo for v in slot)
        for combo in itertools.product(*slot_lists)
    ]
    return all_keys, display_keys, combos


# ---------------------------------------------------------------------------
# Objective
# ---------------------------------------------------------------------------

def compute_objective(summary: dict, objective: str) -> float:
    if objective == "risk_adjusted":
        return float(summary.get("pnl_net_total", 0.0)) * float(summary.get("net_win_rate", 0.0))
    return float(summary.get(objective, float("-inf")))


# ---------------------------------------------------------------------------
# Single backtest run (top-level for ProcessPoolExecutor pickling)
# ---------------------------------------------------------------------------

def run_one(
    combo_id: int,
    combo: tuple,
    *,
    keys: List[str],
    display_keys: List[str],
    base_cfg: dict,
    base_backtest_cfg: dict,
    backtest_json: str,
    indicator_csv: str,
    runs_dir: str,
) -> dict:
    """Run one backtest combination. Writes strategy.json and backtest.log to
    runs_dir/<combo_id>/. Returns {"combo_id": ..., **params} with optional "error" key.

    Keys prefixed with "bt:" are applied to the backtest config; all others are
    applied to the strategy config.
    """
    strategy_flat: dict = {}
    backtest_flat: dict = {}
    result_params: dict = {}  # display_name -> value (used in result dict)

    for raw_key, dk, val in zip(keys, display_keys, combo):
        result_params[dk] = val
        if _key_is_bt(raw_key):
            backtest_flat[_key_dotpath(raw_key)] = val
        else:
            strategy_flat[_key_dotpath(raw_key)] = val

    cfg = apply_params(base_cfg, strategy_flat)

    run_dir = Path(runs_dir) / f"{combo_id:06d}"
    run_dir.mkdir(parents=True, exist_ok=True)

    strategy_file = str(run_dir / "strategy.json")
    log_file = "backtest.log"

    with open(strategy_file, "w") as f:
        json.dump(cfg, f, indent=4)

    bt_cfg = apply_params(base_backtest_cfg, backtest_flat)
    backtest_file = str(run_dir / "backtest.json")
    with open(backtest_file, "w") as f:
        json.dump(bt_cfg, f, indent=4)
    effective_backtest = backtest_file

    env = os.environ.copy()
    env["LOG_DIR"] = str(run_dir)
    env["LOG_FILE"] = log_file

    cmd = [
        "go", "run",
        str(REPO_ROOT / "anchor" / "backtest" / "main.go"),
        "strategy",
        "-s", strategy_file,
        "-b", effective_backtest,
        "-i", indicator_csv,
    ]
    print(f"[#{combo_id:06d}] $ {' '.join(cmd)}")

    proc = subprocess.Popen(
        cmd,
        cwd=str(REPO_ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        stdout, stderr = proc.communicate()
    except (KeyboardInterrupt, SystemExit):
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        raise

    if stdout:
        print(stdout, end="")

    result: dict = {"combo_id": combo_id, **result_params}

    if proc.returncode != 0:
        result["error"] = (stderr or "non-zero exit")[-500:]

    return result


# ---------------------------------------------------------------------------
# cmd: init
# ---------------------------------------------------------------------------

def cmd_init(args) -> None:
    base = _get_anchor_config()
    run = args.run

    if args.strategy:
        strategy_path = Path(args.strategy)
    elif base:
        strategy_path, _, _ = _resolve_run_paths(base, run)
    else:
        sys.exit("Error: provide -s <strategy.json> or set ANCHOR_CONFIG in env / .env")

    if not strategy_path.exists():
        sys.exit(f"Error: strategy.json not found at {strategy_path}")

    with open(strategy_path) as f:
        strategy = json.load(f)

    params = []

    if args.opt_result:
        opt_result_dir = args.opt_result
    elif _get_anchor_opt_result():
        opt_result_dir = str(_get_anchor_opt_result() / run)
    else:
        opt_result_dir = run

    cfg = {
        "task": run,
        "objective": "pnl_net_total",
        "jobs": 1,
        "opt_result": opt_result_dir,
        "display_fields": ["filled", "matched_long", "matched_short", "pnl_gross_total", "pnl_net_total", "gross_win_rate", "net_win_rate", "profit_rate"],
        "params": params,
    }

    if args.output:
        out_path = Path(args.output)
    elif base:
        out_path = base / run / "optimize.json"
    else:
        out_path = Path("optimize.json")
    with open(out_path, "w") as f:
        json.dump(cfg, f, indent=4)
        f.write("\n")

    print(f"  wrote {out_path.resolve()}")
    print("  Add entries to 'params' to define the search space, e.g.:")
    print('    {"key": "signal.slippage.init", "type": "values", "values": [0.0001, 0.0002, 0.0003]}')
    print('    {"key": "signal.profit_target", "type": "range", "range": [0.0001, 0.0005], "step": 0.0001}')


# ---------------------------------------------------------------------------
# cmd: prepare
# ---------------------------------------------------------------------------

def cmd_prepare(args) -> None:
    """Generate per-base strategy/backtest/indicator configs and a multi-task optimize config.

    For each base token, template files are rendered by replacing every
    occurrence of the literal string ``{base}`` with the token value.
    All output files are written to ``$ANCHOR_CONFIG/<base>/``.  An
    optimize.json is then written that merges the optimize template with
    ``tasks: [<base>, ...]``.
    """
    anchor_config = _get_anchor_config()
    if not anchor_config:
        sys.exit("Error: set ANCHOR_CONFIG in env / .env")

    if args.base_file:
        with open(args.base_file) as f:
            bases = json.load(f)
        if not isinstance(bases, list) or not bases:
            sys.exit(f"Error: {args.base_file} must be a non-empty JSON array of base tokens")
    else:
        bases = args.base
    if not bases:
        sys.exit("Error: provide base tokens as positional args or via --base-file")
    args.base = bases

    with open(args.strategy_template) as f:
        strategy_template_str = f.read()
    with open(args.backtest_template) as f:
        backtest_template_str = f.read()
    if args.indicator_template:
        with open(args.indicator_template) as f:
            indicator_template_str = f.read()
    else:
        indicator_template_str = None
    with open(args.optimize_template) as f:
        optimize_cfg = json.load(f)

    prefix = args.prefix
    suffix = args.suffix
    tasks  = []

    for base in args.base:
        task_name = f"{prefix}{base}{suffix}"
        run_dir   = anchor_config / task_name
        run_dir.mkdir(parents=True, exist_ok=True)

        rendered = strategy_template_str.replace("{base}", base).replace("{task}", task_name)
        strategy_cfg = json.loads(rendered)
        with open(run_dir / "strategy.json", "w") as f:
            json.dump(strategy_cfg, f, indent=4)
            f.write("\n")

        rendered_bt = backtest_template_str.replace("{base}", base).replace("{task}", task_name)
        backtest_cfg = json.loads(rendered_bt)
        with open(run_dir / "backtest.json", "w") as f:
            json.dump(backtest_cfg, f, indent=4)
            f.write("\n")

        written = [run_dir / "strategy.json", run_dir / "backtest.json"]

        if indicator_template_str is not None:
            rendered_ind = indicator_template_str.replace("{base}", base).replace("{task}", task_name)
            indicator_cfg = json.loads(rendered_ind)
            with open(run_dir / "indicator.json", "w") as f:
                json.dump(indicator_cfg, f, indent=4)
                f.write("\n")
            written.append(run_dir / "indicator.json")

        print(f"  {task_name}: wrote " + "  ".join(str(p) for p in written))
        tasks.append(task_name)

    out_cfg = dict(optimize_cfg)
    out_cfg["tasks"] = tasks

    out_path = Path(args.output) if args.output else Path("optimize.json")
    with open(out_path, "w") as f:
        json.dump(out_cfg, f, indent=4)
        f.write("\n")
    print(f"  optimize: wrote {out_path.resolve()}")


# ---------------------------------------------------------------------------
# cmd: indicator
# ---------------------------------------------------------------------------

def cmd_indicator(args) -> None:
    """Run the backtest indicator for each task listed in a multi-task config."""
    with open(args.config) as f:
        cfg = json.load(f)

    tasks = cfg.get("tasks")
    if not tasks:
        sys.exit("Error: 'tasks' list is required in config for the indicator subcommand")

    main_go = str(REPO_ROOT / "anchor" / "backtest" / "main.go")
    failed  = []

    for task in tasks:
        if not isinstance(task, str) or not task:
            sys.exit("Error: each entry in 'tasks' must be a non-empty run name string")

        cmd = ["go", "run", main_go, "indicator", task]
        print(f"\n[indicator] $ {' '.join(cmd)}")

        proc = subprocess.Popen(
            cmd,
            cwd=str(REPO_ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            stdout, stderr = proc.communicate()
        except (KeyboardInterrupt, SystemExit):
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            raise

        if stdout:
            print(stdout, end="")
        if proc.returncode != 0:
            print(f"[indicator] ERROR ({task}):\n{stderr}", file=sys.stderr)
            failed.append(task)
        else:
            print(f"[indicator] done: {task}")

    if failed:
        sys.exit(f"\nFailed tasks: {failed}")


# ---------------------------------------------------------------------------
# cmd: single
# ---------------------------------------------------------------------------

def _run_single(cfg: dict, combo_ids: Optional[set] = None) -> Tuple[pd.DataFrame, List[str], List[str]]:
    """Execute a single grid-search run from a fully-resolved config dict.

    Workflow: run all backtests in parallel → extract results from logs → save best configs.
    Returns (df, display_keys, display_fields).

    combo_ids: if provided, only run combinations whose index is in this set.
    """
    run             = cfg.get("task")
    objective       = cfg.get("objective", "pnl_net_total")
    jobs            = int(cfg.get("jobs", 1))
    params_cfg      = cfg.get("params", [])
    backtest_params = cfg.get("backtest", [])

    # Merge strategy params with backtest params (backtest keys prefixed "bt:")
    bt_prefixed = [_prefix_bt(d) for d in backtest_params]
    all_params  = bt_prefixed + params_cfg

    if not run:
        sys.exit("Error: 'task' is required in optimize config")
    if not all_params:
        sys.exit("Error: both 'params' and 'backtest' are empty — nothing to search")


    base = _get_anchor_config()

    if cfg.get("strategy") and cfg.get("backtest_file") and cfg.get("indicator"):
        strategy_path  = Path(cfg["strategy"]).resolve()
        backtest_path  = Path(cfg["backtest_file"]).resolve()
        indicator_path = Path(cfg["indicator"]).resolve()
    elif base:
        strategy_path, backtest_path, indicator_path = _resolve_run_paths(base, run)
        strategy_path  = strategy_path.resolve()
        backtest_path  = backtest_path.resolve()
        indicator_path = indicator_path.resolve()
    else:
        sys.exit(
            "Error: set ANCHOR_CONFIG in env / .env, "
            "or add explicit 'strategy', 'backtest', 'indicator' paths to the config file"
        )

    # Resolve opt_result dir: CLI/config > $ANCHOR_OPT_RESULT/<run> > ./<run>
    if cfg.get("opt_result"):
        output_dir = Path(cfg["opt_result"])
    elif _get_anchor_opt_result():
        output_dir = _get_anchor_opt_result() / run
    else:
        output_dir = Path(run)
    output_dir = output_dir.resolve()

    for p, label in [
        (strategy_path,  "strategy.json"),
        (backtest_path,  "backtest.json"),
        (indicator_path, "indicator CSV"),
    ]:
        if not p.exists():
            sys.exit(f"Error: {label} not found at {p}")

    with open(strategy_path) as f:
        base_cfg = json.load(f)
    with open(backtest_path) as f:
        base_backtest_cfg = json.load(f)

    keys, display_keys, combos = build_combinations(all_params)
    total = len(combos)

    print(f"Run      : {run}")
    print(f"Params   : {display_keys}")
    print(f"Total    : {total} combinations")
    print(f"Objective: {objective}  jobs={jobs}")
    print()

    output_dir.mkdir(parents=True, exist_ok=True)
    runs_dir = output_dir / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)

    # Copy backtest.json to output dir for reference
    shutil.copy(backtest_path, output_dir / "backtest.json")

    worker = partial(
        run_one,
        keys=keys,
        display_keys=display_keys,
        base_cfg=base_cfg,
        base_backtest_cfg=base_backtest_cfg,
        backtest_json=str(backtest_path),
        indicator_csv=str(indicator_path),
        runs_dir=str(runs_dir),
    )

    completed = 0
    run_errors = 0

    if combo_ids is not None:
        invalid = combo_ids - set(range(total))
        if invalid:
            sys.exit(f"Error: combo IDs out of range [0, {total - 1}]: {sorted(invalid)}")
        selected = [(i, combo) for i, combo in enumerate(combos) if i in combo_ids]
        print(f"Rerunning {len(selected)} of {total} combinations: {sorted(combo_ids)}")
    else:
        selected = list(enumerate(combos))

    width = len(str(total))

    executor = ProcessPoolExecutor(max_workers=jobs)
    futures = {
        executor.submit(worker, i, combo): i
        for i, combo in selected
    }

    try:
        for future in as_completed(futures):
            completed += 1
            result = future.result()
            combo_id  = result["combo_id"]
            err       = result.get("error", "")
            param_str = "  ".join(f"{dk}={result.get(dk)}" for dk in display_keys)
            if err:
                run_errors += 1
                status = f"ERROR {err}"
            else:
                status = "ok"
            print(f"[{completed:{width}}/{total}] #{combo_id:0{width}d}  {param_str}  → {status}")
    except KeyboardInterrupt:
        print("\nInterrupted — cancelling remaining tasks...", flush=True)
        for f in futures:
            f.cancel()
        executor.shutdown(wait=False)
        sys.exit(130)

    executor.shutdown(wait=True)

    if run_errors:
        print(f"\n{run_errors} combination(s) failed during backtest run.")

    # --- Extract: analyze logs and write results.csv ---
    print(f"\nExtracting results for {run}...")
    cfg_extract = {**cfg, "opt_result": str(output_dir)}
    df, display_keys, display_fields = _extract_single(cfg_extract, run)

    # Save best strategy (and best backtest config if backtest params were varied)
    best = df.iloc[0]
    best_strategy_flat = {_key_dotpath(k): best[dk] for k, dk in zip(keys, display_keys) if not _key_is_bt(k)}
    best_cfg = apply_params(base_cfg, best_strategy_flat)
    best_json = output_dir / "best_strategy.json"
    with open(best_json, "w") as f:
        json.dump(best_cfg, f, indent=4, cls=_NumpyEncoder)
        f.write("\n")
    print(f"Best cfg → {best_json}")

    if any(_key_is_bt(k) for k in keys):
        best_backtest_flat = {_key_dotpath(k): best[dk] for k, dk in zip(keys, display_keys) if _key_is_bt(k)}
        best_bt_cfg = apply_params(base_backtest_cfg, best_backtest_flat)
        best_bt_json = output_dir / "best_backtest.json"
        with open(best_bt_json, "w") as f:
            json.dump(best_bt_cfg, f, indent=4, cls=_NumpyEncoder)
            f.write("\n")
        print(f"Best bt  → {best_bt_json}")

    return df, display_keys, display_fields


def cmd_single(args) -> None:
    with open(args.config) as f:
        cfg = json.load(f)

    # CLI overrides
    if args.jobs is not None:
        cfg["jobs"] = args.jobs
    if args.opt_result is not None:
        cfg["opt_result"] = args.opt_result
    if args.objective is not None:
        cfg["objective"] = args.objective

    objective      = cfg.get("objective", "pnl_net_total")
    display_fields = cfg.get("display_fields", ["filled", "matched_long", "matched_short", "pnl_gross_total", "pnl_net_total", "gross_win_rate", "net_win_rate", "profit_rate"])
    top_n          = args.top

    df, display_keys, _ = _run_single(cfg)

    show_cols = ["combo_id"] + display_keys + [
        f for f in display_fields if f in df.columns
    ] + (["objective_value"] if "objective_value" in df.columns else [])
    show_cols = list(dict.fromkeys(show_cols))

    print(f"\nTop {top_n} by {objective}:")
    print(df[show_cols].head(top_n).to_string(index=False))

    if args.output:
        out_cols = [c for c in show_cols if c in df.columns]
        df[out_cols].to_csv(args.output, index=False)
        print(f"\nSummary  → {Path(args.output).resolve()}")


def cmd_multi(args) -> None:
    """Run the grid search over multiple tasks defined in a config file."""
    with open(args.config) as f:
        cfg = json.load(f)

    # CLI overrides
    if args.jobs is not None:
        cfg["jobs"] = args.jobs
    if args.opt_result is not None:
        cfg["opt_result"] = args.opt_result
    if args.objective is not None:
        cfg["objective"] = args.objective

    tasks = cfg.get("tasks")
    if not tasks:
        sys.exit("Error: 'tasks' list is required in config for the multi subcommand")

    objective      = cfg.get("objective", "pnl_net_total")
    display_fields = cfg.get("display_fields", ["filled", "matched_long", "matched_short", "pnl_gross_total", "pnl_net_total", "gross_win_rate", "net_win_rate", "profit_rate"])
    top_n          = args.top

    rerun_task   = getattr(args, "task", None)
    rerun_combids: Optional[set] = None
    if rerun_task is not None:
        if rerun_task not in tasks:
            sys.exit(f"Error: --task '{rerun_task}' not found in config tasks: {tasks}")
        combids_str = getattr(args, "combids", None)
        if combids_str:
            try:
                rerun_combids = {int(x.strip()) for x in combids_str.split(",")}
            except ValueError:
                sys.exit("Error: --combids must be comma-separated integers, e.g. '0,3,7'")

    # opt_result for each task is resolved as {base_opt_result}/{run}.
    base_opt_result = cfg.get("opt_result") or (
        str(_get_anchor_opt_result()) if _get_anchor_opt_result() else None
    )
    all_dfs: list = []
    for run in tasks:
        if not isinstance(run, str) or not run:
            sys.exit("Error: each entry in 'tasks' must be a non-empty run name string")
        if rerun_task is not None and run != rerun_task:
            continue
        task_cfg = {k: v for k, v in cfg.items() if k != "tasks"}
        task_cfg["task"] = run
        if base_opt_result:
            task_cfg["opt_result"] = str(Path(base_opt_result) / run)
        else:
            task_cfg["opt_result"] = run
        print(f"\n{'='*60}")
        print(f"Task: {run}")
        print(f"{'='*60}")
        df, display_keys, _ = _run_single(task_cfg, combo_ids=rerun_combids)
        df = df.copy()
        df.insert(0, "task", run)
        all_dfs.append((df, display_keys))

    # Combined summary across all tasks
    param_cols = all_dfs[0][1]
    combined = pd.concat([d for d, _ in all_dfs], ignore_index=True)
    if "objective_value" in combined.columns:
        combined = combined.sort_values("objective_value", ascending=False).reset_index(drop=True)
    show_cols = ["task", "combo_id"] + param_cols + [
        f for f in display_fields if f in combined.columns
    ] + (["objective_value"] if "objective_value" in combined.columns else [])
    show_cols = list(dict.fromkeys(show_cols))

    print(f"\n{'='*60}")
    print(f"All tasks done — top {top_n} by {objective} ({len(combined)} combinations across {len(all_dfs)} tasks):")
    print(f"{'='*60}")
    print(combined[show_cols].head(top_n).to_string(index=False))

    if args.output:
        out_cols = [c for c in show_cols if c in combined.columns]
        combined[out_cols].to_csv(args.output, index=False)
        print(f"\nSummary  → {Path(args.output).resolve()}")


# ---------------------------------------------------------------------------
# cmd: summary
# ---------------------------------------------------------------------------

def _resolve_output_dir(cfg: dict, run: str) -> Path:
    """Resolve the opt_result directory for a given run using the same logic as _run_single."""
    if cfg.get("opt_result"):
        return Path(cfg["opt_result"]).resolve()
    if _get_anchor_opt_result():
        return (_get_anchor_opt_result() / run).resolve()
    return Path(run).resolve()


def cmd_summary(args) -> None:
    """Display a summary of existing backtest optimization results without re-running."""
    with open(args.config) as f:
        cfg = json.load(f)

    if args.opt_result is not None:
        cfg["opt_result"] = args.opt_result

    objective     = cfg.get("objective", "pnl_net_total")
    display_fields = cfg.get("display_fields", ["filled", "matched_long", "matched_short", "pnl_gross_total", "pnl_net_total", "gross_win_rate", "net_win_rate", "profit_rate"])
    top_n         = args.top

    tasks = cfg.get("tasks")

    # csv_df accumulates all rows for --output; show_cols_for_csv tracks column order
    csv_df = None

    if tasks:
        # Multi-task: collect per-task results and show combined table
        base_opt_result = cfg.get("opt_result") or (
            str(_get_anchor_opt_result()) if _get_anchor_opt_result() else None
        )

        all_dfs = []
        for run in tasks:
            if not isinstance(run, str) or not run:
                sys.exit("Error: each entry in 'tasks' must be a non-empty run name string")
            if base_opt_result:
                output_dir = (Path(base_opt_result) / run).resolve()
            else:
                output_dir = Path(run).resolve()

            results_csv = output_dir / "results.csv"
            if not results_csv.exists():
                print(f"[{run}] WARNING: no results at {results_csv}", file=sys.stderr)
                continue

            df = pd.read_csv(results_csv)
            df.insert(0, "task", run)
            all_dfs.append((run, df))

        if not all_dfs:
            sys.exit("No results found for any task.")

        # Per-task top-N
        for run, df in all_dfs:
            param_cols = [
                c for c in df.columns
                if c not in {"task", "combo_id", "objective_value", "error"}
                and c not in display_fields
            ]
            show_cols = ["task", "combo_id"] + param_cols + [
                f for f in display_fields if f in df.columns
            ] + (["objective_value"] if "objective_value" in df.columns else [])
            show_cols = list(dict.fromkeys(show_cols))
            print(f"\n{'='*60}")
            print(f"Task: {run}  ({len(df)} combinations)")
            print(f"{'='*60}")
            print(df[show_cols].head(top_n).to_string(index=False))

        # Combined cross-task table
        combined = pd.concat([df for _, df in all_dfs], ignore_index=True)
        if "objective_value" in combined.columns:
            combined = combined.sort_values("objective_value", ascending=False).reset_index(drop=True)
        param_cols = [
            c for c in combined.columns
            if c not in {"task", "combo_id", "objective_value", "error"}
            and c not in display_fields
        ]
        show_cols = ["task", "combo_id"] + param_cols + [
            f for f in combined.columns if f in display_fields
        ] + (["objective_value"] if "objective_value" in combined.columns else [])
        show_cols = list(dict.fromkeys(show_cols))
        print(f"\n{'='*60}")
        print(f"Combined ({len(combined)} combinations across {len(all_dfs)} tasks) — top {top_n} by {objective}:")
        print(f"{'='*60}")
        print(combined[show_cols].head(top_n).to_string(index=False))

        csv_df = combined
        csv_show_cols = show_cols

    else:
        # Single task
        run = cfg.get("task")
        if not run:
            sys.exit("Error: 'task' or 'tasks' is required in config")

        output_dir  = _resolve_output_dir(cfg, run)
        results_csv = output_dir / "results.csv"

        if not results_csv.exists():
            sys.exit(f"No results found at {results_csv}")

        df = pd.read_csv(results_csv)
        param_cols = [
            c for c in df.columns
            if c not in {"combo_id", "objective_value", "error"}
            and c not in display_fields
        ]
        show_cols = ["combo_id"] + param_cols + [
            f for f in display_fields if f in df.columns
        ] + (["objective_value"] if "objective_value" in df.columns else [])
        show_cols = list(dict.fromkeys(show_cols))

        print(f"Run      : {run}")
        print(f"Results  : {results_csv}")
        print(f"Total    : {len(df)} combinations")
        print(f"Objective: {objective}")
        print(f"\nTop {top_n} by {objective}:")
        print(df[show_cols].head(top_n).to_string(index=False))

        best_json = output_dir / "best_strategy.json"
        if best_json.exists():
            print(f"\nBest cfg : {best_json}")

        csv_df = df
        csv_show_cols = show_cols

    if args.output and csv_df is not None:
        out_cols = [c for c in csv_show_cols if c in csv_df.columns]
        csv_df[out_cols].to_csv(args.output, index=False)
        print(f"\nSummary  → {Path(args.output).resolve()}")


# ---------------------------------------------------------------------------
# cmd: extract
# ---------------------------------------------------------------------------

def _extract_single(cfg: dict, run: str) -> Tuple[pd.DataFrame, List[str], List[str]]:
    """Re-analyze existing backtest logs for one task and overwrite results.csv."""
    objective      = cfg.get("objective", "pnl_net_total")
    display_fields = cfg.get("display_fields", ["filled", "matched_long", "matched_short", "pnl_gross_total", "pnl_net_total", "gross_win_rate", "net_win_rate", "profit_rate"])

    output_dir = _resolve_output_dir(cfg, run)
    runs_dir   = output_dir / "runs"

    params_cfg      = cfg.get("params", [])
    backtest_params = cfg.get("backtest", [])
    bt_prefixed     = [_prefix_bt(d) for d in backtest_params]
    all_params      = bt_prefixed + params_cfg

    if not all_params:
        sys.exit("Error: both 'params' and 'backtest' are empty — nothing to extract")

    keys, display_keys, combos = build_combinations(all_params)
    total = len(combos)

    results = []
    missing = 0

    for combo_id, combo in enumerate(combos):
        result_params = {dk: val for dk, val in zip(display_keys, combo)}
        result = {"combo_id": combo_id, **result_params}

        log_path = runs_dir / f"{combo_id:06d}" / "backtest.log"
        if not log_path.exists():
            result["error"] = "log not found"
            result["objective_value"] = float("-inf")
            missing += 1
            results.append(result)
            continue

        try:
            dfs = order_mod.read_jsons(str(log_path), "type")
            _, summary = order_mod.analyze(dfs)
        except Exception as e:
            result["error"] = str(e)
            result["objective_value"] = float("-inf")
            results.append(result)
            continue

        if summary.get("error"):
            result["error"] = summary["error"]
            result["objective_value"] = float("-inf")
            results.append(result)
            continue

        summary["objective_value"] = compute_objective(summary, objective)
        result.update(summary)
        results.append(result)

    df = pd.DataFrame(results).sort_values("objective_value", ascending=False).reset_index(drop=True)
    # Replace NaN/inf with 0 in all columns except objective_value (kept as -inf for sorting)
    other_cols = [c for c in df.columns if c != "objective_value"]
    df[other_cols] = df[other_cols].replace([float("inf"), float("-inf")], 0).fillna(0)

    csv_cols = ["combo_id"] + display_keys + display_fields + ["objective_value"]
    csv_cols = [c for c in dict.fromkeys(csv_cols) if c in df.columns]

    results_csv = output_dir / "results.csv"
    df[csv_cols].to_csv(results_csv, index=False)

    ok = sum(1 for r in results if not r.get("error"))
    print(f"[{run}] {total} combinations — {ok} ok, {missing} missing log  -> {results_csv}")

    return df, display_keys, display_fields


def cmd_extract(args) -> None:
    """Re-analyze existing backtest logs for all tasks and overwrite results.csv."""
    with open(args.config) as f:
        cfg = json.load(f)

    if args.opt_result is not None:
        cfg["opt_result"] = args.opt_result

    objective      = cfg.get("objective", "pnl_net_total")
    display_fields = cfg.get("display_fields", ["filled", "matched_long", "matched_short", "pnl_gross_total", "pnl_net_total", "gross_win_rate", "net_win_rate", "profit_rate"])
    top_n          = args.top

    tasks = cfg.get("tasks")

    if tasks:
        base_opt_result = cfg.get("opt_result") or (
            str(_get_anchor_opt_result()) if _get_anchor_opt_result() else None
        )
        all_dfs = []
        for run in tasks:
            if not isinstance(run, str) or not run:
                sys.exit("Error: each entry in 'tasks' must be a non-empty run name string")
            task_cfg = {k: v for k, v in cfg.items() if k != "tasks"}
            task_cfg["task"] = run
            if base_opt_result:
                task_cfg["opt_result"] = str(Path(base_opt_result) / run)
            else:
                task_cfg["opt_result"] = run
            print(f"\n{'='*60}\nTask: {run}\n{'='*60}")
            df, display_keys, _ = _extract_single(task_cfg, run)
            df = df.copy()
            df.insert(0, "task", run)
            show_cols = ["task", "combo_id"] + display_keys + [
                f for f in display_fields if f in df.columns
            ] + (["objective_value"] if "objective_value" in df.columns else [])
            show_cols = list(dict.fromkeys(show_cols))
            print(f"\nTop {top_n} by {objective}:")
            print(df[show_cols].head(top_n).to_string(index=False))
            all_dfs.append((df, display_keys))

        combined = pd.concat([d for d, _ in all_dfs], ignore_index=True)
        if "objective_value" in combined.columns:
            combined = combined.sort_values("objective_value", ascending=False).reset_index(drop=True)
        param_cols = all_dfs[0][1]
        show_cols = ["task", "combo_id"] + param_cols + [
            f for f in display_fields if f in combined.columns
        ] + (["objective_value"] if "objective_value" in combined.columns else [])
        show_cols = list(dict.fromkeys(show_cols))
        print(f"\n{'='*60}")
        print(f"Combined ({len(combined)} combinations across {len(all_dfs)} tasks) — top {top_n} by {objective}:")
        print(f"{'='*60}")
        print(combined[show_cols].head(top_n).to_string(index=False))

        if args.output:
            out_cols = [c for c in show_cols if c in combined.columns]
            combined[out_cols].to_csv(args.output, index=False)
            print(f"\nSummary  -> {Path(args.output).resolve()}")

    else:
        run = cfg.get("task")
        if not run:
            sys.exit("Error: 'task' or 'tasks' is required in config")

        print(f"\n{'='*60}\nTask: {run}\n{'='*60}")
        df, display_keys, _ = _extract_single(cfg, run)

        show_cols = ["combo_id"] + display_keys + [
            f for f in display_fields if f in df.columns
        ] + (["objective_value"] if "objective_value" in df.columns else [])
        show_cols = list(dict.fromkeys(show_cols))
        print(f"\nTop {top_n} by {objective}:")
        print(df[show_cols].head(top_n).to_string(index=False))

        if args.output:
            out_cols = [c for c in show_cols if c in df.columns]
            df[out_cols].to_csv(args.output, index=False)
            print(f"\nSummary  -> {Path(args.output).resolve()}")


# ---------------------------------------------------------------------------
# cmd: comb
# ---------------------------------------------------------------------------

def cmd_comb(args) -> None:
    """Print the full combination space of an optimize config without running anything."""
    with open(args.config) as f:
        cfg = json.load(f)

    params_cfg      = cfg.get("params", [])
    backtest_params = cfg.get("backtest", [])
    bt_prefixed     = [_prefix_bt(d) for d in backtest_params]
    all_params      = bt_prefixed + params_cfg

    if not all_params:
        sys.exit("Error: both 'params' and 'backtest' are empty — nothing to show")

    keys, display_keys, combos = build_combinations(all_params)
    total = len(combos)

    print(f"Config : {args.config}")
    print(f"Total  : {total} combinations")
    print()

    df = pd.DataFrame(combos, columns=display_keys)
    df.index.name = "#"
    print(df.to_string())


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="optimize.py",
        description="Anchor strategy parameter grid search",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # -- init --
    p_init = sub.add_parser("init", help="Scaffold an example optimize config for a run")
    p_init.add_argument("run", help="Base run name")
    p_init.add_argument("-s", "--strategy",   default=None, help="Explicit strategy.json path (overrides ANCHOR_CONFIG lookup)")
    p_init.add_argument("-o", "--output",     default=None, help="Output path for optimize.json (default: $ANCHOR_CONFIG/<run>/optimize.json or ./optimize.json)")
    p_init.add_argument("-r", "--opt-result", default=None, dest="opt_result", help="opt_result directory written into the config (default: $ANCHOR_OPT_RESULT/<run> or ./<run>)")

    # -- indicator --
    p_ind = sub.add_parser("indicator", help="Run backtest indicator for each task in a multi config")
    p_ind.add_argument("config", help="Path to optimize config JSON (must contain 'tasks' list)")

    # -- single --
    p_single = sub.add_parser("single", help="Execute the full grid search for one task")
    p_single.add_argument("config", help="Path to optimize config JSON")
    p_single.add_argument("--jobs",       type=int,           help="Parallel workers (overrides config)")
    p_single.add_argument("--opt-result", dest="opt_result",  help="opt_result directory (overrides config)")
    p_single.add_argument("--objective",                      help="Metric to maximize (overrides config)")
    p_single.add_argument("--top",        type=int, default=10, help="Number of top results to display (default: 10)")
    p_single.add_argument("--output",     dest="output",      help="Write summary to this CSV file")

    # -- multi --
    p_multi = sub.add_parser("multi", help="Run the grid search over multiple tasks")
    p_multi.add_argument("config", help="Path to optimize config JSON (must contain 'tasks' list)")
    p_multi.add_argument("--jobs",       type=int,           help="Parallel workers (overrides config)")
    p_multi.add_argument("--opt-result", dest="opt_result",  help="Base opt_result directory (overrides config); each task writes to <opt_result>/<task>")
    p_multi.add_argument("--objective",                      help="Metric to maximize (overrides config)")
    p_multi.add_argument("--top",        type=int, default=10, help="Number of top results to display (default: 10)")
    p_multi.add_argument("--output",     dest="output",      help="Write combined summary to this CSV file")
    p_multi.add_argument("--task",       dest="task",        help="Rerun only this task (must be in 'tasks' list)")
    p_multi.add_argument("--combids",    dest="combids",     help="Comma-separated combination IDs to rerun (requires --task)")

    # -- prepare --
    p_prep = sub.add_parser("prepare", help="Generate per-base configs and a multi-task optimize config")
    p_prep.add_argument("base", nargs="*",          help="Base tokens (e.g. eth btc sol); replaces {base} in strategy template")
    p_prep.add_argument("--base-file", default=None, dest="base_file", help="JSON file containing a list of base tokens (alternative to positional base args)")
    p_prep.add_argument("-s", "--strategy",  required=True, dest="strategy_template",  help="Strategy template JSON (use {base} as placeholder)")
    p_prep.add_argument("-b", "--backtest",  required=True, dest="backtest_template",  help="Backtest template JSON (copied verbatim per base)")
    p_prep.add_argument("-i", "--indicator", default=None,  dest="indicator_template", help="Indicator template JSON (use {base} as placeholder; optional)")
    p_prep.add_argument("-p", "--optimize",  required=True, dest="optimize_template",  help="Optimize template JSON (objective, jobs, display_fields, params, backtest)")
    p_prep.add_argument("-o", "--output",    default=None,                             help="Output path for the generated optimize.json (default: ./optimize.json)")
    p_prep.add_argument("--prefix",          default="",                               help="Prefix prepended to each base token to form the task name (default: '')")
    p_prep.add_argument("--suffix",          default="",                               help="Suffix appended to each base token to form the task name (default: '')")

    # -- summary --
    p_summary = sub.add_parser("summary", help="Display results of a completed optimization run")
    p_summary.add_argument("config", help="Path to optimize config JSON")
    p_summary.add_argument("--top",        type=int, default=10,  help="Number of top results to display (default: 10)")
    p_summary.add_argument("--opt-result", dest="opt_result",     help="opt_result directory (overrides config)")
    p_summary.add_argument("--output",     dest="output",         help="Write all results to this CSV file")

    # -- extract --
    p_extract = sub.add_parser("extract", help="Re-analyze existing backtest logs and overwrite results.csv")
    p_extract.add_argument("config", help="Path to optimize config JSON")
    p_extract.add_argument("--top",        type=int, default=10,  help="Number of top results to display (default: 10)")
    p_extract.add_argument("--opt-result", dest="opt_result",     help="opt_result directory (overrides config)")
    p_extract.add_argument("--output",     dest="output",         help="Write combined results to this CSV file")

    # -- comb --
    p_comb = sub.add_parser("comb", help="Print the combination space of an optimize config")
    p_comb.add_argument("config", help="Path to optimize config JSON")

    args = parser.parse_args()

    if args.cmd == "init":
        cmd_init(args)
    elif args.cmd == "prepare":
        cmd_prepare(args)
    elif args.cmd == "indicator":
        cmd_indicator(args)
    elif args.cmd == "single":
        cmd_single(args)
    elif args.cmd == "multi":
        cmd_multi(args)
    elif args.cmd == "summary":
        cmd_summary(args)
    elif args.cmd == "extract":
        cmd_extract(args)
    elif args.cmd == "comb":
        cmd_comb(args)


if __name__ == "__main__":
    main()
