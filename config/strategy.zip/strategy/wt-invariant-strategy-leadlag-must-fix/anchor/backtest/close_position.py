#!/usr/bin/env python3
"""
close_position.py — Scan a backtest log, compute remaining net position per
exchange from raw order records, and append synthetic close_at_end records to
clear any non-zero position.

The latest depth record for each exchange is used as the price source:
  - Closing a long  (sell): bidPrc1
  - Closing a short (buy):  askPrc1

Usage:
    python close_position.py backtest.log
    python close_position.py backtest.log --dry-run
    python close_position.py backtest.log -o out.log
    python close_position.py backtest.log --threshold 0.001
"""

import argparse
import json
import shutil
import sys
from collections import defaultdict
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Log scanning
# ---------------------------------------------------------------------------

def scan_log(logfile: str) -> Tuple[Dict[str, float], Dict[str, dict], int, str]:
    """
    Read the log and return:
      position     — net filled qty per exchange (side * filled, cumulated)
      latest_depth — latest depth record per symbol
      max_cid      — highest integer CID seen
      last_ts      — last timestamp string seen in the log
    """
    position: Dict[str, float] = defaultdict(float)
    latest_depth: Dict[str, dict] = {}
    max_cid = 0
    last_ts = ""

    with open(logfile, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                doc = json.loads(line)
            except json.JSONDecodeError:
                continue

            ts = doc.get("ts", "")
            if ts:
                last_ts = ts

            rec_type = doc.get("type", "")

            if rec_type in ("order", "close_at_end"):
                filled = float(doc.get("filled", 0))
                if filled <= 0:
                    continue
                side = int(doc.get("side", 0))
                exch = str(doc.get("exchange", ""))
                if exch:
                    position[exch] += side * filled
                cid_str = str(doc.get("cid", ""))
                try:
                    cid_val = int(cid_str)
                    if cid_val > max_cid:
                        max_cid = cid_val
                except ValueError:
                    pass

            elif rec_type == "depth":
                symbol = doc.get("symbol", "")
                if symbol:
                    latest_depth[symbol] = doc

    return dict(position), latest_depth, max_cid, last_ts


# ---------------------------------------------------------------------------
# Depth lookup
# ---------------------------------------------------------------------------

def find_depth(exchange: str, latest_depth: Dict[str, dict]) -> Optional[dict]:
    """Return the latest depth record whose symbol starts with '<exchange>.'."""
    for symbol, depth in latest_depth.items():
        if symbol.startswith(exchange + "."):
            return depth
    return None


# ---------------------------------------------------------------------------
# Record generation
# ---------------------------------------------------------------------------

def make_close_record(
    exchange: str,
    position: float,
    depth: dict,
    cid: str,
    ts: str,
) -> dict:
    """Build a synthetic close_at_end order record that clears *position*."""
    qty = abs(position)
    if position > 0:
        side = -1                          # long → sell to close
        price = float(depth.get("bidPrc1", 0))
    else:
        side = 1                           # short → buy to close
        price = float(depth.get("askPrc1", 0))

    return {
        "type":      "close_at_end",
        "cid":       cid,
        "oid":       "",
        "exchange":  exchange,
        "side":      side,
        "price":     price,
        "avg_price": price,
        "filled":    qty,
        "is_maker":  False,
        "level":     "info",
        "msg":       "",
        "ts":        ts,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Append synthetic close_at_end records to clear non-zero positions."
    )
    parser.add_argument("logfile", help="Path to backtest log")
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print synthetic records without modifying the log",
    )
    parser.add_argument(
        "-o", "--output",
        help="Write result to a new file instead of modifying in-place",
    )
    parser.add_argument(
        "--threshold", type=float, default=1e-9,
        help="Minimum absolute position to treat as non-zero (default: 1e-9)",
    )
    args = parser.parse_args()

    print(f"Scanning: {args.logfile}")
    position, latest_depth, max_cid, last_ts = scan_log(args.logfile)

    nonzero = {
        ex: qty for ex, qty in position.items()
        if abs(qty) > args.threshold
    }

    if not nonzero:
        print("Position is already zero — nothing to do.")
        return

    print("Remaining positions:")
    for ex, qty in nonzero.items():
        print(f"  {ex}: {qty:+.8f}")

    # Generate one close record per exchange.
    records: List[dict] = []
    cid_counter = max_cid
    for exchange, pos in nonzero.items():
        depth = find_depth(exchange, latest_depth)
        if depth is None:
            print(
                f"  WARNING: no depth record found for '{exchange}', skipping.",
                file=sys.stderr,
            )
            continue
        cid_counter += 1
        cid = f"{cid_counter:08d}"
        rec = make_close_record(exchange, pos, depth, cid, last_ts)
        records.append(rec)
        direction = "SELL" if rec["side"] == -1 else "BUY"
        print(f"  → {exchange}: {direction} {abs(pos):.8f} @ {rec['price']} (cid={cid})")

    if not records:
        return

    lines = [json.dumps(r, separators=(",", ":")) for r in records]

    if args.dry_run:
        print("\nDry run — records that would be appended:")
        for ln in lines:
            print(ln)
        return

    target = args.output
    if target:
        shutil.copy(args.logfile, target)
    else:
        target = args.logfile

    with open(target, "a") as f:
        for ln in lines:
            f.write(ln + "\n")

    print(f"\nAppended {len(records)} record(s) to {target}")


if __name__ == "__main__":
    main()
