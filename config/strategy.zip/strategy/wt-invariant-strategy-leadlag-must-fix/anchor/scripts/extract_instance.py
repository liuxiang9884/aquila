#!/usr/bin/env python3
"""
Extract instance data, depth records, and volatility snapshots from anchor strategy logs.

Parses log lines containing:
  - [instance] JSON data
  - DepthRecord<...> Go struct format
  - [Vol], [ComputeMakerAlignedVol], [ComputeTakerAlignedVol] volatility snapshots

Usage:
    python extract_instance.py -l backtest.log -o instance.csv [-d depth.csv] [-v vol.csv]
"""

import argparse
import csv
import json
import re
from datetime import datetime


def extract_backtest_instance_data(logfile: str) -> list[dict]:
    """Extract instance records from backtest newline-delimited JSON log."""
    instances = []

    with open(logfile, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            try:
                doc = json.loads(line)
                # Filter for instance type records
                if doc.get('type') == 'instance':
                    instances.append(doc)
            except json.JSONDecodeError:
                continue

    return instances


def parse_go_map(map_str: str) -> dict:
    """Parse Go map format: map[key1:val1 key2:val2 ...] to Python dict."""
    result = {}
    # Remove 'map[' prefix and ']' suffix
    if map_str.startswith('map[') and map_str.endswith(']'):
        map_str = map_str[4:-1]

    # Split by space but be careful with values that might contain spaces
    # Go map format: key:value pairs separated by space
    pairs = map_str.split()
    for pair in pairs:
        if ':' in pair:
            key, value = pair.split(':', 1)
            result[key] = value

    return result


def extract_depth_records(logfile: str) -> list[dict]:
    """Extract DepthRecord data from log file."""
    depths = []

    with open(logfile, 'r') as f:
        for line in f:
            # Look for DepthRecord pattern
            if 'DepthRecord<' not in line:
                continue

            # Extract timestamp (ISO format at start of line)
            ts_match = re.search(r'time=(\d{4}-\d{2}-\d{2}T[\d:.Z]+)', line)
            timestamp = ts_match.group(1) if ts_match else ""

            # Extract tags map
            tags_match = re.search(r'tags=map\[(.*?)\]', line)
            tags = parse_go_map(f"map[{tags_match.group(1)}]") if tags_match else {}

            # Extract fields map
            fields_match = re.search(r'fields=map\[(.*?)\]>', line)
            fields = parse_go_map(f"map[{fields_match.group(1)}]") if fields_match else {}

            # Combine tags and fields
            record = {'timestamp': timestamp}
            record.update(tags)
            record.update(fields)

            if tags or fields:  # Only add if we found something
                depths.append(record)

    return depths


def parse_log_fields(line: str) -> dict:
    """Parse key=value pairs from a log line.

    Handles both single-word values and multi-word values (e.g., msg=vol snapshot).
    """
    fields = {}
    # Match key=value patterns where value continues until next key= or end of line
    # Uses lookahead to detect where the next key= starts
    pattern = r'(\w+)=([^=]*?)(?=\s+\w+=|\s*$)'
    matches = re.findall(pattern, line)
    for key, value in matches:
        # Remove quotes and trim whitespace
        value = value.strip().strip('"')
        if value:
            fields[key] = value
    return fields


def extract_vol_logs(logfile: str) -> list[dict]:
    """Extract volatility snapshot records from log file.

    Parses logs with:
    - New format: msg=vol snapshot or type=vol (structured logging)
    - Legacy patterns: [Vol], [ComputeMakerAlignedVol], [ComputeTakerAlignedVol]

    Required fields: ema, eventTime, last, max, role
    Optional fields: _id, app, pkg, type, aSize, aVol, aMaxSize, aMin, aMax, aStart, aEnd,
                     bSize, bVol, bMaxSize, bMin, bMax, bStart, bEnd
    All fields present in log lines are captured dynamically.
    """
    vols = []

    with open(logfile, 'r') as f:
        for line in f:
            # Look for volatility log patterns (new structured format or legacy format)
            is_vol_log = (
                ('msg=vol snapshot' in line or 'type=vol' in line) or  # New structured format
                ('[Vol]' in line or '[ComputeMakerAlignedVol]' in line or '[ComputeTakerAlignedVol]' in line)  # Legacy format
            )
            if not is_vol_log:
                continue

            # Parse all key=value pairs from the line
            fields = parse_log_fields(line)

            # Extract timestamp (ISO format)
            ts_match = re.search(r'time=(\d{4}-\d{2}-\d{2}T[\d:.Z]+)', line)
            timestamp = ts_match.group(1) if ts_match else ""

            # Check if all required fields are present
            required_fields = {'ema', 'eventTime', 'last', 'max', 'role'}
            if not required_fields.issubset(set(fields.keys())):
                continue

            # Build record with timestamp and extracted fields
            record = {'timestamp': timestamp}
            record.update(fields)

            # Extract msg pattern if present (legacy format)
            msg_match = re.search(r'msg=\[([^\]]+)\]', line)
            if msg_match:
                record['msg_type'] = msg_match.group(1)

            vols.append(record)

    return vols


def extract_instance_data(logfile: str) -> list[dict]:
    """Extract instance records from log file."""
    instances = []

    with open(logfile, 'r') as f:
        for line in f:
            # Look for [instance] pattern
            if '[instance]' not in line:
                continue

            # Extract timestamp (ISO format at start of line)
            ts_match = re.search(r'time=(\d{4}-\d{2}-\d{2}T[\d:.Z]+)', line)
            timestamp = ts_match.group(1) if ts_match else ""

            # Extract JSON object after [instance]
            json_match = re.search(r'\[instance\]\s+({.*})', line)
            if not json_match:
                continue

            try:
                json_str = json_match.group(1)
                data = json.loads(json_str)
                data['timestamp'] = timestamp
                instances.append(data)
            except json.JSONDecodeError:
                continue

    return instances


def main():
    parser = argparse.ArgumentParser(description="Extract instance, depth, and volatility data from anchor logs")
    parser.add_argument("-l", "--logfile", required=True, help="Path to log file")
    parser.add_argument("-o", "--output", default="instance.csv", help="Output CSV file path for instance data")
    parser.add_argument("-d", "--depth", default=None, help="Output CSV file path for depth records (production logs only)")
    parser.add_argument("-v", "--vol", default=None, help="Output CSV file path for volatility snapshot records")
    parser.add_argument("-b", "--backtest", action="store_true", help="Parse backtest newline-delimited JSON format (instead of production structured logs)")
    args = parser.parse_args()

    print(f"Loading: {args.logfile}")

    # Choose extraction method based on log format
    if args.backtest:
        instances = extract_backtest_instance_data(args.logfile)
    else:
        instances = extract_instance_data(args.logfile)

    if instances:
        print(f"Found {len(instances)} instance records")
        # Get all unique field names
        all_keys = set()
        for inst in instances:
            all_keys.update(inst.keys())

        # Sort keys with timestamp first
        fieldnames = ['timestamp'] + sorted([k for k in all_keys if k != 'timestamp'])

        # Write to CSV
        with open(args.output, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for inst in instances:
                # Ensure all fields exist (fill missing with empty string)
                row = {k: inst.get(k, '') for k in fieldnames}
                writer.writerow(row)

        print(f"Instance data saved to {args.output}")
    else:
        print("No instance data found")

    # Extract depth records if requested (production logs only)
    if args.depth and not args.backtest:
        depths = extract_depth_records(args.logfile)
        if depths:
            print(f"Found {len(depths)} depth records")
            # Get all unique field names
            all_keys = set()
            for depth in depths:
                all_keys.update(depth.keys())

            # Sort keys with timestamp first
            fieldnames = ['timestamp'] + sorted([k for k in all_keys if k != 'timestamp'])

            # Write to CSV
            with open(args.depth, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for depth in depths:
                    # Ensure all fields exist (fill missing with empty string)
                    row = {k: depth.get(k, '') for k in fieldnames}
                    writer.writerow(row)

            print(f"Depth data saved to {args.depth}")
        else:
            print("No depth records found")

    # Extract volatility records if requested
    if args.vol:
        vols = extract_vol_logs(args.logfile)
        if vols:
            print(f"Found {len(vols)} volatility records")
            # Get all unique field names
            all_keys = set()
            for vol in vols:
                all_keys.update(vol.keys())

            # Sort keys with timestamp first
            fieldnames = ['timestamp'] + sorted([k for k in all_keys if k != 'timestamp'])

            # Write to CSV
            with open(args.vol, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for vol in vols:
                    # Ensure all fields exist (fill missing with empty string)
                    row = {k: vol.get(k, '') for k in fieldnames}
                    writer.writerow(row)

            print(f"Volatility data saved to {args.vol}")
        else:
            print("No volatility records found")


if __name__ == "__main__":
    main()
