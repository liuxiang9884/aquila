#!/usr/bin/env python3
"""
Extract JSON msg fields from anchor production logs.

Parses log lines containing msg=<JSON> and extracts them to CSV.
Supports: depth, incr (incremental updates), and other JSON message types.

Usage:
    python extract_msg.py -l production.log -o output.csv
    python extract_msg.py -l production.log -t depth -o depth.csv      # depth only
    python extract_msg.py -l production.log -t incr -o incr.csv        # incr only
"""

import argparse
import csv
import json
import re
from typing import Dict, List


def extract_json_messages(logfile: str, msg_type: str = None) -> List[Dict]:
    """
    Extract JSON msg objects from log file.

    Args:
        logfile: Path to log file
        msg_type: Filter by message type (depth, incr, etc.). None = all types.

    Returns:
        List of dictionaries with extracted data
    """
    messages = []

    with open(logfile, 'r') as f:
        for line in f:
            # Extract timestamp (ISO format)
            ts_match = re.search(r'time=(\d{4}-\d{2}-\d{2}T[\d:.Z]+)', line)
            timestamp = ts_match.group(1) if ts_match else ""

            # Extract JSON from msg= field
            # Handle msg={...} where ... is valid JSON
            msg_match = re.search(r'msg=(\{[^}]+(?:\{[^}]*\}[^}]*)*\})', line)
            if not msg_match:
                continue

            json_str = msg_match.group(1)
            try:
                data = json.loads(json_str)
            except json.JSONDecodeError as e:
                print(f"Warning: Failed to parse JSON in line: {line[:80]}... Error: {e}")
                continue

            # Detect message type from fields if not filtering
            detected_type = _detect_msg_type(data)

            # Filter by type if specified
            if msg_type and detected_type != msg_type:
                continue

            # Add metadata
            record = {
                'timestamp': timestamp,
                'type': detected_type,
            }
            record.update(data)
            messages.append(record)

    return messages


def _detect_msg_type(data: dict) -> str:
    """Detect message type based on fields present."""
    # Incr messages have txMs or localMs fields (transaction timestamp)
    if 'txMs' in data or 'localMs' in data:
        return 'incr'
    # Depth messages typically have depth-related fields
    if any(k in data for k in ['askPrc1', 'bidPrc1', 'localTs', 'serverTs']):
        return 'depth'
    # Default to unknown
    return 'unknown'


def main():
    parser = argparse.ArgumentParser(description="Extract JSON msg from anchor production logs")
    parser.add_argument("-l", "--logfile", required=True, help="Path to production log file")
    parser.add_argument("-o", "--output", default="messages.csv", help="Output CSV file path")
    parser.add_argument("-t", "--type", dest="msg_type", default=None,
                        help="Filter by message type (depth, incr, etc.). None = all types")
    args = parser.parse_args()

    print(f"Loading: {args.logfile}")
    if args.msg_type:
        print(f"Filtering for type: {args.msg_type}")

    messages = extract_json_messages(args.logfile, args.msg_type)

    if not messages:
        print("No messages found")
        return

    print(f"Found {len(messages)} messages")

    # Get all unique field names
    all_keys = set()
    for msg in messages:
        all_keys.update(msg.keys())

    # Sort keys with timestamp and type first
    fieldnames = ['timestamp', 'type'] + sorted([k for k in all_keys if k not in ['timestamp', 'type']])

    # Write to CSV
    with open(args.output, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        for msg in messages:
            # Ensure all fields exist (fill missing with empty string)
            row = {k: msg.get(k, '') for k in fieldnames}
            writer.writerow(row)

    print(f"Output saved to {args.output}")


if __name__ == "__main__":
    main()
