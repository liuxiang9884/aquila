#!/usr/bin/env python3
"""
Extract volatility snapshot logs from anchor strategy logs.

Parses log lines containing volatility data with fields:
  - time: ISO timestamp
  - ema: volatility EMA value
  - eventTime: event timestamp (unix seconds)
  - last: last volatility value
  - max: maximum volatility value
  - role: "maker" or "taker"

Log patterns:
  - [Vol] volatility snapshot
  - [ComputeTakerAlignedVol] / [ComputeMakerAlignedVol] scheduled snapshot

Usage:
    python extract_vol.py -l backtest.log -o vol.csv
"""

import argparse
import csv
import re
from datetime import datetime
from typing import Dict, List


def parse_log_fields(line: str) -> dict:
    """Parse key=value pairs from a log line."""
    fields = {}
    # Match key=value pairs (handles quoted and unquoted values)
    pattern = r'(\w+)=([^\s"]+|"[^"]*")'
    matches = re.findall(pattern, line)
    for key, value in matches:
        # Remove quotes if present
        value = value.strip('"')
        fields[key] = value
    return fields


def extract_vol_logs(logfile: str) -> List[Dict]:
    """Extract volatility snapshot records from log file."""
    vols = []

    with open(logfile, 'r') as f:
        for line in f:
            # Look for volatility log patterns
            if '[Vol]' not in line and '[ComputeMakerAlignedVol]' not in line and '[ComputeTakerAlignedVol]' not in line:
                continue

            # Parse all key=value pairs from the line
            fields = parse_log_fields(line)

            # Extract timestamp (ISO format)
            ts_match = re.search(r'time=(\d{4}-\d{2}-\d{2}T[\d:.Z]+)', line)
            timestamp = ts_match.group(1) if ts_match else ""

            # Check if all required fields are present
            required_fields = {'ema', 'eventTime', 'last', 'max', 'role'}
            if not required_fields.issubset(set(fields.keys())):
                continue

            # Build record with timestamp and extracted fields
            record = {'timestamp': timestamp}
            record.update(fields)

            # Extract msg pattern if present
            msg_match = re.search(r'msg=\[([^\]]+)\]', line)
            if msg_match:
                record['msg_type'] = msg_match.group(1)

            vols.append(record)

    return vols


def main():
    parser = argparse.ArgumentParser(description="Extract volatility snapshot data from anchor logs")
    parser.add_argument("-l", "--logfile", required=True, help="Path to log file")
    parser.add_argument("-o", "--output", default="vol.csv", help="Output CSV file path for volatility data")
    args = parser.parse_args()

    print(f"Loading: {args.logfile}")

    vols = extract_vol_logs(args.logfile)

    if vols:
        print(f"Found {len(vols)} volatility records")

        # Get all unique field names
        all_keys = set()
        for vol in vols:
            all_keys.update(vol.keys())

        # Sort keys with timestamp first
        fieldnames = ['timestamp'] + sorted([k for k in all_keys if k != 'timestamp'])

        # Write to CSV
        with open(args.output, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for vol in vols:
                # Ensure all fields exist (fill missing with empty string)
                row = {k: vol.get(k, '') for k in fieldnames}
                writer.writerow(row)

        print(f"Volatility data saved to {args.output}")
    else:
        print("No volatility records found")


if __name__ == "__main__":
    main()
