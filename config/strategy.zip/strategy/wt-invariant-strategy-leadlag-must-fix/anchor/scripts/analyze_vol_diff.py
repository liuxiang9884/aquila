#!/usr/bin/env python3
"""
Advanced volatility analysis: compare realtime vs backtest logs with exports.

Aligns records by eventTime (exact unix seconds) and exports detailed comparisons
to CSV, JSON, and optionally matplotlib plots.

Usage:
    python analyze_vol_diff.py -r realtime.log -b backtest.log \
        --csv-out metrics_csv/ --json-out stats.json --plot-out plots/ \
        --threshold 0.000001 --metrics aVol,bVol,ema
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd


def parse_log_fields(line: str) -> dict:
    """Parse key=value pairs from a structured log line."""
    fields = {}
    pattern = r'(\w+)=([^=]*?)(?=\s+\w+=|\s*$)'
    matches = re.findall(pattern, line)
    for key, value in matches:
        value = value.strip().strip('"')
        if value:
            fields[key] = value
    return fields


def extract_vol_logs_realtime(logfile: str) -> List[Dict]:
    """Extract volatility snapshot records from realtime log file."""
    vols = []
    with open(logfile, 'r') as f:
        for line in f:
            is_vol_log = (
                ('msg=vol snapshot' in line or 'type=vol' in line) or
                ('[Vol]' in line or '[ComputeMakerAlignedVol]' in line or '[ComputeTakerAlignedVol]' in line)
            )
            if not is_vol_log:
                continue

            fields = parse_log_fields(line)

            required_fields = {'ema', 'eventTime', 'last', 'max', 'role'}
            if not required_fields.issubset(set(fields.keys())):
                continue

            vols.append(fields)

    return vols


def extract_vol_logs_backtest(logfile: str) -> List[Dict]:
    """Extract volatility records from backtest newline-delimited JSON log."""
    vols = []
    with open(logfile, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                doc = json.loads(line)
                if doc.get('type') == 'vol':
                    vols.append(doc)
            except json.JSONDecodeError:
                continue
    return vols


class VolatilityAnalyzer:
    """Advanced volatility analysis with multiple output formats."""

    def __init__(
        self,
        realtime_file: str,
        backtest_file: str,
        metrics: List[str],
        threshold: float = 0.000001,
    ):
        self.realtime_file = realtime_file
        self.backtest_file = backtest_file
        self.metrics = metrics
        self.threshold = threshold
        self.real_df = None
        self.back_df = None
        self.comparisons = {}  # {(role, metric): comparison_df}
        self.statistics = {}  # {(role, metric): stats_dict}

    def load_logs(self):
        """Load and prepare both log files."""
        print(f"Loading realtime log: {self.realtime_file}")
        real_vol = extract_vol_logs_realtime(self.realtime_file)
        print(f"  Found {len(real_vol)} vol records")

        print(f"Loading backtest log: {self.backtest_file}")
        back_vol = extract_vol_logs_backtest(self.backtest_file)
        print(f"  Found {len(back_vol)} vol records")

        # Create DataFrames and set eventTime as index
        self.real_df = pd.DataFrame(real_vol)
        self.back_df = pd.DataFrame(back_vol)

        # Convert numeric columns
        for df in [self.real_df, self.back_df]:
            for col in self.metrics + ['eventTime']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')

        # Set eventTime as index (as int) for alignment
        if 'eventTime' in self.real_df.columns:
            self.real_df['eventTime'] = self.real_df['eventTime'].astype('int64')
            self.real_df = self.real_df.set_index('eventTime')

        if 'eventTime' in self.back_df.columns:
            self.back_df['eventTime'] = self.back_df['eventTime'].astype('int64')
            self.back_df = self.back_df.set_index('eventTime')

    def compare_all_metrics(self):
        """Compare all metrics for all roles."""
        roles = set()
        if 'role' in self.real_df.columns:
            roles.update(self.real_df['role'].unique())
        if 'role' in self.back_df.columns:
            roles.update(self.back_df['role'].unique())

        for role in roles:
            for metric in self.metrics:
                self._compare_metric(metric, str(role))

    def _compare_metric(self, metric: str, role: str):
        """Compare a single metric for a role, aligned by eventTime."""
        real_filtered = self.real_df[
            (self.real_df.get('role') == role) & (metric in self.real_df.columns)
        ]
        back_filtered = self.back_df[
            (self.back_df.get('role') == role) & (metric in self.back_df.columns)
        ]

        if real_filtered.empty or back_filtered.empty:
            return

        # Create comparison DataFrame - pandas auto-aligns by index (eventTime)
        merged = pd.DataFrame({
            'real': real_filtered[metric].astype(float),
            'back': back_filtered[metric].astype(float)
        }).dropna()

        if merged.empty:
            return

        merged['diff'] = merged['real'] - merged['back']
        merged['abs_diff'] = merged['diff'].abs()
        merged['rel_diff'] = merged['diff'] / (merged['real'].abs() + 1e-10)

        self.comparisons[(role, metric)] = merged

        # Compute statistics
        self.statistics[(role, metric)] = {
            'count': len(merged),
            'mean_diff': float(merged['diff'].mean()),
            'std_diff': float(merged['diff'].std()),
            'min_diff': float(merged['diff'].min()),
            'max_diff': float(merged['diff'].max()),
            'median_diff': float(merged['diff'].median()),
            'num_anomalies': len(merged[merged['abs_diff'] > self.threshold]),
        }

    def export_csv(self, output_dir: str):
        """Export detailed comparisons to CSV files."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        for (role, metric), comparison_df in self.comparisons.items():
            filename = output_path / f"{role}_{metric}_comparison.csv"
            comparison_df.to_csv(filename)
            print(f"Exported: {filename}")

    def export_json(self, output_file: str):
        """Export statistics to JSON."""
        output_dict = {}
        for (role, metric), stats in self.statistics.items():
            key = f"{role}_{metric}"
            output_dict[key] = stats

        with open(output_file, 'w') as f:
            json.dump(output_dict, f, indent=2)
        print(f"Exported: {output_file}")

    def plot_comparisons(self, output_dir: str):
        """Generate matplotlib plots of metric differences."""
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            print("Warning: matplotlib not installed, skipping plots")
            return

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        for (role, metric), comparison_df in self.comparisons.items():
            fig, axes = plt.subplots(2, 1, figsize=(12, 8))

            # Plot values
            axes[0].plot(comparison_df.index, comparison_df['real'], label='Real', alpha=0.7)
            axes[0].plot(comparison_df.index, comparison_df['back'], label='Backtest', alpha=0.7)
            axes[0].set_ylabel(metric)
            axes[0].set_title(f"{role.upper()} - {metric} Values")
            axes[0].legend()
            axes[0].grid(True, alpha=0.3)

            # Plot differences
            axes[1].plot(comparison_df.index, comparison_df['diff'], label='Difference', color='red', alpha=0.7)
            axes[1].axhline(y=self.threshold, color='orange', linestyle='--', label=f'Threshold (±{self.threshold})')
            axes[1].axhline(y=-self.threshold, color='orange', linestyle='--')
            axes[1].set_xlabel('Event Time')
            axes[1].set_ylabel('Difference')
            axes[1].set_title(f"{role.upper()} - {metric} Differences")
            axes[1].legend()
            axes[1].grid(True, alpha=0.3)

            filename = output_path / f"{role}_{metric}_plot.png"
            fig.tight_layout()
            fig.savefig(filename, dpi=100)
            plt.close(fig)
            print(f"Exported: {filename}")

    def print_summary(self):
        """Print text summary of statistics."""
        print("\n" + "=" * 80)
        print("VOLATILITY ANALYSIS SUMMARY")
        print("=" * 80)
        print(f"Alignment: eventTime (unix seconds)")
        print(f"Anomaly threshold: {self.threshold}")
        print()

        # Time range analysis
        if len(self.real_df) > 0 and len(self.back_df) > 0:
            real_min = int(self.real_df.index.min())
            real_max = int(self.real_df.index.max())
            back_min = int(self.back_df.index.min())
            back_max = int(self.back_df.index.max())

            overlap_min = max(real_min, back_min)
            overlap_max = min(real_max, back_max)

            print("TIME RANGE ANALYSIS:")
            print(f"  Realtime:  {real_min} to {real_max} ({real_max - real_min} seconds)")
            print(f"  Backtest:  {back_min} to {back_max} ({back_max - back_min} seconds)")

            if overlap_min <= overlap_max:
                overlap_seconds = overlap_max - overlap_min + 1
                print(f"  Overlap:   {overlap_min} to {overlap_max} ({overlap_seconds} seconds)")
            else:
                print(f"  Overlap:   NONE - time ranges don't intersect!")
            print()

        for (role, metric), stats in sorted(self.statistics.items()):
            print(f"{role.upper()} - {metric}:")

            # Show availability
            real_count = len(self.real_df[self.real_df['role'] == role])
            back_count = len(self.back_df[self.back_df['role'] == role])
            matched = stats['count']

            print(f"  Available:          {real_count} real, {back_count} backtest")
            if min(real_count, back_count) > 0:
                pct = (matched / min(real_count, back_count)) * 100
                print(f"  Matched:            {matched} eventTimes ({pct:.1f}% of min)")
            else:
                print(f"  Matched:            {matched} eventTimes")

            # Stats
            print(f"  Mean diff:          {stats['mean_diff']:.2e}")
            print(f"  Std diff:           {stats['std_diff']:.2e}")
            print(f"  Min diff:           {stats['min_diff']:.2e}")
            print(f"  Max diff:           {stats['max_diff']:.2e}")
            print(f"  Median diff:        {stats['median_diff']:.2e}")
            print(f"  Anomalies:          {stats['num_anomalies']}")
            print()

        print("=" * 80)


def main():
    parser = argparse.ArgumentParser(
        description="Advanced volatility analysis: compare realtime vs backtest (aligned by eventTime)"
    )
    parser.add_argument("-r", "--realtime", required=True, help="Path to realtime log")
    parser.add_argument("-b", "--backtest", required=True, help="Path to backtest log")
    parser.add_argument(
        "--metrics",
        default="aVol,bVol,ema,last",
        help="Comma-separated metrics to compare (default: aVol,bVol,ema,last)"
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.000001,
        help="Anomaly threshold for absolute difference (default: 0.000001)"
    )
    parser.add_argument(
        "--csv-out",
        default=None,
        help="Output directory for CSV comparisons"
    )
    parser.add_argument(
        "--json-out",
        default=None,
        help="Output file for JSON statistics"
    )
    parser.add_argument(
        "--plot-out",
        default=None,
        help="Output directory for matplotlib plots"
    )

    args = parser.parse_args()

    try:
        metrics = [m.strip() for m in args.metrics.split(',')]
        analyzer = VolatilityAnalyzer(
            args.realtime,
            args.backtest,
            metrics,
            args.threshold
        )

        print("Loading logs...")
        analyzer.load_logs()

        print("Comparing metrics...")
        analyzer.compare_all_metrics()

        analyzer.print_summary()

        if args.csv_out:
            print(f"\nExporting CSV to {args.csv_out}...")
            analyzer.export_csv(args.csv_out)

        if args.json_out:
            print(f"Exporting JSON to {args.json_out}...")
            analyzer.export_json(args.json_out)

        if args.plot_out:
            print(f"Generating plots in {args.plot_out}...")
            analyzer.plot_comparisons(args.plot_out)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
