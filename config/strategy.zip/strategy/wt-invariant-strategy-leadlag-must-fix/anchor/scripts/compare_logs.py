#!/usr/bin/env python3
"""
Compare volatility metrics between realtime and backtest logs.

Aligns records by eventTime (exact unix seconds) and compares metrics
(aVol, bVol, ema, last) across taker and maker roles.

Usage:
    python compare_logs.py -r realtime.log -b backtest.log [-o report.txt] [--threshold 0.000001]
"""

import argparse
import json
import re
import sys
from typing import Dict, List, Optional

import pandas as pd


def parse_log_fields(line: str) -> dict:
    """Parse key=value pairs from a structured log line."""
    fields = {}
    pattern = r'(\w+)=([^=]*?)(?=\s+\w+=|\s*$)'
    matches = re.findall(pattern, line)
    for key, value in matches:
        value = value.strip().strip('"')
        if value:
            fields[key] = value
    return fields


def extract_vol_logs_realtime(logfile: str) -> List[Dict]:
    """Extract volatility snapshot records from realtime log file."""
    vols = []
    with open(logfile, 'r') as f:
        for line in f:
            is_vol_log = (
                ('msg=vol snapshot' in line or 'type=vol' in line) or
                ('[Vol]' in line or '[ComputeMakerAlignedVol]' in line or '[ComputeTakerAlignedVol]' in line)
            )
            if not is_vol_log:
                continue

            fields = parse_log_fields(line)

            # Check required fields
            required_fields = {'ema', 'eventTime', 'last', 'max', 'role'}
            if not required_fields.issubset(set(fields.keys())):
                continue

            vols.append(fields)

    return vols


def extract_vol_logs_backtest(logfile: str) -> List[Dict]:
    """Extract volatility records from backtest newline-delimited JSON log."""
    vols = []
    with open(logfile, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                doc = json.loads(line)
                if doc.get('type') == 'vol':
                    vols.append(doc)
            except json.JSONDecodeError:
                continue
    return vols


class LogComparison:
    """Compare realtime and backtest volatility logs aligned on eventTime."""

    def __init__(self, realtime_file: str, backtest_file: str, threshold: float = 0.000001):
        self.threshold = threshold
        self.realtime_file = realtime_file
        self.backtest_file = backtest_file
        self.real_df = None
        self.back_df = None

    def load_logs(self):
        """Load and prepare both log files."""
        print(f"Loading realtime log: {self.realtime_file}")
        real_vol = extract_vol_logs_realtime(self.realtime_file)
        print(f"  Found {len(real_vol)} vol records")

        print(f"Loading backtest log: {self.backtest_file}")
        back_vol = extract_vol_logs_backtest(self.backtest_file)
        print(f"  Found {len(back_vol)} vol records")

        # Create DataFrames and set eventTime as index (as integer seconds)
        self.real_df = pd.DataFrame(real_vol)
        self.back_df = pd.DataFrame(back_vol)

        # Convert numeric columns
        for df in [self.real_df, self.back_df]:
            for col in ['aVol', 'bVol', 'ema', 'last', 'aMax', 'aMin', 'bMax', 'bMin', 'eventTime']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')

        # Set eventTime as index (as int) for alignment
        if 'eventTime' in self.real_df.columns:
            self.real_df['eventTime'] = self.real_df['eventTime'].astype('int64')
            self.real_df = self.real_df.set_index('eventTime')

        if 'eventTime' in self.back_df.columns:
            self.back_df['eventTime'] = self.back_df['eventTime'].astype('int64')
            self.back_df = self.back_df.set_index('eventTime')

    def compare_metric(self, metric: str, role: str) -> Optional[pd.DataFrame]:
        """Compare a metric for a specific role (taker/maker) aligned by eventTime."""
        real_filtered = self.real_df[self.real_df['role'] == role]
        back_filtered = self.back_df[self.back_df['role'] == role]

        if real_filtered.empty or back_filtered.empty:
            return None

        # Create comparison DataFrame - pandas auto-aligns by index (eventTime)
        comparison = pd.DataFrame({
            'real': real_filtered[metric].astype(float),
            'back': back_filtered[metric].astype(float)
        }).dropna()

        if comparison.empty:
            return None

        comparison['diff'] = comparison['real'] - comparison['back']
        return comparison

    def generate_report(self) -> str:
        """Generate comparison report."""
        lines = []
        lines.append("=" * 80)
        lines.append("VOLATILITY LOG COMPARISON REPORT")
        lines.append("=" * 80)
        lines.append(f"Realtime log: {self.realtime_file}")
        lines.append(f"Backtest log: {self.backtest_file}")
        lines.append(f"Alignment: eventTime (unix seconds)")
        lines.append(f"Anomaly threshold: {self.threshold}")
        lines.append("")

        # Time range analysis
        lines.append("TIME RANGE ANALYSIS")
        lines.append("-" * 80)

        real_min = int(self.real_df.index.min())
        real_max = int(self.real_df.index.max())
        back_min = int(self.back_df.index.min())
        back_max = int(self.back_df.index.max())

        overlap_min = max(real_min, back_min)
        overlap_max = min(real_max, back_max)

        lines.append(f"Realtime range:  {real_min} to {real_max} ({real_max - real_min} seconds)")
        lines.append(f"Backtest range:  {back_min} to {back_max} ({back_max - back_min} seconds)")

        if overlap_min <= overlap_max:
            overlap_seconds = overlap_max - overlap_min + 1
            lines.append(f"Overlap range:   {overlap_min} to {overlap_max} ({overlap_seconds} seconds)")
            overlap_percent = (overlap_seconds / max(real_max - real_min, back_max - back_min)) * 100
            lines.append(f"Coverage:        {overlap_percent:.1f}% of larger range")
        else:
            lines.append(f"Overlap range:   NONE - time ranges don't intersect!")

        lines.append("")

        # Summary statistics
        lines.append("SUMMARY")
        lines.append("-" * 80)
        lines.append(f"Realtime records: {len(self.real_df)}")
        lines.append(f"Backtest records: {len(self.back_df)}")
        lines.append("")

        # Compare each metric by role
        metrics = ['aVol', 'bVol', 'ema', 'last']
        roles = set()
        if 'role' in self.real_df.columns:
            roles.update(self.real_df['role'].unique())
        if 'role' in self.back_df.columns:
            roles.update(self.back_df['role'].unique())

        for role in sorted(roles):
            lines.append(f"\n{role.upper()} ROLE")
            lines.append("-" * 80)

            for metric in metrics:
                lines.append(f"\n{metric}:")

                comparison = self.compare_metric(metric, role)
                if comparison is None or comparison.empty:
                    real_count = len(self.real_df[self.real_df['role'] == role])
                    back_count = len(self.back_df[self.back_df['role'] == role])
                    lines.append(f"  Available: {real_count} real, {back_count} backtest")
                    lines.append(f"  Matched: 0 (no eventTime overlap)")
                    continue

                real_count = len(self.real_df[self.real_df['role'] == role])
                back_count = len(self.back_df[self.back_df['role'] == role])
                matched = len(comparison)

                # Statistics
                stats = comparison['diff'].describe()
                lines.append(f"  Available: {real_count} real, {back_count} backtest")
                lines.append(f"  Matched:   {matched} eventTimes ({(matched/min(real_count, back_count)*100):.1f}% of min)")
                lines.append(f"  Mean diff:   {stats['mean']:.2e}")
                lines.append(f"  Std diff:    {stats['std']:.2e}")
                lines.append(f"  Min diff:    {stats['min']:.2e}")
                lines.append(f"  25% diff:    {stats['25%']:.2e}")
                lines.append(f"  Median diff: {stats['50%']:.2e}")
                lines.append(f"  75% diff:    {stats['75%']:.2e}")
                lines.append(f"  Max diff:    {stats['max']:.2e}")

                # Anomalies
                anomalies = comparison[comparison['diff'].abs() > self.threshold]
                if not anomalies.empty:
                    lines.append(f"\n  Anomalies (|diff| > {self.threshold}): {len(anomalies)} found")
                    for event_time, row in anomalies.head(10).iterrows():
                        lines.append(
                            f"    eventTime {event_time}: real={row['real']:.2e} "
                            f"back={row['back']:.2e} diff={row['diff']:.2e}"
                        )
                    if len(anomalies) > 10:
                        lines.append(f"    ... and {len(anomalies) - 10} more")
                else:
                    lines.append(f"  No anomalies found")

        lines.append("\n" + "=" * 80)
        return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="Compare volatility metrics between realtime and backtest logs (aligned by eventTime)"
    )
    parser.add_argument("-r", "--realtime", required=True, help="Path to realtime log file")
    parser.add_argument("-b", "--backtest", required=True, help="Path to backtest log file")
    parser.add_argument(
        "-o", "--output",
        default=None,
        help="Output file path (default: print to stdout)"
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.000001,
        help="Anomaly threshold for absolute difference (default: 0.000001)"
    )

    args = parser.parse_args()

    try:
        comparator = LogComparison(args.realtime, args.backtest, args.threshold)
        comparator.load_logs()
        report = comparator.generate_report()

        if args.output:
            with open(args.output, 'w') as f:
                f.write(report)
            print(f"Report saved to {args.output}")
        else:
            print(report)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
