package indicator

import (
	"encoding/csv"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/anchor/algo"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/defaults"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/jsontype"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/queue"
	"gonum.org/v1/gonum/stat"
)

// IndicatorConfig is the configuration for the indicator sub-strategy.
type IndicatorConfig struct {
	Maker algo.ExchangeSymbol `json:"maker"` // "exchange.symbol" e.g. "gateio.eth_usdt"
	Taker algo.ExchangeSymbol `json:"taker"` // "exchange.symbol" e.g. "paradex.eth_usdc"

	Period    jsontype.Duration `json:"period" default:"4h"`
	Frequency jsontype.Duration `json:"frequency" default:"10s"`
	Roll      jsontype.Duration `json:"roll" default:"5m"`

	Percentiles []float64 `json:"percentiles"`
	InitRoll    string    `json:"init_roll"`

	Output string `json:"output"` // output directory
}

func (c *IndicatorConfig) SetDefault() {
	defaults.MustSet(c)
	if len(c.Percentiles) == 0 {
		c.Percentiles = []float64{0.9, 0.95, 0.99}
	}
}

func (c *IndicatorConfig) New(log *logrus.Entry) *IndicatorStrategy {
	return &IndicatorStrategy{
		config: *c,
		log:    log,
	}
}

// percentileWriter holds one CSV writer per percentile file.
type percentileWriter struct {
	file   *os.File
	writer *csv.Writer
}

// IndicatorStrategy computes rolling quantiles from basis ratios and outputs CSV.
type IndicatorStrategy struct {
	template.BaseSingleClientStrategy

	config IndicatorConfig
	log    *logrus.Entry

	makerDepth *utils.Depth
	takerDepth *utils.Depth

	lastDepthTime int64 // Latest depth update time (milisec)

	// Rolling window: timestamped samples kept for `period` duration
	sampleTimes       *queue.Queue[time.Time]
	longRatioHistory  *queue.Queue[float64]
	shortRatioHistory *queue.Queue[float64]

	// One CSV file per percentile
	writers []percentileWriter

	// Raw ratios and depth file
	rawFile   *os.File
	rawWriter *csv.Writer
}

func (s *IndicatorStrategy) SetContext(ctx template.IStrategyContext) {
	s.BaseSingleClientStrategy.SetContext(ctx)

	if err := os.MkdirAll(s.config.Output, 0755); err != nil {
		s.log.Fatalf("failed to create output directory '%s': %v", s.config.Output, err)
	}

	header := []string{"timestamp_ms", "long", "short"}

	s.writers = make([]percentileWriter, len(s.config.Percentiles))
	for i, p := range s.config.Percentiles {
		filename := filepath.Join(s.config.Output, fmt.Sprintf("q%.0f.csv", p*100))
		f, err := os.Create(filename)
		if err != nil {
			s.log.Fatalf("failed to create output file %s: %v", filename, err)
		}
		w := csv.NewWriter(f)
		w.Write(header)
		s.writers[i] = percentileWriter{file: f, writer: w}
	}

	// Create raw ratios and depth file
	rawFilename := filepath.Join(s.config.Output, "raw_ratios.csv")
	rawF, err := os.Create(rawFilename)
	if err != nil {
		s.log.Fatalf("failed to create output file %s: %v", rawFilename, err)
	}
	rawW := csv.NewWriter(rawF)
	rawHeader := []string{"timestamp_ms", "long_ratio", "short_ratio", "maker_ask", "maker_bid", "taker_ask", "taker_bid", "maker_uid", "maker_serverTs", "taker_uid", "taker_serverTs"}
	rawW.Write(rawHeader)
	s.rawFile = rawF
	s.rawWriter = rawW

	// Initialize queues for sample history (initial capacity based on period/frequency)
	period := s.config.Period.Duration()
	freq := s.config.Frequency.Duration()
	roll := s.config.Roll.Duration()
	estimatedCapacity := int(period / freq)
	if estimatedCapacity < 10 {
		estimatedCapacity = 10
	}
	s.sampleTimes = queue.NewQueue[time.Time](estimatedCapacity)
	s.longRatioHistory = queue.NewQueue[float64](estimatedCapacity)
	s.shortRatioHistory = queue.NewQueue[float64](estimatedCapacity)
	// if s.config.InitRoll != "" {
	// 	d, err := time.Parse("2006-01-02T15:04:05", s.config.InitRoll)
	// 	if err != nil {
	// 		panic(err)
	// 	}
	// }
	now := s.Context.Now()
	s.log.Infof("Context init time: %s", now)

	// Schedule initial callbacks
	// Schedule StoreHistoryRatio: wake time = Truncate(now, Frequency) + Frequency
	nextWakeFreq := now.Truncate(freq).Add(freq)
	s.Context.CallFunc(nextWakeFreq, s.storeHistoryRatio)

	// Schedule CalculateIndicator: wake time = Truncate(now, Roll) + Roll
	nextWakeRoll := now.Truncate(roll).Add(roll)
	s.Context.CallFunc(nextWakeRoll, s.calculateIndicator)
}

func DepthLevel1(depth *utils.Depth) string {
	return fmt.Sprintf("Depth<SeqID=%d, Time=%d, Ask[ %f @ %f ], Bid[ %f @ %f ]>", depth.MetaData.DepthSeqId, depth.ServerTS, (*depth.Asks)[0].Prc, (*depth.Asks)[0].Qty, (*depth.Bids)[0].Prc, (*depth.Bids)[0].Qty)
}

func (s *IndicatorStrategy) OnDepth(depth *utils.Depth) error {
	exchangeName := depth.GetSymbol().GetExchangeName()
	switch exchangeName {
	case s.config.Maker.Exchange:
		if s.makerDepth != nil {
			s.Context.ReturnDepthToPool(s.makerDepth)
		}
		s.makerDepth = depth
		if depth.ServerTS > s.lastDepthTime {
			s.lastDepthTime = depth.ServerTS
		}
		return nil
	case s.config.Taker.Exchange:
		if s.takerDepth != nil {
			s.Context.ReturnDepthToPool(s.takerDepth)
		}
		s.takerDepth = depth
		if depth.ServerTS > s.lastDepthTime {
			s.lastDepthTime = depth.ServerTS
		}
	default:
		s.Context.ReturnDepthToPool(depth)
		return nil
	}
	return nil
}

// storeHistoryRatio stores ratio samples at Frequency intervals
func (s *IndicatorStrategy) storeHistoryRatio() error {
	now := s.Context.Now()
	period := s.config.Period.Duration()
	freq := s.config.Frequency.Duration()

	// Check stop condition: current time > latest depth time + Roll
	if s.lastDepthTime > 0 && now.Sub(time.UnixMilli(s.lastDepthTime)) > s.config.Roll.Duration() {
		return nil
	}

	makerDepth := s.makerDepth
	takerDepth := s.takerDepth

	if makerDepth == nil || takerDepth == nil ||
		makerDepth.Asks == nil || len(*makerDepth.Asks) == 0 ||
		makerDepth.Bids == nil || len(*makerDepth.Bids) == 0 ||
		takerDepth.Asks == nil || len(*takerDepth.Asks) == 0 ||
		takerDepth.Bids == nil || len(*takerDepth.Bids) == 0 {
		// Reschedule for next interval
		nextWake := now.Add(freq)
		s.Context.CallFunc(nextWake, s.storeHistoryRatio)
		return nil
	}

	// Store ratio sample
	makerAsk := (*makerDepth.Asks)[0].Prc
	makerBid := (*makerDepth.Bids)[0].Prc
	takerAsk := (*takerDepth.Asks)[0].Prc
	takerBid := (*takerDepth.Bids)[0].Prc

	longRatio := (makerAsk - takerAsk) / (makerAsk + takerAsk) * 2
	shortRatio := (takerBid - makerBid) / (takerBid + makerBid) * 2

	s.sampleTimes.Put(now)
	s.longRatioHistory.Put(longRatio)
	s.shortRatioHistory.Put(shortRatio)

	// Write raw ratios and depth to file
	tsMs := fmt.Sprintf("%d", now.UnixMilli())
	s.rawWriter.Write([]string{
		tsMs,
		fmt.Sprintf("%.10f", longRatio),
		fmt.Sprintf("%.10f", shortRatio),
		fmt.Sprintf("%.10f", makerAsk),
		fmt.Sprintf("%.10f", makerBid),
		fmt.Sprintf("%.10f", takerAsk),
		fmt.Sprintf("%.10f", takerBid),
		fmt.Sprintf("%d", makerDepth.MetaData.DepthSeqId),
		fmt.Sprintf("%d", makerDepth.ServerTS),
		fmt.Sprintf("%d", takerDepth.MetaData.DepthSeqId),
		fmt.Sprintf("%d", takerDepth.ServerTS),
	})

	// Evict samples older than period from queue front
	cutoff := now.Add(-period)
	for {
		if ts, ok := s.sampleTimes.Tail(); ok && ts.Before(cutoff) {
			s.sampleTimes.Pop()
			s.longRatioHistory.Pop()
			s.shortRatioHistory.Pop()
		} else {
			break
		}
	}

	// Schedule next StoreHistoryRatio
	nextWake := now.Add(freq)
	s.Context.CallFunc(nextWake, s.storeHistoryRatio)
	return nil
}

// calculateIndicator calculates and stores quantile indicators at Roll intervals
func (s *IndicatorStrategy) calculateIndicator() error {
	now := s.Context.Now()
	roll := s.config.Roll.Duration()

	// Check stop condition: current time > latest depth time + Roll
	if s.lastDepthTime > 0 && now.Sub(time.UnixMilli(s.lastDepthTime)) > roll {
		return nil
	}

	if s.longRatioHistory.Size() == 0 {
		// Reschedule for next interval
		nextWake := now.Add(roll)
		s.Context.CallFunc(nextWake, s.calculateIndicator)
		return nil
	}

	// Calculate quantiles from queue content
	longSorted := s.longRatioHistory.ToSlice()
	sort.Float64s(longSorted)

	shortSorted := s.shortRatioHistory.ToSlice()
	sort.Float64s(shortSorted)

	tsMs := fmt.Sprintf("%d", now.UnixMilli())
	fields := logrus.Fields{"samples": s.longRatioHistory.Size(), "time": now}

	for i, p := range s.config.Percentiles {
		longQ := stat.Quantile(p, stat.Empirical, longSorted, nil)
		shortQ := stat.Quantile(p, stat.Empirical, shortSorted, nil)

		s.writers[i].writer.Write([]string{
			tsMs,
			fmt.Sprintf("%.10f", longQ),
			fmt.Sprintf("%.10f", shortQ),
		})

		fields[fmt.Sprintf("long_%.0f", p*100)] = fmt.Sprintf("%.10f", longQ)
		fields[fmt.Sprintf("short_%.0f", p*100)] = fmt.Sprintf("%.10f", shortQ)
	}

	s.log.WithFields(fields).Info("indicator")

	// Schedule next CalculateIndicator
	nextWake := now.Add(roll)
	s.Context.CallFunc(nextWake, s.calculateIndicator)
	return nil
}

func (s *IndicatorStrategy) OnTrade(trade *utils.Trade) error {
	s.Context.ReturnTradeToPool(trade)
	return nil
}

func (s *IndicatorStrategy) OnRawBBO(bbo *utils.BBO) error {
	s.Context.ReturnBBOToPool(bbo)
	return nil
}

func (s *IndicatorStrategy) OnOrder(msg *utils.OrderMessage) error {
	s.Context.ReturnOrderMessageToPool(msg)
	return nil
}

func (s *IndicatorStrategy) Brief() {
	for _, w := range s.writers {
		w.writer.Flush()
		w.file.Close()
	}
	if s.rawWriter != nil {
		s.rawWriter.Flush()
		s.rawFile.Close()
	}
	s.log.Infof("[Indicator] Done. Output dir: %s", s.config.Output)
}
