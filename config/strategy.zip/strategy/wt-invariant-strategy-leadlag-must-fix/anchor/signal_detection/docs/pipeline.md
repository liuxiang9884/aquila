# Pipeline Phases

## Phase 1a — `build_maker_trx_front(maker_bbo, maker_trade) → List[Trx]`

Merges BBO and Trade streams by `tx_time` (BBO wins ties). Maintains a
`DepthCache`. Emits a `Trx` whenever a trade crosses the cached best price,
using `min(cache.qty, trade.qty)` as fill quantity. Assumes our order is
**first in queue**. Sets `level_time` to the `tx_time` of the BBO that
established the current price level.

## Phase 1b — `build_maker_trx_back(maker_bbo, maker_trade) → List[Trx]` *(default)*

Same merge logic. Tracks `ahead_ask_qty` / `ahead_bid_qty` (reset to
`bbo.qty` on every BBO update) to model resting orders ahead of us. A
matching trade first drains the ahead queue; only the overflow emits a `Trx`.
Produces **fewer and later** fills than Phase 1a. Also sets `level_time`.

## Phase 2 — `build_expect_taker_trx(maker_trx, delta_t) → List[Trx]`

For each maker fill, projects a counter-trade on the taker exchange arriving
`delta_t` ms later. Taker side = opposite of maker side. Price is `None`.

## Phase 3 — `fill_taker_trx(taker_bbo, taker_trade, expect_taker_trx) → List[Trx]`

Merges taker BBO, taker Trade, and expected taker trx by `tx_time`
(priority: BBO > Trade > Trx). Taker Trade events deplete the cache without
emitting. Each expected trx is filled at the current cache price. Sets
`level_time` to the `tx_time` of the taker BBO active at fill time. Output
is strictly 1:1 with input.

## Phase 4 — `build_pair_table(maker_trx, filled_taker_trx) → pd.DataFrame`

Zips maker and taker fills 1:1 and computes spread metrics.
See [data_structures.md](data_structures.md) for full column reference.
