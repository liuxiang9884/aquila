# Utilities

## Filter & Threshold

### `filter_pairs(df, ind) → (df_buy, df_sell)`

Joins `ind` to pair table via backward asof on `maker_tx_time`.

- `action_side == +1`: keep where `action_ratio <= qDown`
- `action_side == -1`: keep where `action_ratio >= qUp`

`ind` must have columns: `timestamp_ms`, `qUp`, `qDown`.

### `scale_indicator(ind, alpha=1.0, delta=0.0) → pd.DataFrame`

Returns a copy of `ind` with `qUp` / `qDown` scaled around their midpoint:

```
mid       = (qUp + qDown) / 2
gap       = (qUp - qDown) / 2
new_gap   = gap * alpha + delta
new_qUp   = mid + new_gap
new_qDown = mid - new_gap
```

- `alpha=1.0, delta=0.0` → identity (original thresholds)
- `alpha > 1` or `delta > 0` → wider band (looser T)
- `alpha < 1` or `delta < 0` → narrower band (stricter T)
- Raises `ValueError` if `alpha < 0`

---

## BBO Ratio

### `compute_bbo_ratio_resampled(maker_bbo_raw, taker_bbo_raw) → pd.DataFrame`

Resamples both BBO streams to a 1s grid, inner-joins on common timestamps.

| Column | Formula |
|---|---|
| `ask_ratio` | `taker.ask / maker.ask - 1` |
| `bid_ratio` | `taker.bid / maker.bid - 1` |

### `add_level_bbo_ratios(df, maker_bbo_raw, taker_bbo_raw) → pd.DataFrame`

Looks up maker BBO at `maker_level_time` and taker BBO at `taker_level_time`
per pair row, appends `ask_ratio` and `bid_ratio` columns.

---

## BBO Resampling

### `_resample_bbo(bbo_raw, level_times) → pd.DataFrame`

Resamples BBO to 1s grid. BBO rows in `level_times` are pinned at their exact
millisecond timestamp and are not lost to binning.

---

## Plot

### `plot_single(config, df_buy, df_sell, ind)`

Two-panel figure:

**Panel 1 — Price**
- Maker and taker BBO lines (1s + level-time snapshots)
- Filtered maker/taker fill scatter (triangle markers)

**Panel 2 — Ratio**
- Unified `ask_ratio` / `bid_ratio` line
- `qUp` / `qDown` dashed reference lines
- Action ratio scatter: buy = green `^`, sell = red `v`
