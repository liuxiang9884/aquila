# Signal Operators & Set Metrics

## Signal Operators

### `SignalOperator` (base class)

Abstract base with one method: `compute(signal_series, ind) → pd.DataFrame`.

### `DirectSignalOperator`

Default operator. Delegates to `filter_action_signals()`.

### `RollingQuantileSignalOperator(window=100, quantile=0.5)`

Delegates to `filter_action_signals_rolling_quantile()`. Triggers only when
both the current ratio and the rolling quantile satisfy the threshold.

---

## `compute_signal_series(maker_bbo, taker_bbo) → pd.DataFrame`

Dual-pointer scan over the merged maker and taker BBO streams. On every
pointer advance one record is emitted. Tie-breaking at equal `tx_time`:
maker advances first.

| Column | Meaning |
|---|---|
| `tx_time` | `max(maker_tx_time, taker_tx_time)` |
| `maker_tx_time` | Most recent maker BBO tx_time |
| `maker_uid` | `update_id` of the current maker BBO row |
| `taker_tx_time` | Most recent taker BBO tx_time |
| `taker_uid` | `update_id` of the current taker BBO row |
| `ask_ratio` | `taker.ask / maker.ask - 1` |
| `bid_ratio` | `taker.bid / maker.bid - 1` |

---

## `filter_action_signals(signal_series, ind) → pd.DataFrame`

Joins `ind` via backward asof on `tx_time`, then keeps:
- **Long** (`action_side=+1`): `ask_ratio < qDown`
- **Short** (`action_side=-1`): `bid_ratio > qUp`

Additional columns:

| Column | Meaning |
|---|---|
| `action_side` | +1 = long, -1 = short |
| `signal_start_time` | tx_time when the current run first triggered |
| `signal_active` | `tx_time - signal_start_time` (ms active) |

---

## `filter_action_signals_rolling_quantile(signal_series, ind, window, quantile) → pd.DataFrame`

Independent alternative to `filter_action_signals()` — same output schema.
Triggers only when **both** current ratio and rolling quantile satisfy threshold:

```
long  (action_side=+1): ask_ratio < qDown  AND  ask_ratio_q < qDown
short (action_side=-1): bid_ratio > qUp    AND  bid_ratio_q > qUp
```

Rows where rolling window is not yet full (NaN quantile) are non-triggering.
Additional diagnostic columns: `ask_ratio_q`, `bid_ratio_q`.

Parameters: `window=100`, `quantile=0.5`.

---

## Set Definitions (A, E, T)

```
A = set(action_signals['maker_uid'])          — signal BBO uids
E = set(pairs['maker_level_uid'])             — executable trx BBO uids
T = set(filtered_pairs['maker_level_uid'])    — profitable trx BBO uids
T ⊆ E by construction
```

Keys are `update_id` values (uint64), deduplicated.

---

## `compute_pair_sets(action_signals, pairs, filtered_buy, filtered_sell) → dict`

Returns raw A, E, T sets per side.

```python
result.pair_sets["buy"]["A"]   # set of maker_uid
result.pair_sets["buy"]["E"]   # set of maker_level_uid
result.pair_sets["buy"]["T"]   # set of maker_level_uid
```

---

## `compute_pair_metrics(action_signals, pairs, filtered_buy, filtered_sell) → dict`

Returns numeric metrics per side:

| Key | Formula | Meaning |
|---|---|---|
| `count_A` | `len(A)` | Signal count |
| `count_E` | `len(E)` | Executable trx count |
| `count_T` | `len(T)` | Profitable trx count |
| `count_A_and_E` | `len(A ∩ E)` | Signal → executable |
| `count_T_and_A` | `len(T ∩ A)` | Signal → profitable |
| `signal_exec_rate` | `\|A∩E\| / \|A\|` | Fraction of signals that produced a fill |
| `fill_quality_rate` | `\|T∩A\| / \|A∩E\|` | Fraction of fills that passed threshold |
