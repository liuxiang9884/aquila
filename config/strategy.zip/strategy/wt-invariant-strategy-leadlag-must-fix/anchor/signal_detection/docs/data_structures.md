# Data Structures

## `Trx`
```
tx_time         : int           — exchange transmit time (UTC ms)
price           : float | None  — fill price; None for unpriced expect_taker entries
qty             : float         — filled quantity
side            : int           — +1 buy, -1 sell
level_time      : int           — tx_time of the BBO that established this price level
                                  (0 for taker-side trx where not meaningful)
level_uid       : int           — update_id of that BBO row (0 default)
active_duration : int           — ms elapsed since the price level was first seen (0 default)
```

## `DepthCache`
```
bid_price, bid_qty, ask_price, ask_qty : float
```
Always replaced on update — never mutated in place.

---

## Config Classes

### `FileDataSourceConfig`

| Field | Type | Meaning |
|---|---|---|
| `maker_file` | `str` | Explicit path to maker HDF5 file |
| `taker_file` | `str` | Explicit path to taker HDF5 file |

### `RangeDataSourceConfig`

Resolves files from the standard directory tree for a range of hours.

File path: `{root}/{datehour}/{symbol}_{datehour}.h5`

| Field | Type | Meaning |
|---|---|---|
| `root` | `str` | Root data directory |
| `maker` | `str` | Maker symbol, e.g. `"gateio.eth_usdt_swap"` |
| `taker` | `str` | Taker symbol, e.g. `"paradex.eth_usdc_swap"` |
| `start` | `str` | Inclusive start in `YYYYmmddHH` format |
| `end` | `str` | Inclusive end in `YYYYmmddHH` format |

Method: `iter_file_configs() → Iterator[FileDataSourceConfig]`

### `ComputeConfig`

| Field | Type | Default | Meaning |
|---|---|---|---|
| `delta_t` | `int` | — | Taker latency in ms |
| `maker_mode` | `str` | `"back"` | `"front"` or `"back"` maker trx method |
| `signal_operator` | `SignalOperator` | `DirectSignalOperator()` | How to compute action signals |
| `threshold_scaler` | `ThresholdScaler` | `ThresholdScaler()` | How to scale qUp/qDown for T set |

### `DetectionConfig`

| Field | Type | Meaning |
|---|---|---|
| `source` | `FileDataSourceConfig` | HDF5 file paths for this run |
| `compute` | `ComputeConfig` | Computation parameters |

---

## `DetectionResult`

Dataclass holding all intermediate and final tables:

| Field | Type | Meaning |
|---|---|---|
| `pairs` | `pd.DataFrame` | Full pair table (set E) |
| `maker_bbo` | `pd.DataFrame` | Raw maker BBO |
| `taker_bbo` | `pd.DataFrame` | Raw taker BBO |
| `maker_trx` | `list[Trx]` | Maker fills from Phase 1 |
| `taker_trx` | `list[Trx]` | Filled taker trx from Phase 3 |
| `signal_series` | `pd.DataFrame` | Full signal series |
| `action_signals` | `pd.DataFrame` | Filtered action signals |
| `df_buy` | `pd.DataFrame` | Threshold-filtered buy pairs (T, buy side) |
| `df_sell` | `pd.DataFrame` | Threshold-filtered sell pairs (T, sell side) |
| `metrics` | `dict` | Numeric metrics: count_*, signal_exec_rate, fill_quality_rate |
| `pair_sets` | `dict` | A, E, T sets: `result.pair_sets["buy"]["A"]` |

---

## Pair Table Columns

Output of `build_pair_table()`:

| Column | Meaning |
|---|---|
| `maker_tx_time` | Exchange transmit time of maker fill (UTC ms) |
| `maker_level_time` | tx_time of the BBO that established the maker price level |
| `maker_level_uid` | update_id of that maker BBO row |
| `maker_active` | ms the maker price level was active before the fill |
| `maker_price` | Maker fill price |
| `maker_qty` | Maker fill quantity |
| `maker_side` | +1 = maker buy, -1 = maker sell |
| `taker_tx_time` | Expected taker fill time (UTC ms) |
| `taker_level_time` | tx_time of the taker BBO active at taker fill time |
| `taker_level_uid` | update_id of that taker BBO row |
| `taker_active` | ms the taker price level was active before the fill |
| `taker_price` | Simulated taker fill price |
| `taker_qty` | Simulated taker fill quantity |
| `taker_side` | Opposite of maker side |
| `filled_qty` | `min(maker_qty, taker_qty)` |
| `spread` | Absolute price spread (positive = profitable) |
| `spread_ratio` | `spread / mid_price` |
| `action_side` | +1 if we buy taker, -1 if we sell taker |
| `action_ratio` | `taker_price / maker_price - 1` |
