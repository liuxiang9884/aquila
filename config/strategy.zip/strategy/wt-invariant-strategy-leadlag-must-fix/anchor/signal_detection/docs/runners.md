# Runners & CLI

## `run_detection(config) → pd.DataFrame`

Simple path — runs phases 1–4, returns the pair table only.

```python
config = DetectionConfig(
    source=FileDataSourceConfig(maker_file="...", taker_file="..."),
    compute=ComputeConfig(delta_t=500, maker_mode="back"),
)
df = run_detection(config)
```

---

## `run_full(config, ind) → DetectionResult`

Full pipeline — phases 1–4, signal series, signal operator, threshold scaling,
filter_pairs, metrics. Returns all intermediate tables in a `DetectionResult`.

```python
config = DetectionConfig(
    source=FileDataSourceConfig(maker_file="...", taker_file="..."),
    compute=ComputeConfig(
        delta_t=500,
        signal_operator=DirectSignalOperator(),
        threshold_scaler=ThresholdScaler(alpha=1.0, delta=0.0),
    ),
)
result = run_full(config, ind)
# result.pairs, result.signal_series, result.action_signals,
# result.df_buy, result.df_sell, result.metrics, result.pair_sets
```

---

## `run_range(source, compute, ind) → DetectionResult`

Runs `run_full` for every hour in `source`, concatenates all intermediate
DataFrames, recomputes `metrics` and `pair_sets` from the merged data.

```python
source = RangeDataSourceConfig(
    root="/data/raw_data_hourly",
    maker="gateio.eth_usdt_swap",
    taker="paradex.eth_usdc_swap",
    start="2026022601",
    end="2026022623",
)
result = run_range(source, ComputeConfig(delta_t=500), ind)
```

---

## CLI

```
# Single hour, simple detection + plot
python signal_detector.py single <maker.h5> <taker.h5> <indicator.csv> \
    [-d DELTA_T] [-mm front|back]

# Single hour, full pipeline + metrics
python signal_detector.py full <maker.h5> <taker.h5> <indicator.csv> \
    [-d DELTA_T] [-mm front|back] \
    [-so direct|rolling] [--window W] [--quantile Q] \
    [--alpha A] [--delta D] [--plot-set T|T_and_A]

# Multi-hour range, merged metrics (no plot)
python signal_detector.py range <maker> <taker> <indicator.csv> <start> <end> \
    [-r ROOT] [-d DELTA_T] [-mm front|back] \
    [-so direct|rolling] [--window W] [--quantile Q] \
    [--alpha A] [--delta D]
```

Shared flags:
- `-d` — taker latency in ms (default: 500)
- `-mm` / `--maker-mode` — `front` or `back` (default: `back`)
- `-so` / `--signal-op` — `direct` (default) or `rolling`
- `--window` / `--quantile` — rolling quantile parameters
- `--alpha` / `--delta` — `ThresholdScaler` parameters (default: identity)
- `--plot-set` — `T` or `T_and_A` (default: `T_and_A`, `full` only)
- `-r` / `--root` — root data directory (default: `$DATA_DIR`, `range` only)
