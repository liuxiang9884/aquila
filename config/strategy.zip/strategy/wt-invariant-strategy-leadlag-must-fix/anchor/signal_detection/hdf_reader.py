#!/usr/bin/env python3
"""
HDF5 data reader for BBO and Trade tables.

Reads raw integer-encoded price/qty fields from HDF5 files and converts them
to human-readable float values using the per-file config table.

HDF5 schema (from xexchange/utils/h5reader/datatype.go):
  config : ShortConfigDescription  — price_multiplier, qty_multiplier, contract_value, ...
  bbo    : ShortBBODescription      — ask_price, ask_qty, bid_price, bid_qty (uint32), timestamps
  trade  : ShortTradeDescription    — price, qty (uint32), side, timestamps, trade_id, tag

Conversion:
  real_price = raw_price / price_multiplier
  real_qty   = raw_qty   / qty_multiplier * contract_value
"""

import os
from pathlib import Path
from typing import Optional

import pandas as pd
from dateutil import tz


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

DEFAULT_DATA_DIR = os.getenv("DATA_DIR", "/Users/caiming/Works/backtest-go/raw_data_hourly")


def hdf_path(datehour: str, symbol: str, data_dir: str = DEFAULT_DATA_DIR) -> Path:
    """
    Resolve the HDF5 file path for a given date-hour and symbol.

    File layout: {data_dir}/{datehour}/{symbol}_{datehour}.h5

    Parameters
    ----------
    datehour : str
        Date-hour string, e.g. '2026030400'.
    symbol : str
        Symbol name, e.g. 'paradex.eth_usdc_swap'.
    data_dir : str
        Root directory containing hourly data folders.
    """
    return Path(data_dir) / datehour / f"{symbol}_{datehour}.h5"


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config(datehour: str, symbol: str, data_dir: str = DEFAULT_DATA_DIR) -> pd.Series:
    """
    Load the config row from the HDF5 file.

    Returns a Series with fields including:
      price_multiplier (int64), qty_multiplier (int64), contract_value (float64)

    Parameters
    ----------
    datehour : str
        Date-hour string, e.g. '2026030400'.
    symbol : str
        Symbol name, e.g. 'paradex.eth_usdc_swap'.
    data_dir : str
        Root directory containing hourly data folders.
    """
    path = hdf_path(datehour, symbol, data_dir)
    df = pd.read_hdf(str(path), key="config")
    return df.iloc[0]


# ---------------------------------------------------------------------------
# BBO
# ---------------------------------------------------------------------------

def load_bbo(
    datehour: str,
    symbol: str,
    data_dir: str = DEFAULT_DATA_DIR,
    local_tz: Optional[object] = None,
) -> pd.DataFrame:
    """
    Load BBO (Best Bid/Offer) data from an HDF5 file.

    Raw integer price/qty fields are converted using the file's config table:
      ask_price = raw_ask_price / price_multiplier
      bid_price = raw_bid_price / price_multiplier
      ask_qty   = raw_ask_qty   / qty_multiplier * contract_value
      bid_qty   = raw_bid_qty   / qty_multiplier * contract_value

    The DataFrame index is set to local time derived from the ``localtime``
    column (millisecond UTC epoch).

    Columns after loading:
      id, update_id, ask_price, ask_qty, bid_price, bid_qty,
      localtime, timestamp, tx_time

    Parameters
    ----------
    datehour : str
        Date-hour string, e.g. '2026030400'.
    symbol : str
        Symbol name, e.g. 'paradex.eth_usdc_swap'.
    data_dir : str
        Root directory containing hourly data folders.
    local_tz : tzinfo, optional
        Timezone for the index. Defaults to the system local timezone.
    """
    path = hdf_path(datehour, symbol, data_dir)
    cfg = load_config(datehour, symbol, data_dir)

    df = pd.read_hdf(str(path), key="bbo")
    df = df.copy()

    price_mul = float(cfg["price_multiplier"])
    qty_mul = float(cfg["qty_multiplier"])
    contract_value = float(cfg["contract_value"])

    df["ask_price"] = df["ask_price"].astype(float) / price_mul
    df["bid_price"] = df["bid_price"].astype(float) / price_mul
    df["ask_qty"] = df["ask_qty"].astype(float) / qty_mul * contract_value
    df["bid_qty"] = df["bid_qty"].astype(float) / qty_mul * contract_value

    tzinfo = local_tz if local_tz is not None else tz.tzlocal()
    df.index = (
        pd.to_datetime(df["localtime"], unit="ms", utc=True)
        .dt.tz_convert(tzinfo)
        .dt.tz_localize(None)
    )
    df.index.name = "localtime_dt"
    return df


# ---------------------------------------------------------------------------
# Trade
# ---------------------------------------------------------------------------

SIDE_LONG = 1
SIDE_SHORT = 2


def load_trade(
    datehour: str,
    symbol: str,
    data_dir: str = DEFAULT_DATA_DIR,
    local_tz: Optional[object] = None,
) -> pd.DataFrame:
    """
    Load Trade data from an HDF5 file.

    Raw integer price/qty fields are converted using the file's config table:
      price = raw_price / price_multiplier
      qty   = raw_qty   / qty_multiplier * contract_value

    The ``side`` column uses integer codes: 1 = long (buy), 2 = short (sell).
    Use the module constants ``SIDE_LONG`` and ``SIDE_SHORT`` for comparisons.

    Columns after loading:
      id, price, qty, side, localtime, timestamp, tx_time, trade_id, tag

    Parameters
    ----------
    datehour : str
        Date-hour string, e.g. '2026030400'.
    symbol : str
        Symbol name, e.g. 'paradex.eth_usdc_swap'.
    data_dir : str
        Root directory containing hourly data folders.
    local_tz : tzinfo, optional
        Timezone for the index. Defaults to the system local timezone.
    """
    path = hdf_path(datehour, symbol, data_dir)
    cfg = load_config(datehour, symbol, data_dir)

    df = pd.read_hdf(str(path), key="trade")
    df = df.copy()

    price_mul = float(cfg["price_multiplier"])
    qty_mul = float(cfg["qty_multiplier"])
    contract_value = float(cfg["contract_value"])

    df["price"] = df["price"].astype(float) / price_mul
    df["qty"] = df["qty"].astype(float) / qty_mul * contract_value

    tzinfo = local_tz if local_tz is not None else tz.tzlocal()
    df.index = (
        pd.to_datetime(df["localtime"], unit="ms", utc=True)
        .dt.tz_convert(tzinfo)
        .dt.tz_localize(None)
    )
    df.index.name = "localtime_dt"
    return df


# ---------------------------------------------------------------------------
# Batch helpers
# ---------------------------------------------------------------------------

def batch_load_bbo(
    datehours: "list",
    symbol: str,
    data_dir: str = DEFAULT_DATA_DIR,
    local_tz: Optional[object] = None,
) -> pd.DataFrame:
    """
    Load and concatenate BBO data across multiple date-hours.

    Parameters
    ----------
    datehours : list of str
        Ordered list of date-hour strings.
    symbol : str
        Symbol name.
    data_dir : str
        Root directory containing hourly data folders.
    local_tz : tzinfo, optional
        Timezone for the index. Defaults to the system local timezone.
    """
    frames = [load_bbo(dh, symbol, data_dir, local_tz) for dh in datehours]
    return pd.concat(frames)


def batch_load_trade(
    datehours: "list",
    symbol: str,
    data_dir: str = DEFAULT_DATA_DIR,
    local_tz: Optional[object] = None,
) -> pd.DataFrame:
    """
    Load and concatenate Trade data across multiple date-hours.

    Parameters
    ----------
    datehours : list of str
        Ordered list of date-hour strings.
    symbol : str
        Symbol name.
    data_dir : str
        Root directory containing hourly data folders.
    local_tz : tzinfo, optional
        Timezone for the index. Defaults to the system local timezone.
    """
    frames = [load_trade(dh, symbol, data_dir, local_tz) for dh in datehours]
    return pd.concat(frames)
