#!/usr/bin/env python3
"""
Trading Signal Detector

Detects arbitrage opportunities between a maker exchange and a taker exchange
by simulating maker fills and projecting expected taker counter-trades.

Phases:
  1. build_maker_trx_front         — infer maker fills from BBO + Trade data
  2. build_expect_taker_trx  — project expected taker fills with latency offset
  3. fill_taker_trx          — simulate taker fills against taker market data
  4. build_pair_table        — compute spread for each maker/taker pair
"""

import argparse
import os
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterator, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from hdf_reader import load_bbo, load_trade

# Sentinel larger than any valid tx_time (UTC ms); used in merge-sort logic.
_SENTINEL = 10 ** 18

# ---------------------------------------------------------------------------
# Signal operators
# ---------------------------------------------------------------------------


class SignalOperator:
    """Base class for action signal operators."""

    def compute(
        self,
        signal_series,  # pd.DataFrame — output of compute_signal_series()
        ind,            # pd.DataFrame — indicator with timestamp_ms, qUp, qDown
    ):
        # type: (...) -> pd.DataFrame
        """Compute action signals from signal_series and indicator thresholds.

        Parameters
        ----------
        signal_series : pd.DataFrame
            Output of compute_signal_series().
        ind : pd.DataFrame
            Indicator DataFrame with columns: timestamp_ms, qUp, qDown.

        Returns
        -------
        pd.DataFrame
            Action signals with schema identical to filter_action_signals() output.
        """
        raise NotImplementedError


@dataclass
class DirectSignalOperator(SignalOperator):
    """Operator 1: trigger when current ratio crosses threshold directly."""

    buffer: float = 0.0

    def compute(self, signal_series, ind):
        # type: (pd.DataFrame, pd.DataFrame) -> pd.DataFrame
        return filter_action_signals(signal_series, ind, buffer=self.buffer)


@dataclass
class RollingQuantileSignalOperator(SignalOperator):
    """Operator 2: trigger when both current ratio and rolling quantile cross threshold."""

    window: int = 100
    quantile: float = 0.5
    buffer: float = 0.0

    def compute(self, signal_series, ind):
        # type: (pd.DataFrame, pd.DataFrame) -> pd.DataFrame
        return filter_action_signals_rolling_quantile(
            signal_series, ind,
            window=self.window,
            quantile=self.quantile,
            buffer=self.buffer,
        )


@dataclass
class ThresholdScaler:
    """Parameters for scaling qUp / qDown thresholds when computing T.

    alpha=1.0, delta=0.0 reproduces the original thresholds (identity).
    alpha > 1 or delta > 0 widens the band (looser T).
    alpha < 1 or delta < 0 narrows the band (stricter T).
    """

    alpha: float = 1.0
    delta: float = 0.0

    def apply(self, ind):
        # type: (pd.DataFrame) -> pd.DataFrame
        """Return a scaled copy of ind using scale_indicator()."""
        return scale_indicator(ind, alpha=self.alpha, delta=self.delta)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@dataclass
class FileDataSourceConfig:
    """Explicit HDF5 file paths for a single detection run.

    Attributes
    ----------
    maker_file : str
        Path to the maker exchange HDF5 file.
    taker_file : str
        Path to the taker exchange HDF5 file.
    """

    maker_file: str
    taker_file: str


_DATEHOUR_FMT = "%Y%m%d%H"


@dataclass
class RangeDataSourceConfig:
    """Data source resolved from a directory tree covering a range of hours.

    File path convention::

        {root}/{datehour}/{symbol}_{datehour}.h5

    Example:
        root  = "/data/raw_data_hourly"
        maker = "gateio.eth_usdt_swap"
        taker = "paradex.eth_usdc_swap"
        start = "2026022601"
        end   = "2026022623"

    Attributes
    ----------
    root : str
        Root directory containing per-hour subdirectories.
    maker : str
        Maker exchange symbol (e.g. ``"gateio.eth_usdt_swap"``).
    taker : str
        Taker exchange symbol (e.g. ``"paradex.eth_usdc_swap"``).
    start : str
        Inclusive start datehour in ``YYYYmmddHH`` format.
    end : str
        Inclusive end datehour in ``YYYYmmddHH`` format.
    """

    root: str
    maker: str
    taker: str
    start: str
    end: str

    def _resolve_file(self, symbol: str, datehour: str) -> str:
        filename = "{}_{}.h5".format(symbol, datehour)
        return os.path.join(self.root, datehour, filename)

    def iter_file_configs(self) -> Iterator[FileDataSourceConfig]:
        """Yield one FileDataSourceConfig per hour from start to end (inclusive)."""
        dt = datetime.strptime(self.start, _DATEHOUR_FMT)
        end_dt = datetime.strptime(self.end, _DATEHOUR_FMT)
        while dt <= end_dt:
            dh = dt.strftime(_DATEHOUR_FMT)
            yield FileDataSourceConfig(
                maker_file=self._resolve_file(self.maker, dh),
                taker_file=self._resolve_file(self.taker, dh),
            )
            dt += timedelta(hours=1)


@dataclass
class ComputeConfig:
    """Computation parameters for a single detection run.

    Attributes
    ----------
    delta_t : int
        Fixed taker latency in milliseconds.
    maker_mode : str
        Maker trx generation method: ``"front"`` (first-in-queue) or
        ``"back"`` (queue-aware, default).
    signal_operator : SignalOperator
        Strategy for computing action signals.  Defaults to DirectSignalOperator.
    threshold_scaler : ThresholdScaler
        Parameters for scaling qUp/qDown when computing set T.
        Defaults to identity (alpha=1.0, delta=0.0).
    """

    delta_t: int
    maker_mode: str = "back"
    signal_operator: SignalOperator = field(default_factory=DirectSignalOperator)
    threshold_scaler: ThresholdScaler = field(default_factory=ThresholdScaler)


@dataclass
class DetectionConfig:
    """Combined config for a single detection run.

    Attributes
    ----------
    source : FileDataSourceConfig
        HDF5 file paths for this run.
    compute : ComputeConfig
        Computation parameters.
    """

    source: FileDataSourceConfig
    compute: ComputeConfig


# ---------------------------------------------------------------------------
# Internal data structures
# ---------------------------------------------------------------------------


@dataclass
class DepthCache:
    """Best bid/offer snapshot from the most recent BBO event."""

    bid_price: float
    bid_qty: float
    ask_price: float
    ask_qty: float


@dataclass
class Trx:
    """A single transaction record.

    Attributes
    ----------
    tx_time : int
        Exchange transmit time in UTC milliseconds.
    price : float or None
        Execution price; None for unpriced expect_taker_trx entries.
    qty : float
        Executed quantity.
    side : int
        +1 = buy, -1 = sell.
    level_time : int
        tx_time of the BBO event that first established the price level
        at which this fill occurred.  0 for taker-side trx (not meaningful).
    """

    tx_time: int
    price: Optional[float]
    qty: float
    side: int
    level_time: int = 0
    level_uid: int = 0
    active_duration: int = 0


# ---------------------------------------------------------------------------
# File loading helpers
# ---------------------------------------------------------------------------


def _parse_hdf_path(file_path: str):
    """Extract (datehour, symbol, data_dir) from a canonical HDF5 file path.

    Expected layout: {data_dir}/{datehour}/{symbol}_{datehour}.h5
    """
    p = Path(file_path)
    datehour = p.parent.name
    symbol = p.stem[: -(len(datehour) + 1)]  # strip trailing "_{datehour}"
    data_dir = str(p.parent.parent)
    return datehour, symbol, data_dir


def _load_bbo(file_path: str) -> pd.DataFrame:
    dh, sym, dd = _parse_hdf_path(file_path)
    bbo = load_bbo(dh, sym, dd)
    changed = (bbo["ask_price"].diff() != 0) | (bbo["bid_price"].diff() != 0)
    update_time = (
        bbo["tx_time"]
        .where(changed)
        .ffill()
        .fillna(bbo["tx_time"].iloc[0])
        .astype("int64")
    )
    bbo = bbo.assign(
        update_time=update_time,
        active_duration=bbo["tx_time"] - update_time,
    )
    return bbo


def _load_trade(file_path: str) -> pd.DataFrame:
    dh, sym, dd = _parse_hdf_path(file_path)
    return load_trade(dh, sym, dd)


# ---------------------------------------------------------------------------
# Phase 1 — Build Maker Trx
# ---------------------------------------------------------------------------


def build_maker_trx_front(
    maker_bbo: pd.DataFrame,
    maker_trade: pd.DataFrame,
) -> List[Trx]:
    """Infer maker fills from BBO and Trade event streams.

    Merges BBO and Trade events by tx_time. At equal tx_time, BBO is
    processed before Trade. Maintains a DepthCache initialized from the
    first BBO record. Emits a Trx for every trade that crosses the best
    available price in the cache.

    Trade.side mapping: raw 1 -> +1 (aggressive buy), raw 2 -> -1 (aggressive sell).

    Parameters
    ----------
    maker_bbo : pd.DataFrame
        BBO DataFrame with columns: tx_time, bid_price, bid_qty, ask_price, ask_qty.
    maker_trade : pd.DataFrame
        Trade DataFrame with columns: tx_time, price, qty, side.

    Returns
    -------
    list of Trx
        Maker-side fills in chronological order.
    """
    bbo_tx = maker_bbo["tx_time"].values
    bbo_id = maker_bbo["update_id"].values
    bbo_active = maker_bbo["active_duration"].values
    bbo_bid_p = maker_bbo["bid_price"].values
    bbo_bid_q = maker_bbo["bid_qty"].values
    bbo_ask_p = maker_bbo["ask_price"].values
    bbo_ask_q = maker_bbo["ask_qty"].values

    trade_tx = maker_trade["tx_time"].values
    trade_p = maker_trade["price"].values
    trade_q = maker_trade["qty"].values
    # Map raw side codes: 1 -> +1 (buy), 2 -> -1 (sell)
    trade_side = np.where(maker_trade["side"].values == 1, 1, -1)

    n_bbo = len(bbo_tx)
    n_trade = len(trade_tx)

    if n_bbo == 0:
        return []

    # Seed cache from the first BBO; skip trades that arrived before it.
    first_bbo_t = int(bbo_tx[0])
    cache = DepthCache(
        bid_price=float(bbo_bid_p[0]),
        bid_qty=float(bbo_bid_q[0]),
        ask_price=float(bbo_ask_p[0]),
        ask_qty=float(bbo_ask_q[0]),
    )
    level_time = first_bbo_t
    level_uid = int(bbo_id[0])
    active_duration = int(bbo_active[0])

    bi = 1
    ti = 0
    # Skip trades before the first BBO.
    while ti < n_trade and int(trade_tx[ti]) < first_bbo_t:
        ti += 1

    result = []  # type: List[Trx]

    while bi < n_bbo or ti < n_trade:
        b_t = int(bbo_tx[bi]) if bi < n_bbo else _SENTINEL
        t_t = int(trade_tx[ti]) if ti < n_trade else _SENTINEL

        # Priority tuple: (tx_time, type_code); BBO=0 beats Trade=1 at same time.
        if (b_t, 0) <= (t_t, 1):
            # BBO event — refresh depth cache and record when this level was seen.
            cache = DepthCache(
                bid_price=float(bbo_bid_p[bi]),
                bid_qty=float(bbo_bid_q[bi]),
                ask_price=float(bbo_ask_p[bi]),
                ask_qty=float(bbo_ask_q[bi]),
            )
            level_time = b_t
            level_uid = int(bbo_id[bi])
            active_duration = int(bbo_active[bi])
            bi += 1
        else:
            # Trade event — emit maker fill if it crosses the cached price
            side = int(trade_side[ti])
            price = float(trade_p[ti])
            qty = float(trade_q[ti])
            tx = int(trade_tx[ti])

            if side == 1 and price >= cache.ask_price:
                # Aggressive buy — maker was resting at ask (maker sell)
                filled = min(cache.ask_qty, qty)
                if filled > 0:
                    result.append(
                        Trx(tx_time=tx, price=cache.ask_price, qty=filled, side=-1,
                            level_time=level_time, level_uid=level_uid,
                            active_duration=active_duration)
                    )
                    cache = DepthCache(
                        bid_price=cache.bid_price,
                        bid_qty=cache.bid_qty,
                        ask_price=cache.ask_price,
                        ask_qty=cache.ask_qty - filled,
                    )
            elif side == -1 and price <= cache.bid_price:
                # Aggressive sell — maker was resting at bid (maker buy)
                filled = min(cache.bid_qty, qty)
                if filled > 0:
                    result.append(
                        Trx(tx_time=tx, price=cache.bid_price, qty=filled, side=1,
                            level_time=level_time, level_uid=level_uid,
                            active_duration=active_duration)
                    )
                    cache = DepthCache(
                        bid_price=cache.bid_price,
                        bid_qty=cache.bid_qty - filled,
                        ask_price=cache.ask_price,
                        ask_qty=cache.ask_qty,
                    )
            ti += 1

    return result


# ---------------------------------------------------------------------------
# Phase 1b — Queue-Aware Maker Trx
# ---------------------------------------------------------------------------


def build_maker_trx_back(
    maker_bbo: pd.DataFrame,
    maker_trade: pd.DataFrame,
) -> List[Trx]:
    """Infer maker fills modelling our queue position behind existing resting orders.

    Same merge and tie-breaking rules as build_maker_trx_front() (BBO > Trade at
    equal tx_time).  On each BBO update the full qty at that level is treated
    as ahead of our order.  Subsequent matching trades first drain that
    ahead_qty; only the overflow beyond it fills our order.

    Parameters
    ----------
    maker_bbo : pd.DataFrame
        BBO DataFrame with columns: tx_time, bid_price, bid_qty, ask_price, ask_qty.
    maker_trade : pd.DataFrame
        Trade DataFrame with columns: tx_time, price, qty, side.

    Returns
    -------
    list of Trx
        Maker-side fills in chronological order.
    """
    bbo_tx = maker_bbo["tx_time"].values
    bbo_id = maker_bbo["update_id"].values
    bbo_active = maker_bbo["active_duration"].values
    bbo_bid_p = maker_bbo["bid_price"].values
    bbo_bid_q = maker_bbo["bid_qty"].values
    bbo_ask_p = maker_bbo["ask_price"].values
    bbo_ask_q = maker_bbo["ask_qty"].values

    trade_tx = maker_trade["tx_time"].values
    trade_p = maker_trade["price"].values
    trade_q = maker_trade["qty"].values
    trade_side = np.where(maker_trade["side"].values == 1, 1, -1)

    n_bbo = len(bbo_tx)
    n_trade = len(trade_tx)

    if n_bbo == 0:
        return []

    # Seed cache and ahead_qty from the first BBO.
    first_bbo_t = int(bbo_tx[0])
    cache = DepthCache(
        bid_price=float(bbo_bid_p[0]),
        bid_qty=float(bbo_bid_q[0]),
        ask_price=float(bbo_ask_p[0]),
        ask_qty=float(bbo_ask_q[0]),
    )
    ahead_ask_qty = cache.ask_qty
    ahead_bid_qty = cache.bid_qty
    level_time = first_bbo_t
    level_uid = int(bbo_id[0])
    active_duration = int(bbo_active[0])

    bi = 1
    ti = 0
    while ti < n_trade and int(trade_tx[ti]) < first_bbo_t:
        ti += 1

    result = []  # type: List[Trx]

    while bi < n_bbo or ti < n_trade:
        b_t = int(bbo_tx[bi]) if bi < n_bbo else _SENTINEL
        t_t = int(trade_tx[ti]) if ti < n_trade else _SENTINEL

        if (b_t, 0) <= (t_t, 1):
            # BBO event — refresh cache, reset ahead_qty, record level time/uid.
            cache = DepthCache(
                bid_price=float(bbo_bid_p[bi]),
                bid_qty=float(bbo_bid_q[bi]),
                ask_price=float(bbo_ask_p[bi]),
                ask_qty=float(bbo_ask_q[bi]),
            )
            ahead_ask_qty = cache.ask_qty
            ahead_bid_qty = cache.bid_qty
            level_time = b_t
            level_uid = int(bbo_id[bi])
            active_duration = int(bbo_active[bi])
            bi += 1
        else:
            side = int(trade_side[ti])
            price = float(trade_p[ti])
            qty = float(trade_q[ti])
            tx = int(trade_tx[ti])

            if side == 1 and price >= cache.ask_price:
                # Aggressive buy — drain ahead_ask_qty first.
                drain = min(ahead_ask_qty, qty)
                ahead_ask_qty -= drain
                consumed = qty - drain
                if consumed > 0:
                    result.append(
                        Trx(tx_time=tx, price=cache.ask_price, qty=consumed, side=-1,
                            level_time=level_time, level_uid=level_uid,
                            active_duration=active_duration)
                    )
            elif side == -1 and price <= cache.bid_price:
                # Aggressive sell — drain ahead_bid_qty first.
                drain = min(ahead_bid_qty, qty)
                ahead_bid_qty -= drain
                consumed = qty - drain
                if consumed > 0:
                    result.append(
                        Trx(tx_time=tx, price=cache.bid_price, qty=consumed, side=1,
                            level_time=level_time, level_uid=level_uid,
                            active_duration=active_duration)
                    )
            ti += 1

    return result


# ---------------------------------------------------------------------------
# Phase 2 — Build Expect Taker Trx
# ---------------------------------------------------------------------------


def build_expect_taker_trx(
    maker_trx: List[Trx],
    delta_t: int,
) -> List[Trx]:
    """Project expected taker counter-trades from maker fills.

    For each maker fill, produces a corresponding taker order that should
    arrive delta_t milliseconds later on the taker exchange. The taker side
    is the opposite of the maker side. Price is left unset (None).

    Parameters
    ----------
    maker_trx : list of Trx
        Maker fills returned by build_maker_trx_front.
    delta_t : int
        Fixed taker latency in milliseconds.

    Returns
    -------
    list of Trx
        One entry per maker fill, preserving order; price is None (unpriced).
    """
    return [
        Trx(
            tx_time=trx.tx_time + delta_t,
            price=None,
            qty=trx.qty,
            side=-trx.side,
        )
        for trx in maker_trx
    ]


# ---------------------------------------------------------------------------
# Phase 3 — Fill Taker Trx
# ---------------------------------------------------------------------------


def fill_taker_trx(
    taker_bbo: pd.DataFrame,
    taker_trade: pd.DataFrame,
    expect_taker_trx: List[Trx],
) -> List[Trx]:
    """Simulate taker fill prices against the taker exchange order book.

    Merges taker BBO, taker Trade, and expect_taker_trx events by tx_time
    (priority: BBO > Trade > Trx). Maintains a DepthCache from taker BBO
    events. Taker Trade events deplete the book without emitting fills.
    Each expect_taker_trx is filled at the current cache price.

    Output is strictly 1:1 with expect_taker_trx; records are retained even
    when filled_qty is zero (e.g., cache not yet initialized or book empty).

    Parameters
    ----------
    taker_bbo : pd.DataFrame
        BBO DataFrame for the taker exchange.
    taker_trade : pd.DataFrame
        Trade DataFrame for the taker exchange.
    expect_taker_trx : list of Trx
        Unpriced expected taker fills from build_expect_taker_trx.

    Returns
    -------
    list of Trx
        Filled taker trx, one entry per element in expect_taker_trx.
    """
    bbo_tx = taker_bbo["tx_time"].values
    bbo_id = taker_bbo["update_id"].values
    bbo_active = taker_bbo["active_duration"].values
    bbo_bid_p = taker_bbo["bid_price"].values
    bbo_bid_q = taker_bbo["bid_qty"].values
    bbo_ask_p = taker_bbo["ask_price"].values
    bbo_ask_q = taker_bbo["ask_qty"].values

    trade_tx = taker_trade["tx_time"].values
    trade_q = taker_trade["qty"].values
    trade_side = np.where(taker_trade["side"].values == 1, 1, -1)

    n_bbo = len(bbo_tx)
    n_trade = len(trade_tx)
    n_trx = len(expect_taker_trx)

    if n_bbo == 0:
        return []

    # Seed cache from the first BBO; skip trades/trx that arrived before it.
    first_bbo_t = int(bbo_tx[0])
    cache = DepthCache(
        bid_price=float(bbo_bid_p[0]),
        bid_qty=float(bbo_bid_q[0]),
        ask_price=float(bbo_ask_p[0]),
        ask_qty=float(bbo_ask_q[0]),
    )
    level_time = first_bbo_t
    level_uid = int(bbo_id[0])
    active_duration = int(bbo_active[0])

    bi = 1
    ti = 0
    xi = 0
    # Skip trades and trx before the first BBO.
    while ti < n_trade and int(trade_tx[ti]) < first_bbo_t:
        ti += 1
    while xi < n_trx and expect_taker_trx[xi].tx_time < first_bbo_t:
        xi += 1

    result = []  # type: List[Trx]

    while bi < n_bbo or ti < n_trade or xi < n_trx:
        b_t = int(bbo_tx[bi]) if bi < n_bbo else _SENTINEL
        t_t = int(trade_tx[ti]) if ti < n_trade else _SENTINEL
        x_t = expect_taker_trx[xi].tx_time if xi < n_trx else _SENTINEL

        # Priority tuples: BBO=(t,0), Trade=(t,1), Trx=(t,2)
        if (b_t, 0) <= (t_t, 1) and (b_t, 0) <= (x_t, 2):
            # BBO event — refresh depth cache and record level time/uid.
            cache = DepthCache(
                bid_price=float(bbo_bid_p[bi]),
                bid_qty=float(bbo_bid_q[bi]),
                ask_price=float(bbo_ask_p[bi]),
                ask_qty=float(bbo_ask_q[bi]),
            )
            level_time = b_t
            level_uid = int(bbo_id[bi])
            active_duration = int(bbo_active[bi])
            bi += 1

        elif (t_t, 1) <= (x_t, 2):
            # Trade event — deplete cache only, no fill emitted
            side = int(trade_side[ti])
            qty = float(trade_q[ti])
            if side == 1:  # aggressive buy reduces ask liquidity
                cache = DepthCache(
                    bid_price=cache.bid_price,
                    bid_qty=cache.bid_qty,
                    ask_price=cache.ask_price,
                    ask_qty=max(0.0, cache.ask_qty - qty),
                )
            else:  # aggressive sell reduces bid liquidity
                cache = DepthCache(
                    bid_price=cache.bid_price,
                    bid_qty=max(0.0, cache.bid_qty - qty),
                    ask_price=cache.ask_price,
                    ask_qty=cache.ask_qty,
                )
            ti += 1

        else:
            # Trx event — fill against current cache
            trx = expect_taker_trx[xi]
            if trx.side == 1:  # taker buy — fill at ask
                filled = min(cache.ask_qty, trx.qty)
                result.append(
                    Trx(tx_time=trx.tx_time, price=cache.ask_price, qty=filled, side=trx.side,
                        level_time=level_time, level_uid=level_uid,
                        active_duration=active_duration)
                )
                cache = DepthCache(
                    bid_price=cache.bid_price,
                    bid_qty=cache.bid_qty,
                    ask_price=cache.ask_price,
                    ask_qty=cache.ask_qty - filled,
                )
            else:  # taker sell — fill at bid
                filled = min(cache.bid_qty, trx.qty)
                result.append(
                    Trx(tx_time=trx.tx_time, price=cache.bid_price, qty=filled, side=trx.side,
                        level_time=level_time, level_uid=level_uid,
                        active_duration=active_duration)
                )
                cache = DepthCache(
                    bid_price=cache.bid_price,
                    bid_qty=cache.bid_qty - filled,
                    ask_price=cache.ask_price,
                    ask_qty=cache.ask_qty,
                )
            xi += 1
            if xi >= n_trx:
                break  # All Trx events processed; remaining BBO/Trade are irrelevant

    return result


# ---------------------------------------------------------------------------
# Phase 4 — Build Pair Table
# ---------------------------------------------------------------------------


def build_pair_table(
    maker_trx: List[Trx],
    filled_taker_trx: List[Trx],
) -> pd.DataFrame:
    """Zip maker and taker fills and compute the realized spread.

    Pairs are aligned 1:1. Positive spread means the trade is profitable.

    Spread conventions:
      maker sell (side=-1) + taker buy  (side=+1): spread = maker_price - taker_price
      maker buy  (side=+1) + taker sell (side=-1): spread = taker_price - maker_price

    spread_ratio = spread / mid_price, where mid_price = (maker_price + taker_price) / 2.
    Positive spread_ratio means profitable. Records with zero filled_qty or no taker
    price carry NaN for spread fields.

    Parameters
    ----------
    maker_trx : list of Trx
        Maker fills from build_maker_trx_front.
    filled_taker_trx : list of Trx
        Filled taker trx from fill_taker_trx (same length as maker_trx).

    Returns
    -------
    pd.DataFrame
        Columns: maker_tx_time, maker_level_time, maker_level_uid, maker_price,
                 maker_qty, maker_side, taker_tx_time, taker_level_time,
                 taker_level_uid, taker_price, taker_qty, taker_side,
                 filled_qty, spread, spread_ratio.
    """
    records = []
    for mk, tk in zip(maker_trx, filled_taker_trx):
        filled_qty = min(mk.qty, tk.qty)
        if tk.price is None or filled_qty == 0:
            spread = float("nan")
            spread_ratio = float("nan")
            action_side = 0
            action_ratio = float("nan")
        elif mk.side == -1:  # maker sell, taker buy
            spread = mk.price - tk.price
            spread_ratio = spread / ((mk.price + tk.price) / 2)
            action_side = 1
            action_ratio = tk.price / mk.price - 1
        else:  # maker buy, taker sell
            spread = tk.price - mk.price
            spread_ratio = spread / ((mk.price + tk.price) / 2)
            action_side = -1
            action_ratio = tk.price / mk.price - 1

        records.append(
            {
                "maker_tx_time": mk.tx_time,
                "maker_level_time": mk.level_time,
                "maker_level_uid": mk.level_uid,
                "maker_active": mk.active_duration,
                "maker_price": mk.price,
                "maker_qty": mk.qty,
                "maker_side": mk.side,
                "taker_tx_time": tk.tx_time,
                "taker_level_time": tk.level_time,
                "taker_level_uid": tk.level_uid,
                "taker_active": tk.active_duration,
                "taker_price": tk.price,
                "taker_qty": tk.qty,
                "taker_side": tk.side,
                "filled_qty": filled_qty,
                "spread": spread,
                "spread_ratio": spread_ratio,
                "action_side": action_side,
                "action_ratio": action_ratio
            }
        )

    return pd.DataFrame(records)


# ---------------------------------------------------------------------------
# Top-level runner
# ---------------------------------------------------------------------------


def run_detection(config: DetectionConfig) -> pd.DataFrame:
    """Load data and run all four detection phases.

    Parameters
    ----------
    config : DetectionConfig
        Run parameters: delta_t, maker_file, taker_file, queue_aware.

    Returns
    -------
    pd.DataFrame
        Pair table with spread information for each maker/taker fill pair.
    """
    maker_bbo = _load_bbo(config.source.maker_file)
    maker_trade = _load_trade(config.source.maker_file)
    taker_bbo = _load_bbo(config.source.taker_file)
    taker_trade = _load_trade(config.source.taker_file)

    if config.compute.maker_mode == "front":
        maker_trx = build_maker_trx_front(maker_bbo, maker_trade)
    else:
        maker_trx = build_maker_trx_back(maker_bbo, maker_trade)
    expect_taker_trx = build_expect_taker_trx(maker_trx, config.compute.delta_t)
    filled_taker_trx = fill_taker_trx(taker_bbo, taker_trade, expect_taker_trx)
    return build_pair_table(maker_trx, filled_taker_trx)


# ---------------------------------------------------------------------------
# Full pipeline result
# ---------------------------------------------------------------------------


@dataclass
class DetectionResult:
    """All tables produced by run_full().

    Attributes
    ----------
    pairs : pd.DataFrame
        Full pair table (set E). Output of build_pair_table().
    maker_bbo : pd.DataFrame
        Raw maker BBO as loaded by _load_bbo().
    taker_bbo : pd.DataFrame
        Raw taker BBO as loaded by _load_bbo().
    maker_trx : list of Trx
        Maker fills from Phase 1.
    taker_trx : list of Trx
        Filled taker trx from Phase 3.
    signal_series : pd.DataFrame
        Full signal series from compute_signal_series().
    action_signals : pd.DataFrame
        Filtered action signals from config.signal_operator.compute().
    df_buy : pd.DataFrame
        Threshold-filtered buy pairs (set T, buy side).
    df_sell : pd.DataFrame
        Threshold-filtered sell pairs (set T, sell side).
    metrics : dict
        Numeric performance metrics per side.  Output of compute_pair_metrics().
        Keys per side: count_A, count_E, count_T, count_A_and_E, count_T_and_A,
        signal_exec_rate, fill_quality_rate.
    pair_sets : dict
        Underlying A, E, T maker_uid sets per side.  Output of compute_pair_sets().
        Keys per side: A (signal BBOs), E (executable fills), T (filtered fills).
    """

    pairs: pd.DataFrame
    maker_bbo: pd.DataFrame
    taker_bbo: pd.DataFrame
    maker_trx: list
    taker_trx: list
    signal_series: pd.DataFrame
    action_signals: pd.DataFrame
    df_buy: pd.DataFrame
    df_sell: pd.DataFrame
    metrics: dict
    pair_sets: dict


def run_full(
    config,  # DetectionConfig
    ind,     # pd.DataFrame — indicator with timestamp_ms, qUp, qDown
):
    # type: (...) -> DetectionResult
    """Run the complete detection pipeline and return all intermediate tables.

    Parameters
    ----------
    config : DetectionConfig
        Full run configuration including signal_operator and threshold_scaler.
    ind : pd.DataFrame
        Indicator DataFrame with columns: timestamp_ms, qUp, qDown.

    Returns
    -------
    DetectionResult
        All intermediate and final tables.
    """
    # Step 1 — load data
    maker_bbo = _load_bbo(config.source.maker_file)
    maker_trade = _load_trade(config.source.maker_file)
    taker_bbo = _load_bbo(config.source.taker_file)
    taker_trade = _load_trade(config.source.taker_file)

    # Step 2 — detection phases
    if config.compute.maker_mode == "front":
        maker_trx = build_maker_trx_front(maker_bbo, maker_trade)
    else:
        maker_trx = build_maker_trx_back(maker_bbo, maker_trade)
    expect_taker_trx = build_expect_taker_trx(maker_trx, config.compute.delta_t)
    taker_trx = fill_taker_trx(taker_bbo, taker_trade, expect_taker_trx)
    pairs = build_pair_table(maker_trx, taker_trx)

    # Step 3 — signal series + action signals
    signal_series = compute_signal_series(maker_bbo, taker_bbo)
    action_signals = config.compute.signal_operator.compute(signal_series, ind)

    # Step 4 — threshold filtering
    ind_scaled = config.compute.threshold_scaler.apply(ind)
    df_buy, df_sell = filter_pairs(pairs, ind_scaled)

    # Step 5 — metrics and sets
    metrics   = compute_pair_metrics(action_signals, pairs, df_buy, df_sell)
    pair_sets = compute_pair_sets(action_signals, pairs, df_buy, df_sell)

    return DetectionResult(
        pairs=pairs,
        maker_bbo=maker_bbo,
        taker_bbo=taker_bbo,
        maker_trx=maker_trx,
        taker_trx=taker_trx,
        signal_series=signal_series,
        action_signals=action_signals,
        df_buy=df_buy,
        df_sell=df_sell,
        metrics=metrics,
        pair_sets=pair_sets,
    )


def run_range(
    source,   # RangeDataSourceConfig
    compute,  # ComputeConfig
    ind,      # pd.DataFrame
):
    # type: (RangeDataSourceConfig, ComputeConfig, pd.DataFrame) -> DetectionResult
    """Run the full pipeline over every hour in *source* and merge into one DetectionResult.

    Each hour is processed independently via :func:`run_full`.  The intermediate
    DataFrames are concatenated and ``metrics`` / ``pair_sets`` are recomputed
    from the merged data so that rates are correct across the whole range.

    Parameters
    ----------
    source : RangeDataSourceConfig
        Defines root, symbols, and the hour range to iterate.
    compute : ComputeConfig
        Shared computation parameters applied to every hour.
    ind : pd.DataFrame
        Indicator DataFrame with columns: timestamp_ms, qUp, qDown.

    Returns
    -------
    DetectionResult
        Merged result covering all hours in the range.
    """
    hour_results = []
    for file_cfg in source.iter_file_configs():
        config = DetectionConfig(source=file_cfg, compute=compute)
        hour_results.append(run_full(config, ind))

    if not hour_results:
        raise ValueError("RangeDataSourceConfig produced no hours to process")

    def _concat(frames):
        # type: (List[pd.DataFrame]) -> pd.DataFrame
        return pd.concat(frames, ignore_index=True)

    merged_pairs          = _concat([r.pairs          for r in hour_results])
    merged_maker_bbo      = _concat([r.maker_bbo      for r in hour_results])
    merged_taker_bbo      = _concat([r.taker_bbo      for r in hour_results])
    merged_signal_series  = _concat([r.signal_series  for r in hour_results])
    merged_action_signals = _concat([r.action_signals for r in hour_results])
    merged_df_buy         = _concat([r.df_buy         for r in hour_results])
    merged_df_sell        = _concat([r.df_sell        for r in hour_results])
    merged_maker_trx      = [trx for r in hour_results for trx in r.maker_trx]
    merged_taker_trx      = [trx for r in hour_results for trx in r.taker_trx]

    # Recompute metrics and pair_sets from merged data so rates span the full range
    merged_metrics   = compute_pair_metrics(merged_action_signals, merged_pairs, merged_df_buy, merged_df_sell)
    merged_pair_sets = compute_pair_sets(merged_action_signals, merged_pairs, merged_df_buy, merged_df_sell)

    return DetectionResult(
        pairs=merged_pairs,
        maker_bbo=merged_maker_bbo,
        taker_bbo=merged_taker_bbo,
        maker_trx=merged_maker_trx,
        taker_trx=merged_taker_trx,
        signal_series=merged_signal_series,
        action_signals=merged_action_signals,
        df_buy=merged_df_buy,
        df_sell=merged_df_sell,
        metrics=merged_metrics,
        pair_sets=merged_pair_sets,
    )


# ---------------------------------------------------------------------------
# Filter
# ---------------------------------------------------------------------------


def scale_indicator(
    ind: pd.DataFrame,
    alpha: float = 1.0,
    delta: float = 0.0,
) -> pd.DataFrame:
    """Return a copy of ind with qUp and qDown scaled around their midpoint.

    Scaling formula (per row):
        mid       = (qUp + qDown) / 2
        gap       = (qUp - qDown) / 2
        new_gap   = gap * alpha + delta
        new_qUp   = mid + new_gap
        new_qDown = mid - new_gap

    Parameters
    ----------
    ind : pd.DataFrame
        Indicator DataFrame with columns: timestamp_ms, qUp, qDown.
        All other columns are preserved unchanged.
    alpha : float
        Scale factor applied to the half-gap.  alpha > 1 widens the band
        (looser T); alpha < 1 narrows it (stricter T).  Must be >= 0.
    delta : float
        Absolute shift added to the half-gap after scaling.  delta > 0
        widens; delta < 0 narrows.

    Returns
    -------
    pd.DataFrame
        Copy of ind with qUp and qDown replaced by the scaled values.

    Raises
    ------
    ValueError
        If alpha < 0.
    """
    if alpha < 0:
        raise ValueError(f"alpha must be >= 0, got {alpha}")

    result = ind.copy()
    mid = (result["qUp"] + result["qDown"]) / 2.0
    gap = (result["qUp"] - result["qDown"]) / 2.0
    new_gap = gap * alpha + delta
    result["qUp"] = mid + new_gap
    result["qDown"] = mid - new_gap
    return result


def filter_pairs(
    df: pd.DataFrame,
    ind: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Join detection output with indicator quantiles and apply threshold filters.

    ind must contain columns: timestamp_ms, qUp (= short), qDown (= -long).
    Each pair row is matched to the most recent indicator snapshot via a
    backward asof join on maker_tx_time.

    Filters:
      action_side =  1: keep where action_ratio <= qDown
      action_side = -1: keep where action_ratio >= qUp

    Parameters
    ----------
    df : pd.DataFrame
        Output of run_detection.
    ind : pd.DataFrame
        Indicator DataFrame with columns: timestamp_ms, qUp, qDown.

    Returns
    -------
    (df_buy, df_sell) : Tuple[pd.DataFrame, pd.DataFrame]
    """
    df_s = df.sort_values("maker_tx_time").reset_index(drop=True)
    ind_s = ind.sort_values("timestamp_ms").reset_index(drop=True)

    dj = pd.merge_asof(
        df_s,
        ind_s[["timestamp_ms", "qUp", "qDown"]],
        left_on="maker_tx_time",
        right_on="timestamp_ms",
        direction="backward",
    )

    df_buy = dj[
        (dj["action_side"] == 1) & (dj["action_ratio"] <= dj["qDown"])
    ].reset_index(drop=True)
    df_sell = dj[
        (dj["action_side"] == -1) & (dj["action_ratio"] >= dj["qUp"])
    ].reset_index(drop=True)
    return df_buy, df_sell


# ---------------------------------------------------------------------------
# Signal Series
# ---------------------------------------------------------------------------


def compute_signal_series(
    maker_bbo: pd.DataFrame,
    taker_bbo: pd.DataFrame,
) -> pd.DataFrame:
    """Dual-pointer scan over merged maker and taker BBO streams.

    On every pointer advance, emits one record with the current state of both
    sides.  Tie-breaking at equal tx_time: maker advances first.

    Parameters
    ----------
    maker_bbo : pd.DataFrame
        BBO DataFrame with columns: id, tx_time, ask_price, bid_price.
    taker_bbo : pd.DataFrame
        BBO DataFrame with columns: id, tx_time, ask_price, bid_price.

    Returns
    -------
    pd.DataFrame
        Columns: tx_time, maker_tx_time, maker_uid, taker_tx_time, taker_uid,
                 ask_ratio, bid_ratio.
    """
    m_tx = maker_bbo["tx_time"].values
    m_id = maker_bbo["update_id"].values
    m_ask = maker_bbo["ask_price"].values
    m_bid = maker_bbo["bid_price"].values

    t_tx = taker_bbo["tx_time"].values
    t_id = taker_bbo["update_id"].values
    t_ask = taker_bbo["ask_price"].values
    t_bid = taker_bbo["bid_price"].values

    n_m = len(m_tx)
    n_t = len(t_tx)

    if n_m == 0 or n_t == 0:
        return pd.DataFrame(columns=[
            "tx_time", "maker_tx_time", "maker_uid",
            "taker_tx_time", "taker_uid", "ask_ratio", "bid_ratio",
        ])

    # Seed both sides from their first BBO.
    mi = 0
    ti = 0
    cur_m_tx = int(m_tx[0])
    cur_m_uid = int(m_id[0])
    cur_m_ask = float(m_ask[0])
    cur_m_bid = float(m_bid[0])
    cur_t_tx = int(t_tx[0])
    cur_t_uid = int(t_id[0])
    cur_t_ask = float(t_ask[0])
    cur_t_bid = float(t_bid[0])

    mi = 1
    ti = 1

    records = []  # type: list
    # Emit initial record.
    records.append((
        max(cur_m_tx, cur_t_tx),
        cur_m_tx, cur_m_uid, cur_t_tx, cur_t_uid,
        cur_t_ask / cur_m_ask - 1, cur_t_bid / cur_m_bid - 1,
    ))

    while mi < n_m or ti < n_t:
        m_next = int(m_tx[mi]) if mi < n_m else _SENTINEL
        t_next = int(t_tx[ti]) if ti < n_t else _SENTINEL

        # Maker advances first at equal tx_time.
        if m_next <= t_next:
            cur_m_tx = m_next
            cur_m_uid = int(m_id[mi])
            cur_m_ask = float(m_ask[mi])
            cur_m_bid = float(m_bid[mi])
            mi += 1
        else:
            cur_t_tx = t_next
            cur_t_uid = int(t_id[ti])
            cur_t_ask = float(t_ask[ti])
            cur_t_bid = float(t_bid[ti])
            ti += 1

        records.append((
            max(cur_m_tx, cur_t_tx),
            cur_m_tx, cur_m_uid, cur_t_tx, cur_t_uid,
            cur_t_ask / cur_m_ask - 1, cur_t_bid / cur_m_bid - 1,
        ))

    return pd.DataFrame(records, columns=[
        "tx_time", "maker_tx_time", "maker_uid",
        "taker_tx_time", "taker_uid", "ask_ratio", "bid_ratio",
    ])


def filter_action_signals(
    signal_series: pd.DataFrame,
    ind: pd.DataFrame,
    buffer: float = 0.0,
) -> pd.DataFrame:
    """Filter signal series by indicator thresholds.

    Join ind to signal_series via backward asof on tx_time, then keep:
      - long action  (action_side=+1): ask_ratio < qDown - buffer
      - short action (action_side=-1): bid_ratio > qUp + buffer

    Parameters
    ----------
    signal_series : pd.DataFrame
        Output of compute_signal_series.
    ind : pd.DataFrame
        Indicator DataFrame with columns: timestamp_ms, qUp, qDown.
    buffer : float
        Offset applied to both thresholds: effective qUp = qUp + buffer,
        effective qDown = qDown - buffer.  Positive buffer makes the filter
        stricter (fewer signals); default 0.0 is identity.

    Returns
    -------
    pd.DataFrame
        Filtered rows with an added action_side column.
    """
    ss = signal_series.sort_values("tx_time").reset_index(drop=True)
    ind_s = ind.sort_values("timestamp_ms").reset_index(drop=True)

    dj = pd.merge_asof(
        ss,
        ind_s[["timestamp_ms", "qUp", "qDown"]],
        left_on="tx_time",
        right_on="timestamp_ms",
        direction="backward",
    )

    long_mask = dj["ask_ratio"] < dj["qDown"] - buffer
    short_mask = dj["bid_ratio"] > dj["qUp"] + buffer

    # Long: track when each continuous long run started.
    # Rows that are not a continuation (non-long OR first trigger) anchor the start time;
    # continuation rows get NaN and are forward-filled.
    long_first = long_mask & ~long_mask.shift(1, fill_value=False)
    long_start = (
        dj["tx_time"]
        .where(~long_mask | long_first)
        .ffill()
        .astype("int64")
    )

    # Short: same pattern.
    short_first = short_mask & ~short_mask.shift(1, fill_value=False)
    short_start = (
        dj["tx_time"]
        .where(~short_mask | short_first)
        .ffill()
        .astype("int64")
    )

    long_df = dj[long_mask].copy()
    long_df["action_side"] = 1
    long_df["signal_start_time"] = long_start[long_mask].values
    long_df["signal_active"] = long_df["tx_time"] - long_df["signal_start_time"]

    short_df = dj[short_mask].copy()
    short_df["action_side"] = -1
    short_df["signal_start_time"] = short_start[short_mask].values
    short_df["signal_active"] = short_df["tx_time"] - short_df["signal_start_time"]

    result = pd.concat([long_df, short_df], ignore_index=True)
    return result.sort_values("tx_time").reset_index(drop=True)


def filter_action_signals_rolling_quantile(
    signal_series: pd.DataFrame,
    ind: pd.DataFrame,
    window: int = 100,
    quantile: float = 0.5,
    buffer: float = 0.0,
) -> pd.DataFrame:
    """Filter signal series using both a static threshold and a rolling quantile.

    Joins ind to signal_series via backward asof on tx_time to obtain qUp and
    qDown per row, then computes a rolling quantile over the last ``window``
    rows of ask_ratio and bid_ratio.  A signal triggers only when *both* the
    current ratio and the rolling quantile satisfy the threshold.

    Parameters
    ----------
    signal_series : pd.DataFrame
        Output of compute_signal_series; must contain tx_time, ask_ratio,
        bid_ratio, maker_uid, maker_tx_time, taker_tx_time, taker_uid.
    ind : pd.DataFrame
        Indicator DataFrame with columns: timestamp_ms, qUp, qDown.
    window : int
        Number of BBO events over which to compute the rolling quantile.
        Rows where the window is not yet full (fewer than ``window`` preceding
        rows) produce NaN for the quantile and are treated as non-triggering.
    quantile : float
        Quantile level in [0, 1] passed to ``pd.Series.rolling().quantile()``.
    buffer : float
        Offset applied to both thresholds: effective qUp = qUp + buffer,
        effective qDown = qDown - buffer.  Positive buffer makes the filter
        stricter (fewer signals); default 0.0 is identity.

    Returns
    -------
    pd.DataFrame
        Filtered rows with columns identical to filter_action_signals plus two
        additional diagnostic columns:
          - ask_ratio_q : rolling quantile of ask_ratio
          - bid_ratio_q : rolling quantile of bid_ratio
    """
    ss = signal_series.sort_values("tx_time").reset_index(drop=True)
    ind_s = ind.sort_values("timestamp_ms").reset_index(drop=True)

    dj = pd.merge_asof(
        ss,
        ind_s[["timestamp_ms", "qUp", "qDown"]],
        left_on="tx_time",
        right_on="timestamp_ms",
        direction="backward",
    )

    ask_ratio_q = dj["ask_ratio"].rolling(window).quantile(quantile)
    bid_ratio_q = dj["bid_ratio"].rolling(window).quantile(quantile)

    dj = dj.assign(ask_ratio_q=ask_ratio_q, bid_ratio_q=bid_ratio_q)

    long_mask = (dj["ask_ratio"] < dj["qDown"] - buffer) & (dj["ask_ratio_q"] < dj["qDown"] - buffer)
    short_mask = (dj["bid_ratio"] > dj["qUp"] + buffer) & (dj["bid_ratio_q"] > dj["qUp"] + buffer)

    # Treat NaN quantile (window not yet full) as non-triggering.
    long_mask = long_mask.fillna(False)
    short_mask = short_mask.fillna(False)

    long_first = long_mask & ~long_mask.shift(1, fill_value=False)
    long_start = (
        dj["tx_time"]
        .where(~long_mask | long_first)
        .ffill()
        .astype("int64")
    )

    short_first = short_mask & ~short_mask.shift(1, fill_value=False)
    short_start = (
        dj["tx_time"]
        .where(~short_mask | short_first)
        .ffill()
        .astype("int64")
    )

    long_df = dj[long_mask].copy()
    long_df["action_side"] = 1
    long_df["signal_start_time"] = long_start[long_mask].values
    long_df["signal_active"] = long_df["tx_time"] - long_df["signal_start_time"]

    short_df = dj[short_mask].copy()
    short_df["action_side"] = -1
    short_df["signal_start_time"] = short_start[short_mask].values
    short_df["signal_active"] = short_df["tx_time"] - short_df["signal_start_time"]

    result = pd.concat([long_df, short_df], ignore_index=True)
    return result.sort_values("tx_time").reset_index(drop=True)


def _build_side_sets(
    action_signals_side: pd.DataFrame,
    pairs_side: pd.DataFrame,
    filtered_side: pd.DataFrame,
) -> Tuple[set, set, set]:
    """Extract A, E, T sets for one action side."""
    A = set(action_signals_side["maker_uid"].values)
    E = set(pairs_side["maker_level_uid"].values)
    T = set(filtered_side["maker_level_uid"].values)
    return A, E, T


def _compute_side_metrics(A: set, E: set, T: set) -> dict:
    """Compute numeric metrics from pre-built A, E, T sets."""
    a_and_e = len(A & E)
    t_and_a = len(T & A)
    signal_exec_rate  = a_and_e / len(A) if len(A) > 0 else 0.0
    fill_quality_rate = t_and_a / a_and_e if a_and_e > 0 else 0.0
    return {
        "count_A":          len(A),
        "count_E":          len(E),
        "count_T":          len(T),
        "count_A_and_E":    a_and_e,
        "count_T_and_A":    t_and_a,
        "signal_exec_rate":  signal_exec_rate,
        "fill_quality_rate": fill_quality_rate,
    }


def compute_pair_sets(
    action_signals: pd.DataFrame,
    pairs: pd.DataFrame,
    filtered_buy: pd.DataFrame,
    filtered_sell: pd.DataFrame,
) -> dict:
    """Extract A, E, T maker_uid sets separately for buy and sell sides.

    Set definitions per side (keyed on maker_uid / maker_level_uid):
      A = signal BBOs: maker_uid values from action_signals where action_side == side
      E = executable fills: maker_level_uid values from pairs where action_side == side
      T = threshold-filtered fills: maker_level_uid values from filtered pairs

    Parameters
    ----------
    action_signals : pd.DataFrame
        Filtered action signals (has action_side and maker_uid columns).
    pairs : pd.DataFrame
        Full pair table from build_pair_table (has action_side and maker_level_uid).
    filtered_buy : pd.DataFrame
        Threshold-filtered buy pairs (df_buy from filter_pairs).
    filtered_sell : pd.DataFrame
        Threshold-filtered sell pairs (df_sell from filter_pairs).

    Returns
    -------
    dict
        Keys: 'buy' and 'sell', each a dict with keys: A, E, T (all sets).
    """
    buy_A, buy_E, buy_T = _build_side_sets(
        action_signals[action_signals["action_side"] == 1],
        pairs[pairs["action_side"] == 1],
        filtered_buy,
    )
    sell_A, sell_E, sell_T = _build_side_sets(
        action_signals[action_signals["action_side"] == -1],
        pairs[pairs["action_side"] == -1],
        filtered_sell,
    )
    return {
        "buy":  {"A": buy_A,  "E": buy_E,  "T": buy_T},
        "sell": {"A": sell_A, "E": sell_E, "T": sell_T},
    }


def compute_pair_metrics(
    action_signals: pd.DataFrame,
    pairs: pd.DataFrame,
    filtered_buy: pd.DataFrame,
    filtered_sell: pd.DataFrame,
) -> dict:
    """Compute numeric performance metrics separately for buy and sell sides.

    Buy side  — taker buy  & maker sell (action_side == +1): ask_ratio < qDown
    Sell side — taker sell & maker buy  (action_side == -1): bid_ratio > qUp

    Parameters
    ----------
    action_signals : pd.DataFrame
        Filtered action signals from filter_action_signals (has action_side column).
    pairs : pd.DataFrame
        Full pair table from run_detection (has action_side column).
    filtered_buy : pd.DataFrame
        Threshold-filtered pairs for the buy side (df_buy from filter_pairs).
    filtered_sell : pd.DataFrame
        Threshold-filtered pairs for the sell side (df_sell from filter_pairs).

    Returns
    -------
    dict
        Keys: 'buy' and 'sell', each a dict with keys:
        count_A, count_E, count_T, count_A_and_E, count_T_and_A,
        signal_exec_rate, fill_quality_rate.
        Use compute_pair_sets() to obtain the underlying A, E, T sets.
    """
    buy_A, buy_E, buy_T = _build_side_sets(
        action_signals[action_signals["action_side"] == 1],
        pairs[pairs["action_side"] == 1],
        filtered_buy,
    )
    sell_A, sell_E, sell_T = _build_side_sets(
        action_signals[action_signals["action_side"] == -1],
        pairs[pairs["action_side"] == -1],
        filtered_sell,
    )
    return {
        "buy":  _compute_side_metrics(buy_A, buy_E, buy_T),
        "sell": _compute_side_metrics(sell_A, sell_E, sell_T),
    }


# ---------------------------------------------------------------------------
# BBO Ratio
# ---------------------------------------------------------------------------


def compute_bbo_ratio_resampled(
    maker_bbo_raw: pd.DataFrame,
    taker_bbo_raw: pd.DataFrame,
) -> pd.DataFrame:
    """Compute ask_ratio and bid_ratio from 1s-resampled maker and taker BBO.

    Both streams are resampled independently to a 1s grid using tx_time as the
    index.  The two grids are then inner-joined on their common timestamps.

    Parameters
    ----------
    maker_bbo_raw : pd.DataFrame
        Raw maker BBO as returned by _load_bbo / load_bbo.
    taker_bbo_raw : pd.DataFrame
        Raw taker BBO as returned by _load_bbo / load_bbo.

    Returns
    -------
    pd.DataFrame
        Columns: ask_ratio, bid_ratio.
        Index: datetime derived from tx_time (1s resolution).
    """
    maker_1s = _resample_bbo(maker_bbo_raw, set())
    taker_1s = _resample_bbo(taker_bbo_raw, set())

    common = maker_1s.index.intersection(taker_1s.index)
    m = maker_1s.loc[common]
    t = taker_1s.loc[common]

    return pd.DataFrame(
        {
            "ask_ratio": t["ask_price"].values / m["ask_price"].values - 1,
            "bid_ratio": t["bid_price"].values / m["bid_price"].values - 1,
        },
        index=common,
    )


def add_level_bbo_ratios(
    df: pd.DataFrame,
    maker_bbo_raw: pd.DataFrame,
    taker_bbo_raw: pd.DataFrame,
) -> pd.DataFrame:
    """Add ask_ratio and bid_ratio columns to a pair table using level_time BBO lookups.

    For each row the maker BBO is fetched at maker_level_time and the taker BBO
    at taker_level_time.  Both level_times must exist as tx_time values in their
    respective raw BBO DataFrames (they are set by the detection pipeline).

    ask_ratio = taker.ask / maker.ask - 1
    bid_ratio = taker.bid / maker.bid - 1

    Parameters
    ----------
    df : pd.DataFrame
        Pair table from build_pair_table; must contain maker_level_time and
        taker_level_time columns.
    maker_bbo_raw : pd.DataFrame
        Raw maker BBO as returned by _load_bbo / load_bbo.
    taker_bbo_raw : pd.DataFrame
        Raw taker BBO as returned by _load_bbo / load_bbo.

    Returns
    -------
    pd.DataFrame
        Copy of df with two new columns: ask_ratio, bid_ratio.
    """
    maker_lookup = (maker_bbo_raw.drop_duplicates(subset="tx_time", keep="last")
                    .set_index("tx_time")[["ask_price", "bid_price"]])
    taker_lookup = (taker_bbo_raw.drop_duplicates(subset="tx_time", keep="last")
                    .set_index("tx_time")[["ask_price", "bid_price"]])

    m = maker_lookup.reindex(df["maker_level_time"].values)
    t = taker_lookup.reindex(df["taker_level_time"].values)

    result = df.copy()
    result["ask_ratio"] = t["ask_price"].values / m["ask_price"].values - 1
    result["bid_ratio"] = t["bid_price"].values / m["bid_price"].values - 1
    return result


# ---------------------------------------------------------------------------
# Plot helpers
# ---------------------------------------------------------------------------


def _resample_bbo(
    bbo_raw: pd.DataFrame,
    level_times: "set",
) -> pd.DataFrame:
    """Resample BBO to 1s using tx_time as the datetime index.

    BBO rows whose tx_time appears in level_times are always included at their
    exact millisecond timestamp, so those snapshots are never lost to binning.

    Parameters
    ----------
    bbo_raw : pd.DataFrame
        Raw BBO DataFrame as returned by _load_bbo; must contain tx_time.
    level_times : set of int
        tx_time values (UTC ms) that must be represented exactly.

    Returns
    -------
    pd.DataFrame
        Combined DataFrame with columns ask_price, bid_price, indexed by
        datetime derived from tx_time.
    """
    dt_index = pd.to_datetime(bbo_raw["tx_time"].values, unit="ms")
    bbo = bbo_raw[["ask_price", "bid_price"]].copy()
    bbo.index = dt_index

    # Regular 1s grid: last tick per second, forward-filled.
    regular = bbo.resample("1s").last().ffill()

    # Exact level-time rows: look up the BBO snapshot at each level_time.
    matched = bbo_raw[bbo_raw["tx_time"].isin(level_times)]
    if not matched.empty:
        level_rows = matched[["ask_price", "bid_price"]].copy()
        level_rows.index = pd.to_datetime(matched["tx_time"].values, unit="ms")
        combined = pd.concat([regular, level_rows]).sort_index()
        combined = combined[~combined.index.duplicated(keep="last")]
        return combined

    return regular


# ---------------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------------


def plot_single(
    config: DetectionConfig,
    df_buy: pd.DataFrame,
    df_sell: pd.DataFrame,
    ind: pd.DataFrame,
) -> None:
    """Plot a single-hour overview: BBO + filtered trx (panel 1), action ratio vs quantiles (panel 2).

    Parameters
    ----------
    config : DetectionConfig
        Used to load BBO files.
    df_buy : pd.DataFrame
        Filtered buy-signal pairs from filter_pairs.
    df_sell : pd.DataFrame
        Filtered sell-signal pairs from filter_pairs.
    ind : pd.DataFrame
        Indicator DataFrame with columns: timestamp_ms, qUp, qDown.
    """
    # ── BBO: load & resample, pinning level_time snapshots ───────────────────
    filtered = pd.concat([df_buy, df_sell], ignore_index=True)

    maker_level_times = set(filtered["maker_level_time"].dropna().astype(int))
    taker_level_times = set(filtered["taker_level_time"].dropna().astype(int))

    bbo_raw = _load_bbo(config.source.maker_file)
    bbo_1s = _resample_bbo(bbo_raw, maker_level_times)

    taker_raw = _load_bbo(config.source.taker_file)
    taker_1s = _resample_bbo(taker_raw, taker_level_times)

    # ── Filtered trx in long form ─────────────────────────────────────────────
    mk_pts = pd.DataFrame({
        "dt":    pd.to_datetime(filtered["maker_tx_time"].values, unit="ms"),
        "price": filtered["maker_price"].values,
        "side":  filtered["maker_side"].values,
        "role":  "maker",
    })
    tk_pts = pd.DataFrame({
        "dt":    pd.to_datetime(filtered["taker_tx_time"].values, unit="ms"),
        "price": filtered["taker_price"].values,
        "side":  filtered["taker_side"].values,
        "role":  "taker",
    })
    trx_pts = pd.concat([mk_pts, tk_pts], ignore_index=True)

    # ── BBO ratio: unified table (1s grid + level-time snapshots) ────────────
    bbo_ratio_1s = compute_bbo_ratio_resampled(bbo_raw, taker_raw)

    df_filtered = add_level_bbo_ratios(filtered, bbo_raw, taker_raw)
    level_ratio = df_filtered[["maker_level_time", "ask_ratio", "bid_ratio"]].copy()
    level_ratio = level_ratio.drop_duplicates(subset="maker_level_time")
    level_ratio.index = pd.to_datetime(level_ratio["maker_level_time"].values, unit="ms")
    level_ratio = level_ratio[["ask_ratio", "bid_ratio"]]

    bbo_ratio = (
        pd.concat([bbo_ratio_1s, level_ratio])
        .sort_index()
        .loc[lambda x: ~x.index.duplicated(keep="last")]
    )

    # ── Indicator & action ────────────────────────────────────────────────────
    ind_dt = ind.copy()
    ind_dt["dt"] = pd.to_datetime(ind_dt["timestamp_ms"], unit="ms")

    act = filtered.copy()
    act["dt"] = pd.to_datetime(act["maker_tx_time"], unit="ms")

    # ── Figure ────────────────────────────────────────────────────────────────
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 8), sharex=True)

    # Panel 1 — BBO lines
    ax1.plot(bbo_1s.index,   bbo_1s["ask_price"],   color="salmon",        lw=0.8, label="maker ask")
    ax1.plot(bbo_1s.index,   bbo_1s["bid_price"],   color="skyblue",       lw=0.8, label="maker bid")
    ax1.plot(taker_1s.index, taker_1s["ask_price"], color="firebrick",     lw=0.8, ls="--", label="taker ask")
    ax1.plot(taker_1s.index, taker_1s["bid_price"], color="cornflowerblue",lw=0.8, ls="--", label="taker bid")

    ROLE_COLOR = {"maker": "steelblue", "taker": "darkorange"}
    for role, rg in trx_pts.groupby("role"):
        for side, marker in [(1, "^"), (-1, "v")]:
            sub = rg[rg["side"] == side]
            if not sub.empty:
                ax1.scatter(sub["dt"], sub["price"],
                            marker=marker, color=ROLE_COLOR[role],
                            s=60, alpha=0.7, linewidths=0,
                            label=f"{role} {side:+d}")

    ax1.set_ylabel("price")
    ax1.legend(fontsize=7, ncol=3, loc="upper left")
    ax1.set_title("Maker BBO (1s + level snapshots) + Paired Trx")

    # Panel 2 — unified BBO ratio + qUp/qDown + trx action scatter
    ax2.plot(bbo_ratio.index, bbo_ratio["ask_ratio"], color="salmon",  lw=0.8, label="ask_ratio")
    ax2.plot(bbo_ratio.index, bbo_ratio["bid_ratio"], color="skyblue", lw=0.8, label="bid_ratio")

    ax2.plot(ind_dt["dt"], ind_dt["qUp"],   color="green", lw=1.0, ls="--", label="qUp")
    ax2.plot(ind_dt["dt"], ind_dt["qDown"], color="red",   lw=1.0, ls="--", label="qDown")
    ax2.axhline(0, color="gray", lw=0.5, ls=":")

    SIDE_COLOR = {1: "green", -1: "red"}
    for side, marker in [(1, "^"), (-1, "v")]:
        sub = act[act["action_side"] == side]
        if not sub.empty:
            ax2.scatter(sub["dt"], sub["action_ratio"],
                        marker=marker, color=SIDE_COLOR[side],
                        s=60, alpha=0.7, linewidths=0,
                        label=f"action_side={side:+d}")

    ax2.set_ylabel("ratio")
    ax2.legend(fontsize=7, ncol=3, loc="upper left")
    ax2.set_title("BBO Ratio + qUp / qDown + Action Ratio")

    # Pin x-axis to BBO range so indicator lines do not push it wider
    ax1.set_xlim(bbo_1s.index[0], bbo_1s.index[-1])

    plt.tight_layout()
    plt.show()


def plot_from_result(
    result: "DetectionResult",
    df_buy: pd.DataFrame,
    df_sell: pd.DataFrame,
    ind: pd.DataFrame,
) -> None:
    """Same two-panel figure as plot_single, using pre-loaded BBO from a DetectionResult.

    Parameters
    ----------
    result : DetectionResult
        Used for result.maker_bbo and result.taker_bbo (raw BBO as returned by _load_bbo).
    df_buy : pd.DataFrame
        Buy-side pairs to display (e.g. from _build_plot_pairs).
    df_sell : pd.DataFrame
        Sell-side pairs to display.
    ind : pd.DataFrame
        Indicator DataFrame with columns: timestamp_ms, qUp, qDown.
    """
    bbo_raw   = result.maker_bbo
    taker_raw = result.taker_bbo

    filtered = pd.concat([df_buy, df_sell], ignore_index=True)

    maker_level_times = set(filtered["maker_level_time"].dropna().astype(int))
    taker_level_times = set(filtered["taker_level_time"].dropna().astype(int))

    bbo_1s   = _resample_bbo(bbo_raw,   maker_level_times)
    taker_1s = _resample_bbo(taker_raw, taker_level_times)

    mk_pts = pd.DataFrame({
        "dt":    pd.to_datetime(filtered["maker_tx_time"].values, unit="ms"),
        "price": filtered["maker_price"].values,
        "side":  filtered["maker_side"].values,
        "role":  "maker",
    })
    tk_pts = pd.DataFrame({
        "dt":    pd.to_datetime(filtered["taker_tx_time"].values, unit="ms"),
        "price": filtered["taker_price"].values,
        "side":  filtered["taker_side"].values,
        "role":  "taker",
    })
    trx_pts = pd.concat([mk_pts, tk_pts], ignore_index=True)

    bbo_ratio_1s = compute_bbo_ratio_resampled(bbo_raw, taker_raw)
    df_filtered  = add_level_bbo_ratios(filtered, bbo_raw, taker_raw)
    level_ratio  = df_filtered[["maker_level_time", "ask_ratio", "bid_ratio"]].copy()
    level_ratio  = level_ratio.drop_duplicates(subset="maker_level_time")
    level_ratio.index = pd.to_datetime(level_ratio["maker_level_time"].values, unit="ms")
    level_ratio  = level_ratio[["ask_ratio", "bid_ratio"]]

    bbo_ratio = (
        pd.concat([bbo_ratio_1s, level_ratio])
        .sort_index()
        .loc[lambda x: ~x.index.duplicated(keep="last")]
    )

    ind_dt = ind.copy()
    ind_dt["dt"] = pd.to_datetime(ind_dt["timestamp_ms"], unit="ms")

    act = filtered.copy()
    act["dt"] = pd.to_datetime(act["maker_tx_time"], unit="ms")

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 8), sharex=True)

    ax1.plot(bbo_1s.index,   bbo_1s["ask_price"],   color="salmon",         lw=0.8, label="maker ask")
    ax1.plot(bbo_1s.index,   bbo_1s["bid_price"],   color="skyblue",        lw=0.8, label="maker bid")
    ax1.plot(taker_1s.index, taker_1s["ask_price"], color="firebrick",      lw=0.8, ls="--", label="taker ask")
    ax1.plot(taker_1s.index, taker_1s["bid_price"], color="cornflowerblue", lw=0.8, ls="--", label="taker bid")

    ROLE_COLOR = {"maker": "steelblue", "taker": "darkorange"}
    for role, rg in trx_pts.groupby("role"):
        for side, marker in [(1, "^"), (-1, "v")]:
            sub = rg[rg["side"] == side]
            if not sub.empty:
                ax1.scatter(sub["dt"], sub["price"],
                            marker=marker, color=ROLE_COLOR[role],
                            s=60, alpha=0.7, linewidths=0,
                            label="{} {:+d}".format(role, side))

    ax1.set_ylabel("price")
    ax1.legend(fontsize=7, ncol=3, loc="upper left")
    ax1.set_title("Maker BBO (1s + level snapshots) + Paired Trx")

    ax2.plot(bbo_ratio.index, bbo_ratio["ask_ratio"], color="salmon",  lw=0.8, label="ask_ratio")
    ax2.plot(bbo_ratio.index, bbo_ratio["bid_ratio"], color="skyblue", lw=0.8, label="bid_ratio")
    ax2.plot(ind_dt["dt"], ind_dt["qUp"],   color="green", lw=1.0, ls="--", label="qUp")
    ax2.plot(ind_dt["dt"], ind_dt["qDown"], color="red",   lw=1.0, ls="--", label="qDown")
    ax2.axhline(0, color="gray", lw=0.5, ls=":")

    SIDE_COLOR = {1: "green", -1: "red"}
    for side, marker in [(1, "^"), (-1, "v")]:
        sub = act[act["action_side"] == side]
        if not sub.empty:
            ax2.scatter(sub["dt"], sub["action_ratio"],
                        marker=marker, color=SIDE_COLOR[side],
                        s=60, alpha=0.7, linewidths=0,
                        label="action_side={:+d}".format(side))

    ax2.set_ylabel("ratio")
    ax2.legend(fontsize=7, ncol=3, loc="upper left")
    ax2.set_title("BBO Ratio + qUp / qDown + Action Ratio")

    ax1.set_xlim(bbo_1s.index[0], bbo_1s.index[-1])

    plt.tight_layout()
    plt.show()


def _build_plot_pairs(plot_set, result):
    # type: (str, DetectionResult) -> Tuple[pd.DataFrame, pd.DataFrame]
    """Select buy/sell pair DataFrames to display based on plot_set name.

    Parameters
    ----------
    plot_set : str
        One of "TandE", "TandA", "EminusTandA".
    result : DetectionResult
        Full pipeline result.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame]
        (plot_buy, plot_sell) DataFrames.

    Set definitions
    ---------------
    TandE      : T  — threshold-filtered pairs (T ⊆ E by definition).
    TandA      : T ∩ A — threshold-filtered pairs whose maker level was also a
                 signal BBO (win trades).
    EminusTandA: (E \\ T) ∩ A — pairs that executed while a signal was active
                 but did not pass the threshold filter (loss trades).
    """
    a_buy  = result.pair_sets["buy"]["A"]
    a_sell = result.pair_sets["sell"]["A"]

    if plot_set == "TandE":
        return result.df_buy.copy(), result.df_sell.copy()

    if plot_set == "TandA":
        buy  = result.df_buy[result.df_buy["maker_level_uid"].isin(a_buy)]
        sell = result.df_sell[result.df_sell["maker_level_uid"].isin(a_sell)]
        return buy, sell

    # EminusTandA: (E \ T) ∩ A
    t_uids_buy  = set(result.df_buy["maker_level_uid"])
    t_uids_sell = set(result.df_sell["maker_level_uid"])
    buy_e  = result.pairs[result.pairs["action_side"] == 1]
    sell_e = result.pairs[result.pairs["action_side"] == -1]
    buy  = buy_e[ buy_e["maker_level_uid"].isin(a_buy)   & ~buy_e["maker_level_uid"].isin(t_uids_buy)]
    sell = sell_e[sell_e["maker_level_uid"].isin(a_sell)  & ~sell_e["maker_level_uid"].isin(t_uids_sell)]
    return buy, sell


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    """Entry point for the signal detector CLI."""
    parser = argparse.ArgumentParser(description="Signal detector")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("single", help="Run detection on one hour and plot an overview")
    p.add_argument("maker",     help="Maker HDF5 file path")
    p.add_argument("taker",     help="Taker HDF5 file path")
    p.add_argument("indicator", help="Indicator CSV path (e.g. q95.csv)")
    p.add_argument("-d", "--delta-t", type=int, default=500, help="Taker latency in ms (default: 500)")
    p.add_argument("-mm", "--maker-mode", choices=["front", "back"], default="back",
                   help="Maker trx method: front (first-in-queue) or back (queue-aware, default)")

    pf = sub.add_parser("full", help="Run full pipeline (with signal operator) on one hour and plot")
    pf.add_argument("maker",     help="Maker HDF5 file path")
    pf.add_argument("taker",     help="Taker HDF5 file path")
    pf.add_argument("indicator", help="Indicator CSV path (e.g. q95.csv)")
    pf.add_argument("-d", "--delta-t", type=int, default=500, help="Taker latency in ms (default: 500)")
    pf.add_argument("-mm", "--maker-mode", choices=["front", "back"], default="back",
                    help="Maker trx method: front (first-in-queue) or back (queue-aware, default)")
    pf.add_argument("-so", "--signal-op", choices=["direct", "rolling"], default="direct",
                    help="Signal operator: direct (default) or rolling quantile")
    pf.add_argument("--window",   type=int,   default=100, help="Rolling quantile window (default: 100)")
    pf.add_argument("--quantile", type=float, default=0.5, help="Rolling quantile level (default: 0.5)")
    pf.add_argument("--alpha",    type=float, default=1.0, help="Threshold scaler alpha (default: 1.0)")
    pf.add_argument("--delta",    type=float, default=0.0, help="Threshold scaler delta (default: 0.0)")
    pf.add_argument("--buffer",   type=float, default=0.0,
                    help="Signal filter buffer: effective qUp = qUp + buffer, qDown = qDown - buffer (default: 0.0)")
    pf.add_argument("--plot-set", choices=["TandE", "TandA", "EminusTandA"], default="TandA",
                    help="Which trades to display: TandE (threshold-filtered), TandA (wins, default), EminusTandA (losses)")

    pr = sub.add_parser("range", help="Run full pipeline over a range of hours and print merged metrics")
    pr.add_argument("maker",     help="Maker symbol (e.g. gateio.eth_usdt_swap)")
    pr.add_argument("taker",     help="Taker symbol (e.g. paradex.eth_usdc_swap)")
    pr.add_argument("indicator", help="Indicator CSV path (e.g. q95.csv)")
    pr.add_argument("start",     help="Inclusive start datehour in YYYYmmddHH format")
    pr.add_argument("end",       help="Inclusive end datehour in YYYYmmddHH format")
    pr.add_argument("-r", "--root", default=None,
                    help="Root data directory (default: $DATA_DIR)")
    pr.add_argument("-d", "--delta-t", type=int, default=500, help="Taker latency in ms (default: 500)")
    pr.add_argument("-mm", "--maker-mode", choices=["front", "back"], default="back",
                    help="Maker trx method: front (first-in-queue) or back (queue-aware, default)")
    pr.add_argument("-so", "--signal-op", choices=["direct", "rolling"], default="direct",
                    help="Signal operator: direct (default) or rolling quantile")
    pr.add_argument("--window",   type=int,   default=100, help="Rolling quantile window (default: 100)")
    pr.add_argument("--quantile", type=float, default=0.5, help="Rolling quantile level (default: 0.5)")
    pr.add_argument("--alpha",    type=float, default=1.0, help="Threshold scaler alpha (default: 1.0)")
    pr.add_argument("--delta",    type=float, default=0.0, help="Threshold scaler delta (default: 0.0)")
    pr.add_argument("--buffer",   type=float, default=0.0,
                    help="Signal filter buffer: effective qUp = qUp + buffer, qDown = qDown - buffer (default: 0.0)")
    pr.add_argument("--plot", action="store_true",
                    help="Draw a single-like figure after running")
    pr.add_argument("--plot-set", choices=["TandE", "TandA", "EminusTandA"], default="TandA",
                    help="Which trades to display: TandE (threshold-filtered), TandA (wins, default), EminusTandA (losses)")
    pr.add_argument("-o", "--output", default=None, help="Save merged pair table to this CSV path")

    args = parser.parse_args()

    if args.cmd == "single":
        config = DetectionConfig(
            source=FileDataSourceConfig(maker_file=args.maker, taker_file=args.taker),
            compute=ComputeConfig(delta_t=args.delta_t, maker_mode=args.maker_mode),
        )

        df = run_detection(config)

        ind = pd.read_csv(args.indicator)
        ind["qUp"]   = ind["short"]
        ind["qDown"] = -ind["long"]

        df_buy, df_sell = filter_pairs(df, ind)

        print(f"total pairs : {len(df)}")
        print(f"buy  kept   : {len(df_buy)}  ({len(df_buy) / len(df):.2%})")
        print(f"sell kept   : {len(df_sell)}  ({len(df_sell) / len(df):.2%})")

        plot_single(config, df_buy, df_sell, ind)

    elif args.cmd == "full":
        if args.signal_op == "rolling":
            signal_op = RollingQuantileSignalOperator(window=args.window, quantile=args.quantile, buffer=args.buffer)
        else:
            signal_op = DirectSignalOperator(buffer=args.buffer)

        config = DetectionConfig(
            source=FileDataSourceConfig(maker_file=args.maker, taker_file=args.taker),
            compute=ComputeConfig(
                delta_t=args.delta_t,
                maker_mode=args.maker_mode,
                signal_operator=signal_op,
                threshold_scaler=ThresholdScaler(alpha=args.alpha, delta=args.delta),
            ),
        )

        ind = pd.read_csv(args.indicator)
        ind["qUp"]   = ind["short"]
        ind["qDown"] = -ind["long"]

        result = run_full(config, ind)

        a_buy  = result.pair_sets["buy"]["A"]
        a_sell = result.pair_sets["sell"]["A"]
        t_and_a_buy  = result.df_buy[result.df_buy["maker_level_uid"].isin(a_buy)]
        t_and_a_sell = result.df_sell[result.df_sell["maker_level_uid"].isin(a_sell)]

        plot_buy, plot_sell = _build_plot_pairs(args.plot_set, result)

        m_buy  = result.metrics["buy"]
        m_sell = result.metrics["sell"]
        print(f"total pairs        : {len(result.pairs)}")
        print(f"buy  kept (T)      : {len(result.df_buy)}  ({len(result.df_buy) / len(result.pairs):.2%})")
        print(f"sell kept (T)      : {len(result.df_sell)}  ({len(result.df_sell) / len(result.pairs):.2%})")
        print(f"buy  T∩A           : {len(t_and_a_buy)}")
        print(f"sell T∩A           : {len(t_and_a_sell)}")
        print(f"signal_exec_rate   buy={m_buy['signal_exec_rate']:.2%}  sell={m_sell['signal_exec_rate']:.2%}")
        print(f"fill_quality_rate  buy={m_buy['fill_quality_rate']:.2%}  sell={m_sell['fill_quality_rate']:.2%}")

        plot_from_result(result, plot_buy, plot_sell, ind)

    elif args.cmd == "range":
        root = args.root or os.environ.get("DATA_DIR")
        if not root:
            parser.error("--root is required when $DATA_DIR is not set")

        if args.signal_op == "rolling":
            signal_op = RollingQuantileSignalOperator(window=args.window, quantile=args.quantile, buffer=args.buffer)
        else:
            signal_op = DirectSignalOperator(buffer=args.buffer)

        source = RangeDataSourceConfig(
            root=root,
            maker=args.maker,
            taker=args.taker,
            start=args.start,
            end=args.end,
        )
        compute = ComputeConfig(
            delta_t=args.delta_t,
            maker_mode=args.maker_mode,
            signal_operator=signal_op,
            threshold_scaler=ThresholdScaler(alpha=args.alpha, delta=args.delta),
        )

        ind = pd.read_csv(args.indicator)
        ind["qUp"]   = ind["short"]
        ind["qDown"] = -ind["long"]

        result = run_range(source, compute, ind)

        a_buy  = result.pair_sets["buy"]["A"]
        a_sell = result.pair_sets["sell"]["A"]
        t_and_a_buy  = result.df_buy[result.df_buy["maker_level_uid"].isin(a_buy)]
        t_and_a_sell = result.df_sell[result.df_sell["maker_level_uid"].isin(a_sell)]

        m_buy  = result.metrics["buy"]
        m_sell = result.metrics["sell"]
        print(f"hours              : {args.start} – {args.end}")
        print(f"total pairs        : {len(result.pairs)}")
        print(f"buy  kept (T)      : {len(result.df_buy)}  ({len(result.df_buy) / len(result.pairs):.2%})")
        print(f"sell kept (T)      : {len(result.df_sell)}  ({len(result.df_sell) / len(result.pairs):.2%})")
        print(f"buy  T∩A           : {len(t_and_a_buy)}")
        print(f"sell T∩A           : {len(t_and_a_sell)}")
        print(f"signal_exec_rate   buy={m_buy['signal_exec_rate']:.2%}  sell={m_sell['signal_exec_rate']:.2%}")
        print(f"fill_quality_rate  buy={m_buy['fill_quality_rate']:.2%}  sell={m_sell['fill_quality_rate']:.2%}")

        if args.output:
            result.pairs.to_csv(args.output, index=False)
            print(f"pairs saved to     : {args.output}")

        if args.plot:
            plot_buy, plot_sell = _build_plot_pairs(args.plot_set, result)
            plot_from_result(result, plot_buy, plot_sell, ind)


if __name__ == "__main__":
    main()
