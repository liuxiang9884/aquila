# invariant-strategy

## 环境配置

### 前置要求

- Go `1.23.4`（见 `go.mod`）
- 需要能访问私有 GitLab（推荐使用 OAuth2 Token）

本项目依赖 3 个私有 Go module：

- `gitlab.com/hashingbotrepo/backend/pinnaquant`（建议本地 clone）
- `gitlab.com/hashingbotrepo/backend/xexchange`（建议本地 clone）
- `git.hashingbot.com/aurthes/xex_mm_go`（通过 `replace` 重定向到 GitLab）

在 `go.mod` 中，`pinnaquant` 和 `xexchange` 通过 `replace` 指向 `../pinnaquant` 与 `../xexchange`，因此这两个仓库需要与本仓库放在同一层级目录下。

### 目录结构（必须）

请确保三个仓库并列放置：

```bash
backtest-go/
	invariant-strategy/
	pinnaquant/
	xexchange/
```

示例：

```bash
cd /path/to/backtest-go
git clone https://gitlab.com/hashingbotrepo/backend/pinnaquant.git
git clone https://gitlab.com/hashingbotrepo/backend/xexchange.git
git clone https://gitlab.com/hashingbotrepo/strategy/invariant-strategy.git
```

### 配置 Go 访问私有 module

告诉 Go 这些 module path 属于私有仓库（跳过 proxy 与 checksum DB）：

```bash
go env -w GOPRIVATE=gitlab.com/hashingbotrepo/*
go env -w GONOSUMDB=gitlab.com/hashingbotrepo/*
```

说明：

- 只需要把 `gitlab.com/hashingbotrepo/*` 视为 private。
- 虽然 `go.mod` 里写的是 `git.hashingbot.com/aurthes/xex_mm_go`，但它会通过 `replace` 被重定向到 `gitlab.com/hashingbotrepo/strategy/xex_mm_go.git`，所以认证仍然只需要针对 `gitlab.com`。

### 私有 GitLab 认证（OAuth2）

所有仓库都在私有 GitLab 上，需要 OAuth2 认证。

常见做法是使用 GitLab Personal Access Token（PAT），并通过 git 的 URL rewrite 在拉取依赖时自动带上 token。

#### 方式：git URL rewrite（HTTPS）

```bash
git config --global url."https://oauth2:<YOUR_GITLAB_TOKEN>@gitlab.com/".insteadOf "https://gitlab.com/"
```

> 注意：不要把 token 提交到任何仓库文件中。

### 拉取依赖

完成同级仓库准备与认证配置后：

```bash
cd invariant-strategy
go mod tidy
```

如果 `go` 仍然提示认证或拉取失败，通常原因是：

- `GOPRIVATE` 没有覆盖到对应 module path
- OAuth2 token 没有足够的 read 权限
- `pinnaquant` / `xexchange` 没有放在 `../pinnaquant` 与 `../xexchange`
