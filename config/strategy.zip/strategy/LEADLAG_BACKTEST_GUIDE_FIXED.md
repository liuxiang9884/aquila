# LeadLag Fixed 版策略回测完整指南

> 基于当前 latest fixed 版本整理。
>
> 文档定位：
> - 本文档负责 **当前 fixed 版本** 的完整运行说明、配置解释、代码逻辑解读、输出解读与调参建议
> - 最短运行路径见 `LEADLAG_QUICK_START_FIXED.md`
> - 工作区整体结构见根目录 `README.md`
> - 根因与恢复总结见 `docs/leadlag-root-cause-and-recovery-20260419.md`
> - 收益与成交质量分析见 `docs/leadlag-performance-quality-comparison-20260419.md`
> - current fixed vs baseline 的实现差异见 `docs/leadlag-strategy-version-diff.md`

---

## 一、基础配置文件

### 1.1 当前 fixed 版配置入口

当前工作区中，fixed 版有两类常用配置：

#### A. fixed 默认显式配置

用途：

- 单独运行 current fixed
- 做参数调试
- 做非 baseline 对比的功能验证

路径：

```text
temp/leadlag-default-explicit/
├── strategy.json
└── backtest.json
```

#### B. baseline vs fixed 严格对比配置

用途：

- 与 baseline 做同口径回测对比

短窗口：

```text
temp/backtest-compare-2026022600-2026022610/
├── strategy-baseline.json
├── strategy-fixed.json
├── backtest-baseline.json
└── backtest-fixed.json
```

长窗口：

```text
temp/backtest-compare-2026022600-2026022702/
├── strategy-baseline.json
├── strategy-fixed.json
├── backtest-baseline.json
└── backtest-fixed.json
```

---

### 1.2 strategy.json - 当前 fixed 策略参数配置

推荐参考：

- `temp/leadlag-default-explicit/strategy.json`

示例：

```json
{
  "symbol": "eth_usdt",
  "lead": "binance",
  "lag": "gateio",
  "trigger": {
    "lead": 0.0025,
    "close": 0.0005,
    "lag_part": 0.5,
    "quantile": {
      "move": 0.75
    },
    "target_profit_rate": 0.0,
    "drift_limit": 0.02,
    "drift_period": "1m"
  },
  "execute": {
    "open": "100",
    "trailing_stop": 0.01,
    "max_entry_spread": 0.01,
    "parallel": 1
  },
  "bbo_record": {
    "window": "1s",
    "stats_window": "30s",
    "size": 100
  }
}
```

> 注意：
> - `trigger.lead` / `trigger.close` 只在最初一个窗口作为种子，之后会被自适应阈值覆盖。
> - current fixed 已引入 `max_entry_spread`，不要再把 `trailing_stop` 理解为开仓 spread 过滤参数。

#### 手续费率来源

- current fixed 主流程里的手续费率不是从 `strategy.json` 或 `backtest.json` 配置出来的。
- 当前实际来源是修复版策略代码中的硬编码映射：
  - `.wt-invariant-strategy-leadlag-must-fix/leadlag/algo/strategy.go`
- 关键实现是：
  - `var takerFees = map[string]float64{...}`
  - `s.lagContext.fee = takerFees[s.config.Lag]`
- 运行时总是取 **lag 交易所的 taker fee**。
- 在 current fixed 的显式成本模型里，费用按双边进入：
  - `Fee = s.lagContext.fee * 2`
- 例如当前 `lag = gateio` 时，单边费率为 `0.00016`，双边成本项为 `0.00032`。
- 如果要改回测里的手续费假设，应直接修改这个 `takerFees` 表，而不是改 `backtest.json`。

---

### 1.3 顶层配置 `StrategyConfig`

| 字段 | 类型 | 必需 | 说明 |
|---|---|---|---|
| `symbol` | string | ✅ | 交易对，如 `eth_usdt` |
| `lead` | string | ✅ | lead 交易所名称，如 `binance` |
| `lag` | string | ✅ | lag 交易所名称，如 `gateio` |
| `trigger` | TriggerConfig | ✅ | 信号检测与对齐门控参数 |
| `execute` | ExecutionConfig | ✅ | 下单、止损、开仓过滤参数 |
| `bbo_record` | BBORecord | ✅ | recorder 初始化窗口参数 |

---

### 1.4 `BBORecord` — 仅初始化时生效

所有字段在 `SetContext` 中一次性消费，用于初始化内部 recorder；运行中不可更改。

| 字段 | 默认值 | 作用 |
|---|---|---|
| `window` | `5s` | lead / lag 两侧 `BBOVolRecorder` 的滚动窗口，决定 min/max bid/ask 的回溯范围；也是 `volema` 的内层 std 窗口 |
| `stats_window` | `5s` | `MoveQueue` 的滚动周期；同时也是 `volema` 的 EMA 周期、lag spread 统计窗口、drift std EMA 窗口 |
| `size` | `100` | 各类内部队列容量上限 |

---

### 1.5 `TriggerConfig` — 当前 fixed 的信号触发参数

| 字段 | 默认值 | 生命周期 | 说明 |
|---|---|---|---|
| `lead` | — | **仅初始化种子** | 初始化 `UpEntry` / `DownEntry`；第一个 `stats_window` 后会被覆盖 |
| `open` | — | **未使用** | 结构体中定义但不参与逻辑 |
| `close` | — | **仅初始化种子** | 初始化 `UpExit` / `DownExit`；后续被 drift std EMA 覆盖 |
| `lag_part` | `0.5` | **运行时** | `(lead_move - lag_move) / lead_move > lag_part`，判断 lag 是否仍未跟上 |
| `lead_part` | `1.0` | **未使用** | 当前逻辑不使用 |
| `quantile.move` | `0.99` | **运行时（每次滚动）** | 从 move 分布提取分位数，更新 entry 阈值 |
| `target_profit_rate` | `0` | **运行时** | 在显式成本门槛之上额外要求的利润空间 |
| `drift_limit` | `0.02` | **运行时** | 只有在 `driftReady` 后才对新开仓生效 |
| `drift_period` | `1h` | **仅初始化** | `lag_mid / lead_mid` 滚动均值窗口 |
| `drift_min_samples` | `20` | **运行时门控** | 至少多少 paired drift 样本后才允许进入 `Active` |
| `drift_warmup` | 未设置时回退到 `stats_window` | **运行时门控** | 对齐至少持续多久后才允许进入 `Active` |

#### `drift_period` 与 `drift_limit` 的关系

- `drift_period` 决定 drift mean 如何平滑
- `drift_limit` 决定 drift mean 偏离 1 多少时禁止新开仓

---

### 1.6 `ExecutionConfig` — 当前 fixed 的执行参数

| 字段 | 默认值 | 生命周期 | 说明 |
|---|---|---|---|
| `open` | `1000` | **运行时** | 每笔名义金额，实际数量由 `CalOpenQty` 计算 |
| `trailing_stop` | `0.001` | **运行时** | 仅用于 trailing stop / stoploss |
| `max_entry_spread` | `-1` | **运行时** | 仅用于开仓前 spread 过滤；负值时回退到 `trailing_stop` |
| `parallel` | `1` | **运行时** | 最大同时持仓数量 |

#### 当前 fixed 与旧版最大的执行参数差异

- baseline：`trailing_stop` 同时负责
  - 开仓 spread 过滤
  - 持仓止损
- current fixed：
  - `trailing_stop` 只负责止损
  - `max_entry_spread` 只负责开仓过滤

---

## 二、backtest.json - 回测环境配置

### 2.1 示例

推荐参考：

- `temp/leadlag-default-explicit/backtest.json`

```json
{
  "group": {
    "hourly": {
      "data": {
        "gateio": { "perp": ["eth_usdt_swap"] },
        "binance": { "perp": ["eth_usdt_swap"] }
      },
      "root": "/Users/yukio/Downloads/raw_data_hourly",
      "range": ["2026022600", "2026022600"],
      "Memory": "128M"
    }
  },
  "global": {
    "depth": {
      "disabled": true
    },
    "bbo": {
      "disabled": false,
      "ignore": false
    },
    "trade": {
      "ignore": false
    },
    "market_reduce_split": 0.5
  },
  "latencies": {
    "binance": {
      "public": { "type": "fixed", "fixed": 2, "real": false }
    },
    "gateio": {
      "req": { "type": "fixed", "fixed": 2, "real": false },
      "resp": { "type": "fixed", "fixed": 2, "real": false },
      "public": { "type": "fixed", "fixed": 2, "real": false }
    }
  }
}
```

### 2.2 核心字段

| 字段 | 说明 |
|---|---|
| `group.hourly.root` | 数据根目录 |
| `group.hourly.range` | 回测时间区间 |
| `global.depth.disabled` | depth 全禁用，不推给策略也不进撮合 |
| `global.bbo.disabled` | BBO 保持开启 |
| `global.bbo.ignore` | BBO 继续喂给撮合引擎 |
| `latencies.binance.public.fixed` | lead 侧 public 延迟 = 2 |
| `latencies.gateio.req/resp/public.fixed` | lag 侧 req/resp/public 延迟 = 2 |

### 2.3 当前推荐口径

- 数据路径：`/Users/yukio/Downloads/raw_data_hourly`
- `depth.disabled = true`
- `bbo.disabled = false`
- `bbo.ignore = false`
- `lead (binance) public = 2`
- `lag (gateio) req/resp/public = 2`

---

## 三、回测策略运行入口

### 3.1 current fixed 主仓库

```text
.wt-invariant-strategy-leadlag-must-fix/
```

### 3.2 入口脚本位置

```text
leadlag/backtest/main.go
```

### 3.3 运行命令

#### 运行 fixed 默认显式配置

```bash
cd "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/.wt-invariant-strategy-leadlag-must-fix"
mkdir -p "$PWD/logs/fixed-default"
GODEBUG=cgocheck=0 \
LOG_DIR="$PWD/logs/fixed-default" \
LOG_FILE=json.log \
go run leadlag/backtest/main.go \
  -s "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/leadlag-default-explicit/strategy.json" \
  -b "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/leadlag-default-explicit/backtest.json" \
  > "$PWD/logs/fixed-default/console.log" 2>&1
```

#### 运行 short 对比窗口

```bash
cd "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/.wt-invariant-strategy-leadlag-must-fix"
mkdir -p "$PWD/logs/fixed-short"
GODEBUG=cgocheck=0 \
LOG_DIR="$PWD/logs/fixed-short" \
LOG_FILE=json.log \
go run leadlag/backtest/main.go \
  -s "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022610/strategy-fixed.json" \
  -b "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022610/backtest-fixed.json" \
  > "$PWD/logs/fixed-short/console.log" 2>&1
```

#### 运行 long 对比窗口

```bash
cd "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/.wt-invariant-strategy-leadlag-must-fix"
mkdir -p "$PWD/logs/fixed-long"
GODEBUG=cgocheck=0 \
LOG_DIR="$PWD/logs/fixed-long" \
LOG_FILE=json.log \
go run leadlag/backtest/main.go \
  -s "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022702/strategy-fixed.json" \
  -b "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022702/backtest-fixed.json" \
  > "$PWD/logs/fixed-long/console.log" 2>&1
```

### 3.4 参数说明

- `-s`: 策略配置路径
- `-b`: 回测配置路径
- `-cpuprofile`: CPU profile 输出
- `-memprofile`: 内存 profile 输出

---

## 四、策略逻辑脚本详解

### 4.1 关键目录

```text
leadlag/algo/
├── strategy.go        # 主策略逻辑
├── move.go            # MoveQueue / 分位数阈值
├── analysis.go        # recorder / drift / noise 统计
├── cost_model.go      # 统一 entry cost model
└── execute_cache.go   # ExecuteCache / 状态机
```

### 4.2 `strategy.go` 核心逻辑详解

#### ① 策略结构体

核心职责：

- 维护 lead / lag 两侧市场状态
- 维护动态阈值
- 维护对齐阶段
- 维护交易缓存和状态机

当前 fixed 的结构重点在三块：

```go
leadContext   // lead 侧原始 BBO、drifted BBO、recorder、move
lagContext    // lag 侧 BBO、spread、drift、volema
alignment     // Bootstrap / Aligning / Active
```

#### ② `SetContext`

作用：

- 初始化各类 recorder
- 初始化 move queue
- 初始化 drift recorder
- 设置 entry / exit seed
- 设置 lag fee
- 设置 alignment 初始阶段

当前 fixed 的关键点：

- `driftReady` 初始为 false
- `alignment.phase` 初始为 `Bootstrap`

#### ③ `OnRawBBO`

这是 current fixed 相比 baseline 最大的流程变化点。

current fixed 的处理顺序：

```text
1. 先更新 raw market state
2. 如果 lead/lag 都有效，则更新 drift
3. 更新 alignment phase
4. 只有 phase == Active 才进入交易逻辑
5. 第一次进入 Active 时调用 enterActivePhase() 重新播种 recorder
```

功能解读：

- 在 `Active` 之前，不允许把未对齐样本推进交易逻辑
- 这样可以避免 cold-start / half-ready 样本污染阈值

#### ④ `alignmentReady` / `updateAlignmentPhase`

current fixed 新增的外层门控。

需要同时满足：

1. raw lead BBO 有效
2. raw lag BBO 有效
3. `driftSamples >= drift_min_samples`
4. `paired_elapsed >= drift_warmup`

阶段：

- `Bootstrap`
- `Aligning`
- `Active`

#### ⑤ `enterActivePhase`

作用：

- 在第一次进入 Active 时，重新初始化交易侧 recorder
- 用当前最新的 lead / lag 快照播种 recorder

功能解读：

- 这是 current fixed 的关键边界：
  - 对齐阶段积累 drift
  - Active 之后才允许交易侧统计真正开始

#### ⑥ `OnLeadBBO`

current fixed 的 lead 处理顺序：

```text
1. 保存 lead_origin
2. 如果 driftReady，则按 drift mean 缩放 lead
3. 更新 lead recorder / volema / move threshold
4. 先检查已有仓位的平仓
5. 若 `parallel` 未满且 drift_limit 未超限，再尝试开仓
```

功能解读：

- `driftReady` 之前不会强行对 lead 缩放
- `drift_limit` 只阻止新开仓，不阻止 recorder 和已有持仓逻辑

#### ⑦ `UpdateMoveThreshold`

每次 `stats_window` 到期时滚动：

```text
LeadNoise = volema.GetStdEma()
LagNoise  = volema.GetStdEma()
up/down   = move quantile
exit      = DriftStdEma.GetMean()
profitBuffer = fee*2 + LeadNoise + LagNoise
```

然后更新：

- `UpEntry`
- `DownEntry`
- `UpExit`
- `DownExit`

功能解读：

- current fixed 的 entry 门槛不再只看 lead noise
- 而是把 lag noise 也显式纳入

#### ⑧ `OpenLong` / `OpenShort`

开仓过滤链条：

```text
Lead threshold
 -> lag_part
 -> targetSpace > RequiredEdge + target_profit_rate
 -> spreadPct(lag) <= EntrySpreadLimit()
 -> send IOC order
```

功能解读：

- `EntrySpreadLimit()` 优先使用 `max_entry_spread`
- 未配置时才回退到 `trailing_stop`

#### ⑨ `OnOrder`

作用：

- 更新订单状态
- 更新持仓
- 维护 `Idle -> Open -> Hold -> Close -> Idle` 状态机

当前 fixed 与 baseline 在这里没有本质语义变化。

---

## 五、策略核心模块详解

### 5.1 `analysis.go`

当前 fixed 需要理解的重点：

- `BBOVolRecorder`
- `StreamRecorder`
- `StreamStdEmaRecorder`

#### `BBOVolRecorder`

作用：

- 在滚动窗口内维护 ask / bid 的 min / max
- 为 `leadMove` / `askDiff` / `bidDiff` 提供基准

#### `StreamRecorder`

作用：

- 保存滚动窗口内的均值和方差统计
- 被用于：
  - drift mean
  - drift std
  - volatility EMA 的基础统计

当前 fixed 已修复的重要问题：

- `Init()` 会同时清理：
  - `count`
  - `total`
  - `sqTotal`

否则会污染 `GetStd()` 结果。

#### `StreamStdEmaRecorder`

作用：

- 先在内层窗口算 std
- 再对 `std / mean` 做滚动 EMA

在 current fixed 中，它决定：

- `LeadNoise`
- `LagNoise`

### 5.2 `move.go`

`MoveQueue` 的作用：

- 收集当前窗口内的 up / down move 样本
- 到期后做 quantile 统计

当前 fixed 里：

- 只有在 `Active` 阶段才推进 `MoveQueue`

### 5.3 `cost_model.go`

current fixed 新增统一成本模型 helper：

```text
RequiredEdge = fee*2 + LeadNoise + LagNoise
```

并保留：

- `Spread`
- `LagSpreadBuffer`

作为诊断项写入 `EntryCost<...>` 日志。

### 5.4 `execute_cache.go`

负责：

- 仓位状态缓存
- 挂单状态维护
- 每笔交易的状态机推进

---

## 六、参数联动与调参建议

### 6.1 参数联动图

```text
bbo_record.stats_window
    ├──> MoveQueue 滚动周期
    ├──> volatility EMA 周期
    ├──> drift std EMA 周期
    └──> 默认 drift_warmup

drift_period
    └──> drift mean 平滑程度
           └──> drift_limit 开仓门控

quantile.move
    └──> UpEntry / DownEntry

LeadNoise + LagNoise + fee
    └──> RequiredEdge
           └──> target_profit_rate
                  └──> 最终 entry 成本门槛

max_entry_spread
    └──> 开仓前价差过滤
trailing_stop
    └──> 持仓后止损
```

### 6.2 常见调参方向

#### 更敏感、更高频

- 降低 `quantile.move`
- 降低 `lag_part`
- 缩短 `stats_window`
- 放宽 `max_entry_spread`

#### 更稳、更少噪声

- 提高 `quantile.move`
- 提高 `lag_part`
- 提高 `target_profit_rate`
- 收紧 `max_entry_spread`

#### 调 alignment

- 若希望更快进入 Active：
  - 降低 `drift_min_samples`
  - 缩短 `drift_warmup`
- 若希望更稳健：
  - 增大 `drift_min_samples`
  - 拉长 `drift_warmup`

---

## 七、输出文件与结果解读

### 7.1 推荐输出

推荐每次运行都显式隔离：

| 输出类型 | 推荐路径 |
|---|---|
| 结构化日志 | `$LOG_DIR/json.log` |
| 控制台日志 | `$LOG_DIR/console.log` |

### 7.2 先看哪些字段

#### `alignment phase transition`

说明：

- 对齐已经进入 Active

#### `[Brief] PRIVATE`

最值得看的字段：

| 字段 | 含义 |
|---|---|
| `UpLeadCount` / `DownLeadCount` | 第一层 trigger 命中次数 |
| `UpLadCount` / `DownLadCount` | lag 未跟上的通过次数 |
| `UpSpaceCount` / `DownSpaceCount` | 通过最终利润空间与价差过滤的次数 |
| `History<Total)` | 最终订单历史数 |
| `LastUpEntry` / `LastDownEntry` | 最近一次 entry 阈值 |
| `LastProfitBuffer` | 最近一次显式成本门槛 |

#### `EntryCost<...>`

可以直接观察：

- `fee`
- `lead_noise`
- `lag_noise`
- `required`

用来判断到底是谁在抬高门槛。

### 7.3 当前正常量级参考

当前 fixed 的正常量级大致是：

- `LastUpEntry ≈ 0.0003 ~ 0.0005`
- `LastProfitBuffer ≈ 0.0003 ~ 0.0004`

如果再次看到：

- `LastUpEntry` 到几十、几百甚至 `924`

那不是正常状态，应优先回看：

- `analysis.go`
- recorder init / noise 统计链路

---

## 八、常见问题

### 情况 1：`LeadCount` 很少

优先检查：

- `quantile.move` 是否过高
- `lag_part` 是否过严
- `drift_limit` 是否过严

### 情况 2：`LeadCount` 有，但 `SpaceCount` 很少

优先检查：

- `target_profit_rate` 是否过高
- `LagNoise` / `LeadNoise` 是否偏高
- `max_entry_spread` 是否过严

### 情况 3：`History<Total)` 低于预期

优先检查：

- 成交率
- `parallel`
- IOC 取消率
- 是否是开仓机会变少，还是开了单但没成交

### 情况 4：又出现 `0` 交易

优先排查：

1. 是否真的进入 `Active`
2. `LastUpEntry` / `LastProfitBuffer` 是否异常
3. 是否重新引入 recorder 污染

---

## 九、当前 fixed 版最值得读的文档

- 运行和修复结论：
  - `docs/leadlag-root-cause-and-recovery-20260419.md`
- 收益与成交质量：
  - `docs/leadlag-performance-quality-comparison-20260419.md`
- current fixed vs baseline 差异：
  - `docs/leadlag-strategy-version-diff.md`
- short / long 窗口报告：
  - `docs/leadlag-sample-backtest-visual-analysis.md`
  - `docs/leadlag-long-window-visual-analysis-2026022600-2026022702.md`

历史旧文档统一在：

- `docs/old/`
