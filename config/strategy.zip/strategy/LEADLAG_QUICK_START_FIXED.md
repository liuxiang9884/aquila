# LeadLag Fixed 版快速入门

> 本文档以 **当前 latest fixed 版本** 为准。
>
> 文档定位：
> - 只保留最短运行路径、关键参数速查、最常见输出解读
> - 如果你需要完整理解 current fixed 的配置、逻辑和调参方式，请直接读：
>   - `LEADLAG_BACKTEST_GUIDE_FIXED.md`

---

## 1. 运行前你应该知道的事

current fixed 已经不是旧的“0 交易”版本。

当前状态：

- 根因已修复：`StreamRecorder.Init()` 会清理 `sqTotal`
- fixed 已恢复真实回测交易能力
- current fixed 的成本门槛为：

```text
RequiredEdge = fee*2 + LeadNoise + LagNoise
targetSpace > RequiredEdge + target_profit_rate
```

---

## 2. 当前 fixed 常用配置

### A. 默认显式配置

```text
temp/leadlag-default-explicit/strategy.json
temp/leadlag-default-explicit/backtest.json
```

### B. baseline 对比配置

短窗口：

```text
temp/backtest-compare-2026022600-2026022610/strategy-fixed.json
temp/backtest-compare-2026022600-2026022610/backtest-fixed.json
```

长窗口：

```text
temp/backtest-compare-2026022600-2026022702/strategy-fixed.json
temp/backtest-compare-2026022600-2026022702/backtest-fixed.json
```

---

## 3. 最短运行命令

### short 窗口

```bash
cd "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/.wt-invariant-strategy-leadlag-must-fix"
mkdir -p "$PWD/logs/fixed-short"
GODEBUG=cgocheck=0 \
LOG_DIR="$PWD/logs/fixed-short" \
LOG_FILE=json.log \
go run leadlag/backtest/main.go \
  -s "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022610/strategy-fixed.json" \
  -b "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022610/backtest-fixed.json" \
  > "$PWD/logs/fixed-short/console.log" 2>&1
```

### long 窗口

```bash
cd "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/.wt-invariant-strategy-leadlag-must-fix"
mkdir -p "$PWD/logs/fixed-long"
GODEBUG=cgocheck=0 \
LOG_DIR="$PWD/logs/fixed-long" \
LOG_FILE=json.log \
go run leadlag/backtest/main.go \
  -s "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022702/strategy-fixed.json" \
  -b "/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/temp/backtest-compare-2026022600-2026022702/backtest-fixed.json" \
  > "$PWD/logs/fixed-long/console.log" 2>&1
```

---

## 4. 关键参数速查

| 参数 | 当前 fixed 语义 | 调整方向 |
|---|---|---|
| `trigger.quantile.move` | 自适应阈值分位数 | 越小越敏感 |
| `trigger.lag_part` | lag 尚未跟上的要求 | 越小越容易开仓 |
| `trigger.target_profit_rate` | 额外利润要求 | 越大越保守 |
| `trigger.drift_limit` | drift 偏离容忍度 | 越小越严格 |
| `trigger.drift_min_samples` | 进入 Active 的最小 paired 样本数 | 越小越快激活 |
| `trigger.drift_warmup` | 进入 Active 的最小 paired 时间 | 越短越快激活 |
| `execute.trailing_stop` | 只用于 trailing stop | 越大止损越宽 |
| `execute.max_entry_spread` | 只用于开仓 spread 过滤 | 越大越容易开仓 |
| `bbo_record.window` | 近端极值窗口 | 越短越敏感 |
| `bbo_record.stats_window` | move 分布滚动周期 | 越长越稳定 |

---

## 5. 你最该怎么看结果

打开 `console.log`，优先看三处：

### A. `alignment phase transition`

说明：

- 策略已经进入 `Active`
- 若始终没有这行，就说明你还停在对齐阶段

### B. `[Brief] PRIVATE`

重点字段：

| 字段 | 含义 |
|---|---|
| `UpLeadCount` / `DownLeadCount` | 第一层 trigger 命中次数 |
| `UpLadCount` / `DownLadCount` | 通过 lag_part 的次数 |
| `UpSpaceCount` / `DownSpaceCount` | 通过最终利润空间门槛的次数 |
| `History<Total)` | 最终订单数 |
| `LastUpEntry` / `LastDownEntry` | 最近一次自适应 entry 阈值 |
| `LastProfitBuffer` | 最近一次显式成本门槛 |

### C. `EntryCost<...>`

可以直接观察：

- `fee`
- `lead_noise`
- `lag_noise`
- `required`

---

## 6. 当前正常参考值

在 current fixed 的正常运行里，通常应看到：

- `UpLeadCount` / `DownLeadCount` 大于 `0`
- `History<Total)` 大于 `0`
- `LastUpEntry` 大致在 `0.0003 ~ 0.0005`
- `LastProfitBuffer` 大致在 `0.0003 ~ 0.0004`

如果又出现：

- `LeadCount = 0`
- `History<Total = 0)`
- `LastUpEntry` 到几十、几百甚至 `924`

优先回看：

- `docs/leadlag-root-cause-and-recovery-20260419.md`

---

## 7. 当前最值得读的文档

- 完整 fixed 指南：
  - `LEADLAG_BACKTEST_GUIDE_FIXED.md`
- 根因与恢复总结：
  - `docs/leadlag-root-cause-and-recovery-20260419.md`
- 收益与成交质量：
  - `docs/leadlag-performance-quality-comparison-20260419.md`
- current fixed vs baseline 差异：
  - `docs/leadlag-strategy-version-diff.md`
