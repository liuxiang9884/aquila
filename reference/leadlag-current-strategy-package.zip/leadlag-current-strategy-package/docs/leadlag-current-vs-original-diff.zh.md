# LeadLag 当前策略与改动前原版策略差异说明

本文面向策略研发和回测使用者，说明 LeadLag 策略从改动前原版到当前版本的行为差异。重点不是逐行复述 `git diff`，而是解释这些差异对信号筛选、下单价格、成本口径、归因日志和回测解读的影响。

## 版本边界

当前版本：

- 路径：`/Users/yukio/.codex/worktrees/11be/backtest-go/.wt-invariant-strategy-leadlag-must-fix`
- branch：`codex/fixed-leadlag-optimization-strategy`
- HEAD：`86b1540`

改动前原版：

- 路径：`/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/.wt-invariant-strategy-leadlag-must-fix`
- branch：`codex/leadlag-must-fix`
- HEAD：`541bce2`

文档 worktree：

- 路径：`/Users/yukio/.codex/worktrees/11be/backtest-go/.wt-leadlag-current-vs-original-doc`
- branch：`codex/leadlag-current-vs-original-doc`
- HEAD：`86b1540`
- 版本关系：`541bce2` 是 `86b1540` 的祖先。

## 核心代码文件

版本范围 `541bce2..86b1540` 中，`leadlag/algo` 下的核心改动文件如下：

- `leadlag/algo/strategy.go`：主策略执行路径、信号评估、post-signal guard、taker buffer、auto warmup、freshness、normal close retry。
- `leadlag/algo/guards.go`：新增 lag volatility guard 和 drift guard 的配置、状态与评估逻辑。
- `leadlag/algo/cost_model.go`：成本模型增加 entry/normal close taker buffer 拆分项。
- `leadlag/algo/execute_cache.go`：执行缓存增加 normal close 失败计数、pending close 类型、原始价/限价记录。
- `leadlag/algo/attribution.go`：归因 schema 增加 `signal_decision`，补强稳定链路和 order lifecycle 价格语义。
- `leadlag/algo/strategy_test.go`：覆盖策略执行、guard、warmup、freshness、buffer、retry 等行为。
- `leadlag/algo/cost_model_test.go`：覆盖成本模型和 taker buffer 成本口径。
- `leadlag/algo/attribution_test.go`：覆盖归因日志、稳定 ID、order lifecycle 价格字段。

## 总体变化

原版策略的开仓路径更偏向“先全局风控，再检查是否有开仓信号”：`parallel-limit` 和 `drift_limit` 在 `OnLeadBBO` 中先执行，命中后不会进入 open long/short 信号评估。

当前版本改为“先判断是否形成开仓信号，再执行开仓后置 guard”。这意味着：

- 没形成信号仍归入 no-trigger 或 entry-cost/entry-spread 等信号层原因。
- 形成信号但被风控拦截，会记录为 signal 已触发，但 post-signal guard blocked。
- 回测分析可以区分“策略没有机会”和“有机会但被执行风控拦截”。

## Post-Signal Guard 解耦

原版：

- `parallel-limit` 在 open signal 评估前执行。
- `trigger.drift_limit` 在 open signal 评估前执行。
- 如果这些条件命中，后续不会计算开仓方向、target space、required edge，也无法知道该 tick 是否本来会触发策略信号。

当前版本：

- `evaluateOpenLongSignal` / `evaluateOpenShortSignal` 先产生结构化 `openSignal`。
- `handleOpenSignal` 再调用 `openGuardBlockReason` 做 post-signal guard。
- guard 结果会写入 `OpenSignalTriggered`、`OpenGuardBlocked`、`LastOpenGuardBlock` 以及 full attribution 里的 guard snapshot。
- 当前 post-signal guard 包括 parallel limit、lag vol guard、drift guard、lead freshness、lag freshness。

对回测解读的影响：

- 原版中被 drift/parallel 提前挡掉的 tick，可能表现为没有后续信号统计。
- 当前版本中这些 tick 如果满足 open 条件，会成为“有信号但被 guard 拦截”的样本。
- 做参数归因时，应优先用当前的 `signal_decision`、`entry_opportunity` 和 guard 字段，而不是只看下单数量。

## Taker Buffer 和成本模型

当前版本新增 `cost.taker_buffer`：

- `mode`：`fixed` 或 `auto`，空值按 `fixed`。
- `entry_fixed_pct`：开仓 IOC 限价相对 BBO 的吃单 buffer。
- `normal_close_fixed_pct`：普通信号平仓 IOC 限价相对 BBO 的吃单 buffer。
- `auto_warmup`：自动 buffer 采样窗口，默认 `1m`。
- `auto_fallback_pct`：auto 模式无有效样本时的 fallback。
- `exclude_from_cost_model`：是否把 taker buffer 从 entry cost model 中排除，默认 `false`。

下单价格变化：

- 开多：原版使用 lag ask；当前版本使用 `lag ask * (1 + entry_buffer)`。
- 开空：原版使用 lag bid；当前版本使用 `lag bid * (1 - entry_buffer)`。
- 普通信号平多：原版使用 lag bid；当前版本使用 `lag bid * (1 - normal_close_buffer)`。
- 普通信号平空：原版使用 lag ask；当前版本使用 `lag ask * (1 + normal_close_buffer)`。
- stoploss 平仓仍使用原本更激进的固定价格逻辑，不吃 `normal_close_fixed_pct`。

成本模型变化：

- 原版 `EntryCostBreakdown.RequiredEdge()` 只包含 `fee + lead_noise + lag_noise`。
- 当前版本默认包含 `fee + entry_taker_buffer + normal_close_taker_buffer + lead_noise + lag_noise`。
- `spread` 和 `lag_spread_buffer` 仍属于 `EmbeddedPriceFriction()`，用于解释价格摩擦，不直接进入 `RequiredEdge()`。
- 如果设置 `exclude_from_cost_model=true`，buffer 仍影响实际限价，但不会提高 `ProfitBuffer()` 和 entry required edge。

对回测解读的影响：

- buffer 默认值为 0 时，价格和 required edge 与原版成本口径保持接近。
- 配置正 buffer 后，成交概率可能提升，但 entry filter 会更严格，除非显式 `exclude_from_cost_model=true`。
- 分析 PnL 时需要区分“报价更激进导致更容易成交”和“成本模型更保守导致更少入场”。

## Auto Warmup 与 Freshness

当前版本新增两类自动 warmup。

第一类是 taker buffer auto warmup：

- 来源：lag depth 的买卖两侧 L1/L2 spread。
- 取值：warmup 窗口内的最大有效 L2 spread。
- 无有效深度样本时使用 `auto_fallback_pct`。
- 负数、NaN、Inf 或无效 depth level 不会进入样本。

第二类是 freshness auto warmup：

- 来源：每个交易所 BBO 的 `LocalTimeMS - ServerTimeMS`。
- 取值：每个交易所独立计算 `mean + 3 * std`。
- 负 latency 不作为样本，但会启动对应 warmup 窗口。
- 当前 freshness 状态也使用 BBO 自带 local/server time，不再用策略 `Context.Now()` 估算。

freshness guard 的启用规则：

- `execute.freshness.mode=auto` 时，优先使用 auto warmup 得到的 threshold。
- auto threshold 不可用时，回退到 `lead_fixed_threshold_ms` / `lag_fixed_threshold_ms`。
- fixed threshold 小于等于 0 时，该侧 freshness guard 视为 disabled。
- 如果 threshold 已启用但当前 latency 不可用，post-signal guard 会 block。

对回测解读的影响：

- 默认 freshness fixed threshold 为 0，因此默认不启用 freshness block。
- 一旦配置 fixed threshold 或 auto threshold 可用，freshness 会成为开仓 post-signal guard，而不是信号计算的一部分。
- auto warmup 会在 alignment active 之前持续采样，并在配置窗口结束时 freeze，避免 late samples 改写早期阈值。

## Normal Close Retry Aggressive 与开关

当前版本新增 `execute.normal_close_retry_aggressive`，默认 `false`。

普通信号平仓的 retry 行为：

- 每个 `ExecuteCache` 记录 `normalCloseFailures`。
- 只有 normal close IOC 完成后仍有残余仓位时，失败计数才增加。
- stoploss close 不增加该计数，也不会触发 normal close escalation。
- SendOrder 失败会清理 pending order 状态，但不增加失败计数，后续可以重新发单。

aggressive 开关行为：

- 默认关闭时，普通平仓重试一直使用配置的 `normal_close_fixed_pct`。
- 开启后，如果同一仓位已有 2 次 normal close 失败，下一次 normal close buffer 至少提升到 `0.005`。
- 如果配置的 `normal_close_fixed_pct` 已经高于 `0.005`，则保留更高的配置值。

对回测解读的影响：

- 默认配置不改变原版的 normal close retry 激进程度。
- 开启 aggressive 后，残余仓位更可能被后续 IOC 平掉，但平仓限价更激进，滑点/成交价风险也更高。
- close attribution 会记录本次使用的 `close_buffer`，包括 escalation 后的值。

## Full Signal Attribution / Log

当前版本扩展了 attribution：

- 新增事件 `signal_decision`。
- `analysis.attribution_output.mode=full` 时，才记录 full signal decision。
- bounded 默认仍保留 trigger、order_create、order_lifecycle、close_decision、entry_opportunity 等核心事件。
- `analysis.attribution_log=false` 时不写归因，也不会为了归因分配 stable ID。

开仓 full signal decision 包含：

- decision：`sent` 或 `blocked`。
- block_reason：如 `parallel-limit`、`lag-vol-guard-trigger`、`drift-guard`、`freshness-lead`。
- signal_side、position_side、lead_move、lag_move、ask_diff/bid_diff。
- entry/exit threshold、target_space、required_edge、fee、entry_buffer、close_buffer。
- raw BBO price 与 effective order price。
- lag depth 前两档、parallel 状态、guard 状态、freshness latency/threshold。

平仓 full signal decision 包含：

- position=`close`。
- held position side、close signal value、exit threshold。
- 本次 normal close 使用的 `close_buffer`。
- 与 close_decision、order_create、order_lifecycle 共享 `close_attempt_id` / `close_seq`。

稳定链路变化：

- entry opportunity、trigger、order_create、order_lifecycle 之间共享 stable linkage。
- guard-blocked open signal 在 full mode 下也会创建可关联的 opportunity/linkage，但不会发送订单。
- close decision 如果没有 open linkage，不会伪造 entry ID，而是标记 unavailable。

## Order Lifecycle 成交价语义

原版 order lifecycle 的 `price` 字段容易混淆限价和成交价语义。

当前版本明确区分：

- `price`：使用 `AvgFillPrc`，即平均成交价。
- `avg_fill_price`：同样为 `AvgFillPrc`，显式字段。
- `raw_price`：下单前按订单方向看到的原始 BBO 价。
- `limit_price`：实际发出的 IOC limit price；优先来自 pending metadata，缺失时回退到订单回报里的 `msg.Price`。
- `order_price`：本地 order 对象保存的 limit price。
- `order_server_time` / `order_local_time`：订单回报时间。

对回测解读的影响：

- 计算真实成交成本时应使用 `price` 或 `avg_fill_price`。
- 分析 buffer 影响时使用 `raw_price` 与 `limit_price`。
- 排查本地订单对象和交易所回报差异时使用 `order_price` 与 `limit_price`。
- pending price metadata 会在订单完成或 SendOrder 失败后清理，避免污染下一笔订单。

## Lag Vol Guard / Drift Guard 替代 Drift Limit

原版使用单一 `trigger.drift_limit`：

- 默认 `0.02`。
- 在 open signal 评估前检查 `abs(drift - 1) > drift_limit`。
- 命中后记录 `drift-limit` filter，并跳过后续开仓信号评估。

当前版本移除了 `DriftLimit` 字段，新增两类 post-signal guard。

`trigger.lag_vol_guard`：

- `enabled` 是 `*bool`，未配置时默认启用，显式 `false` 会保留。
- `jump_threshold` 默认 `0.005`。
- `jump_count` 默认 `3`。
- `jump_window` 默认 `5m`。
- `amplitude_threshold` 默认 `0.025`。
- `amplitude_window` 默认 `1s`。
- `cooldown` 默认 `15m`。
- 当 lag mid 在窗口内多次跳变或短窗振幅过大时，拦截开仓，并进入 cooldown。

`trigger.drift_guard`：

- `enabled` 是 `*bool`，未配置时默认启用，显式 `false` 会保留。
- `drift_instant` 默认 `0.015`，检查当前 lag/lead mid ratio 与 1 的偏离。
- `ratio_std` 默认 `0.008`，检查 ratio 窗口标准差。
- `ratio_std_window` 默认 `1m`。
- `drift_mean` 默认 `0.02`，检查 ratio 均值与 1 的偏离。
- `drift_mean_window` 默认 `1m`。

迁移注意：

- 旧配置里的 `trigger.drift_limit` 不再被当前 `StrategyConfig` 读取。
- 如果想接近原版 drift limit 的“均值漂移超过 2% 不开仓”口径，可设置 `trigger.drift_guard.drift_mean=0.02`，并根据需要关闭 `drift_instant` / `ratio_std` 的影响，或直接配置 `trigger.drift_guard.enabled=false` 保留更接近无新 drift guard 的行为。
- 如果想复现原版“没有 lag vol guard”的行为，需要显式设置 `trigger.lag_vol_guard.enabled=false`。
- 当前 guard 在 open signal 之后执行，因此即便阈值相近，统计口径也不同。

## 配置兼容与默认行为

兼容性要点：

- 新增配置字段都有默认值，旧配置通常可以继续解析。
- `cost.taker_buffer` 缺省时 mode 为 fixed，entry/close buffer 都是 0。
- `execute.freshness` 缺省时 fixed threshold 为 0，freshness guard disabled。
- `execute.normal_close_retry_aggressive` 缺省为 false。
- `analysis.attribution_log` 缺省为 false。
- `analysis.attribution_output.mode` 缺省为 bounded，只有 full mode 会写 `signal_decision`。
- `trigger.lag_vol_guard.enabled` 和 `trigger.drift_guard.enabled` 未配置时默认启用；显式 `false` 不会被 defaults 覆盖。
- `execute.max_entry_spread < 0` 仍回退到 `trailing_stop`，保留原有兼容行为。

默认行为与原版的差异：

- 如果不配置 taker buffer，开仓/普通平仓价格基本保持原版 BBO 价。
- 如果不配置 freshness threshold，不会新增 freshness block。
- 但 lag vol guard 和 drift guard 默认启用，且替代了原版单一 pre-signal `drift_limit`。这可能改变开仓拦截样本和指标口径。
- 旧的 `trigger.drift_limit` 不再生效，迁移时不能只依赖旧字段。

## 测试覆盖

当前版本显著增加测试，覆盖面包括：

- 成本模型：buffer 默认保持旧 required edge、buffer 纳入/排除成本模型、auto buffer fallback、负数/非有限值 clamp、taker fee 配置覆盖。
- auto warmup：depth L2 spread 采样、无效 depth 过滤、auto buffer freeze、freshness mean+3std、负 latency、早/晚 alignment 对 warmup freeze 的影响。
- post-signal guard：parallel、drift guard、lag vol guard、cooldown、lead/lag freshness 均在 open signal 之后拦截，并记录对应 block reason。
- 显式 guard 开关：`enabled=false` 在 `SetDefault` 后仍保留，未配置时默认启用。
- taker buffer 下单价：统一 open signal 路径、legacy OpenLong/OpenShort 路径、guard-blocked opportunity attribution、normal close、stoploss 不受 normal close buffer 影响、buffer 为 0 时保持 BBO 价。
- normal close retry：默认不开启 aggressive、开启后第三次提升到 0.5% floor、partial fill 计失败、fully close 删除 cache、stoploss 不计失败、SendOrder 失败清理 pending 状态。
- attribution：默认关闭不写日志、不分配 stable ID；bounded/full 输出策略；entry opportunity 稳定 ID；full signal decision；close linkage；order lifecycle 分类。
- order lifecycle 价格语义：raw/limit/order/avg fill price 各自独立，并在订单完成后清理 pending price metadata。

建议回测使用者在比较新旧结果时至少分三组配置：

- 兼容基线：关闭 `lag_vol_guard`、`drift_guard`，taker buffer 为 0，freshness disabled，normal close aggressive disabled。
- 新风控基线：保持默认 guard，但 taker buffer 为 0，用于观察 post-signal guard 对入场的影响。
- 执行增强组：开启 fixed/auto taker buffer 与 normal close aggressive，用于评估成交率和滑点之间的权衡。

## 辅助检查命令

本文整理时使用的主要命令：

```bash
git status --short --branch
git rev-parse HEAD
git log --oneline 541bce2..HEAD
git diff --name-status 541bce2..HEAD -- leadlag/algo
git diff --stat 541bce2..HEAD -- leadlag/algo
git diff --unified=80 541bce2..HEAD -- leadlag/algo/cost_model.go leadlag/algo/guards.go leadlag/algo/execute_cache.go
git diff --unified=80 541bce2..HEAD -- leadlag/algo/attribution.go leadlag/algo/strategy.go
git show 541bce2:leadlag/algo/strategy.go
git show 541bce2:leadlag/algo/cost_model.go
rg -n "PostSignal|Taker|Buffer|Warmup|Fresh|Retry|Aggressive|Attribution|Lifecycle|Drift|Guard" leadlag/algo
rg -n "func Test.*(Guard|Fresh|Warmup|Taker|Close|Attribution|Lifecycle|Drift|LagVol|Retry|Buffer)" leadlag/algo/*_test.go
```
