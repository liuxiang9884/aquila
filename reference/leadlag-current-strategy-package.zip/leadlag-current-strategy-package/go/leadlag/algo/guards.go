package algo

import (
	"math"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/jsontype"
)

type LagVolGuardConfig struct {
	Enabled            *bool             `json:"enabled"`
	JumpThreshold      float64           `json:"jump_threshold" default:"0.005"`
	JumpCount          int               `json:"jump_count" default:"3"`
	JumpWindow         jsontype.Duration `json:"jump_window" default:"5m"`
	AmplitudeThreshold float64           `json:"amplitude_threshold" default:"0.025"`
	AmplitudeWindow    jsontype.Duration `json:"amplitude_window" default:"1s"`
	Cooldown           jsontype.Duration `json:"cooldown" default:"15m"`
}

func (c *LagVolGuardConfig) IsEnabled() bool {
	if c.Enabled == nil {
		return true
	}
	return *c.Enabled
}

type DriftGuardConfig struct {
	Enabled         *bool             `json:"enabled"`
	DriftInstant    float64           `json:"drift_instant" default:"0.015"`
	RatioStd        float64           `json:"ratio_std" default:"0.008"`
	RatioStdWindow  jsontype.Duration `json:"ratio_std_window" default:"1m"`
	DriftMean       float64           `json:"drift_mean" default:"0.02"`
	DriftMeanWindow jsontype.Duration `json:"drift_mean_window" default:"1m"`
}

func (c *DriftGuardConfig) IsEnabled() bool {
	if c.Enabled == nil {
		return true
	}
	return *c.Enabled
}

type lagVolJumpEntry struct {
	tsMS     int64
	absRTick float64
}

type lagVolMidEntry struct {
	tsMS int64
	mid  float64
}

type lagVolGuardState struct {
	jumps           []lagVolJumpEntry
	mids            []lagVolMidEntry
	cooldownUntilMS int64
}

type driftGuardState struct {
	ratioStd  StreamRecorder
	ratioMean StreamRecorder
	ready     bool
}

func bboMid(bbo *utils.BBO) float64 {
	if bbo == nil || !bbo.ValidBBO {
		return 0
	}
	return (bbo.BestAskPrc + bbo.BestBidPrc) / 2
}

func lagLeadRatio(leadBBO, lagBBO *utils.BBO) (float64, bool) {
	if leadBBO == nil || lagBBO == nil || !leadBBO.ValidBBO || !lagBBO.ValidBBO {
		return 0, false
	}
	leadMid := bboMid(leadBBO)
	lagMid := bboMid(lagBBO)
	if leadMid <= 0 || lagMid <= 0 {
		return 0, false
	}
	return lagMid / leadMid, true
}

func trimLagVolJumps(entries []lagVolJumpEntry, nowMS, windowMS int64) []lagVolJumpEntry {
	if windowMS <= 0 {
		return entries[:0]
	}
	cutoff := nowMS - windowMS
	idx := 0
	for idx < len(entries) && entries[idx].tsMS < cutoff {
		idx++
	}
	if idx == 0 {
		return entries
	}
	trimmed := entries[idx:]
	if len(trimmed) == 0 {
		return entries[:0]
	}
	return trimmed
}

func trimLagVolMids(entries []lagVolMidEntry, nowMS, windowMS int64) []lagVolMidEntry {
	if windowMS <= 0 {
		return entries[:0]
	}
	cutoff := nowMS - windowMS
	idx := 0
	for idx < len(entries) && entries[idx].tsMS < cutoff {
		idx++
	}
	if idx == 0 {
		return entries
	}
	trimmed := entries[idx:]
	if len(trimmed) == 0 {
		return entries[:0]
	}
	return trimmed
}

func lagVolJumpCount(entries []lagVolJumpEntry, threshold float64) int {
	count := 0
	for _, entry := range entries {
		if entry.absRTick >= threshold {
			count++
		}
	}
	return count
}

func lagVolAmplitude(entries []lagVolMidEntry) float64 {
	if len(entries) == 0 {
		return 0
	}
	minMid := entries[0].mid
	maxMid := entries[0].mid
	for _, entry := range entries[1:] {
		if entry.mid < minMid {
			minMid = entry.mid
		}
		if entry.mid > maxMid {
			maxMid = entry.mid
		}
	}
	if minMid <= 0 {
		return 0
	}
	return maxMid/minMid - 1
}

func (s *Strategy) initLagVolGuard() {
	s.lagVolGuard.jumps = make([]lagVolJumpEntry, 0, 64)
	s.lagVolGuard.mids = make([]lagVolMidEntry, 0, 64)
	s.lagVolGuard.cooldownUntilMS = 0
}

func (s *Strategy) initDriftGuard() {
	cfg := s.config.Trigger.DriftGuard
	s.driftGuard.ratioStd.Init(cfg.RatioStdWindow.Duration(), 256)
	s.driftGuard.ratioMean.Init(cfg.DriftMeanWindow.Duration(), 256)
	s.driftGuard.ready = false
}

func (s *Strategy) updateLagVolGuard(bbo *utils.BBO) {
	if !s.config.Trigger.LagVolGuard.IsEnabled() || bbo == nil {
		return
	}
	prev := s.lagContext.prevBBO
	if !prev.ValidBBO || !bbo.ValidBBO {
		return
	}
	prevMid := bboMid(&prev)
	curMid := bboMid(bbo)
	if prevMid <= 0 || curMid <= 0 || prevMid == curMid {
		return
	}

	cfg := s.config.Trigger.LagVolGuard
	tMS := bbo.ServerTime
	amplitudeWindowMS := cfg.AmplitudeWindow.Duration().Milliseconds()
	s.lagVolGuard.mids = append(s.lagVolGuard.mids, lagVolMidEntry{tsMS: tMS, mid: curMid})
	s.lagVolGuard.mids = trimLagVolMids(s.lagVolGuard.mids, tMS, amplitudeWindowMS)

	rTick := curMid/prevMid - 1
	jumpWindowMS := cfg.JumpWindow.Duration().Milliseconds()
	s.lagVolGuard.jumps = append(s.lagVolGuard.jumps, lagVolJumpEntry{
		tsMS:     tMS,
		absRTick: math.Abs(rTick),
	})
	s.lagVolGuard.jumps = trimLagVolJumps(s.lagVolGuard.jumps, tMS, jumpWindowMS)
}

func (s *Strategy) updateDriftGuardRatio(now time.Time, leadBBO, lagBBO *utils.BBO) {
	if !s.config.Trigger.DriftGuard.IsEnabled() {
		return
	}
	ratio, ok := lagLeadRatio(leadBBO, lagBBO)
	if !ok {
		return
	}
	s.driftGuard.ratioStd.OnData(now, ratio)
	s.driftGuard.ratioMean.OnData(now, ratio)
	s.driftGuard.ready = true
}

func (s *Strategy) lagVolGuardHot(nowMS int64) (bool, int, float64) {
	cfg := s.config.Trigger.LagVolGuard
	jumpWindowMS := cfg.JumpWindow.Duration().Milliseconds()
	amplitudeWindowMS := cfg.AmplitudeWindow.Duration().Milliseconds()

	jumps := trimLagVolJumps(s.lagVolGuard.jumps, nowMS, jumpWindowMS)
	mids := trimLagVolMids(s.lagVolGuard.mids, nowMS, amplitudeWindowMS)
	jumpCount := lagVolJumpCount(jumps, cfg.JumpThreshold)
	amplitude := lagVolAmplitude(mids)

	g2 := jumpCount >= cfg.JumpCount
	g3 := amplitude > cfg.AmplitudeThreshold
	return g2 || g3, jumpCount, amplitude
}

type driftGuardEvaluation struct {
	ready            bool
	instantRatio     float64
	instantHit       bool
	ratioStdValue    float64
	ratioStdHit      bool
	driftMeanValue   float64
	driftMeanHit     bool
	blockReason      string
	blocked          bool
}

func (s *Strategy) evaluateDriftGuard(leadBBO, lagBBO *utils.BBO) driftGuardEvaluation {
	cfg := s.config.Trigger.DriftGuard
	eval := driftGuardEvaluation{
		ready: s.driftGuard.ready && leadBBO != nil && lagBBO != nil && leadBBO.ValidBBO && lagBBO.ValidBBO,
	}
	if !cfg.IsEnabled() || !eval.ready {
		return eval
	}

	if ratio, ok := lagLeadRatio(leadBBO, lagBBO); ok {
		eval.instantRatio = ratio
		if math.Abs(ratio-1) > cfg.DriftInstant {
			eval.instantHit = true
		}
	}

	eval.ratioStdValue = s.driftGuard.ratioStd.GetStd()
	if eval.ratioStdValue > cfg.RatioStd {
		eval.ratioStdHit = true
	}

	eval.driftMeanValue = s.driftGuard.ratioMean.GetMean()
	if math.Abs(eval.driftMeanValue-1) > cfg.DriftMean {
		eval.driftMeanHit = true
	}

	if eval.instantHit || eval.ratioStdHit || eval.driftMeanHit {
		eval.blocked = true
		eval.blockReason = "drift-guard"
	}
	return eval
}

func (s *Strategy) populateLagVolGuardSnapshot(guard *signalGuardSnapshot, nowMS int64) {
	cfg := s.config.Trigger.LagVolGuard
	guard.LagVolGuardEnabled = cfg.IsEnabled()
	if !cfg.IsEnabled() {
		guard.LagVolOutcome = "disabled"
		return
	}
	hot, jumpCount, amplitude := s.lagVolGuardHot(nowMS)
	guard.LagVolJumpCount = jumpCount
	guard.LagVolAmplitude = amplitude
	guard.LagVolHot = hot
	guard.LagVolCooldownUntilMS = s.lagVolGuard.cooldownUntilMS
	if nowMS < s.lagVolGuard.cooldownUntilMS {
		guard.LagVolOutcome = "blocked"
		return
	}
	if hot {
		guard.LagVolOutcome = "blocked"
		return
	}
	guard.LagVolOutcome = "allowed"
}

func (s *Strategy) populateDriftGuardSnapshot(guard *signalGuardSnapshot, leadBBO, lagBBO *utils.BBO) {
	cfg := s.config.Trigger.DriftGuard
	guard.DriftGuardEnabled = cfg.IsEnabled()
	guard.DriftGuardReady = s.driftGuard.ready && leadBBO != nil && lagBBO != nil && leadBBO.ValidBBO && lagBBO.ValidBBO
	guard.DriftInstantThreshold = cfg.DriftInstant
	guard.RatioStdThreshold = cfg.RatioStd
	guard.DriftMeanThreshold = cfg.DriftMean
	if !cfg.IsEnabled() {
		guard.DriftGuardOutcome = "disabled"
		return
	}
	eval := s.evaluateDriftGuard(leadBBO, lagBBO)
	guard.DriftInstantRatio = eval.instantRatio
	guard.DriftInstantHit = eval.instantHit
	guard.RatioStdValue = eval.ratioStdValue
	guard.RatioStdHit = eval.ratioStdHit
	guard.DriftMeanValue = eval.driftMeanValue
	guard.DriftMeanHit = eval.driftMeanHit
	if eval.blocked {
		guard.DriftGuardOutcome = "blocked"
		return
	}
	guard.DriftGuardOutcome = "allowed"
}
