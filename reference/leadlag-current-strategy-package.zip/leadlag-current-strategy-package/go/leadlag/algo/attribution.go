package algo

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"

	"git.hashingbot.com/aurthes/xex_mm_go/requests"
	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

const (
	AttributionSchemaVersion = "leadlag_attribution.v1"
	StableLinkageVersion     = "leadlag_stable_linkage.v1"
	DefaultStrategyVariant   = "fixed"

	AttributionEventTrigger                     = "trigger"
	AttributionEventFilter                      = "filter"
	AttributionEventOrderCreate                 = "order_create"
	AttributionEventOrderLifecycle              = "order_lifecycle"
	AttributionEventCloseDecision               = "close_decision"
	AttributionEventEntryOpportunity            = "entry_opportunity"
	AttributionEventEntryGuardFeatureDiagnostic = "entry_guard_feature_diagnostic"
	AttributionEventSignalDecision              = "signal_decision"

	AttributionReasonTrigger       = "trigger"
	AttributionReasonFiltered      = "filtered"
	AttributionReasonNoTrigger     = "no-trigger"
	AttributionReasonCloseDecision = "close-decision"
	AttributionReasonNotApplicable = "not-applicable"

	AttributionDecisionOutcomeAllowed = "allowed"

	AttributionFilterNoFilter                       = "no-filter"
	AttributionFilterCloseabilityEntryGuardNotional = "closeability-entry-guard-notional"

	StableLinkageStatusAvailable                      = "available"
	StableLinkageStatusUnavailableMissingEntryLinkage = "unavailable_missing_entry_linkage"

	AttributionLifecycleNotApplicable          = "not-applicable"
	AttributionLifecycleOrderCreate            = "order-create"
	AttributionLifecyclePartialFill            = "partial-fill"
	AttributionLifecycleFullFill               = "full-fill"
	AttributionLifecycleZeroFillCanceled       = "zero-fill-canceled"
	AttributionLifecycleZeroFillExpired        = "zero-fill-expired"
	AttributionLifecycleCancelOrExpireWithFill = "cancel-or-expire-with-fill"
	AttributionLifecycleRejected               = "rejected"
	AttributionLifecyclePending                = "pending"
	AttributionLifecycleNew                    = "new"
	AttributionLifecycleUnknown                = "unknown"

	AttributionOutputModeBounded = "bounded"
	AttributionOutputModeFull    = "full"
	AttributionOutputModeOff     = "off"

	AttributionOutputFilterModeChanges = "changes"
	AttributionOutputFilterModeSampled = "sampled"
	AttributionOutputFilterModeFull    = "full"
	AttributionOutputFilterModeOff     = "off"

	AttributionOutputNoTriggerModeSampled = "sampled"
	AttributionOutputNoTriggerModeFull    = "full"
	AttributionOutputNoTriggerModeOff     = "off"

	EntryOpportunityKeyVersion = "entry_opportunity_key.v1"
	entryOpportunityKeyScale   = 1e9
)

type AnalysisConfig struct {
	AttributionLog    bool                    `json:"attribution_log" default:"false"`
	Variant           string                  `json:"variant"`
	AttributionOutput AttributionOutputConfig `json:"attribution_output"`
}

type AttributionOutputConfig struct {
	Mode                      string   `json:"mode"`
	AlwaysEvents              []string `json:"always_events"`
	FilterMode                string   `json:"filter_mode"`
	NoTriggerMode             string   `json:"no_trigger_mode"`
	SampleIntervalMs          int64    `json:"sample_interval_ms"`
	ReasonChangeMinIntervalMs int64    `json:"reason_change_min_interval_ms"`
}

type attributionEmissionState struct {
	LastSignature string
	LastEmittedMs int64
}

type AttributionStableLinkage struct {
	StableLinkageVersion    string
	StableLinkageStatus     string
	EntrySignalID           string
	EntrySignalHash         string
	EntryOpportunityID      string
	EntryOpportunityKey     string
	EntryAttemptID          string
	AttemptSeq              int64
	EntryDecisionSeq        int64
	DecisionID              string
	OrderGroupStableID      string
	OrderIntentID           string
	OrderSeq                int64
	CloseAttemptID          string
	CloseSeq                int64
	DecisionOutcome         string
	FeatureSnapshotID       string
	FeatureAvailabilityMask string
}

type stableEntryHashInput struct {
	SchemaVersion    string  `json:"schema_version"`
	StableVersion    string  `json:"stable_linkage_version"`
	Symbol           string  `json:"symbol"`
	Lead             string  `json:"lead"`
	Lag              string  `json:"lag"`
	TimestampMs      int64   `json:"timestamp_ms"`
	Position         string  `json:"position"`
	Side             int     `json:"side"`
	EntryDecisionSeq int64   `json:"entry_decision_seq"`
	SignalValue      float64 `json:"signal_value"`
	Threshold        float64 `json:"threshold"`
}

type stableEntryOpportunityHashInput struct {
	SchemaVersion string  `json:"schema_version"`
	StableVersion string  `json:"stable_linkage_version"`
	Symbol        string  `json:"symbol"`
	Lead          string  `json:"lead"`
	Lag           string  `json:"lag"`
	TimestampMs   int64   `json:"timestamp_ms"`
	Position      string  `json:"position"`
	Side          int     `json:"side"`
	SignalValue   float64 `json:"signal_value"`
	Threshold     float64 `json:"threshold"`
	Price         float64 `json:"price"`
	Qty           float64 `json:"qty"`
}

type stableEntryOpportunityKeyHashInput struct {
	SchemaVersion        string `json:"schema_version"`
	KeyVersion           string `json:"entry_opportunity_key_version"`
	StableVersion        string `json:"stable_linkage_version"`
	Symbol               string `json:"symbol"`
	Lead                 string `json:"lead"`
	Lag                  string `json:"lag"`
	TimestampMs          int64  `json:"timestamp_ms"`
	Position             string `json:"position"`
	Side                 int    `json:"side"`
	SignalValueRoundedE9 int64  `json:"signal_value_rounded_e9"`
	ThresholdRoundedE9   int64  `json:"threshold_rounded_e9"`
}

func (c *AnalysisConfig) SetDefault() {
	if c.AttributionOutput.Mode == "" {
		c.AttributionOutput.Mode = AttributionOutputModeBounded
	}
	if len(c.AttributionOutput.AlwaysEvents) == 0 {
		c.AttributionOutput.AlwaysEvents = []string{
			AttributionEventTrigger,
			AttributionEventOrderCreate,
			AttributionEventOrderLifecycle,
			AttributionEventCloseDecision,
			AttributionEventEntryOpportunity,
		}
	}
	if c.AttributionOutput.FilterMode == "" {
		c.AttributionOutput.FilterMode = AttributionOutputFilterModeChanges
	}
	if c.AttributionOutput.NoTriggerMode == "" {
		c.AttributionOutput.NoTriggerMode = AttributionOutputNoTriggerModeSampled
	}
	if c.AttributionOutput.SampleIntervalMs <= 0 {
		c.AttributionOutput.SampleIntervalMs = 60_000
	}
	if c.AttributionOutput.ReasonChangeMinIntervalMs <= 0 {
		c.AttributionOutput.ReasonChangeMinIntervalMs = 10_000
	}
}

type AttributionInput struct {
	Event                string
	Position             string
	CID                  string
	GroupID              string
	OrderID              string
	Side                 int
	Qty                  float64
	Price                float64
	SignalValue          float64
	Threshold            float64
	Cost                 float64
	Liquidity            float64
	DecisionReason       string
	OrderLifecycleReason string
	FilterName           string
	FilterReason         string
	StatusCode           int
	FilledQty            float64
	StableLinkage        AttributionStableLinkage
	ExtraFields          map[string]interface{}
}

func (s *Strategy) attributionEnabled() bool {
	return s != nil && s.config.Analysis.AttributionLog && s.recorder != nil
}

func (s *Strategy) shouldRecordAttribution(input AttributionInput) bool {
	if !s.attributionEnabled() {
		return false
	}
	policy := s.config.Analysis.AttributionOutput
	if input.Event == AttributionEventSignalDecision {
		return policy.Mode == AttributionOutputModeFull
	}
	switch policy.Mode {
	case AttributionOutputModeOff:
		return false
	case AttributionOutputModeFull:
		return true
	}
	for _, event := range policy.AlwaysEvents {
		if input.Event == event {
			return true
		}
	}
	if input.Event != AttributionEventFilter {
		return true
	}
	reason := input.FilterReason
	if reason == "" || reason == AttributionReasonNotApplicable {
		reason = input.DecisionReason
	}
	if reason == AttributionReasonNoTrigger || input.DecisionReason == AttributionReasonNoTrigger {
		return s.shouldEmitSampledAttribution(input, policy.NoTriggerMode, policy.SampleIntervalMs)
	}
	return s.shouldEmitReasonChangeAttribution(input, policy.FilterMode, policy.ReasonChangeMinIntervalMs)
}

func (s *Strategy) shouldEmitSampledAttribution(input AttributionInput, mode string, intervalMs int64) bool {
	switch mode {
	case AttributionOutputNoTriggerModeOff:
		return false
	case AttributionOutputNoTriggerModeFull:
		return true
	}
	if s.attributionEmission == nil {
		s.attributionEmission = map[string]attributionEmissionState{}
	}
	key := s.attributionStateKey("sample", input)
	nowMs := s.Context.Now().UnixMilli()
	state := s.attributionEmission[key]
	if state.LastEmittedMs == 0 || nowMs-state.LastEmittedMs >= intervalMs {
		state.LastEmittedMs = nowMs
		s.attributionEmission[key] = state
		return true
	}
	return false
}

func (s *Strategy) shouldEmitReasonChangeAttribution(input AttributionInput, mode string, minIntervalMs int64) bool {
	switch mode {
	case AttributionOutputFilterModeOff:
		return false
	case AttributionOutputFilterModeFull:
		return true
	case AttributionOutputFilterModeSampled:
		return s.shouldEmitSampledAttribution(input, AttributionOutputNoTriggerModeSampled, s.config.Analysis.AttributionOutput.SampleIntervalMs)
	}
	if s.attributionEmission == nil {
		s.attributionEmission = map[string]attributionEmissionState{}
	}
	key := s.attributionStateKey("change", input)
	signature := fmt.Sprintf("%s|%s|%s|%s", input.DecisionReason, input.FilterName, input.FilterReason, input.Position)
	nowMs := s.Context.Now().UnixMilli()
	state := s.attributionEmission[key]
	if state.LastSignature != signature || state.LastEmittedMs == 0 || nowMs-state.LastEmittedMs >= minIntervalMs {
		state.LastSignature = signature
		state.LastEmittedMs = nowMs
		s.attributionEmission[key] = state
		return true
	}
	return false
}

func (s *Strategy) attributionStateKey(kind string, input AttributionInput) string {
	return fmt.Sprintf("%s|%s|%s|%d|%s", kind, input.Event, input.FilterName, input.Side, input.Position)
}

func (s *Strategy) newEntryStableLinkage(position string, side int, signalValue float64, threshold float64, decisionOutcome string) AttributionStableLinkage {
	if position == "" {
		position = "open"
	}
	if decisionOutcome == "" {
		decisionOutcome = AttributionReasonNotApplicable
	}
	nowMs := s.Context.Now().UnixMilli()
	s.attributionDecisionSeq++
	entryDecisionSeq := s.attributionDecisionSeq
	attemptSeq := int64(1)
	entrySignalID := fmt.Sprintf("esi_v1:%s:%s:%s:%d:%s:%d:%d", s.config.Symbol, s.config.Lead, s.config.Lag, nowMs, position, side, entryDecisionSeq)
	hashInput := stableEntryHashInput{
		SchemaVersion:    AttributionSchemaVersion,
		StableVersion:    StableLinkageVersion,
		Symbol:           s.config.Symbol,
		Lead:             s.config.Lead,
		Lag:              s.config.Lag,
		TimestampMs:      nowMs,
		Position:         position,
		Side:             side,
		EntryDecisionSeq: entryDecisionSeq,
		SignalValue:      signalValue,
		Threshold:        threshold,
	}
	hashBytes, _ := json.Marshal(hashInput)
	sum := sha256.Sum256(hashBytes)
	entrySignalHash := hex.EncodeToString(sum[:])
	entryAttemptID := fmt.Sprintf("eat_v1:%s:%d", entrySignalID, attemptSeq)
	decisionID := fmt.Sprintf("dec_v1:%s:%d", entryAttemptID, entryDecisionSeq)
	return AttributionStableLinkage{
		StableLinkageVersion: StableLinkageVersion,
		StableLinkageStatus:  StableLinkageStatusAvailable,
		EntrySignalID:        entrySignalID,
		EntrySignalHash:      entrySignalHash,
		EntryOpportunityKey:  s.newEntryOpportunityKeyAt(nowMs, position, side, signalValue, threshold),
		EntryAttemptID:       entryAttemptID,
		AttemptSeq:           attemptSeq,
		EntryDecisionSeq:     entryDecisionSeq,
		DecisionID:           decisionID,
		DecisionOutcome:      decisionOutcome,
		FeatureSnapshotID:    fmt.Sprintf("fss_v1:%s", decisionID),
	}
}

func (s *Strategy) newEntryOpportunityID(position string, side int, signalValue float64, threshold float64, price float64, qty float64) string {
	if position == "" {
		position = "open"
	}
	// Deterministic for the same strategy identity, timestamp, position, side,
	// signal, threshold, price, and quantity. Once attached to an ExecuteCache,
	// later attribution rows reuse the cached id instead of recomputing it.
	hashInput := stableEntryOpportunityHashInput{
		SchemaVersion: AttributionSchemaVersion,
		StableVersion: StableLinkageVersion,
		Symbol:        s.config.Symbol,
		Lead:          s.config.Lead,
		Lag:           s.config.Lag,
		TimestampMs:   s.Context.Now().UnixMilli(),
		Position:      position,
		Side:          side,
		SignalValue:   signalValue,
		Threshold:     threshold,
		Price:         price,
		Qty:           qty,
	}
	hashBytes, _ := json.Marshal(hashInput)
	sum := sha256.Sum256(hashBytes)
	return fmt.Sprintf("eop_v1:%s", hex.EncodeToString(sum[:]))
}

func (s *Strategy) newEntryOpportunityKey(position string, side int, signalValue float64, threshold float64) string {
	return s.newEntryOpportunityKeyAt(s.Context.Now().UnixMilli(), position, side, signalValue, threshold)
}

func (s *Strategy) newEntryOpportunityKeyAt(timestampMs int64, position string, side int, signalValue float64, threshold float64) string {
	if position == "" {
		position = "open"
	}
	hashInput := stableEntryOpportunityKeyHashInput{
		SchemaVersion:        AttributionSchemaVersion,
		KeyVersion:           EntryOpportunityKeyVersion,
		StableVersion:        StableLinkageVersion,
		Symbol:               s.config.Symbol,
		Lead:                 s.config.Lead,
		Lag:                  s.config.Lag,
		TimestampMs:          timestampMs,
		Position:             position,
		Side:                 side,
		SignalValueRoundedE9: roundEntryOpportunityKeyValue(signalValue),
		ThresholdRoundedE9:   roundEntryOpportunityKeyValue(threshold),
	}
	hashBytes, _ := json.Marshal(hashInput)
	sum := sha256.Sum256(hashBytes)
	return fmt.Sprintf("eok_v1:%s", hex.EncodeToString(sum[:]))
}

func roundEntryOpportunityKeyValue(value float64) int64 {
	return int64(math.Round(value * entryOpportunityKeyScale))
}

func (s *Strategy) ensureAttributionStableLinkage(input *AttributionInput) {
	if input.StableLinkage.StableLinkageVersion == "" {
		input.StableLinkage.StableLinkageVersion = StableLinkageVersion
	}
	if input.StableLinkage.FeatureAvailabilityMask == "" {
		input.StableLinkage.FeatureAvailabilityMask = AttributionReasonNotApplicable
	}
	if input.StableLinkage.DecisionOutcome == "" {
		input.StableLinkage.DecisionOutcome = input.DecisionReason
	}
	if input.StableLinkage.EntrySignalID != "" {
		return
	}
	switch input.Event {
	case AttributionEventFilter, AttributionEventTrigger, AttributionEventEntryOpportunity, AttributionEventEntryGuardFeatureDiagnostic, AttributionEventSignalDecision:
		linkage := s.newEntryStableLinkage(input.Position, input.Side, input.SignalValue, input.Threshold, input.StableLinkage.DecisionOutcome)
		linkage.EntryOpportunityID = input.StableLinkage.EntryOpportunityID
		if input.StableLinkage.EntryOpportunityKey != "" {
			linkage.EntryOpportunityKey = input.StableLinkage.EntryOpportunityKey
		}
		linkage.FeatureAvailabilityMask = input.StableLinkage.FeatureAvailabilityMask
		input.StableLinkage = linkage
	}
	if input.StableLinkage.StableLinkageStatus == "" {
		if input.StableLinkage.EntrySignalID == "" {
			input.StableLinkage.StableLinkageStatus = StableLinkageStatusUnavailableMissingEntryLinkage
		} else {
			input.StableLinkage.StableLinkageStatus = StableLinkageStatusAvailable
		}
	}
}

func (s *Strategy) fullSignalDecisionLogEnabled() bool {
	return s.attributionEnabled() && s.config.Analysis.AttributionOutput.Mode == AttributionOutputModeFull
}

func (s *Strategy) ensureCacheEntryStableLinkage(cache *ExecuteCache, position string, side int, signalValue float64, threshold float64, decisionOutcome string) AttributionStableLinkage {
	if cache == nil {
		return s.newEntryStableLinkage(position, side, signalValue, threshold, decisionOutcome)
	}
	if cache.stableLinkage.EntryAttemptID == "" {
		cache.stableLinkage = s.newEntryStableLinkage(position, side, signalValue, threshold, decisionOutcome)
		cache.stableLinkage.OrderGroupStableID = fmt.Sprintf("ogs_v1:%s", cache.stableLinkage.EntryAttemptID)
	}
	if cache.stableLinkage.StableLinkageVersion == "" {
		cache.stableLinkage.StableLinkageVersion = StableLinkageVersion
	}
	if cache.stableLinkage.EntryOpportunityKey == "" {
		cache.stableLinkage.EntryOpportunityKey = s.newEntryOpportunityKey(position, side, signalValue, threshold)
	}
	return cache.stableLinkage
}

func (cache *ExecuteCache) nextOrderIntentStableLinkage(position string) AttributionStableLinkage {
	if cache == nil {
		return AttributionStableLinkage{StableLinkageVersion: StableLinkageVersion, StableLinkageStatus: StableLinkageStatusUnavailableMissingEntryLinkage}
	}
	cache.orderSeq++
	cache.currentOrderIntentID = fmt.Sprintf("oit_v1:%s:%s:%d", cache.stableLinkage.OrderGroupStableID, position, cache.orderSeq)
	linkage := cache.stableLinkage
	linkage.OrderIntentID = cache.currentOrderIntentID
	linkage.OrderSeq = cache.orderSeq
	linkage.CloseAttemptID = cache.currentCloseAttemptID
	linkage.CloseSeq = cache.closeSeq
	return linkage
}

func (cache *ExecuteCache) currentOrderLifecycleStableLinkage() AttributionStableLinkage {
	if cache == nil {
		return AttributionStableLinkage{StableLinkageVersion: StableLinkageVersion, StableLinkageStatus: StableLinkageStatusUnavailableMissingEntryLinkage}
	}
	if cache.stableLinkage.EntryAttemptID == "" {
		return AttributionStableLinkage{StableLinkageVersion: StableLinkageVersion, StableLinkageStatus: StableLinkageStatusUnavailableMissingEntryLinkage}
	}
	linkage := cache.stableLinkage
	linkage.OrderIntentID = cache.currentOrderIntentID
	linkage.OrderSeq = cache.orderSeq
	linkage.CloseAttemptID = cache.currentCloseAttemptID
	linkage.CloseSeq = cache.closeSeq
	return linkage
}

func (cache *ExecuteCache) currentCloseAttemptStableLinkage() AttributionStableLinkage {
	if cache == nil {
		return AttributionStableLinkage{StableLinkageVersion: StableLinkageVersion, StableLinkageStatus: StableLinkageStatusUnavailableMissingEntryLinkage}
	}
	if cache.stableLinkage.EntryAttemptID == "" || cache.currentCloseAttemptID == "" {
		return AttributionStableLinkage{StableLinkageVersion: StableLinkageVersion, StableLinkageStatus: StableLinkageStatusUnavailableMissingEntryLinkage}
	}
	linkage := cache.stableLinkage
	linkage.CloseAttemptID = cache.currentCloseAttemptID
	linkage.CloseSeq = cache.closeSeq
	linkage.DecisionID = fmt.Sprintf("dec_v1:%s:%d", cache.currentCloseAttemptID, cache.closeSeq)
	return linkage
}

func (cache *ExecuteCache) nextCloseAttemptStableLinkage() AttributionStableLinkage {
	if cache == nil {
		return AttributionStableLinkage{StableLinkageVersion: StableLinkageVersion, StableLinkageStatus: StableLinkageStatusUnavailableMissingEntryLinkage}
	}
	cache.closeSeq++
	cache.currentCloseAttemptID = fmt.Sprintf("cat_v1:%s:%d", cache.stableLinkage.OrderGroupStableID, cache.closeSeq)
	linkage := cache.stableLinkage
	linkage.CloseAttemptID = cache.currentCloseAttemptID
	linkage.CloseSeq = cache.closeSeq
	linkage.DecisionID = fmt.Sprintf("dec_v1:%s:%d", cache.currentCloseAttemptID, cache.closeSeq)
	linkage.DecisionOutcome = AttributionReasonCloseDecision
	return linkage
}

func (s *Strategy) RecordAttribution(input AttributionInput) {
	variant := s.config.Analysis.Variant
	if variant == "" {
		variant = DefaultStrategyVariant
	}
	if input.DecisionReason == "" {
		input.DecisionReason = AttributionReasonNotApplicable
	}
	if input.OrderLifecycleReason == "" {
		input.OrderLifecycleReason = AttributionLifecycleNotApplicable
	}
	if input.FilterName == "" {
		input.FilterName = AttributionFilterNoFilter
	}
	if input.FilterReason == "" {
		input.FilterReason = AttributionReasonNotApplicable
	}
	if !s.shouldRecordAttribution(input) {
		return
	}
	s.ensureAttributionStableLinkage(&input)
	now := s.Context.Now()
	fields := map[string]interface{}{
		"schema_version":            AttributionSchemaVersion,
		"stable_linkage_version":    input.StableLinkage.StableLinkageVersion,
		"stable_linkage_status":     input.StableLinkage.StableLinkageStatus,
		"strategy_variant":          variant,
		"event":                     input.Event,
		"symbol":                    s.config.Symbol,
		"lead":                      s.config.Lead,
		"lag":                       s.config.Lag,
		"timestamp_ms":              now.UnixMilli(),
		"date_hour":                 now.Format("2006010215"),
		"cid":                       input.CID,
		"group_id":                  input.GroupID,
		"order_id":                  input.OrderID,
		"entry_signal_id":           input.StableLinkage.EntrySignalID,
		"entry_signal_hash":         input.StableLinkage.EntrySignalHash,
		"entry_opportunity_id":      input.StableLinkage.EntryOpportunityID,
		"entry_opportunity_key":     input.StableLinkage.EntryOpportunityKey,
		"entry_attempt_id":          input.StableLinkage.EntryAttemptID,
		"attempt_seq":               input.StableLinkage.AttemptSeq,
		"entry_decision_seq":        input.StableLinkage.EntryDecisionSeq,
		"decision_id":               input.StableLinkage.DecisionID,
		"decision_outcome":          input.StableLinkage.DecisionOutcome,
		"order_group_stable_id":     input.StableLinkage.OrderGroupStableID,
		"order_intent_id":           input.StableLinkage.OrderIntentID,
		"order_seq":                 input.StableLinkage.OrderSeq,
		"close_attempt_id":          input.StableLinkage.CloseAttemptID,
		"close_seq":                 input.StableLinkage.CloseSeq,
		"feature_snapshot_id":       input.StableLinkage.FeatureSnapshotID,
		"feature_availability_mask": input.StableLinkage.FeatureAvailabilityMask,
		"side":                      input.Side,
		"qty":                       input.Qty,
		"price":                     input.Price,
		"signal_value":              input.SignalValue,
		"threshold":                 input.Threshold,
		"cost":                      input.Cost,
		"liquidity":                 input.Liquidity,
		"decision_reason":           input.DecisionReason,
		"order_lifecycle_reason":    input.OrderLifecycleReason,
		"filter_name":               input.FilterName,
		"filter_reason":             input.FilterReason,
		"status_code":               input.StatusCode,
		"filled_qty":                input.FilledQty,
		"position":                  input.Position,
	}
	for key, value := range input.ExtraFields {
		if key == "entry_opportunity_id" || key == "entry_opportunity_key" {
			continue
		}
		fields[key] = value
	}
	s.recorder.Record(&recorder.RawRecord{
		Tag: map[string]string{
			"type":                   "attribution",
			"schema_version":         AttributionSchemaVersion,
			"stable_linkage_version": StableLinkageVersion,
			"event":                  input.Event,
			"variant":                variant,
		},
		Field: fields,
		Extra: map[string]interface{}{
			"time": now,
		},
	})
}

func ClassifyOrderLifecycle(status int, filledQty float64, orderQty float64) string {
	switch status {
	case 10:
		return AttributionLifecycleNew
	case 20:
		if filledQty > 0 {
			return AttributionLifecyclePartialFill
		}
		return AttributionLifecyclePending
	case 30:
		return AttributionLifecyclePending
	case 40:
		return AttributionLifecycleFullFill
	case 41:
		if filledQty > 0 {
			return AttributionLifecycleCancelOrExpireWithFill
		}
		return AttributionLifecycleZeroFillCanceled
	case 42:
		return AttributionLifecycleRejected
	case 45:
		if filledQty > 0 {
			return AttributionLifecycleCancelOrExpireWithFill
		}
		return AttributionLifecycleZeroFillExpired
	default:
		return AttributionLifecycleUnknown
	}
}

func (s *Strategy) RecordFilterAttribution(reason string, signalValue float64, threshold float64, cost float64, filterName string) {
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventFilter,
		Position:             "open",
		SignalValue:          signalValue,
		Threshold:            threshold,
		Cost:                 cost,
		DecisionReason:       reason,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           filterName,
		FilterReason:         reason,
		StableLinkage: AttributionStableLinkage{
			DecisionOutcome:         reason,
			FeatureAvailabilityMask: "signal=1,threshold=1",
		},
	})
}

type EntryOpportunityAttributionInput struct {
	Cache                      *ExecuteCache
	Side                       int
	SignalValue                float64
	Threshold                  float64
	Price                      float64
	Qty                        float64
	TargetSpace                float64
	RequiredEdge               float64
	LeadMove                   float64
	LagMove                    float64
	EntrySpread                float64
	EntrySpreadLimit           float64
	ReverseCloseSide           int
	ReverseCloseNotional       float64
	ReverseCloseDepth          float64
	ReverseCloseSlack          float64
	ReverseCloseSpread         float64
	ParallelUsed               int
	ParallelLimit              int
	PendingOpenOrders          int
	PendingCloseOrders         int
	CloseabilityBBOAvailable   bool
	CloseabilityDepthAvailable bool
	PendingStateAvailable      bool
	CooldownStateAvailable     bool
	PositionStateAvailable     bool
	CooldownActive             bool
	PositionState              string
	StateAvailability          string
	StableLinkage              AttributionStableLinkage
}

func (s *Strategy) RecordEntryOpportunityAttribution(input EntryOpportunityAttributionInput) {
	preflight := AttributionInput{
		Event:                AttributionEventEntryOpportunity,
		Position:             "open",
		Side:                 input.Side,
		DecisionReason:       AttributionDecisionOutcomeAllowed,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           AttributionFilterCloseabilityEntryGuardNotional,
		FilterReason:         AttributionReasonNotApplicable,
	}
	if !s.shouldRecordAttribution(preflight) {
		return
	}
	if input.PositionState == "" {
		input.PositionState = "none"
	}
	if input.StateAvailability == "" {
		input.StateAvailability = "closeability_bbo=0,closeability_depth=0,pending=1,cooldown=0"
	}
	reverseSide := input.ReverseCloseSide
	if reverseSide == 0 {
		reverseSide = reverseCloseSide(input.Side)
	}
	linkage := input.StableLinkage
	if input.Cache != nil {
		linkage = s.ensureCacheEntryStableLinkage(input.Cache, "open", input.Side, input.SignalValue, input.Threshold, AttributionDecisionOutcomeAllowed)
	}
	if linkage.EntryOpportunityID == "" {
		linkage.EntryOpportunityID = s.newEntryOpportunityID("open", input.Side, input.SignalValue, input.Threshold, input.Price, input.Qty)
	}
	if linkage.EntryOpportunityKey == "" {
		linkage.EntryOpportunityKey = s.newEntryOpportunityKey("open", input.Side, input.SignalValue, input.Threshold)
	}
	if input.Cache != nil {
		input.Cache.stableLinkage.EntryOpportunityID = linkage.EntryOpportunityID
		input.Cache.stableLinkage.EntryOpportunityKey = linkage.EntryOpportunityKey
	}
	linkage.DecisionOutcome = AttributionDecisionOutcomeAllowed
	linkage.FeatureAvailabilityMask = input.StateAvailability
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventEntryOpportunity,
		Position:             "open",
		Side:                 input.Side,
		Qty:                  input.Qty,
		Price:                input.Price,
		SignalValue:          input.SignalValue,
		Threshold:            input.Threshold,
		Cost:                 input.RequiredEdge,
		Liquidity:            input.ReverseCloseDepth,
		DecisionReason:       AttributionDecisionOutcomeAllowed,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           AttributionFilterCloseabilityEntryGuardNotional,
		FilterReason:         AttributionReasonNotApplicable,
		StableLinkage:        linkage,
		ExtraFields: map[string]interface{}{
			"opportunity_name":             AttributionFilterCloseabilityEntryGuardNotional,
			"target_space":                 input.TargetSpace,
			"required_edge":                input.RequiredEdge,
			"lead_move":                    input.LeadMove,
			"lag_move":                     input.LagMove,
			"entry_spread":                 input.EntrySpread,
			"entry_spread_limit":           input.EntrySpreadLimit,
			"reverse_close_side":           reverseSide,
			"reverse_close_notional":       input.ReverseCloseNotional,
			"reverse_close_depth":          input.ReverseCloseDepth,
			"reverse_close_slack":          input.ReverseCloseSlack,
			"reverse_close_spread":         input.ReverseCloseSpread,
			"parallel_used":                input.ParallelUsed,
			"parallel_limit":               input.ParallelLimit,
			"pending_open_orders":          input.PendingOpenOrders,
			"pending_close_orders":         input.PendingCloseOrders,
			"closeability_bbo_available":   input.CloseabilityBBOAvailable,
			"closeability_depth_available": input.CloseabilityDepthAvailable,
			"pending_state_available":      input.PendingStateAvailable,
			"cooldown_state_available":     input.CooldownStateAvailable,
			"position_state_available":     input.PositionStateAvailable,
			"cooldown_active":              input.CooldownActive,
			"position_state":               input.PositionState,
			"state_availability":           input.StateAvailability,
			"guard_outcome_available":      false,
		},
	})
}

func (s *Strategy) RecordOrderCreateAttribution(cache *ExecuteCache, param *template.OrderParam, position string, signalValue float64, threshold float64, cost float64, liquidity float64) {
	if param == nil || cache == nil {
		return
	}
	input := AttributionInput{
		Event:                AttributionEventOrderCreate,
		Position:             position,
		CID:                  param.CID,
		GroupID:              cache.groupTag,
		Side:                 param.Side,
		Qty:                  param.Qty,
		Price:                param.Price,
		SignalValue:          signalValue,
		Threshold:            threshold,
		Cost:                 cost,
		Liquidity:            liquidity,
		DecisionReason:       AttributionReasonTrigger,
		OrderLifecycleReason: AttributionLifecycleOrderCreate,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
	}
	if !s.shouldRecordAttribution(input) {
		return
	}
	if cache.stableLinkage.EntryAttemptID == "" {
		if position == "close" {
			input.StableLinkage = AttributionStableLinkage{
				StableLinkageVersion:    StableLinkageVersion,
				StableLinkageStatus:     StableLinkageStatusUnavailableMissingEntryLinkage,
				DecisionOutcome:         AttributionReasonCloseDecision,
				FeatureAvailabilityMask: "signal=1,threshold=1",
			}
			s.RecordAttribution(input)
			return
		}
		cache.stableLinkage = s.ensureCacheEntryStableLinkage(cache, position, param.Side, signalValue, threshold, AttributionDecisionOutcomeAllowed)
	}
	linkage := cache.nextOrderIntentStableLinkage(position)
	linkage.DecisionOutcome = AttributionDecisionOutcomeAllowed
	linkage.FeatureAvailabilityMask = "signal=1,threshold=1"
	input.StableLinkage = linkage
	s.RecordAttribution(input)
}

func (s *Strategy) RecordOrderLifecycleAttribution(cache *ExecuteCache, order requests.Order, msg *utils.OrderMessage) {
	if cache == nil || order == nil || msg == nil {
		return
	}
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventOrderLifecycle,
		CID:                  msg.ClientID,
		GroupID:              cache.groupTag,
		OrderID:              msg.OrderID,
		Side:                 msg.Side,
		Qty:                  msg.Qty,
		Price:                msg.AvgFillPrc,
		SignalValue:          0,
		Threshold:            0,
		Cost:                 0,
		DecisionReason:       AttributionReasonNotApplicable,
		OrderLifecycleReason: ClassifyOrderLifecycle(msg.Status, msg.FilledQty, msg.Qty),
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
		StatusCode:           msg.Status,
		FilledQty:            msg.FilledQty,
		Position:             cache.stage.String(),
		StableLinkage:        cache.currentOrderLifecycleStableLinkage(),
		ExtraFields: map[string]interface{}{
			"avg_fill_price":    msg.AvgFillPrc,
			"raw_price":         cache.pendingOrderRawPrice,
			"limit_price":       pendingOrderLimitPrice(cache, msg),
			"order_price":       order.GetPrice(),
			"order_server_time": msg.ServerTime,
			"order_local_time":  msg.LocalTime,
		},
	})
}

func pendingOrderLimitPrice(cache *ExecuteCache, msg *utils.OrderMessage) float64 {
	if cache != nil && cache.pendingOrderLimitPrice != 0 {
		return cache.pendingOrderLimitPrice
	}
	if msg == nil {
		return 0
	}
	return msg.Price
}

func (s *Strategy) RecordEntryGuardFeatureDiagnostic(signalValue float64, threshold float64, cost float64, featureAvailabilityMask string) {
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventEntryGuardFeatureDiagnostic,
		Position:             "open",
		SignalValue:          signalValue,
		Threshold:            threshold,
		Cost:                 cost,
		DecisionReason:       AttributionReasonNotApplicable,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
		StableLinkage: AttributionStableLinkage{
			DecisionOutcome:         AttributionReasonNotApplicable,
			FeatureAvailabilityMask: featureAvailabilityMask,
		},
	})
}
