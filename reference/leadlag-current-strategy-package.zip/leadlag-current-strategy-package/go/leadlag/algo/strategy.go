package algo

import (
	"fmt"
	"math"
	"strings"
	"time"

	"git.hashingbot.com/aurthes/xex_mm_go/atom_symbol"
	"git.hashingbot.com/aurthes/xex_mm_go/requests"
	"git.hashingbot.com/aurthes/xex_mm_go/utils"
	"github.com/shopspring/decimal"
	"github.com/sirupsen/logrus"
	"gitlab.com/hashingbotrepo/backend/pinnaquant/template"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/defaults"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/idgen"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/jsontype"
	"gitlab.com/hashingbotrepo/strategy/invariant-strategy/utils/recorder"
)

var takerFees = map[string]float64{
	"gateio": 1.6 * 1e-4,
	"bybit":  1.5 * 1e-4,
}

type BBORecord struct {
	StatsWindow jsontype.Duration `json:"stats_window" default:"5s"`
	Window      jsontype.Duration `json:"window" default:"5s"`
	Size        int               `json:"size" default:"100"`
}

type TriggerConfig struct {
	Lead  float64 `json:"lead"`
	Open  float64 `json:"open"`
	Close float64 `json:"close"`

	LagPart  float64 `json:"lag_part" default:"0.5"` // require [lag move space]:(lead move - lag move) / (lead move) > LagPart
	LeadPart float64 `json:"lead_part" default:"1"`  // require: lead / price diff > LeadPart

	Quantile struct {
		Move float64 `json:"move" default:"0.99"`
	} `json:"quantile"`

	TargetProfitRate float64 `json:"target_profit_rate" default:"0"`

	LagVolGuard LagVolGuardConfig `json:"lag_vol_guard"`
	DriftGuard  DriftGuardConfig  `json:"drift_guard"`

	DriftPeriod     jsontype.Duration `json:"drift_period" default:"1h"`
	DriftMinSamples int               `json:"drift_min_samples" default:"20"`
	DriftWarmup     jsontype.Duration `json:"drift_warmup"`
}

type ExecutionConfig struct {
	OpenNotional               decimal.Decimal `json:"open" default:"1000"`
	TrailingStop               float64         `json:"trailing_stop" default:"0.001"`
	MaxEntrySpread             float64         `json:"max_entry_spread" default:"-1"` // <0 keeps backward-compatible fallback to trailing_stop
	Parallel                   int             `json:"parallel" default:"1"`
	NormalCloseRetryAggressive bool            `json:"normal_close_retry_aggressive" default:"false"`
	Freshness                  FreshnessConfig `json:"freshness"`
}

func (c ExecutionConfig) EntrySpreadLimit() float64 {
	if c.MaxEntrySpread < 0 {
		return c.TrailingStop
	}
	return c.MaxEntrySpread
}

type CostConfig struct {
	LagTakerFee *float64          `json:"lag_taker_fee"`
	TakerBuffer TakerBufferConfig `json:"taker_buffer"`
}

type TakerBufferConfig struct {
	Mode                 string            `json:"mode"`
	EntryFixedPct        float64           `json:"entry_fixed_pct" default:"0"`
	NormalCloseFixedPct  float64           `json:"normal_close_fixed_pct" default:"0"`
	AutoWarmup           jsontype.Duration `json:"auto_warmup" default:"1m"`
	AutoFallbackPct      float64           `json:"auto_fallback_pct" default:"0"`
	ExcludeFromCostModel bool              `json:"exclude_from_cost_model" default:"false"`
}

type FreshnessConfig struct {
	Mode                 string            `json:"mode"`
	LeadFixedThresholdMS int64             `json:"lead_fixed_threshold_ms" default:"0"`
	LagFixedThresholdMS  int64             `json:"lag_fixed_threshold_ms" default:"0"`
	AutoWarmup           jsontype.Duration `json:"auto_warmup" default:"1m"`
}

type AlignmentPhase uint8

const (
	AlignmentBootstrap AlignmentPhase = iota
	AlignmentAligning
	AlignmentActive
)

type StrategyConfig struct {
	Symbol string `json:"symbol"`
	Lead   string `json:"lead"`
	Lag    string `json:"lag"`

	Trigger   TriggerConfig   `json:"trigger"`
	Execute   ExecutionConfig `json:"execute"`
	Cost      CostConfig      `json:"cost"`
	Analysis  AnalysisConfig  `json:"analysis"`
	BBORecord BBORecord       `json:"bbo_record"`
}

func (c *StrategyConfig) SetDefault() {
	defaults.MustSet(c)
	if c.Analysis.Variant == "" {
		c.Analysis.Variant = DefaultStrategyVariant
	}
	c.Analysis.SetDefault()
}

func (c *StrategyConfig) New(log *logrus.Entry) *Strategy {
	return &Strategy{
		bboCounts: map[string]int64{},

		config:   *c,
		log:      log,
		recorder: (*recorder.EmptyRecorder)(nil),
	}
}

func (c *StrategyConfig) LagTakerFee() float64 {
	if c.Cost.LagTakerFee != nil {
		return *c.Cost.LagTakerFee
	}
	return takerFees[c.Lag]
}

func (c *StrategyConfig) EntryTakerBufferPct() float64 {
	return c.Cost.TakerBuffer.EntryFixedPct
}

func (c *StrategyConfig) NormalCloseTakerBufferPct() float64 {
	return c.Cost.TakerBuffer.NormalCloseFixedPct
}

type PrivateVar struct {
	UpLeadCount    int
	UpLadCount     int
	UpSpaceCount   int
	DownLeadCount  int
	DownLadCount   int
	DownSpaceCount int
	MaxParallel    int

	ActiveLeadTicks       int
	ActiveLagTicks        int
	ThresholdRolls        int
	OpenChecks            int
	OpenSignalTriggered   int
	OpenGuardBlocked      int
	ParallelBlocked            int
	LagVolGuardCooldownBlocks  int
	LagVolGuardTriggerBlocks   int
	DriftGuardBlocks           int
	FreshnessBlocked           int
	LongPriceDiffBlocked  int
	LongThresholdBlocked  int
	ShortPriceDiffBlocked int
	ShortThresholdBlocked int

	LastUpEntry        float64
	LastDownEntry      float64
	LastDrift          float64
	LastUpQuantile     float64
	LastDownQuantile   float64
	LastExit           float64
	LastProfitBuffer   float64
	LastOpenGuardBlock string
	MaxExit            float64
	MaxUpQuantile      float64
	MinDownQuantile    float64
	MaxLeadMove        float64
	MaxAskDiff         float64
	MinLeadMove        float64
	MinBidDiff         float64
}

type Strategy struct {
	template.BaseSingleClientStrategy

	clientID    idgen.IDGenerator
	leadContext struct {
		origin      utils.BBO
		prevOrigin  utils.BBO
		drifted     utils.BBO
		recorder    BBOVolRecorder
		recordPoint int64

		volema StreamStdEmaRecorder

		move MoveQueue
	}
	lagContext struct {
		bbo        utils.BBO
		prevBBO    utils.BBO
		recorder   BBOVolRecorder
		drift      StreamRecorder
		driftReady bool
		stdema     StreamRecorder
		spread     StreamRecorder

		volema StreamStdEmaRecorder

		depth *utils.Depth

		fee float64
	}

	threshold struct {
		UpEntry float64
		UpExit  float64

		DownEntry float64
		DownExit  float64

		LeadNoise float64
		LagNoise  float64

		DriftStdEma StreamRecorder
	}
	alignment struct {
		phase              AlignmentPhase
		driftSamples       int
		firstPairedDriftTs time.Time
		resumeLeadTick     bool
		loggedActive       bool
	}
	autoWarmup struct {
		takerBuffer autoTakerBufferWarmup
		freshness   struct {
			lead autoFreshnessWarmup
			lag  autoFreshnessWarmup
		}
		current struct {
			leadLatencyMS int64
			leadOK        bool
			lagLatencyMS  int64
			lagOK         bool
		}
	}
	lagVolGuard lagVolGuardState
	driftGuard  driftGuardState

	cache                  ExecuteCache
	caches                 map[string]*ExecuteCache
	cacheOrderMap          map[string]string
	attributionEmission    map[string]attributionEmissionState
	attributionDecisionSeq int64

	bboCounts map[string]int64

	pr PrivateVar

	config StrategyConfig

	log *logrus.Entry
	// recorder *logrus.Entry

	recorder recorder.IRecorder
}

func (s *Strategy) newExecuteCache() *ExecuteCache {
	return &ExecuteCache{
		stage:    StageIdle,
		grouping: make([]requests.Order, 0, 2),
	}
}

func (s *Strategy) registerCacheOrder(cacheKey string, cache *ExecuteCache, order requests.Order) {
	cache.order = order
	s.cacheOrderMap[order.GetCID()] = cacheKey
}

func (s *Strategy) recordPendingOrderPrices(cache *ExecuteCache, rawPrice float64, limitPrice float64) {
	if cache == nil {
		return
	}
	cache.pendingOrderRawPrice = rawPrice
	cache.pendingOrderLimitPrice = limitPrice
}

func (s *Strategy) clearPendingOrderPrices(cache *ExecuteCache) {
	if cache == nil {
		return
	}
	cache.pendingOrderRawPrice = 0
	cache.pendingOrderLimitPrice = 0
}

func (s *Strategy) clearPendingCacheOrder(cache *ExecuteCache, cid string) {
	cache.order = nil
	cache.pendingCloseOrderKind = pendingCloseOrderNone
	s.clearPendingOrderPrices(cache)
	delete(s.cacheOrderMap, cid)
}

func (s *Strategy) SetContext(ctx template.IStrategyContext) {
	s.BaseSingleClientStrategy.SetContext(ctx)
	s.leadContext.recorder.Init(100, s.config.BBORecord.Window.Duration().Milliseconds())
	s.lagContext.recorder.Init(100, s.config.BBORecord.Window.Duration().Milliseconds())
	s.lagContext.drift.Init(s.config.Trigger.DriftPeriod.Duration(), 100)
	s.clientID = idgen.NewInt64Generator(8)
	s.caches = map[string]*ExecuteCache{}
	s.cacheOrderMap = map[string]string{}
	s.attributionEmission = map[string]attributionEmissionState{}
	s.attributionDecisionSeq = 0
	s.leadContext.move.Init(s.Context.Now(), s.config.BBORecord.StatsWindow.Duration())
	s.leadContext.volema.Init(
		s.config.BBORecord.Window.Duration(),
		s.config.BBORecord.StatsWindow.Duration(),
		100,
	)
	s.lagContext.volema.Init(
		s.config.BBORecord.Window.Duration(),
		s.config.BBORecord.StatsWindow.Duration(),
		100,
	)
	s.lagContext.spread.Init(s.config.BBORecord.StatsWindow.Duration(), 100)
	s.threshold.UpEntry = s.config.Trigger.Lead
	s.threshold.UpExit = s.config.Trigger.Close
	s.threshold.DownEntry = -s.config.Trigger.Lead
	s.threshold.DownExit = -s.config.Trigger.Close
	s.threshold.DriftStdEma.Init(s.config.BBORecord.StatsWindow.Duration(), 100)
	s.lagContext.fee = s.config.LagTakerFee()
	s.initLagVolGuard()
	s.initDriftGuard()
	s.alignment.phase = AlignmentBootstrap
	s.pr.MinLeadMove = math.MaxFloat64
	s.pr.MinBidDiff = math.MaxFloat64
	s.pr.MinDownQuantile = math.MaxFloat64
}

func (s *Strategy) SetRecorder(recorder recorder.IRecorder) {
	s.recorder = recorder
}

func (s *Strategy) Brief() {
	// s.log.Infof("[Brief] BBO Counts: %+v", s.bboCounts)
	s.log.Infof("[Brief] PRIVATE: %+v", s.pr)
	s.log.Infof("[Config] %+v", s.config)
}

func (s *Strategy) OnBBO(bbo *utils.BBO) error {

	s.Context.ReturnBBOToPool(bbo)
	return nil
}

func (s *Strategy) OnRawBBO(bbo *utils.BBO) error {
	if s == nil || bbo == nil || s.Context == nil {
		return nil
	}
	defer s.Context.ReturnBBOToPool(bbo)
	symbol := bbo.GetSymbol()
	if symbol == nil {
		return nil
	}
	s.bboCounts[symbol.GetName()]++
	exchange := symbol.GetExchangeName()
	prevLead := s.leadContext.origin
	prevLag := s.lagContext.bbo
	priceChanged, tracked := s.updateRawMarketState(bbo, exchange)
	if !tracked {
		return nil
	}
	s.recordBBOFreshnessWarmup(bbo, exchange)
	now := s.Context.Now()
	if s.leadContext.origin.ValidBBO && s.lagContext.bbo.ValidBBO {
		s.UpdateDrift(now, &s.leadContext.origin, &s.lagContext.bbo)
	}

	prevPhase := s.alignment.phase
	switch s.updateAlignmentPhase(now) {
	case AlignmentBootstrap, AlignmentAligning:
		// Alignment-first: before Active we only keep raw market state and drift stats.
		// If position restore is added later, add a restricted recovery path here instead
		// of reusing the full active handlers.
		return nil
	case AlignmentActive:
		if prevPhase != AlignmentActive {
			leadSeed := s.leadContext.origin
			lagSeed := s.lagContext.bbo
			if exchange == s.config.Lead && priceChanged && prevLead.ValidBBO {
				leadSeed = prevLead
			}
			if exchange != s.config.Lead && s.leadContext.prevOrigin.ValidBBO {
				leadSeed = s.leadContext.prevOrigin
			}
			if exchange == s.config.Lag && priceChanged && prevLag.ValidBBO {
				lagSeed = prevLag
			}
			s.alignment.resumeLeadTick = exchange != s.config.Lead
			s.enterActivePhase(now, leadSeed, lagSeed)
			s.logAlignmentTransition(now)
		}
	}
	allowResumeLead := exchange == s.config.Lead && s.alignment.resumeLeadTick
	if !priceChanged && prevPhase == AlignmentActive && !allowResumeLead {
		return nil
	}
	if allowResumeLead {
		s.alignment.resumeLeadTick = false
	}

	switch exchange {
	case s.config.Lead:
		s.pr.ActiveLeadTicks++
		return s.OnLeadBBO(bbo)
	case s.config.Lag:
		s.pr.ActiveLagTicks++
		return s.OnLagBBO(bbo)
	default:
		return nil
	}
}

func (s *Strategy) ProfitBuffer() float64 {
	return EntryCostBreakdown{
		Fee:                    s.lagContext.fee * 2,
		EntryTakerBuffer:       s.entryTakerBufferCostModelPct(),
		NormalCloseTakerBuffer: s.normalCloseTakerBufferCostModelPct(),
		LeadNoise:              s.threshold.LeadNoise,
		LagNoise:               s.threshold.LagNoise,
	}.RequiredEdge()
}

func (s *Strategy) EffectiveEntryTakerBufferPct() float64 {
	if takerBufferMode(s.config.Cost.TakerBuffer.Mode) == "auto" {
		return s.effectiveAutoTakerBufferPct()
	}
	return nonNegativePct(s.config.EntryTakerBufferPct())
}

func (s *Strategy) EffectiveNormalCloseTakerBufferPct() float64 {
	if takerBufferMode(s.config.Cost.TakerBuffer.Mode) == "auto" {
		return s.effectiveAutoTakerBufferPct()
	}
	return nonNegativePct(s.config.NormalCloseTakerBufferPct())
}

const normalCloseRetryBufferFloorPct = 0.005

func (s *Strategy) normalCloseOrderBufferForCache(cache *ExecuteCache) float64 {
	buffer := s.EffectiveNormalCloseTakerBufferPct()
	if s.config.Execute.NormalCloseRetryAggressive && cache != nil && cache.normalCloseFailures >= 2 && buffer < normalCloseRetryBufferFloorPct {
		return normalCloseRetryBufferFloorPct
	}
	return buffer
}

func bufferedOrderPrice(rawPrice, candidate float64) float64 {
	if candidate > 0 && !math.IsNaN(candidate) && !math.IsInf(candidate, 0) {
		return candidate
	}
	if rawPrice > 0 && !math.IsNaN(rawPrice) && !math.IsInf(rawPrice, 0) {
		return rawPrice
	}
	return 0
}

func rawFallbackOrderPrice(lagBBO *utils.BBO) float64 {
	if lagBBO == nil {
		return 0
	}
	if price := bufferedOrderPrice(lagBBO.GetAskPrc(), lagBBO.GetAskPrc()); price > 0 {
		return price
	}
	return bufferedOrderPrice(lagBBO.GetBidPrc(), lagBBO.GetBidPrc())
}

func (s *Strategy) entryOrderPrice(orderSide int, lagBBO *utils.BBO) float64 {
	if lagBBO == nil {
		return 0
	}
	buffer := s.EffectiveEntryTakerBufferPct()
	switch orderSide {
	case utils.Side.Long:
		rawPrice := lagBBO.GetAskPrc()
		return bufferedOrderPrice(rawPrice, rawPrice*(1+buffer))
	case utils.Side.Short:
		rawPrice := lagBBO.GetBidPrc()
		return bufferedOrderPrice(rawPrice, rawPrice*(1-buffer))
	default:
		return rawFallbackOrderPrice(lagBBO)
	}
}

func (s *Strategy) normalCloseOrderPrice(orderSide int, lagBBO *utils.BBO) float64 {
	return normalCloseOrderPriceWithBuffer(orderSide, lagBBO, s.EffectiveNormalCloseTakerBufferPct())
}

func (s *Strategy) normalCloseOrderPriceForCache(orderSide int, lagBBO *utils.BBO, cache *ExecuteCache) float64 {
	return normalCloseOrderPriceWithBuffer(orderSide, lagBBO, s.normalCloseOrderBufferForCache(cache))
}

func normalCloseOrderPriceWithBuffer(orderSide int, lagBBO *utils.BBO, buffer float64) float64 {
	if lagBBO == nil {
		return 0
	}
	switch orderSide {
	case utils.Side.Long:
		rawPrice := lagBBO.GetAskPrc()
		return bufferedOrderPrice(rawPrice, rawPrice*(1+buffer))
	case utils.Side.Short:
		rawPrice := lagBBO.GetBidPrc()
		return bufferedOrderPrice(rawPrice, rawPrice*(1-buffer))
	default:
		return rawFallbackOrderPrice(lagBBO)
	}
}

func takerBufferMode(mode string) string {
	switch strings.ToLower(strings.TrimSpace(mode)) {
	case "auto":
		return "auto"
	default:
		return "fixed"
	}
}

func freshnessMode(mode string) string {
	switch strings.ToLower(strings.TrimSpace(mode)) {
	case "auto":
		return "auto"
	default:
		return "fixed"
	}
}

func (s *Strategy) effectiveAutoTakerBufferPct() float64 {
	if s.autoWarmup.takerBuffer.available {
		return nonNegativePct(s.autoWarmup.takerBuffer.value)
	}
	return nonNegativePct(s.config.Cost.TakerBuffer.AutoFallbackPct)
}

func (s *Strategy) EffectiveLeadFreshnessThresholdMS() (float64, bool) {
	if freshnessMode(s.config.Execute.Freshness.Mode) == "auto" {
		if threshold, ok := s.autoWarmup.freshness.lead.Threshold(); ok {
			return threshold, true
		}
		return fixedFreshnessThreshold(s.config.Execute.Freshness.LeadFixedThresholdMS)
	}
	return fixedFreshnessThreshold(s.config.Execute.Freshness.LeadFixedThresholdMS)
}

func (s *Strategy) EffectiveLagFreshnessThresholdMS() (float64, bool) {
	if freshnessMode(s.config.Execute.Freshness.Mode) == "auto" {
		if threshold, ok := s.autoWarmup.freshness.lag.Threshold(); ok {
			return threshold, true
		}
		return fixedFreshnessThreshold(s.config.Execute.Freshness.LagFixedThresholdMS)
	}
	return fixedFreshnessThreshold(s.config.Execute.Freshness.LagFixedThresholdMS)
}

func fixedFreshnessThreshold(thresholdMS int64) (float64, bool) {
	if thresholdMS <= 0 {
		return 0, false
	}
	return float64(thresholdMS), true
}

func (s *Strategy) CurrentBBOFreshnessLatencyMS(exchange string) (int64, bool) {
	switch exchange {
	case s.config.Lead:
		return s.autoWarmup.current.leadLatencyMS, s.autoWarmup.current.leadOK
	case s.config.Lag:
		return s.autoWarmup.current.lagLatencyMS, s.autoWarmup.current.lagOK
	default:
		return 0, false
	}
}

func nonNegativePct(v float64) float64 {
	if math.IsNaN(v) || math.IsInf(v, 0) {
		return 0
	}
	if v < 0 {
		return 0
	}
	return v
}

type autoTakerBufferWarmup struct {
	frozen    bool
	available bool
	value     float64
	samples   int
	maxSpread float64
	start     time.Time
}

func (w *autoTakerBufferWarmup) Add(now time.Time, warmup time.Duration, spread float64) {
	w.MaybeFreeze(now, warmup)
	if w.frozen || spread < 0 || math.IsNaN(spread) || math.IsInf(spread, 0) {
		return
	}
	if w.start.IsZero() {
		w.start = now
	}
	if w.samples == 0 || spread > w.maxSpread {
		w.maxSpread = spread
	}
	w.samples++
}

func (w *autoTakerBufferWarmup) MaybeFreeze(now time.Time, warmup time.Duration) {
	if w.frozen || w.start.IsZero() {
		return
	}
	if warmup < 0 {
		warmup = 0
	}
	if !now.Before(w.start.Add(warmup)) {
		w.Freeze()
	}
}

func (w *autoTakerBufferWarmup) Freeze() {
	if w.frozen {
		return
	}
	w.frozen = true
	if w.samples > 0 {
		w.available = true
		w.value = w.maxSpread
	}
}

type autoFreshnessWarmup struct {
	frozen    bool
	available bool
	value     float64
	stats     onlineStats
	start     time.Time
}

func (w *autoFreshnessWarmup) Add(now time.Time, warmup time.Duration, latencyMS int64) {
	w.MaybeFreeze(now, warmup)
	if w.frozen || latencyMS < 0 {
		return
	}
	if w.start.IsZero() {
		w.start = now
	}
	w.stats.Add(float64(latencyMS))
}

func (w *autoFreshnessWarmup) MaybeFreeze(now time.Time, warmup time.Duration) {
	if w.frozen || w.start.IsZero() {
		return
	}
	if warmup < 0 {
		warmup = 0
	}
	if !now.Before(w.start.Add(warmup)) {
		w.Freeze()
	}
}

func (w *autoFreshnessWarmup) Freeze() {
	if w.frozen {
		return
	}
	w.frozen = true
	if w.stats.count > 0 {
		w.available = true
		w.value = w.stats.Mean() + 3*w.stats.Std()
	}
}

func (w *autoFreshnessWarmup) Threshold() (float64, bool) {
	return w.value, w.available
}

type onlineStats struct {
	count int
	mean  float64
	m2    float64
}

func (s *onlineStats) Add(v float64) {
	if math.IsNaN(v) || math.IsInf(v, 0) {
		return
	}
	s.count++
	delta := v - s.mean
	s.mean += delta / float64(s.count)
	s.m2 += delta * (v - s.mean)
}

func (s onlineStats) Mean() float64 {
	return s.mean
}

func (s onlineStats) Std() float64 {
	if s.count == 0 {
		return 0
	}
	return math.Sqrt(s.m2 / float64(s.count))
}

func (s *Strategy) maybeFreezeAutoWarmup(now time.Time) {
	s.autoWarmup.takerBuffer.MaybeFreeze(now, s.config.Cost.TakerBuffer.AutoWarmup.Duration())
	s.autoWarmup.freshness.lead.MaybeFreeze(now, s.config.Execute.Freshness.AutoWarmup.Duration())
	s.autoWarmup.freshness.lag.MaybeFreeze(now, s.config.Execute.Freshness.AutoWarmup.Duration())
}

func (s *Strategy) recordBBOFreshnessWarmup(bbo *utils.BBO, exchange string) {
	if bbo == nil || s.Context == nil {
		return
	}
	now := s.Context.Now()
	s.maybeFreezeAutoWarmup(now)
	switch exchange {
	case s.config.Lead:
		if s.autoWarmup.freshness.lead.start.IsZero() {
			s.autoWarmup.freshness.lead.start = now
		}
	case s.config.Lag:
		if s.autoWarmup.freshness.lag.start.IsZero() {
			s.autoWarmup.freshness.lag.start = now
		}
	}
	latencyMS := bbo.GetLocalTimeMS() - bbo.GetServerTimeMS()
	if latencyMS < 0 {
		return
	}
	switch exchange {
	case s.config.Lead:
		s.autoWarmup.current.leadLatencyMS = latencyMS
		s.autoWarmup.current.leadOK = true
		s.autoWarmup.freshness.lead.Add(now, s.config.Execute.Freshness.AutoWarmup.Duration(), latencyMS)
	case s.config.Lag:
		s.autoWarmup.current.lagLatencyMS = latencyMS
		s.autoWarmup.current.lagOK = true
		s.autoWarmup.freshness.lag.Add(now, s.config.Execute.Freshness.AutoWarmup.Duration(), latencyMS)
	}
}

func (s *Strategy) recordLagDepthAutoTakerBufferWarmup(depth *utils.Depth) {
	if depth == nil || s.Context == nil {
		return
	}
	now := s.Context.Now()
	if s.autoWarmup.takerBuffer.start.IsZero() {
		s.autoWarmup.takerBuffer.start = now
	}
	s.maybeFreezeAutoWarmup(now)
	if spread, ok := depthL2SpreadPct(depth.Asks, true); ok {
		s.autoWarmup.takerBuffer.Add(now, s.config.Cost.TakerBuffer.AutoWarmup.Duration(), spread)
	}
	if spread, ok := depthL2SpreadPct(depth.Bids, false); ok {
		s.autoWarmup.takerBuffer.Add(now, s.config.Cost.TakerBuffer.AutoWarmup.Duration(), spread)
	}
}

func depthL2SpreadPct(levels *[]*utils.Level, askSide bool) (float64, bool) {
	l1, l2, ok := depthFirstTwoValidLevels(levels)
	if !ok {
		return 0, false
	}
	var spread float64
	if askSide {
		spread = l2.Prc/l1.Prc - 1
	} else {
		spread = 1 - l2.Prc/l1.Prc
	}
	if spread < 0 || math.IsNaN(spread) || math.IsInf(spread, 0) {
		return 0, false
	}
	return spread, true
}

func depthFirstTwoValidLevels(levels *[]*utils.Level) (*utils.Level, *utils.Level, bool) {
	if levels == nil || len(*levels) < 2 {
		return nil, nil, false
	}
	l1 := (*levels)[0]
	l2 := (*levels)[1]
	if !validDepthL2Level(l1) || !validDepthL2Level(l2) {
		return nil, nil, false
	}
	return l1, l2, true
}

func validDepthL2Level(level *utils.Level) bool {
	if level == nil {
		return false
	}
	if level.Prc <= 0 || level.Qty <= 0 {
		return false
	}
	if math.IsNaN(level.Prc) || math.IsNaN(level.Qty) {
		return false
	}
	if math.IsInf(level.Prc, 0) || math.IsInf(level.Qty, 0) {
		return false
	}
	return true
}

func (s *Strategy) UpdateDrift(t time.Time, leadBBO, lagBBO *utils.BBO) {
	// drift :=
	lead := (leadBBO.BestAskPrc + leadBBO.BestBidPrc)
	lag := (lagBBO.BestAskPrc + lagBBO.BestBidPrc)
	drift := lag / lead
	if s.alignment.driftSamples == 0 {
		s.alignment.firstPairedDriftTs = t
	}
	s.alignment.driftSamples++
	s.lagContext.drift.OnData(t, drift)
	s.lagContext.driftReady = true
	s.threshold.DriftStdEma.OnData(t, s.lagContext.drift.GetStd())
	s.updateDriftGuardRatio(t, leadBBO, lagBBO)
}

func (s *Strategy) updateRawMarketState(bbo *utils.BBO, exchange string) (bool, bool) {
	switch exchange {
	case s.config.Lead:
		if bbo.BestAskPrc == s.leadContext.origin.BestAskPrc && bbo.BestBidPrc == s.leadContext.origin.BestBidPrc {
			return false, true
		}
		s.leadContext.prevOrigin = s.leadContext.origin
		s.leadContext.origin = *bbo
		return true, true
	case s.config.Lag:
		if bbo.BestAskPrc == s.lagContext.bbo.BestAskPrc && bbo.BestBidPrc == s.lagContext.bbo.BestBidPrc {
			return false, true
		}
		s.lagContext.prevBBO = s.lagContext.bbo
		s.lagContext.bbo = *bbo
		return true, true
	default:
		return false, false
	}
}

func (s *Strategy) logAlignmentTransition(now time.Time) {
	if s.log == nil || s.alignment.loggedActive {
		return
	}
	s.alignment.loggedActive = true
	s.log.WithFields(logrus.Fields{
		"phase":            "active",
		"drift_samples":    s.alignment.driftSamples,
		"drift_ready":      s.lagContext.driftReady,
		"first_paired_ts":  s.alignment.firstPairedDriftTs,
		"warmup":           s.alignmentWarmup(),
		"resume_lead_tick": s.alignment.resumeLeadTick,
		"now":              now,
	}).Info("alignment phase transition")
}

func (s *Strategy) alignmentWarmup() time.Duration {
	if warmup := s.config.Trigger.DriftWarmup.Duration(); warmup > 0 {
		return warmup
	}
	return s.config.BBORecord.StatsWindow.Duration()
}

func (s *Strategy) alignmentReady(now time.Time) bool {
	if !s.leadContext.origin.ValidBBO || !s.lagContext.bbo.ValidBBO {
		return false
	}
	if s.alignment.driftSamples < s.config.Trigger.DriftMinSamples {
		return false
	}
	if s.alignment.firstPairedDriftTs.IsZero() {
		return false
	}
	return !now.Before(s.alignment.firstPairedDriftTs.Add(s.alignmentWarmup()))
}

func (s *Strategy) updateAlignmentPhase(now time.Time) AlignmentPhase {
	switch {
	case !s.leadContext.origin.ValidBBO || !s.lagContext.bbo.ValidBBO:
		s.alignment.phase = AlignmentBootstrap
	case s.alignmentReady(now):
		s.alignment.phase = AlignmentActive
	default:
		s.alignment.phase = AlignmentAligning
	}
	return s.alignment.phase
}

func (s *Strategy) enterActivePhase(now time.Time, leadSeed, lagSeed utils.BBO) {
	s.maybeFreezeAutoWarmup(now)

	window := s.config.BBORecord.Window.Duration()
	statsWindow := s.config.BBORecord.StatsWindow.Duration()

	s.leadContext.recorder.Init(100, window.Milliseconds())
	s.lagContext.recorder.Init(100, window.Milliseconds())
	s.leadContext.volema.Init(window, statsWindow, 100)
	s.lagContext.volema.Init(window, statsWindow, 100)
	s.lagContext.spread.Init(statsWindow, 100)
	s.leadContext.move.Init(now, statsWindow)

	scaledLead := leadSeed
	if s.lagContext.driftReady {
		drift := s.lagContext.drift.GetMean()
		scaledLead.BestAskPrc = scaledLead.BestAskPrc * drift
		scaledLead.BestBidPrc = scaledLead.BestBidPrc * drift
	}
	s.leadContext.drifted = scaledLead
	s.leadContext.recorder.OnBBO(scaledLead.ServerTime, scaledLead.BestAskPrc, scaledLead.BestBidPrc)
	s.leadContext.volema.OnData(now, (scaledLead.BestAskPrc+scaledLead.BestBidPrc)/2)
	s.lagContext.recorder.OnBBO(lagSeed.ServerTime, lagSeed.BestAskPrc, lagSeed.BestBidPrc)
	s.lagContext.spread.OnData(now, lagSeed.BestAskPrc-lagSeed.BestBidPrc)
	s.lagContext.volema.OnData(now, (lagSeed.BestAskPrc+lagSeed.BestBidPrc)/2)
}

func (s *Strategy) UpdateMoveThreshold(t time.Time, bbo *utils.BBO) {
	if s.leadContext.move.ShouldRoll(t) {
		s.pr.ThresholdRolls++
		s.threshold.LeadNoise = s.leadContext.volema.GetStdEma()
		s.threshold.LagNoise = s.lagContext.volema.GetStdEma()
		s.leadContext.move.Sort()
		up, down := s.leadContext.move.Qunatile(s.config.Trigger.Quantile.Move)
		exit := s.threshold.DriftStdEma.GetMean()

		profitBuffer := s.ProfitBuffer()
		s.pr.LastUpQuantile = up
		s.pr.LastDownQuantile = down
		s.pr.LastExit = exit
		s.pr.LastProfitBuffer = profitBuffer
		if exit > s.pr.MaxExit {
			s.pr.MaxExit = exit
		}
		if up > s.pr.MaxUpQuantile {
			s.pr.MaxUpQuantile = up
		}
		if down < s.pr.MinDownQuantile {
			s.pr.MinDownQuantile = down
		}

		if up-exit > profitBuffer {
			s.threshold.UpEntry = up
			s.threshold.UpExit = exit

		} else {
			s.threshold.UpEntry = exit + profitBuffer
			s.threshold.UpExit = exit

		}
		if -down-exit > profitBuffer {
			s.threshold.DownEntry = down
			s.threshold.DownExit = -exit
		} else {
			s.threshold.DownEntry = -exit - profitBuffer
			s.threshold.DownExit = -exit
		}
		s.pr.LastUpEntry = s.threshold.UpEntry
		s.pr.LastDownEntry = s.threshold.DownEntry
		if s.log != nil && (math.Abs(exit) > 1 || math.Abs(s.threshold.UpEntry) > 1 || math.Abs(s.threshold.DownEntry) > 1) {
			s.log.WithFields(logrus.Fields{
				"up_quantile":   up,
				"down_quantile": down,
				"exit":          exit,
				"profit_buffer": profitBuffer,
				"up_entry":      s.threshold.UpEntry,
				"down_entry":    s.threshold.DownEntry,
				"lead_noise":    s.threshold.LeadNoise,
				"lag_noise":     s.threshold.LagNoise,
				"drift_mean":    s.lagContext.drift.GetMean(),
				"drift_std":     s.lagContext.drift.GetStd(),
				"drift_samples": s.alignment.driftSamples,
				"move_samples":  s.leadContext.move.Size(),
				"active_lead":   s.pr.ActiveLeadTicks,
				"active_lag":    s.pr.ActiveLagTicks,
			}).Info("threshold anomaly")
		}
		// s.NowEntry().
		// 	WithFields(logrus.Fields{
		// 		// "size": s.leadContext.move.Size(),
		// 		"up entry":   fmt.Sprintf("%.2f%%", up*100),
		// 		"up exit":    fmt.Sprintf("%.2f%%", exit*100),
		// 		"down entry": fmt.Sprintf("%.2f%%", down*100),
		// 		"down exit":  fmt.Sprintf("%.2f%%", -exit*100),
		// 		// "lead noise":    fmt.Sprintf("%.2f%%", s.threshold.LeadNoise*100),
		// 		// "lag noise":     fmt.Sprintf("%.2f%%", s.threshold.LagNoise*100),
		// 		// "profit buffer": fmt.Sprintf("%.2f%%", profitBuffer*100),
		// 	}).Info()
		s.leadContext.move.Roll(t)
	}
	bidMin, _ := s.leadContext.recorder.Bid.GetMin()
	askMax, _ := s.leadContext.recorder.Ask.GetMax()

	s.leadContext.move.Push(bbo.BestBidPrc/bidMin.Price-1, bbo.BestAskPrc/askMax.Price-1)
}

func (s *Strategy) OnLeadBBO(bbo *utils.BBO) error {
	s.leadContext.origin = *bbo

	drift := 1.0
	if s.lagContext.driftReady {
		drift = s.lagContext.drift.GetMean()
		bbo.BestAskPrc = bbo.BestAskPrc * drift
		bbo.BestBidPrc = bbo.BestBidPrc * drift
	}
	s.leadContext.drifted = *bbo
	s.leadContext.recorder.OnBBO(
		bbo.ServerTime,
		bbo.BestAskPrc,
		bbo.BestBidPrc,
	)
	s.leadContext.volema.OnData(s.Context.Now(), (bbo.BestAskPrc+bbo.BestBidPrc)/2)
	s.UpdateMoveThreshold(s.Context.Now(), bbo)

	// Close first for all existing caches, then try to open a new position.
	for key, cache := range s.caches {
		switch cache.stage {
		case StageHold:
			if cache.position.IsPositive() {
				err := s.CloseLong(key, cache, bbo, &s.lagContext.bbo)
				if err != nil {
					return err
				}
			} else if cache.position.IsNegative() {
				err := s.CloseShort(key, cache, bbo, &s.lagContext.bbo)
				if err != nil {
					return err
				}
			}
		}
	}
	s.pr.OpenChecks++
	s.pr.LastDrift = drift
	signal, ok, err := s.evaluateOpenLongSignal(bbo)
	if err != nil {
		return err
	}
	if ok {
		return s.handleOpenSignal(bbo, signal, drift)
	}
	signal, ok, err = s.evaluateOpenShortSignal(bbo)
	if err != nil {
		return err
	}
	if ok {
		return s.handleOpenSignal(bbo, signal, drift)
	}
	return nil
}

func (s *Strategy) handleOpenSignal(bbo *utils.BBO, signal openSignal, drift float64) error {
	s.pr.OpenSignalTriggered++
	s.pr.LastOpenGuardBlock = ""
	reason, blocked, guard := s.openGuardBlockReason(bbo, signal, drift)
	if blocked {
		blockedCache := s.recordBlockedOpenSignal(signal)
		s.RecordOpenSignalDecision(bbo, signal, guard, "blocked", reason, blockedCache, nil)
		s.pr.OpenGuardBlocked++
		s.pr.LastOpenGuardBlock = reason
		s.RecordFilterAttribution(AttributionReasonFiltered, signal.signalValue, signal.threshold, signal.requiredEdge, reason)
		return nil
	}
	_, err := s.executeOpenSignal(bbo, signal, guard)
	return err
}

func (s *Strategy) OnLagBBO(bbo *utils.BBO) error {
	s.updateLagVolGuard(bbo)

	s.lagContext.recorder.OnBBO(
		bbo.ServerTime,
		bbo.BestAskPrc,
		bbo.BestBidPrc,
	)
	s.lagContext.spread.OnData(s.Context.Now(), bbo.BestAskPrc-bbo.BestBidPrc)
	s.lagContext.volema.OnData(s.Context.Now(), (bbo.BestAskPrc+bbo.BestBidPrc)/2)
	s.lagContext.bbo = *bbo

	// Close first for all existing caches on lag updates (stoploss/trailing/signal close).
	for key, cache := range s.caches {
		switch cache.stage {
		case StageHold:
			if cache.position.IsPositive() {
				s.TrackLogTrailingLong(cache, bbo)
				ok, err := s.ExecuteStoplossLong(key, cache, bbo)
				if err != nil {
					return err
				}
				if ok {
					continue
				}
				err = s.CloseLong(key, cache, &s.leadContext.drifted, bbo)
				if err != nil {
					return err
				}
			} else if cache.position.IsNegative() {
				s.TrackLogTrailingShort(cache, bbo)
				ok, err := s.ExecuteStoplossShort(key, cache, bbo)
				if err != nil {
					return err
				}
				if ok {
					continue
				}
				err = s.CloseShort(key, cache, &s.leadContext.drifted, bbo)
				if err != nil {
					return err
				}
			}
		}
	}
	return nil
}

func (s *Strategy) EstimateLagSpread() float64 {
	return s.lagContext.bbo.BestAskPrc - s.lagContext.bbo.BestBidPrc
}

func (s *Strategy) LagSpreadBuffer(bbo *utils.BBO) float64 {
	current := bbo.BestAskPrc - bbo.BestBidPrc
	histroy := s.lagContext.spread.GetMean()
	return math.Max(current-histroy, 0)
}

func spreadPct(bbo *utils.BBO) float64 {
	if bbo == nil || !bbo.ValidBBO || bbo.BestAskPrc <= 0 || bbo.BestBidPrc <= 0 {
		return 0
	}
	return (bbo.BestAskPrc - bbo.BestBidPrc) / (bbo.BestAskPrc + bbo.BestBidPrc) * 2
}

func reverseCloseSide(entrySide int) int {
	if entrySide == utils.Side.Long {
		return utils.Side.Short
	}
	return utils.Side.Long
}

func closeabilityStateAvailability(bboAvailable bool, depthAvailable bool) string {
	bboFlag := "0"
	if bboAvailable {
		bboFlag = "1"
	}
	depthFlag := "0"
	if depthAvailable {
		depthFlag = "1"
	}
	return "closeability_bbo=" + bboFlag + ",closeability_depth=" + depthFlag + ",pending=1,cooldown=0"
}

func validCloseabilityBBOLevel(bbo *utils.BBO, side int) (float64, float64, bool) {
	if bbo == nil || !bbo.ValidBBO {
		return 0, 0, false
	}
	if side == utils.Side.Short {
		if bbo.BestBidPrc <= 0 || bbo.BestBidQty <= 0 {
			return 0, 0, false
		}
		return bbo.BestBidPrc, bbo.BestBidQty, true
	}
	if bbo.BestAskPrc <= 0 || bbo.BestAskQty <= 0 {
		return 0, 0, false
	}
	return bbo.BestAskPrc, bbo.BestAskQty, true
}

func validCloseabilityDepthLevel(depth *utils.Depth, side int) (*utils.Level, bool) {
	if depth == nil {
		return nil, false
	}
	var levels *[]*utils.Level
	if side == utils.Side.Short {
		levels = depth.Bids
	} else {
		levels = depth.Asks
	}
	if levels == nil || len(*levels) == 0 || (*levels)[0] == nil {
		return nil, false
	}
	level := (*levels)[0]
	if level.Prc <= 0 || level.Qty <= 0 {
		return nil, false
	}
	return level, true
}

func (s *Strategy) entryOpportunityAttributionInput(cache *ExecuteCache, side int, signalValue float64, threshold float64, price float64, qty float64, targetSpace float64, requiredEdge float64, leadMove float64, lagMove float64, lagBBO *utils.BBO) EntryOpportunityAttributionInput {
	reverseSide := reverseCloseSide(side)
	reversePrice := 0.0
	reverseDepth := 0.0
	closeabilityBBOAvailable := false
	closeabilityDepthAvailable := false
	stateAvailability := "closeability_bbo=0,closeability_depth=0,pending=1,cooldown=0"
	if sidePrice, sideQty, ok := validCloseabilityBBOLevel(lagBBO, reverseSide); ok {
		closeabilityBBOAvailable = true
		reversePrice = sidePrice
		reverseDepth = sidePrice * sideQty
	}
	if level, ok := validCloseabilityDepthLevel(s.lagContext.depth, reverseSide); ok {
		closeabilityDepthAvailable = true
		reverseDepth = level.Prc * level.Qty
		if reversePrice == 0 {
			reversePrice = level.Prc
		}
	}
	stateAvailability = closeabilityStateAvailability(closeabilityBBOAvailable, closeabilityDepthAvailable)
	reverseNotional := qty * reversePrice
	pendingOpen, pendingClose := s.pendingOrderCounts()
	parallelUsed := len(s.caches)
	if cache != nil {
		for _, existing := range s.caches {
			if existing == cache && existing.stage == StageIdle && existing.order == nil {
				parallelUsed--
				break
			}
		}
	}
	return EntryOpportunityAttributionInput{
		Cache:                      cache,
		Side:                       side,
		SignalValue:                signalValue,
		Threshold:                  threshold,
		Price:                      price,
		Qty:                        qty,
		TargetSpace:                targetSpace,
		RequiredEdge:               requiredEdge,
		LeadMove:                   leadMove,
		LagMove:                    lagMove,
		EntrySpread:                spreadPct(lagBBO),
		EntrySpreadLimit:           s.config.Execute.EntrySpreadLimit(),
		ReverseCloseSide:           reverseSide,
		ReverseCloseNotional:       reverseNotional,
		ReverseCloseDepth:          reverseDepth,
		ReverseCloseSlack:          reverseDepth - reverseNotional,
		ReverseCloseSpread:         spreadPct(lagBBO),
		ParallelUsed:               parallelUsed,
		ParallelLimit:              s.config.Execute.Parallel,
		PendingOpenOrders:          pendingOpen,
		PendingCloseOrders:         pendingClose,
		CloseabilityBBOAvailable:   closeabilityBBOAvailable,
		CloseabilityDepthAvailable: closeabilityDepthAvailable,
		PendingStateAvailable:      true,
		CooldownStateAvailable:     false,
		PositionStateAvailable:     true,
		CooldownActive:             false,
		PositionState:              "none",
		StateAvailability:          stateAvailability,
	}
}

func (s *Strategy) pendingOrderCounts() (int, int) {
	pendingOpen := 0
	pendingClose := 0
	for _, cache := range s.caches {
		if cache == nil || cache.order == nil {
			continue
		}
		switch cache.stage {
		case StageOpen:
			pendingOpen++
		case StageClose:
			pendingClose++
		}
	}
	return pendingOpen, pendingClose
}

type openSignal struct {
	method        string
	side          int
	price         float64
	qty           float64
	signalValue   float64
	threshold     float64
	exitThreshold float64
	targetSpace   float64
	requiredEdge  float64
	leadMove      float64
	lagMove       float64
	askDiff       float64
	bidDiff       float64
	base          PricePoint
}

type signalGuardSnapshot struct {
	ParallelUsed    int
	ParallelLimit   int
	ParallelOutcome string

	DriftValue float64
	DriftReady bool

	LagVolGuardEnabled    bool
	LagVolJumpCount       int
	LagVolAmplitude       float64
	LagVolHot             bool
	LagVolCooldownUntilMS int64
	LagVolOutcome         string

	DriftGuardEnabled     bool
	DriftGuardReady       bool
	DriftInstantRatio     float64
	DriftInstantThreshold float64
	DriftInstantHit       bool
	RatioStdValue         float64
	RatioStdThreshold     float64
	RatioStdHit           bool
	DriftMeanValue        float64
	DriftMeanThreshold    float64
	DriftMeanHit          bool
	DriftGuardOutcome     string

	LeadFreshnessLatencyMS int64
	LeadFreshnessLatencyOK bool
	LeadFreshnessThreshold float64
	LeadFreshnessEnabled   bool
	LeadFreshnessOutcome   string

	LagFreshnessLatencyMS int64
	LagFreshnessLatencyOK bool
	LagFreshnessThreshold float64
	LagFreshnessEnabled   bool
	LagFreshnessOutcome   string
}

func (s *Strategy) evaluateOpenLongSignal(bbo *utils.BBO) (openSignal, bool, error) {
	leadBase, _ := s.leadContext.recorder.Bid.GetMin()
	minAsk, _ := s.leadContext.recorder.Ask.GetMin()

	leadMove := bbo.BestBidPrc/leadBase.Price - 1
	askDiff := bbo.BestAskPrc/minAsk.Price - 1
	if leadMove > s.pr.MaxLeadMove {
		s.pr.MaxLeadMove = leadMove
	}
	if askDiff > s.pr.MaxAskDiff {
		s.pr.MaxAskDiff = askDiff
	}
	trigPrice := s.lagContext.bbo.GetAskPrc()
	prcDiff := bbo.BestBidPrc/trigPrice - 1
	if prcDiff <= 0 {
		s.pr.LongPriceDiffBlocked++
		s.RecordFilterAttribution(AttributionReasonNoTrigger, prcDiff, 0, 0, "long-price-diff")
		return openSignal{}, false, nil
	}

	if (leadMove >= s.threshold.UpEntry) && (askDiff >= s.threshold.UpEntry) {
		s.pr.UpLeadCount++
		if !s.lagContext.bbo.ValidBBO {
			return openSignal{}, false, nil
		}

		lagBase, _ := s.lagContext.recorder.Bid.GetMin()
		basePrice := math.Min(leadBase.Price, lagBase.Price)
		lagMove := s.lagContext.bbo.GetBidPrc()/basePrice - 1
		moveSpace := leadMove - lagMove

		if moveSpace/leadMove > s.config.Trigger.LagPart {
			s.pr.UpLadCount++
			targetPrice := bbo.BestBidPrc - bbo.BestBidPrc*s.threshold.UpExit - s.LagSpreadBuffer(&s.lagContext.bbo)
			targetSpace := targetPrice/trigPrice - 1
			entryCost := s.BuildEntryCostBreakdown(&s.lagContext.bbo, trigPrice)
			requiredEdge := entryCost.RequiredEdgeWithTargetProfit(s.config.Trigger.TargetProfitRate)
			if targetSpace < requiredEdge {
				s.RecordFilterAttribution(AttributionReasonFiltered, targetSpace, requiredEdge, requiredEdge, "entry-cost")
				return openSignal{}, false, nil
			}
			if spreadPct(&s.lagContext.bbo) > s.config.Execute.EntrySpreadLimit() {
				s.RecordFilterAttribution(AttributionReasonFiltered, spreadPct(&s.lagContext.bbo), s.config.Execute.EntrySpreadLimit(), requiredEdge, "entry-spread")
				return openSignal{}, false, nil
			}
			s.pr.UpSpaceCount++
			return openSignal{
				method:        "OpenLong",
				side:          utils.Side.Long,
				price:         trigPrice,
				qty:           s.CalOpenQty(s.lagContext.bbo.GetSymbol(), trigPrice),
				signalValue:   leadMove,
				threshold:     s.threshold.UpEntry,
				exitThreshold: s.threshold.UpExit,
				targetSpace:   targetSpace,
				requiredEdge:  requiredEdge,
				leadMove:      leadMove,
				lagMove:       lagMove,
				askDiff:       askDiff,
				base:          leadBase,
			}, true, nil
		}
	}
	s.pr.LongThresholdBlocked++
	s.RecordFilterAttribution(AttributionReasonNoTrigger, leadMove, s.threshold.UpEntry, 0, "long-threshold")
	return openSignal{}, false, nil
}

func (s *Strategy) evaluateOpenShortSignal(bbo *utils.BBO) (openSignal, bool, error) {
	leadBase, _ := s.leadContext.recorder.Ask.GetMax()
	leadMove := bbo.BestAskPrc/leadBase.Price - 1
	if leadMove < s.pr.MinLeadMove {
		s.pr.MinLeadMove = leadMove
	}
	trigPrice := s.lagContext.bbo.GetBidPrc()
	prcDiff := bbo.BestAskPrc/trigPrice - 1
	if prcDiff >= 0 {
		s.pr.ShortPriceDiffBlocked++
		s.RecordFilterAttribution(AttributionReasonNoTrigger, prcDiff, 0, 0, "short-price-diff")
		return openSignal{}, false, nil
	}

	maxBid, _ := s.leadContext.recorder.Bid.GetMax()
	bidDiff := bbo.BestBidPrc/maxBid.Price - 1
	if bidDiff < s.pr.MinBidDiff {
		s.pr.MinBidDiff = bidDiff
	}
	if (leadMove <= s.threshold.DownEntry) && (bidDiff <= s.threshold.DownEntry) {
		s.pr.DownLeadCount++
		if !s.lagContext.bbo.ValidBBO {
			return openSignal{}, false, nil
		}
		lagBase, _ := s.lagContext.recorder.Ask.GetMax()
		basePrice := math.Max(leadBase.Price, lagBase.Price)
		lagMove := s.lagContext.bbo.GetAskPrc()/basePrice - 1
		moveSpace := leadMove - lagMove

		if moveSpace/leadMove >= s.config.Trigger.LagPart {
			targetPrice := bbo.BestAskPrc - leadBase.Price*s.threshold.DownExit + s.LagSpreadBuffer(&s.lagContext.bbo)
			s.pr.DownLadCount++
			targetSpace := targetPrice/trigPrice - 1
			entryCost := s.BuildEntryCostBreakdown(&s.lagContext.bbo, trigPrice)
			requiredEdge := entryCost.RequiredEdgeWithTargetProfit(s.config.Trigger.TargetProfitRate)
			if -targetSpace < requiredEdge {
				s.RecordFilterAttribution(AttributionReasonFiltered, -targetSpace, requiredEdge, requiredEdge, "entry-cost")
				return openSignal{}, false, nil
			}
			if spreadPct(&s.lagContext.bbo) > s.config.Execute.EntrySpreadLimit() {
				s.RecordFilterAttribution(AttributionReasonFiltered, spreadPct(&s.lagContext.bbo), s.config.Execute.EntrySpreadLimit(), requiredEdge, "entry-spread")
				return openSignal{}, false, nil
			}

			s.pr.DownSpaceCount++
			return openSignal{
				method:        "OpenShort",
				side:          utils.Side.Short,
				price:         trigPrice,
				qty:           s.CalOpenQty(s.lagContext.bbo.GetSymbol(), trigPrice),
				signalValue:   leadMove,
				threshold:     s.threshold.DownEntry,
				exitThreshold: s.threshold.DownExit,
				targetSpace:   targetSpace,
				requiredEdge:  requiredEdge,
				leadMove:      leadMove,
				lagMove:       lagMove,
				bidDiff:       bidDiff,
				base:          leadBase,
			}, true, nil
		}
	}
	s.pr.ShortThresholdBlocked++
	s.RecordFilterAttribution(AttributionReasonNoTrigger, leadMove, s.threshold.DownEntry, 0, "short-threshold")
	return openSignal{}, false, nil
}

func (s *Strategy) openGuardBlockReason(leadBBO *utils.BBO, _ openSignal, drift float64) (string, bool, signalGuardSnapshot) {
	nowMS := int64(0)
	if leadBBO != nil {
		nowMS = leadBBO.ServerTime
	}
	rawLead := &s.leadContext.origin
	lagBBO := &s.lagContext.bbo

	guard := signalGuardSnapshot{
		ParallelUsed:         len(s.caches),
		ParallelLimit:        s.config.Execute.Parallel,
		ParallelOutcome:      "allowed",
		DriftValue:           drift,
		DriftReady:           s.lagContext.driftReady,
		LeadFreshnessOutcome: "not_evaluated",
		LagFreshnessOutcome:  "not_evaluated",
	}
	if guard.ParallelUsed >= guard.ParallelLimit {
		guard.ParallelOutcome = "blocked"
		s.pr.ParallelBlocked++
		return "parallel-limit", true, guard
	}
	if s.config.Trigger.LagVolGuard.IsEnabled() {
		s.populateLagVolGuardSnapshot(&guard, nowMS)
		if nowMS < s.lagVolGuard.cooldownUntilMS {
			guard.LagVolOutcome = "blocked"
			s.pr.LagVolGuardCooldownBlocks++
			return "lag-vol-guard-cooldown", true, guard
		}
		if guard.LagVolHot {
			cooldownMS := s.config.Trigger.LagVolGuard.Cooldown.Duration().Milliseconds()
			s.lagVolGuard.cooldownUntilMS = nowMS + cooldownMS
			guard.LagVolCooldownUntilMS = s.lagVolGuard.cooldownUntilMS
			guard.LagVolOutcome = "blocked"
			s.pr.LagVolGuardTriggerBlocks++
			return "lag-vol-guard-trigger", true, guard
		}
	} else {
		guard.LagVolOutcome = "disabled"
	}
	if s.config.Trigger.DriftGuard.IsEnabled() {
		s.populateDriftGuardSnapshot(&guard, rawLead, lagBBO)
		if guard.DriftGuardReady {
			if guard.DriftInstantHit || guard.RatioStdHit || guard.DriftMeanHit {
				guard.DriftGuardOutcome = "blocked"
				s.pr.DriftGuardBlocks++
				return "drift-guard", true, guard
			}
		}
	} else {
		guard.DriftGuardOutcome = "disabled"
	}
	if threshold, ok := s.EffectiveLeadFreshnessThresholdMS(); ok {
		guard.LeadFreshnessEnabled = true
		guard.LeadFreshnessThreshold = threshold
		latency, latencyOK := s.CurrentBBOFreshnessLatencyMS(s.config.Lead)
		guard.LeadFreshnessLatencyMS = latency
		guard.LeadFreshnessLatencyOK = latencyOK
		guard.LeadFreshnessOutcome = "allowed"
		if !latencyOK || float64(latency) > threshold {
			guard.LeadFreshnessOutcome = "blocked"
			s.pr.FreshnessBlocked++
			return "freshness-lead", true, guard
		}
	} else {
		guard.LeadFreshnessOutcome = "disabled"
	}
	if threshold, ok := s.EffectiveLagFreshnessThresholdMS(); ok {
		guard.LagFreshnessEnabled = true
		guard.LagFreshnessThreshold = threshold
		latency, latencyOK := s.CurrentBBOFreshnessLatencyMS(s.config.Lag)
		guard.LagFreshnessLatencyMS = latency
		guard.LagFreshnessLatencyOK = latencyOK
		guard.LagFreshnessOutcome = "allowed"
		if !latencyOK || float64(latency) > threshold {
			guard.LagFreshnessOutcome = "blocked"
			s.pr.FreshnessBlocked++
			return "freshness-lag", true, guard
		}
	} else {
		guard.LagFreshnessOutcome = "disabled"
	}
	return "", false, guard
}

func (s *Strategy) recordBlockedOpenSignal(signal openSignal) *ExecuteCache {
	orderPrice := s.entryOrderPrice(signal.side, &s.lagContext.bbo)
	orderQty := s.CalOpenQty(s.lagContext.bbo.GetSymbol(), orderPrice)
	var cache *ExecuteCache
	if s.fullSignalDecisionLogEnabled() {
		cache = s.newExecuteCache()
	}
	s.RecordEntryOpportunityAttribution(s.entryOpportunityAttributionInput(
		cache,
		signal.side,
		signal.signalValue,
		signal.threshold,
		orderPrice,
		orderQty,
		signal.targetSpace,
		signal.requiredEdge,
		signal.leadMove,
		signal.lagMove,
		&s.lagContext.bbo,
	))
	if cache == nil || cache.stableLinkage.EntryAttemptID == "" {
		return nil
	}
	return cache
}

func positionSideFromOpenOrderSide(side int) string {
	if side == utils.Side.Long {
		return "long"
	}
	if side == utils.Side.Short {
		return "short"
	}
	return ""
}

func positionSideFromCloseOrderSide(side int) string {
	if side == utils.Side.Short {
		return "long"
	}
	if side == utils.Side.Long {
		return "short"
	}
	return ""
}

func rawOrderSideBBOPrice(side int, bbo *utils.BBO) float64 {
	if bbo == nil {
		return 0
	}
	if side == utils.Side.Long {
		return bbo.GetAskPrc()
	}
	if side == utils.Side.Short {
		return bbo.GetBidPrc()
	}
	return rawFallbackOrderPrice(bbo)
}

func addBBOFields(fields map[string]interface{}, leadBBO *utils.BBO, lagBBO *utils.BBO) {
	if leadBBO != nil {
		fields["lead_ask"] = leadBBO.GetAskPrc()
		fields["lead_ask_qty"] = leadBBO.GetAskQty()
		fields["lead_bid"] = leadBBO.GetBidPrc()
		fields["lead_bid_qty"] = leadBBO.GetBidQty()
	}
	if lagBBO != nil {
		fields["lag_ask"] = lagBBO.GetAskPrc()
		fields["lag_ask_qty"] = lagBBO.GetAskQty()
		fields["lag_bid"] = lagBBO.GetBidPrc()
		fields["lag_bid_qty"] = lagBBO.GetBidQty()
	}
}

func addDepthLevelFields(fields map[string]interface{}, prefix string, levels *[]*utils.Level) {
	for i := 0; i < 2; i++ {
		levelPrefix := fmt.Sprintf("%s_l%d", prefix, i+1)
		fields[levelPrefix+"_price"] = float64(0)
		fields[levelPrefix+"_qty"] = float64(0)
		if levels == nil || len(*levels) <= i || (*levels)[i] == nil {
			continue
		}
		fields[levelPrefix+"_price"] = (*levels)[i].Prc
		fields[levelPrefix+"_qty"] = (*levels)[i].Qty
	}
}

func (s *Strategy) addLagDepthFields(fields map[string]interface{}) {
	if s.lagContext.depth == nil {
		addDepthLevelFields(fields, "lag_depth_ask", nil)
		addDepthLevelFields(fields, "lag_depth_bid", nil)
		return
	}
	addDepthLevelFields(fields, "lag_depth_ask", s.lagContext.depth.Asks)
	addDepthLevelFields(fields, "lag_depth_bid", s.lagContext.depth.Bids)
}

func (s *Strategy) addGuardFields(fields map[string]interface{}, guard signalGuardSnapshot) {
	fields["parallel_used"] = guard.ParallelUsed
	fields["parallel_limit"] = guard.ParallelLimit
	fields["parallel_outcome"] = guard.ParallelOutcome
	fields["drift"] = guard.DriftValue
	fields["drift_ready"] = guard.DriftReady
	fields["lag_vol_guard_enabled"] = guard.LagVolGuardEnabled
	fields["lag_vol_jump_count"] = guard.LagVolJumpCount
	fields["lag_vol_amplitude"] = guard.LagVolAmplitude
	fields["lag_vol_hot"] = guard.LagVolHot
	fields["lag_vol_cooldown_until_ms"] = guard.LagVolCooldownUntilMS
	fields["lag_vol_outcome"] = guard.LagVolOutcome
	fields["drift_guard_enabled"] = guard.DriftGuardEnabled
	fields["drift_guard_ready"] = guard.DriftGuardReady
	fields["drift_instant_ratio"] = guard.DriftInstantRatio
	fields["drift_instant_threshold"] = guard.DriftInstantThreshold
	fields["drift_instant_hit"] = guard.DriftInstantHit
	fields["ratio_std"] = guard.RatioStdValue
	fields["ratio_std_threshold"] = guard.RatioStdThreshold
	fields["ratio_std_hit"] = guard.RatioStdHit
	fields["drift_mean"] = guard.DriftMeanValue
	fields["drift_mean_threshold"] = guard.DriftMeanThreshold
	fields["drift_mean_hit"] = guard.DriftMeanHit
	fields["drift_guard_outcome"] = guard.DriftGuardOutcome
	fields["freshness_lead_latency_ms"] = guard.LeadFreshnessLatencyMS
	fields["freshness_lead_latency_available"] = guard.LeadFreshnessLatencyOK
	fields["freshness_lead_threshold_ms"] = guard.LeadFreshnessThreshold
	fields["freshness_lead_enabled"] = guard.LeadFreshnessEnabled
	fields["freshness_lead_outcome"] = guard.LeadFreshnessOutcome
	fields["freshness_lag_latency_ms"] = guard.LagFreshnessLatencyMS
	fields["freshness_lag_latency_available"] = guard.LagFreshnessLatencyOK
	fields["freshness_lag_threshold_ms"] = guard.LagFreshnessThreshold
	fields["freshness_lag_enabled"] = guard.LagFreshnessEnabled
	fields["freshness_lag_outcome"] = guard.LagFreshnessOutcome
}

func (s *Strategy) RecordOpenSignalDecision(leadBBO *utils.BBO, signal openSignal, guard signalGuardSnapshot, decision string, blockReason string, cache *ExecuteCache, param *template.OrderParam) {
	if !s.fullSignalDecisionLogEnabled() {
		return
	}
	orderPrice := s.entryOrderPrice(signal.side, &s.lagContext.bbo)
	orderQty := signal.qty
	cid := ""
	groupID := ""
	if param != nil {
		orderPrice = param.Price
		orderQty = param.Qty
		cid = param.CID
	}
	if cache != nil {
		groupID = cache.groupTag
	}
	fields := map[string]interface{}{
		"decision":              decision,
		"block_reason":          blockReason,
		"signal_side":           signal.side,
		"position_side":         positionSideFromOpenOrderSide(signal.side),
		"lead_move":             signal.leadMove,
		"lag_move":              signal.lagMove,
		"ask_diff":              signal.askDiff,
		"bid_diff":              signal.bidDiff,
		"entry_threshold":       signal.threshold,
		"exit_threshold":        signal.exitThreshold,
		"target_space":          signal.targetSpace,
		"required_edge":         signal.requiredEdge,
		"fee":                   s.lagContext.fee * 2,
		"entry_buffer":          s.EffectiveEntryTakerBufferPct(),
		"close_buffer":          s.EffectiveNormalCloseTakerBufferPct(),
		"raw_bbo_price":         rawOrderSideBBOPrice(signal.side, &s.lagContext.bbo),
		"effective_order_price": orderPrice,
	}
	addBBOFields(fields, leadBBO, &s.lagContext.bbo)
	s.addLagDepthFields(fields)
	s.addGuardFields(fields, guard)
	linkage := AttributionStableLinkage{DecisionOutcome: decision, FeatureAvailabilityMask: "signal=1,threshold=1"}
	if cache != nil && cache.stableLinkage.EntryAttemptID != "" {
		linkage = cache.stableLinkage
		linkage.DecisionOutcome = decision
		linkage.FeatureAvailabilityMask = "signal=1,threshold=1"
	}
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventSignalDecision,
		Position:             "open",
		CID:                  cid,
		GroupID:              groupID,
		Side:                 signal.side,
		Qty:                  orderQty,
		Price:                orderPrice,
		SignalValue:          signal.signalValue,
		Threshold:            signal.threshold,
		Cost:                 signal.requiredEdge,
		Liquidity:            s.EstimateOrderLiquidity(&s.lagContext.bbo, param),
		DecisionReason:       decision,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         blockReason,
		StableLinkage:        linkage,
		ExtraFields:          fields,
	})
}

func (s *Strategy) executeOpenSignal(bbo *utils.BBO, signal openSignal, guard signalGuardSnapshot) (bool, error) {
	entry := s.NowEntry().WithField("Method", signal.method)
	entry.Infof("Move=<Lead=%f%%, Lag=%f%%, Predict=%f%%>", signal.leadMove*100, signal.lagMove*100, signal.targetSpace*100)
	param := template.OrderParam{
		Symbol:      s.lagContext.bbo.GetSymbol(),
		CID:         s.clientID.Next(),
		Side:        signal.side,
		Price:       s.entryOrderPrice(signal.side, &s.lagContext.bbo),
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	}
	param.Qty = s.CalOpenQty(s.lagContext.bbo.GetSymbol(), param.Price)
	cacheKey := param.CID
	cache := s.newExecuteCache()
	s.caches[cacheKey] = cache
	s.UpdateGroupTag(cache, entry, cacheKey)
	s.RecordEntryOpportunityAttribution(s.entryOpportunityAttributionInput(
		cache,
		param.Side,
		signal.signalValue,
		signal.threshold,
		param.Price,
		param.Qty,
		signal.targetSpace,
		signal.requiredEdge,
		signal.leadMove,
		signal.lagMove,
		&s.lagContext.bbo,
	))
	s.LogBBO(entry, "LeadBBO", bbo)
	s.LogBBO(entry, "LagBBO_", &s.lagContext.bbo)
	entry.Infof("Order Param %+v", &param)
	s.RecordTrigger(
		cache,
		s.Context.Now(),
		&s.leadContext.origin, &s.lagContext.bbo,
		TriggerParam{
			by:           "signal",
			Entry:        signal.threshold,
			Exit:         signal.exitThreshold,
			leadDiff:     signal.leadMove,
			lagDiff:      signal.lagMove,
			drift:        s.lagContext.drift.GetMean(),
			base:         signal.base,
			positionSide: "open",
			targetSpace:  signal.targetSpace,
		},
		&param,
	)
	order := s.Context.NewOrder(param)
	s.registerCacheOrder(cacheKey, cache, order)
	s.recordPendingOrderPrices(cache, rawOrderSideBBOPrice(param.Side, &s.lagContext.bbo), param.Price)
	err := s.Client.SendOrder(order)
	if err != nil {
		s.clearPendingCacheOrder(cache, param.CID)
		delete(s.caches, cacheKey)
		return false, err
	}
	s.RecordOpenSignalDecision(bbo, signal, guard, "sent", "", cache, &param)
	s.RecordOrderCreateAttribution(cache, &param, "open", signal.signalValue, signal.threshold, signal.requiredEdge, s.EstimateOrderLiquidity(&s.lagContext.bbo, &param))
	s.SetStage(cache, StageOpen, entry)
	return true, nil
}

func (s *Strategy) OpenLong(bbo *utils.BBO) (bool, error) {
	// input param bbo is lead bbo
	leadBase, _ := s.leadContext.recorder.Bid.GetMin()
	minAsk, _ := s.leadContext.recorder.Ask.GetMin()

	leadMove := bbo.BestBidPrc/leadBase.Price - 1
	askDiff := bbo.BestAskPrc/minAsk.Price - 1
	if leadMove > s.pr.MaxLeadMove {
		s.pr.MaxLeadMove = leadMove
	}
	if askDiff > s.pr.MaxAskDiff {
		s.pr.MaxAskDiff = askDiff
	}
	trigPrice := s.lagContext.bbo.GetAskPrc()
	prcDiff := bbo.BestBidPrc/trigPrice - 1
	if prcDiff <= 0 {
		s.pr.LongPriceDiffBlocked++
		s.RecordFilterAttribution(AttributionReasonNoTrigger, prcDiff, 0, 0, "long-price-diff")
		return false, nil
	}

	if (leadMove >= s.threshold.UpEntry) && (askDiff >= s.threshold.UpEntry) {
		s.pr.UpLeadCount++
		if !s.lagContext.bbo.ValidBBO {
			return false, nil
		}

		lagBase, _ := s.lagContext.recorder.Bid.GetMin()
		basePrice := math.Min(leadBase.Price, lagBase.Price)
		lagMove := s.lagContext.bbo.GetBidPrc()/basePrice - 1

		moveSpace := leadMove - lagMove

		if moveSpace/leadMove > s.config.Trigger.LagPart {
			s.pr.UpLadCount++
			targetPrice := bbo.BestBidPrc - bbo.BestBidPrc*s.threshold.UpExit - s.LagSpreadBuffer(&s.lagContext.bbo)
			targetSpace := targetPrice/trigPrice - 1
			entryCost := s.BuildEntryCostBreakdown(&s.lagContext.bbo, trigPrice)
			requiredEdge := entryCost.RequiredEdgeWithTargetProfit(s.config.Trigger.TargetProfitRate)
			if targetSpace < requiredEdge {
				s.RecordFilterAttribution(AttributionReasonFiltered, targetSpace, requiredEdge, requiredEdge, "entry-cost")
				return false, nil
			}
			if spreadPct(&s.lagContext.bbo) > s.config.Execute.EntrySpreadLimit() {
				s.RecordFilterAttribution(AttributionReasonFiltered, spreadPct(&s.lagContext.bbo), s.config.Execute.EntrySpreadLimit(), requiredEdge, "entry-spread")
				return false, nil
			}
			s.pr.UpSpaceCount++
			entry := s.NowEntry().WithField("Method", "OpenLong")
			entry.Infof("Move=<Lead=%f%%, Lag=%f%%, Predict=%f%%>", leadMove*100, lagMove*100, targetSpace*100)
			entry.Infof("EntryCost<%s, target_profit_rate=%.6f>", entryCost.String(), s.config.Trigger.TargetProfitRate)
			param := template.OrderParam{
				Symbol:      s.lagContext.bbo.GetSymbol(),
				CID:         s.clientID.Next(),
				Side:        utils.Side.Long,
				Price:       s.entryOrderPrice(utils.Side.Long, &s.lagContext.bbo),
				OrderType:   template.OrderTypeLimit,
				TimeInForce: template.IOC,
			}
			cacheKey := param.CID
			cache := s.newExecuteCache()
			s.caches[cacheKey] = cache
			s.UpdateGroupTag(cache, entry, cacheKey)
			param.Qty = s.CalOpenQty(s.lagContext.bbo.GetSymbol(), param.Price)
			s.RecordEntryOpportunityAttribution(s.entryOpportunityAttributionInput(
				cache,
				param.Side,
				leadMove,
				s.threshold.UpEntry,
				param.Price,
				param.Qty,
				targetSpace,
				requiredEdge,
				leadMove,
				lagMove,
				&s.lagContext.bbo,
			))
			s.LogBBO(entry, "LeadBBO", bbo)
			s.LogBBO(entry, "LagBBO_", &s.lagContext.bbo)
			entry.Infof("Order Param %+v", &param)
			s.RecordTrigger(
				cache,
				s.Context.Now(),
				&s.leadContext.origin, &s.lagContext.bbo,
				TriggerParam{
					by:           "signal",
					Entry:        s.threshold.UpEntry,
					Exit:         s.threshold.UpExit,
					leadDiff:     leadMove,
					lagDiff:      lagMove,
					drift:        s.lagContext.drift.GetMean(),
					base:         leadBase,
					positionSide: "open",
					targetSpace:  targetSpace,
				},
				&param,
			)
			order := s.Context.NewOrder(param)
			s.registerCacheOrder(cacheKey, cache, order)
			s.recordPendingOrderPrices(cache, rawOrderSideBBOPrice(param.Side, &s.lagContext.bbo), param.Price)
			err := s.Client.SendOrder(order)
			if err != nil {
				s.clearPendingCacheOrder(cache, param.CID)
				delete(s.caches, cacheKey)
				return false, err
			}
			s.RecordOrderCreateAttribution(cache, &param, "open", leadMove, s.threshold.UpEntry, requiredEdge, s.EstimateOrderLiquidity(&s.lagContext.bbo, &param))
			s.SetStage(cache, StageOpen, entry)
			return true, nil
		}
	}
	s.pr.LongThresholdBlocked++
	s.RecordFilterAttribution(AttributionReasonNoTrigger, leadMove, s.threshold.UpEntry, 0, "long-threshold")
	return false, nil
}

func (s *Strategy) OpenShort(bbo *utils.BBO) (bool, error) {
	leadBase, _ := s.leadContext.recorder.Ask.GetMax()
	leadMove := bbo.BestAskPrc/leadBase.Price - 1
	if leadMove < s.pr.MinLeadMove {
		s.pr.MinLeadMove = leadMove
	}
	trigPrice := s.lagContext.bbo.GetBidPrc()
	prcDiff := bbo.BestAskPrc/trigPrice - 1
	if prcDiff >= 0 {
		s.pr.ShortPriceDiffBlocked++
		s.RecordFilterAttribution(AttributionReasonNoTrigger, prcDiff, 0, 0, "short-price-diff")
		return false, nil
	}

	maxBid, _ := s.leadContext.recorder.Bid.GetMax()
	bidDiff := bbo.BestBidPrc/maxBid.Price - 1
	if bidDiff < s.pr.MinBidDiff {
		s.pr.MinBidDiff = bidDiff
	}
	if (leadMove <= s.threshold.DownEntry) && (bidDiff <= s.threshold.DownEntry) {
		s.pr.DownLeadCount++
		if !s.lagContext.bbo.ValidBBO {
			return false, nil
		}
		lagBase, _ := s.lagContext.recorder.Ask.GetMax()
		basePrice := math.Max(leadBase.Price, lagBase.Price)
		lagMove := s.lagContext.bbo.GetAskPrc()/basePrice - 1

		moveSpace := leadMove - lagMove

		if moveSpace/leadMove >= s.config.Trigger.LagPart {

			targetPrice := bbo.BestAskPrc - leadBase.Price*s.threshold.DownExit + s.LagSpreadBuffer(&s.lagContext.bbo)
			s.pr.DownLadCount++
			trigPrice := s.lagContext.bbo.GetBidPrc()
			targetSpace := targetPrice/trigPrice - 1
			entryCost := s.BuildEntryCostBreakdown(&s.lagContext.bbo, trigPrice)
			requiredEdge := entryCost.RequiredEdgeWithTargetProfit(s.config.Trigger.TargetProfitRate)
			if -targetSpace < requiredEdge {
				s.RecordFilterAttribution(AttributionReasonFiltered, -targetSpace, requiredEdge, requiredEdge, "entry-cost")
				return false, nil
			}
			if spreadPct(&s.lagContext.bbo) > s.config.Execute.EntrySpreadLimit() {
				s.RecordFilterAttribution(AttributionReasonFiltered, spreadPct(&s.lagContext.bbo), s.config.Execute.EntrySpreadLimit(), requiredEdge, "entry-spread")
				return false, nil
			}

			s.pr.DownSpaceCount++

			entry := s.NowEntry().WithField("Method", "OpenShort")

			entry.Infof("Diff=<Lead=%f%%, Lag=%f%%, LagBid=%f%%>", leadMove*100, lagMove*100, targetSpace*100)
			entry.Infof("Down<Lead=%f%%, Lag=%f%%, LagBid=%f%%>", leadMove*100, lagMove*100, targetSpace*100)
			entry.Infof("EntryCost<%s, target_profit_rate=%.6f>", entryCost.String(), s.config.Trigger.TargetProfitRate)
			param := template.OrderParam{
				Symbol:      s.lagContext.bbo.GetSymbol(),
				CID:         s.clientID.Next(),
				Side:        utils.Side.Short,
				Price:       s.entryOrderPrice(utils.Side.Short, &s.lagContext.bbo),
				OrderType:   template.OrderTypeLimit,
				TimeInForce: template.IOC,
			}
			cacheKey := param.CID
			cache := s.newExecuteCache()
			s.caches[cacheKey] = cache
			s.UpdateGroupTag(cache, entry, cacheKey)
			param.Qty = s.CalOpenQty(s.lagContext.bbo.GetSymbol(), param.Price)
			s.RecordEntryOpportunityAttribution(s.entryOpportunityAttributionInput(
				cache,
				param.Side,
				leadMove,
				s.threshold.DownEntry,
				param.Price,
				param.Qty,
				targetSpace,
				requiredEdge,
				leadMove,
				lagMove,
				&s.lagContext.bbo,
			))
			s.LogBBO(entry, "LeadBBO", bbo)
			s.LogBBO(entry, "LagBBO_", &s.lagContext.bbo)
			entry.Infof("Order Param %+v", &param)
			s.RecordTrigger(
				cache,
				s.Context.Now(),
				&s.leadContext.origin, &s.lagContext.bbo,
				TriggerParam{
					by:           "signal",
					Entry:        s.threshold.DownEntry,
					Exit:         s.threshold.DownExit,
					leadDiff:     leadMove,
					lagDiff:      lagMove,
					drift:        s.lagContext.drift.GetMean(),
					base:         leadBase,
					positionSide: "open",
					targetSpace:  targetSpace,
				},
				&param,
			)
			order := s.Context.NewOrder(param)
			s.registerCacheOrder(cacheKey, cache, order)
			s.recordPendingOrderPrices(cache, rawOrderSideBBOPrice(param.Side, &s.lagContext.bbo), param.Price)
			err := s.Client.SendOrder(order)
			if err != nil {
				s.clearPendingCacheOrder(cache, param.CID)
				delete(s.caches, cacheKey)
				return false, err
			}
			s.RecordOrderCreateAttribution(cache, &param, "open", leadMove, s.threshold.DownEntry, requiredEdge, s.EstimateOrderLiquidity(&s.lagContext.bbo, &param))
			s.SetStage(cache, StageOpen, entry)

			return true, nil
		}
	}
	s.pr.ShortThresholdBlocked++
	s.RecordFilterAttribution(AttributionReasonNoTrigger, leadMove, s.threshold.DownEntry, 0, "short-threshold")
	return false, nil
}

func (s *Strategy) RecordNormalCloseSignalDecision(leadBBO *utils.BBO, lagBBO *utils.BBO, cache *ExecuteCache, param *template.OrderParam, heldPositionSide string, signalValue float64, exitThreshold float64, closeBuffer float64) {
	if !s.fullSignalDecisionLogEnabled() || param == nil {
		return
	}
	groupID := ""
	linkage := AttributionStableLinkage{
		StableLinkageVersion:    StableLinkageVersion,
		StableLinkageStatus:     StableLinkageStatusUnavailableMissingEntryLinkage,
		DecisionOutcome:         "sent",
		FeatureAvailabilityMask: "signal=1,threshold=1",
	}
	if cache != nil {
		groupID = cache.groupTag
		if cache.currentCloseAttemptID != "" {
			linkage = cache.currentCloseAttemptStableLinkage()
			linkage.DecisionOutcome = "sent"
			linkage.FeatureAvailabilityMask = "signal=1,threshold=1"
		} else if cache.stableLinkage.EntryAttemptID != "" {
			linkage = cache.stableLinkage
			linkage.DecisionOutcome = "sent"
			linkage.FeatureAvailabilityMask = "signal=1,threshold=1"
		}
	}
	fields := map[string]interface{}{
		"decision":              "sent",
		"block_reason":          "",
		"signal_side":           param.Side,
		"position_side":         heldPositionSide,
		"lead_move":             float64(0),
		"lag_move":              signalValue,
		"ask_diff":              float64(0),
		"bid_diff":              float64(0),
		"entry_threshold":       float64(0),
		"exit_threshold":        exitThreshold,
		"target_space":          float64(0),
		"required_edge":         float64(0),
		"fee":                   s.lagContext.fee * 2,
		"entry_buffer":          s.EffectiveEntryTakerBufferPct(),
		"close_buffer":          closeBuffer,
		"raw_bbo_price":         rawOrderSideBBOPrice(param.Side, lagBBO),
		"effective_order_price": param.Price,
		"parallel_used":         len(s.caches),
		"parallel_limit":        s.config.Execute.Parallel,
		"parallel_outcome":      "not_applicable",
		"drift":                 s.lagContext.drift.GetMean(),
		"drift_ready":           s.lagContext.driftReady,
		"drift_guard_outcome":   "not_applicable",
		"lag_vol_outcome":       "not_applicable",
	}
	if leadThreshold, ok := s.EffectiveLeadFreshnessThresholdMS(); ok {
		latency, latencyOK := s.CurrentBBOFreshnessLatencyMS(s.config.Lead)
		fields["freshness_lead_latency_ms"] = latency
		fields["freshness_lead_latency_available"] = latencyOK
		fields["freshness_lead_threshold_ms"] = leadThreshold
		fields["freshness_lead_enabled"] = true
		if latencyOK && float64(latency) <= leadThreshold {
			fields["freshness_lead_outcome"] = "allowed"
		} else {
			fields["freshness_lead_outcome"] = "blocked"
		}
	} else {
		fields["freshness_lead_latency_ms"] = int64(0)
		fields["freshness_lead_latency_available"] = false
		fields["freshness_lead_threshold_ms"] = float64(0)
		fields["freshness_lead_enabled"] = false
		fields["freshness_lead_outcome"] = "disabled"
	}
	if lagThreshold, ok := s.EffectiveLagFreshnessThresholdMS(); ok {
		latency, latencyOK := s.CurrentBBOFreshnessLatencyMS(s.config.Lag)
		fields["freshness_lag_latency_ms"] = latency
		fields["freshness_lag_latency_available"] = latencyOK
		fields["freshness_lag_threshold_ms"] = lagThreshold
		fields["freshness_lag_enabled"] = true
		if latencyOK && float64(latency) <= lagThreshold {
			fields["freshness_lag_outcome"] = "allowed"
		} else {
			fields["freshness_lag_outcome"] = "blocked"
		}
	} else {
		fields["freshness_lag_latency_ms"] = int64(0)
		fields["freshness_lag_latency_available"] = false
		fields["freshness_lag_threshold_ms"] = float64(0)
		fields["freshness_lag_enabled"] = false
		fields["freshness_lag_outcome"] = "disabled"
	}
	addBBOFields(fields, leadBBO, lagBBO)
	s.addLagDepthFields(fields)
	s.RecordAttribution(AttributionInput{
		Event:                AttributionEventSignalDecision,
		Position:             "close",
		CID:                  param.CID,
		GroupID:              groupID,
		Side:                 param.Side,
		Qty:                  param.Qty,
		Price:                param.Price,
		SignalValue:          signalValue,
		Threshold:            exitThreshold,
		Cost:                 0,
		Liquidity:            s.EstimateOrderLiquidity(lagBBO, param),
		DecisionReason:       "sent",
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
		StableLinkage:        linkage,
		ExtraFields:          fields,
	})
}

func (s *Strategy) UpdateGroupTag(cache *ExecuteCache, entry *logrus.Entry, group string) {
	entry.Infof("Update Group: %s -> %s", cache.groupTag, group)
	cache.groupTag = group
}

func (s *Strategy) SetTrackTrailing(cache *ExecuteCache, price float64) {
	cache.trailing = price
}

func (s *Strategy) TrackLogTrailingLong(cache *ExecuteCache, bbo *utils.BBO) {
	if bbo.BestBidPrc > cache.trailing {
		cache.trailing = bbo.BestBidPrc
	}

}

func (s *Strategy) ExecuteStoplossLong(cacheKey string, cache *ExecuteCache, bbo *utils.BBO) (bool, error) {
	if cache.order != nil {
		return false, nil
	}

	fallback := bbo.BestBidPrc/cache.trailing - 1

	if fallback > -s.config.Execute.TrailingStop {
		return false, nil
	}

	entry := s.NowEntry().WithField("Method", "ExecuteStoplossLong")
	entry.Infof("TrailingStop<fallback=%f%%, highest=%f>", fallback, cache.trailing)
	s.LogBBO(entry, "LagSL", bbo)

	params := template.OrderParam{
		Symbol:      s.lagContext.bbo.GetSymbol(),
		CID:         s.clientID.Next(),
		Side:        utils.Side.Short,
		Qty:         cache.position.InexactFloat64(),
		Price:       bbo.GetBidPrc() * 0.995,
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	}
	entry.Infof("StoplossOrderParam<%+v>", params)
	s.RecordTrigger(
		cache,
		s.Context.Now(),
		&s.leadContext.origin, bbo,
		TriggerParam{
			by:           "sl",
			drift:        s.lagContext.drift.GetMean(),
			base:         PricePoint{Price: cache.trailing, Time: s.Context.Now().UnixMilli()},
			positionSide: "close",
		},
		&params,
	)
	order := s.Context.NewOrder(params)
	s.registerCacheOrder(cacheKey, cache, order)
	s.recordPendingOrderPrices(cache, rawOrderSideBBOPrice(params.Side, bbo), params.Price)
	cache.pendingCloseOrderKind = pendingCloseOrderStoploss
	err := s.Client.SendOrder(order)
	if err != nil {
		s.clearPendingCacheOrder(cache, params.CID)
		return false, err
	}
	s.RecordOrderCreateAttribution(cache, &params, "close", fallback, -s.config.Execute.TrailingStop, 0, s.EstimateOrderLiquidity(bbo, &params))
	s.SetStage(cache, StageClose, entry)
	return true, nil
}

func (s *Strategy) ExecuteStoplossShort(cacheKey string, cache *ExecuteCache, bbo *utils.BBO) (bool, error) {
	if cache.order != nil {
		return false, nil
	}

	fallback := -(bbo.BestAskPrc/cache.trailing - 1)

	if fallback > -s.config.Execute.TrailingStop {
		return false, nil
	}

	entry := s.NowEntry().WithField("Method", "ExecuteStoplossShort")
	entry.Infof("TrailingStop<fallback=%f%%, lowest=%f>", fallback, cache.trailing)
	s.LogBBO(entry, "LagSL", bbo)

	params := template.OrderParam{
		Symbol:      s.lagContext.bbo.GetSymbol(),
		CID:         s.clientID.Next(),
		Side:        utils.Side.Long,
		Qty:         cache.position.Abs().InexactFloat64(),
		Price:       bbo.BestAskPrc * 1.005,
		OrderType:   template.OrderTypeLimit,
		TimeInForce: template.IOC,
	}
	entry.Infof("StoplossOrderParam<%+v>", params)
	s.RecordTrigger(
		cache,
		s.Context.Now(),
		&s.leadContext.origin, bbo,
		TriggerParam{
			by:           "sl",
			drift:        s.lagContext.drift.GetMean(),
			base:         PricePoint{Price: cache.trailing, Time: s.Context.Now().UnixMilli()},
			positionSide: "close",
		},
		&params,
	)
	order := s.Context.NewOrder(params)
	s.registerCacheOrder(cacheKey, cache, order)
	s.recordPendingOrderPrices(cache, rawOrderSideBBOPrice(params.Side, bbo), params.Price)
	cache.pendingCloseOrderKind = pendingCloseOrderStoploss
	err := s.Client.SendOrder(order)
	if err != nil {
		s.clearPendingCacheOrder(cache, params.CID)
		return false, err
	}
	s.RecordOrderCreateAttribution(cache, &params, "close", fallback, -s.config.Execute.TrailingStop, 0, s.EstimateOrderLiquidity(bbo, &params))
	s.SetStage(cache, StageClose, entry)
	return true, nil
}

func (s *Strategy) TrackLogTrailingShort(cache *ExecuteCache, bbo *utils.BBO) {
	if bbo.BestAskPrc < cache.trailing {
		cache.trailing = bbo.BestAskPrc
	}

}

func (s *Strategy) CloseLong(cacheKey string, cache *ExecuteCache, leadBBO, lagBBO *utils.BBO) error {
	if cache.order != nil {
		return nil
	}

	lagDiff := leadBBO.BestBidPrc/lagBBO.BestBidPrc - 1
	if lagDiff < s.threshold.UpExit {
		// trigger close long
		entry := s.NowEntry().WithField("Method", "CloseLong")
		entry.Infof("Diff=<Lag=%f%%>", lagDiff*100)
		param := template.OrderParam{
			Symbol:      s.lagContext.bbo.GetSymbol(),
			CID:         s.clientID.Next(),
			Side:        utils.Side.Short,
			Qty:         cache.position.InexactFloat64(),
			Price:       s.normalCloseOrderPriceForCache(utils.Side.Short, lagBBO, cache),
			OrderType:   template.OrderTypeLimit,
			TimeInForce: template.IOC,
		}
		s.LogBBO(entry, "LeadBBO", leadBBO)
		s.LogBBO(entry, "LagBBO_", lagBBO)
		entry.Infof("CloseLong OrderParam<%+v>", &param)
		s.RecordTrigger(
			cache,
			s.Context.Now(),
			&s.leadContext.origin, lagBBO,
			TriggerParam{
				by:           "signal",
				lagDiff:      lagDiff,
				drift:        s.lagContext.drift.GetMean(),
				base:         PricePoint{Price: lagBBO.BestBidPrc, Time: s.Context.Now().UnixMilli()},
				positionSide: "close",
			},
			&param,
		)
		order := s.Context.NewOrder(param)
		s.registerCacheOrder(cacheKey, cache, order)
		s.recordPendingOrderPrices(cache, rawOrderSideBBOPrice(param.Side, lagBBO), param.Price)
		cache.pendingCloseOrderKind = pendingCloseOrderNormal
		err := s.Client.SendOrder(order)
		if err != nil {
			s.clearPendingCacheOrder(cache, param.CID)
			return err
		}
		s.RecordNormalCloseSignalDecision(leadBBO, lagBBO, cache, &param, positionSideFromCloseOrderSide(param.Side), lagDiff, s.threshold.UpExit, s.normalCloseOrderBufferForCache(cache))
		s.RecordOrderCreateAttribution(cache, &param, "close", lagDiff, s.threshold.UpExit, 0, s.EstimateOrderLiquidity(lagBBO, &param))
		s.SetStage(cache, StageClose, entry)

	}
	return nil
}

func (s *Strategy) CloseShort(cacheKey string, cache *ExecuteCache, leadBBO, lagBBO *utils.BBO) error {
	if cache.order != nil {
		return nil
	}

	lagDiff := leadBBO.BestAskPrc/lagBBO.BestAskPrc - 1
	if lagDiff > s.threshold.DownExit {
		// trigger close short
		entry := s.NowEntry().WithField("Method", "CloseShort")
		entry.Infof("Diff=<Lag=%f%%>", lagDiff*100)
		param := template.OrderParam{
			Symbol:      s.lagContext.bbo.GetSymbol(),
			CID:         s.clientID.Next(),
			Side:        utils.Side.Long,
			Qty:         cache.position.Abs().InexactFloat64(),
			Price:       s.normalCloseOrderPriceForCache(utils.Side.Long, lagBBO, cache),
			OrderType:   template.OrderTypeLimit,
			TimeInForce: template.IOC,
		}
		s.LogBBO(entry, "LeadBBO", leadBBO)
		s.LogBBO(entry, "LagBBO_", lagBBO)
		entry.Infof("CloseShort OrderParam<%+v>", &param)
		s.RecordTrigger(
			cache,
			s.Context.Now(),
			&s.leadContext.origin, lagBBO,
			TriggerParam{
				by:           "signal",
				lagDiff:      lagDiff,
				drift:        s.lagContext.drift.GetMean(),
				base:         PricePoint{Price: lagBBO.BestAskPrc, Time: s.Context.Now().UnixMilli()},
				positionSide: "close",
			},
			&param,
		)
		order := s.Context.NewOrder(param)
		s.registerCacheOrder(cacheKey, cache, order)
		s.recordPendingOrderPrices(cache, rawOrderSideBBOPrice(param.Side, lagBBO), param.Price)
		cache.pendingCloseOrderKind = pendingCloseOrderNormal
		err := s.Client.SendOrder(order)
		if err != nil {
			s.clearPendingCacheOrder(cache, param.CID)
			return err
		}
		s.RecordNormalCloseSignalDecision(leadBBO, lagBBO, cache, &param, positionSideFromCloseOrderSide(param.Side), lagDiff, s.threshold.DownExit, s.normalCloseOrderBufferForCache(cache))
		s.RecordOrderCreateAttribution(cache, &param, "close", lagDiff, s.threshold.DownExit, 0, s.EstimateOrderLiquidity(lagBBO, &param))
		s.SetStage(cache, StageClose, entry)
	}
	return nil
}

type TriggerParam struct {
	by           string
	drift        float64
	Entry        float64
	Exit         float64
	base         PricePoint
	positionSide string
	leadDiff     float64
	lagDiff      float64
	targetSpace  float64

	depthQty float64
}

func (s *Strategy) RecordTrigger(
	cache *ExecuteCache,
	ts time.Time, leadBBO *utils.BBO, lagBBO *utils.BBO,
	trigger TriggerParam,
	order *template.OrderParam,
) {
	attributionLiquidity := s.EstimateOrderLiquidity(lagBBO, order)
	rr := recorder.RawRecord{
		Tag: map[string]string{
			"type": "trigger",
			"by":   trigger.by,
			"lag":  lagBBO.GetSymbol().GetName(),
			"lead": leadBBO.GetSymbol().GetName(),
		},
		Extra: map[string]interface{}{
			"time": ts,
		},
		Field: map[string]interface{}{
			"group":      cache.groupTag,
			"entry":      trigger.Entry,
			"exit":       trigger.Exit,
			"drift":      trigger.drift,
			"lead_ask":   leadBBO.BestAskPrc,
			"lead_bid":   leadBBO.BestBidPrc,
			"lag_ask":    lagBBO.BestAskPrc,
			"lag_bid":    lagBBO.BestBidPrc,
			"position":   trigger.positionSide,
			"base_price": trigger.base.Price,
			"base_time":  time.UnixMilli(trigger.base.Time).Format("2006-01-02 15:04:05.999"),
			"cid":        order.CID,
			"side":       order.Side,
			"type":       order.OrderType,
			"price":      order.Price,
			"qty":        order.Qty,
		},
	}
	if s.lagContext.depth != nil {
		rr.Field["liq_ts"] = time.UnixMilli(s.lagContext.depth.ServerTS).Format("2006-01-02 15:04:05.999")
		if order.Side == utils.Side.Long {
			ask := s.lagContext.depth.GetBestAsk()
			if ask != nil && ask.Prc <= order.Price {
				rr.Field["liquidity"] = ask.Qty * ask.Prc
			} else {
				rr.Field["liquidity"] = 0
			}

		} else {
			bid := s.lagContext.depth.GetBestBid()
			if bid != nil && bid.Prc >= order.Price {
				rr.Field["liquidity"] = bid.Qty * bid.Prc
			} else {
				rr.Field["liquidity"] = 0
			}
		}
	} else {
		rr.Field["liq_ts"] = time.UnixMilli(lagBBO.ServerTime).Format("2006-01-02 15:04:05.999")
		if order.Side == utils.Side.Long {
			rr.Field["liquidity"] = lagBBO.BestAskPrc * lagBBO.BestAskQty
		} else {
			rr.Field["liquidity"] = lagBBO.BestBidPrc * lagBBO.BestBidQty
		}
	}
	switch trigger.by {
	case "signal":
		rr.Field["lead_diff"] = trigger.leadDiff
		rr.Field["lag_diff"] = trigger.lagDiff
		rr.Field["target_space"] = trigger.targetSpace
	}
	event := AttributionEventTrigger
	reason := AttributionReasonTrigger
	signalValue := trigger.leadDiff
	threshold := trigger.Entry
	if trigger.positionSide == "close" {
		event = AttributionEventCloseDecision
		reason = AttributionReasonCloseDecision
		signalValue = trigger.lagDiff
		threshold = trigger.Exit
	}
	input := AttributionInput{
		Event:                event,
		Position:             trigger.positionSide,
		CID:                  order.CID,
		GroupID:              cache.groupTag,
		Side:                 order.Side,
		Qty:                  order.Qty,
		Price:                order.Price,
		SignalValue:          signalValue,
		Threshold:            threshold,
		Cost:                 s.ProfitBuffer() + s.config.Trigger.TargetProfitRate,
		Liquidity:            attributionLiquidity,
		DecisionReason:       reason,
		OrderLifecycleReason: AttributionLifecycleNotApplicable,
		FilterName:           AttributionFilterNoFilter,
		FilterReason:         AttributionReasonNotApplicable,
	}
	if trigger.positionSide == "close" && trigger.by == "signal" {
		input.ExtraFields = map[string]interface{}{
			"close_buffer": s.normalCloseOrderBufferForCache(cache),
		}
	}
	if s.shouldRecordAttribution(input) {
		linkage := AttributionStableLinkage{}
		if trigger.positionSide == "close" {
			if cache.stableLinkage.EntryAttemptID != "" {
				linkage = cache.nextCloseAttemptStableLinkage()
			} else {
				linkage = AttributionStableLinkage{
					StableLinkageVersion: StableLinkageVersion,
					StableLinkageStatus:  StableLinkageStatusUnavailableMissingEntryLinkage,
					DecisionOutcome:      AttributionReasonCloseDecision,
				}
			}
		} else {
			linkage = s.ensureCacheEntryStableLinkage(cache, trigger.positionSide, order.Side, signalValue, threshold, AttributionDecisionOutcomeAllowed)
		}
		rr.Field["schema_version"] = AttributionSchemaVersion
		rr.Field["stable_linkage_version"] = StableLinkageVersion
		rr.Field["stable_linkage_status"] = linkage.StableLinkageStatus
		if linkage.EntrySignalID != "" {
			rr.Field["entry_signal_id"] = linkage.EntrySignalID
			rr.Field["entry_signal_hash"] = linkage.EntrySignalHash
			rr.Field["entry_opportunity_id"] = linkage.EntryOpportunityID
			rr.Field["entry_opportunity_key"] = linkage.EntryOpportunityKey
			rr.Field["entry_attempt_id"] = linkage.EntryAttemptID
			rr.Field["attempt_seq"] = linkage.AttemptSeq
			rr.Field["entry_decision_seq"] = linkage.EntryDecisionSeq
			rr.Field["order_group_stable_id"] = linkage.OrderGroupStableID
		}
		if linkage.DecisionID != "" {
			rr.Field["decision_id"] = linkage.DecisionID
		}
		if linkage.DecisionOutcome != "" {
			rr.Field["decision_outcome"] = linkage.DecisionOutcome
		}
		if linkage.CloseAttemptID != "" {
			rr.Field["close_attempt_id"] = linkage.CloseAttemptID
			rr.Field["close_seq"] = linkage.CloseSeq
		}
		linkage.FeatureAvailabilityMask = "signal=1,threshold=1"
		input.StableLinkage = linkage
	}
	s.recorder.Record(&rr)
	s.RecordAttribution(input)
}

func (s *Strategy) EstimateOrderLiquidity(lagBBO *utils.BBO, order *template.OrderParam) float64 {
	if lagBBO == nil || order == nil {
		return 0
	}
	if s.lagContext.depth != nil {
		if order.Side == utils.Side.Long {
			ask := s.lagContext.depth.GetBestAsk()
			if ask != nil && ask.Prc <= order.Price {
				return ask.Qty * ask.Prc
			}
			return 0
		}
		bid := s.lagContext.depth.GetBestBid()
		if bid != nil && bid.Prc >= order.Price {
			return bid.Qty * bid.Prc
		}
		return 0
	}
	if order.Side == utils.Side.Long {
		return lagBBO.BestAskPrc * lagBBO.BestAskQty
	}
	return lagBBO.BestBidPrc * lagBBO.BestBidQty
}

func (s *Strategy) SetStage(cache *ExecuteCache, stage ExecuteStage, entry *logrus.Entry) {
	if entry == nil {
		cache.stage = stage
	} else {
		prev := cache.stage
		cache.stage = stage
		entry.Infof("UpdateStage[%s -> %s]<position=%s>", prev, stage, cache.position)
	}
}

func (s *Strategy) LogBBO(entry *logrus.Entry, name string, bbo *utils.BBO) {
	spread := (bbo.BestAskPrc - bbo.BestBidPrc) / (bbo.BestAskPrc + bbo.BestBidPrc) * 2
	entry.Infof("%s<spread=%f%%, Ask=<%f: %f>, Bid=<%f: %f>>", name, spread*100, bbo.GetAskPrc(), bbo.GetAskQty(), bbo.GetBidPrc(), bbo.GetBidQty())
}

func (s *Strategy) NowEntry() *logrus.Entry {
	return s.log.WithTime(s.Context.Now())
}

func (s *Strategy) CalOpenQty(symbol *atom_symbol.Symbol, price float64) float64 {
	qty := s.config.Execute.OpenNotional.Div(decimal.NewFromFloat(price))
	// s.log.WithField("cv", symbol.GetContractValue()).Infof("symbol config")
	// return symbol.FormatQty(qty.InexactFloat64())
	return s.FormatQty(symbol, qty.InexactFloat64())
}

func (s *Strategy) FormatQty(symbol *atom_symbol.Symbol, rawQuantity float64) float64 {
	cv := symbol.GetContractValue()
	return math.Round(rawQuantity/symbol.RawSymbol.QuantityTick/symbol.GetContractValue()) * symbol.RawSymbol.QuantityTick * cv
}

func (s *Strategy) OnDepth(depth *utils.Depth) error {
	if s == nil || depth == nil || s.Context == nil {
		return nil
	}
	symbol := depth.GetSymbol()
	if symbol == nil {
		s.Context.ReturnDepthToPool(depth)
		return nil
	}
	if symbol.GetExchangeName() == s.config.Lag {
		s.recordLagDepthAutoTakerBufferWarmup(depth)
		s.Context.ReturnDepthToPool(s.lagContext.depth)
		s.lagContext.depth = depth
	} else {
		s.Context.ReturnDepthToPool(depth)
	}

	return nil
}

func (s *Strategy) OnTrade(trade *utils.Trade) error {
	s.Context.ReturnTradeToPool(trade)
	return nil
}

func (s *Strategy) OnAggTrade(trade *utils.Trade) error {
	s.Context.ReturnTradeToPool(trade)
	// s.log.Infof("OnAggTrade %+v", trade)
	return nil
}

func (s *Strategy) OnOrder(msg *utils.OrderMessage) error {
	defer s.Context.ReturnOrderMessageToPool(msg)
	entry := s.NowEntry().WithField("Method", "OnOrder")
	entry.Debugf("OnOrderMsg<%+v>", msg)

	cacheKey, ok := s.cacheOrderMap[msg.ClientID]
	if !ok {
		entry.Warningf("Order not found")
		return nil
	}
	cache := s.caches[cacheKey]
	if cache == nil || cache.order == nil {
		entry.Warningf("Order cache not found")
		return nil
	}
	if msg.OrderID == cache.order.GetOID() {
	} else if msg.ClientID == cache.order.GetCID() {
		cache.order.SetOID(msg.OrderID)
	} else {
		entry.Warningf("Order mismatch")
	}

	order := cache.order
	wasNormalClose := cache.stage == StageClose && cache.pendingCloseOrderKind == pendingCloseOrderNormal
	order.SetFilledQuantity(msg.FilledQty)
	order.SetStatus(msg.Status)
	entry.Infof("OrderInstance[%s]<%s>", msg.OrderID, order)
	s.RecordOrderLifecycleAttribution(cache, order, msg)
	if cache.order.Finished() {
		cache.grouping = append(cache.grouping, cache.order)
		s.recorder.Record(&recorder.RawRecord{
			Tag: map[string]string{
				"type":   "order",
				"symbol": order.GetSymbol().GetName(),
			},
			Field: map[string]interface{}{
				"group":     cache.groupTag,
				"server_ms": msg.ServerTime,
				"local_us":  msg.LocalTime,
				"oid":       msg.OrderID,
				"cid":       msg.ClientID,
				"side":      msg.Side,
				"staus":     msg.Status,
				"price":     msg.Price,
				"avg":       msg.AvgFillPrc,
				"qty":       msg.Qty,
				"filled":    msg.FilledQty,
			},
			Extra: map[string]interface{}{
				"time": s.Context.Now(),
			},
		})
		filled := s.GetOrderFilled(order)

		if order.GetSide() == utils.Side.Long {
			cache.position = cache.position.Add(filled)
		} else {
			cache.position = cache.position.Sub(filled)
		}

		if cache.position.Equal(decimal.Zero) {
			s.SetStage(cache, StageIdle, entry)
			delete(s.caches, cacheKey)
		} else {
			if wasNormalClose {
				cache.normalCloseFailures++
			}
			if cache.stage == StageOpen {
				if msg.AvgFillPrc > 0 {
					s.SetTrackTrailing(cache, msg.AvgFillPrc)
				}
			}
			s.SetStage(cache, StageHold, entry)
		}
		s.clearPendingCacheOrder(cache, msg.ClientID)
	}

	return nil
}

func (s *Strategy) InitGrouping(cache *ExecuteCache) {
	cache.grouping = make([]requests.Order, 0, 2)
}

func (s *Strategy) LogStage(cache *ExecuteCache, entry *logrus.Entry) {
	entry.Infof("Stage[%s]<Hold=%s>", cache.stage, cache.position)
}

func (s *Strategy) GetOrderFilled(order requests.Order) decimal.Decimal {
	symbol := order.GetSymbol()
	tick := decimal.NewFromFloat(symbol.GetQuantityTick() * symbol.GetContractValue())
	qty := decimal.NewFromFloat(order.GetFilledQuantity())
	return qty.Div(tick).Round(0).Mul(tick)
}
