package algo

import (
	"fmt"

	"git.hashingbot.com/aurthes/xex_mm_go/utils"
)

// EntryCostBreakdown captures the entry-side cost budget on the same percentage
// basis as the strategy's target space calculations.
type EntryCostBreakdown struct {
	Fee                    float64
	Spread                 float64
	LagSpreadBuffer        float64
	EntryTakerBuffer       float64
	NormalCloseTakerBuffer float64
	LeadNoise              float64
	LagNoise               float64
}

func (b EntryCostBreakdown) RequiredEdge() float64 {
	return b.Fee + b.EntryTakerBuffer + b.NormalCloseTakerBuffer + b.LeadNoise + b.LagNoise
}

func (b EntryCostBreakdown) EmbeddedPriceFriction() float64 {
	return b.Spread + b.LagSpreadBuffer
}

func (b EntryCostBreakdown) RequiredEdgeWithTargetProfit(targetProfitRate float64) float64 {
	return b.RequiredEdge() + targetProfitRate
}

func (b EntryCostBreakdown) String() string {
	return fmt.Sprintf(
		"fee=%.6f spread=%.6f lag_spread_buffer=%.6f entry_taker_buffer=%.6f normal_close_taker_buffer=%.6f lead_noise=%.6f lag_noise=%.6f embedded=%.6f required=%.6f",
		b.Fee,
		b.Spread,
		b.LagSpreadBuffer,
		b.EntryTakerBuffer,
		b.NormalCloseTakerBuffer,
		b.LeadNoise,
		b.LagNoise,
		b.EmbeddedPriceFriction(),
		b.RequiredEdge(),
	)
}

func (s *Strategy) BuildEntryCostBreakdown(lagBBO *utils.BBO, triggerPrice float64) EntryCostBreakdown {
	lagSpreadBuffer := 0.0
	if triggerPrice > 0 {
		lagSpreadBuffer = s.LagSpreadBuffer(lagBBO) / triggerPrice
	}
	return EntryCostBreakdown{
		Fee:                    s.lagContext.fee * 2,
		Spread:                 spreadPct(lagBBO),
		LagSpreadBuffer:        lagSpreadBuffer,
		EntryTakerBuffer:       s.entryTakerBufferCostModelPct(),
		NormalCloseTakerBuffer: s.normalCloseTakerBufferCostModelPct(),
		LeadNoise:              s.threshold.LeadNoise,
		LagNoise:               s.threshold.LagNoise,
	}
}

func (s *Strategy) entryTakerBufferCostModelPct() float64 {
	if s.config.Cost.TakerBuffer.ExcludeFromCostModel {
		return 0
	}
	return s.EffectiveEntryTakerBufferPct()
}

func (s *Strategy) normalCloseTakerBufferCostModelPct() float64 {
	if s.config.Cost.TakerBuffer.ExcludeFromCostModel {
		return 0
	}
	return s.EffectiveNormalCloseTakerBufferPct()
}
