# LeadLag Current Strategy Package

这个目录打包当前 LeadLag 策略后续复用需要的配置、生产 Go 源码和差异说明文档。

## 来源

- 当前策略 branch: `codex/fixed-leadlag-optimization-strategy`
- package commit: `e69bd9e`
- 策略代码实际提交到: `86b1540`
- 文档提交: `4413d4f`
- 原版对比路径: `/Users/yukio/Desktop/Cursor Projects/reserch/backtest-go/.wt-invariant-strategy-leadlag-must-fix`
- 原版对比 commit: `541bce2`

## 目录说明

- `configs/`: Phase 13 Wide 48x14d 使用的 strategy/backtest template；其中 `backtest.depth_on_bbo.json` 是 Depth+BBO 开启的 backtest 配置。
- `go/`: 当前 LeadLag 策略生产源码副本，不包含 `*_test.go`。
- `docs/`: 当前版本相对原版的差异说明。
